@echo off
setlocal
where powershell.exe >nul 2>nul
if errorlevel 1 goto USE_PWSH
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Local-Bridge.ps1" -Apply
set "MITOM_RESULT=%ERRORLEVEL%"
goto DONE
:USE_PWSH
where pwsh.exe >nul 2>nul
if errorlevel 1 goto NO_POWERSHELL
pwsh.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Local-Bridge.ps1" -Apply
set "MITOM_RESULT=%ERRORLEVEL%"
goto DONE
:NO_POWERSHELL
echo Windows PowerShell 5.1 or PowerShell 7 is required.
set "MITOM_RESULT=1"
:DONE
if "%MITOM_RESULT%"=="0" echo Installed. Reload the MITOM Photoshop panel to see MITOM Web.
if not "%MITOM_RESULT%"=="0" echo Installation stopped. No application was closed. Read the error above.
pause
exit /b %MITOM_RESULT%
