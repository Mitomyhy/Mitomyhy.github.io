/* Additive CEP bootstrap. No changes to existing panel tabs/workflows. */
(function (root) {
  'use strict';
  function start() {
    if (!root.document || !root.__adobe_cep__ || root.__mitomWebTools) return;
    var fs, path, os, bridge, pending = false, disposed = false, token = '';
    try { fs = require('fs'); path = require('path'); os = require('os'); } catch (_) { return; }
    var doc = root.document, panelRoot = path.dirname(decodeURIComponent(root.location.pathname).replace(/^\/([A-Za-z]:)/, '$1'));
    var toolbar = doc.createElement('div'); toolbar.id = 'mitomWebTools'; toolbar.style.cssText = 'margin:5px 7px;padding:5px;border:1px solid #455060;border-radius:4px;font-size:11px;';
    var toggle = doc.createElement('button'); toggle.type = 'button'; toggle.textContent = 'MITOM Web · kết nối Photoshop'; toggle.style.cssText = 'width:100%;padding:5px;cursor:pointer;';
    var details = doc.createElement('div'); details.hidden = true; details.style.paddingTop = '5px';
    var note = doc.createElement('div'); note.textContent = 'Chỉ MITOM web trên máy này. Sao chép mã và dán vào Connect Photoshop trên web. Mã chỉ tồn tại trong phiên panel này.';
    var input = doc.createElement('input'); input.type = 'text'; input.readOnly = true; input.autocomplete = 'off'; input.setAttribute('aria-label', 'Mã kết nối MITOM Web'); input.style.cssText = 'box-sizing:border-box;width:100%;margin-top:4px;font-family:monospace;font-size:10px;';
    var copy = doc.createElement('button'); copy.type = 'button'; copy.textContent = 'Copy mã kết nối'; copy.disabled = true; copy.style.cssText = 'margin-top:4px;padding:4px 8px;';
    var status = doc.createElement('div'); status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite'); status.style.cssText = 'margin-top:4px;white-space:normal;overflow-wrap:anywhere;';
    function say(message) { if (!disposed) status.textContent = message; }
    function fold(p) { return path.resolve(p).toLowerCase(); }
    function makeTemp(bytes) {
      var tempRoot = fs.realpathSync(os.tmpdir()), dir = fs.mkdtempSync(path.join(tempRoot, 'mitom-webtools-'));
      if (!/^mitom-webtools-[a-z0-9]{6}$/i.test(path.basename(dir)) || fold(path.dirname(dir)) !== fold(tempRoot)) throw new Error('MITOM_TEMP');
      var file = path.join(dir, 'transfer.png'), marker = path.join(dir, '.owner.json');
      fs.writeFileSync(marker, JSON.stringify({ scope: 'mitom-webtools-v1', createdAt: Date.now(), pid: process.pid }), { flag: 'wx', mode: 384 });
      fs.writeFileSync(file, bytes, { flag: 'wx', mode: 384 });
      return { dir: dir, file: file, marker: marker, root: tempRoot };
    }
    function cleanup(temp) {
      // Remove exactly our own two files, only after native callback completed.
      if (!temp || !fs.existsSync(temp.dir)) return;
      var stat = fs.lstatSync(temp.dir);
      if (!stat.isDirectory() || stat.isSymbolicLink() || fold(fs.realpathSync(temp.dir)) !== fold(temp.dir) || fold(path.dirname(temp.dir)) !== fold(temp.root)) return;
      var names = fs.readdirSync(temp.dir);
      if (names.some(function (n) { return n !== 'transfer.png' && n !== '.owner.json'; })) return;
      [temp.file, temp.marker].forEach(function (p) { if (fs.existsSync(p)) { var s = fs.lstatSync(p); if (!s.isFile() || s.isSymbolicLink()) throw new Error('MITOM_TEMP'); fs.unlinkSync(p); } });
      fs.rmdirSync(temp.dir);
    }
    function importImage(item) {
      if (pending || disposed) return Promise.reject(new Error('Panel đang nhận ảnh hoặc đã đóng.'));
      pending = true; say('Đang thêm ' + item.label + ' vào Photoshop…');
      var temp;
      try { temp = makeTemp(item.bytes); } catch (e) { pending = false; return Promise.reject(new Error('Không tạo được vùng tạm riêng để thêm ảnh.')); }
      return new Promise(function (resolve, reject) {
        var escaped = function (s) { return JSON.stringify(String(s)).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029'); };
        var script = '$.evalFile(new File(' + escaped(path.join(panelRoot, 'jsx', 'web-tools-import.jsx')) + '));mitomWebImport(' + escaped(temp.file) + ',' + escaped(item.label) + ')';
        var warning = setTimeout(function () { say('Photoshop chưa phản hồi. Giữ nguyên lượt này, kiểm tra hộp thoại Photoshop; không gửi ảnh lại.'); }, 120000);
        try {
          root.__adobe_cep__.evalScript(script, function (reply) {
            clearTimeout(warning); pending = false;
            try { cleanup(temp); } catch (_) { /* Keep unknown material, never recursive cleanup. */ }
            if (reply === 'OK:LAYER' || reply === 'OK:DOCUMENT') { say('Đã nhận ' + item.label + ' từ MITOM web.'); resolve({ mode: reply === 'OK:LAYER' ? 'layer' : 'document' }); }
            else { say('Photoshop chưa nhận ảnh. File gốc giữ nguyên.'); reject(new Error(String(reply || 'Photoshop không trả kết quả.').slice(0, 240))); }
          });
        } catch (e) { clearTimeout(warning); pending = false; try { cleanup(temp); } catch (_) {} reject(new Error('Không gọi được Photoshop; chưa nhận ảnh.')); }
      });
    }
    function connect() {
      details.hidden = !details.hidden;
      if (bridge) return;
      try { bridge = require(path.join(panelRoot, 'js', 'web-tools-bridge.js')).create({ onImport: importImage }); }
      catch (_) { say('MITOM Web chưa có đủ file cầu nối; cần cập nhật panel.'); return; }
      bridge.start().then(function (info) { if (disposed) return; token = info.token; input.value = token; copy.disabled = false; say('Sẵn sàng nhận ảnh từ https://mitomyhy.github.io.'); }).catch(function (e) { bridge = null; say(String(e.message || e)); });
    }
    copy.addEventListener('click', function () { if (!token) return; input.focus(); input.select(); try { if (!doc.execCommand('copy')) throw new Error(); say('Đã copy mã. Dán trong Connect Photoshop trên web; không chia sẻ mã.'); } catch (_) { say('Đã chọn mã. Bấm Ctrl+C để sao chép.'); } });
    toggle.addEventListener('click', connect); details.appendChild(note); details.appendChild(input); details.appendChild(copy); details.appendChild(status); toolbar.appendChild(toggle); toolbar.appendChild(details);
    var tabs = doc.querySelector('.tabs');
    if (tabs && tabs.parentNode) tabs.parentNode.insertBefore(toolbar, tabs.nextSibling);
    else doc.body.appendChild(toolbar);
    function dispose() { if (disposed) return; disposed = true; token = ''; input.value = ''; if (bridge) bridge.dispose(); }
    root.addEventListener('unload', dispose); root.__mitomWebTools = { dispose: dispose };
  }
  if (root && root.document) { if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', start); else start(); }
}(typeof window !== 'undefined' ? window : this));
