/* Dedicated MITOM PNG receiver. No filesystem path, URL, JSX or host command
 * crosses this API. Only the trusted panel callback may import decoded images.
 */
'use strict';
var PORT = 8791, ORIGIN = 'https://mitomyhy.github.io', MAX_BYTES = 60 * 1024 * 1024, MAX_PIXELS = 40000000;
var SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), CRC_TABLE = [];
for (var ci = 0; ci < 256; ci++) { var cv = ci; for (var cb = 0; cb < 8; cb++) cv = cv & 1 ? 0xedb88320 ^ cv >>> 1 : cv >>> 1; CRC_TABLE[ci] = cv >>> 0; }
function crc32(bytes) { var c = 0xffffffff; for (var i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 255] ^ c >>> 8; return (c ^ 0xffffffff) >>> 0; }
function error(code, message) { var e = new Error(message || code); e.code = code; return e; }
function wipe(bytes) { if (Buffer.isBuffer(bytes)) bytes.fill(0); }
function validatePng(bytes, zlib) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 57 || bytes.length > MAX_BYTES || !bytes.slice(0, 8).equals(SIGNATURE)) throw error('PNG_INVALID', 'Kết quả không phải PNG hoàn chỉnh.');
  var at = 8, width = 0, height = 0, channels = 0, idats = [], ended = false, seenIdat = false, afterIdat = false, count = 0, inflated;
  while (at < bytes.length) {
    if (++count > 2048 || at + 12 > bytes.length) throw error('PNG_INVALID');
    var size = bytes.readUInt32BE(at), type = bytes.toString('ascii', at + 4, at + 8), next = at + 12 + size;
    if (size > MAX_BYTES || next > bytes.length || !/^[A-Za-z]{4}$/.test(type) || crc32(bytes.slice(at + 4, at + 8 + size)) !== bytes.readUInt32BE(at + 8 + size)) throw error('PNG_INVALID');
    if (count === 1) {
      if (type !== 'IHDR' || size !== 13) throw error('PNG_INVALID');
      width = bytes.readUInt32BE(at + 8); height = bytes.readUInt32BE(at + 12);
      var depth = bytes[at + 16], color = bytes[at + 17];
      if (!width || !height || width > 32768 || height > 32768 || width * height > MAX_PIXELS) throw error('IMAGE_SIZE', 'Kết quả vượt 40 megapixel.');
      // Browser canvas exports 8-bit RGB/RGBA, noninterlaced PNG. Do not accept
      // arbitrary PNG features/critical chunks in this narrow transfer API.
      if (depth !== 8 || [2, 6].indexOf(color) < 0 || bytes[at + 18] !== 0 || bytes[at + 19] !== 0 || bytes[at + 20] !== 0) throw error('PNG_FORMAT', 'Xuất kết quả PNG từ canvas MITOM trước khi thêm Photoshop.');
      channels = color === 6 ? 4 : 3;
    } else if (type === 'IHDR') throw error('PNG_INVALID');
    else if (type === 'IDAT') { if (afterIdat) throw error('PNG_INVALID'); seenIdat = true; idats.push(bytes.slice(at + 8, at + 8 + size)); }
    else if (type === 'IEND') { if (size || !seenIdat || next !== bytes.length) throw error('PNG_INVALID'); ended = true; at = next; break; }
    else {
      if (seenIdat) afterIdat = true;
      if (type.charCodeAt(0) < 97) throw error('PNG_FORMAT');
      if (type === 'acTL' || type === 'fcTL' || type === 'fdAT') throw error('PNG_ANIMATED');
    }
    at = next;
  }
  if (!ended || at !== bytes.length) throw error('PNG_INVALID');
  var expected = (width * channels + 1) * height, packed = Buffer.concat(idats);
  try {
    inflated = zlib.inflateSync(packed, { maxOutputLength: expected });
    if (inflated.length !== expected) throw error('PNG_INVALID');
    for (var row = 0; row < height; row++) if (inflated[row * (width * channels + 1)] > 4) throw error('PNG_INVALID');
  } catch (e) { throw error('PNG_INVALID', 'Dữ liệu PNG thiếu hoặc không hợp lệ.'); }
  finally { wipe(inflated); wipe(packed); }
  return { width: width, height: height };
}
function create(options) {
  options = options || {};
  var http = options.http || require('http'), crypto = options.crypto || require('crypto'), zlib = options.zlib || require('zlib');
  var token = crypto.randomBytes(32).toString('hex'), server = null, starting = null, active = null, receipts = [], sockets = new Set(), closed = false;
  var now = options.now || Date.now, onImport = options.onImport;
  if (typeof onImport !== 'function') throw error('IMPORT_REQUIRED');
  function send(res, code, value) {
    if (res.destroyed || res.writableEnded) return;
    var body = value == null ? '' : JSON.stringify(value);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(body);
  }
  function fail(res, code, kind, message) { send(res, code, { error: kind, message: message || kind }); }
  function handle(req, res) {
    if (String(req.headers.host || '') !== '127.0.0.1:' + PORT) { fail(res, 403, 'HOST_DENIED'); req.resume(); return; }
    if (req.headers.origin !== ORIGIN) { fail(res, 403, 'ORIGIN_DENIED'); req.resume(); return; }
    res.setHeader('Access-Control-Allow-Origin', ORIGIN); res.setHeader('Vary', 'Origin');
    if (req.method === 'OPTIONS') {
      var method = String(req.headers['access-control-request-method'] || ''), headers = String(req.headers['access-control-request-headers'] || '').toLowerCase().split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      if (['GET', 'POST'].indexOf(method) < 0 || headers.some(function (s) { return ['authorization', 'content-type', 'x-mitom-request-id', 'x-mitom-tool'].indexOf(s) < 0; })) { fail(res, 403, 'PREFLIGHT_DENIED'); return; }
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Mitom-Request-Id, X-Mitom-Tool'); res.setHeader('Access-Control-Allow-Private-Network', 'true'); res.setHeader('Access-Control-Max-Age', '300'); send(res, 204); return;
    }
    var auth = /^Bearer ([a-f0-9]{64})$/.exec(String(req.headers.authorization || ''));
    if (!auth || !token || !crypto.timingSafeEqual(Buffer.from(auth[1]), Buffer.from(token))) { fail(res, 401, 'AUTH', 'Mã kết nối hết hạn hoặc không đúng. Lấy mã mới trong panel.'); req.resume(); return; }
    if (req.method === 'GET' && req.url === '/v1/health') { send(res, 200, { ok: true, service: 'mitom-web-image', version: 1, busy: !!active }); return; }
    if (req.url !== '/v1/import' || req.method !== 'POST') { fail(res, 404, 'ROUTE'); req.resume(); return; }
    var id = String(req.headers['x-mitom-request-id'] || ''), label;
    try { label = decodeURIComponent(String(req.headers['x-mitom-tool'] || 'MITOM Tools')); } catch (_) { fail(res, 400, 'LABEL'); req.resume(); return; }
    if (!/^[a-f0-9]{32}$/.test(id) || label.length < 1 || label.length > 80 || /[\x00-\x1f\x7f]/.test(label)) { fail(res, 400, 'REQUEST'); req.resume(); return; }
    if (req.headers['content-type'] !== 'image/png') { fail(res, 415, 'PNG_REQUIRED'); req.resume(); return; }
    var length = String(req.headers['content-length'] || '');
    if (req.headers['transfer-encoding'] || !/^\d+$/.test(length) || !Number.isSafeInteger(Number(length)) || Number(length) < 1 || Number(length) > MAX_BYTES) { fail(res, 413, 'BODY_SIZE'); req.resume(); return; }
    if (active) { fail(res, 409, 'BUSY', 'Photoshop đang nhận một ảnh. Chờ xác nhận trước khi gửi tiếp.'); req.resume(); return; }
    var job = { id: id, bytes: null, chunks: [], size: 0, reading: true, settled: false, cancelled: false }; active = job;
    function finish() { job.chunks.forEach(wipe); job.chunks.length = 0; wipe(job.bytes); job.bytes = null; job.settled = true; if (active === job) active = null; }
    function abort() { if (!job.reading || job.settled) return; job.cancelled = true; finish(); }
    req.once('aborted', abort); req.once('error', abort);
    req.on('data', function (chunk) {
      if (job.settled) return;
      job.size += chunk.length;
      if (job.size > Number(length) || job.size > MAX_BYTES) { fail(res, 413, 'BODY_SIZE'); job.cancelled = true; finish(); req.resume(); return; }
      job.chunks.push(Buffer.from(chunk));
    });
    req.on('end', function () {
      if (job.settled) return;
      job.reading = false;
      if (job.size !== Number(length)) { fail(res, 400, 'BODY_TRUNCATED'); finish(); return; }
      job.bytes = Buffer.concat(job.chunks, job.size); job.chunks.forEach(wipe); job.chunks.length = 0;
      var dimensions, sha = crypto.createHash('sha256').update(job.bytes).digest('hex');
      try { dimensions = validatePng(job.bytes, zlib); } catch (e) { fail(res, 422, e.code || 'PNG_INVALID', e.message); finish(); return; }
      receipts = receipts.filter(function (r) { return now() - r.at < 300000; });
      var prior = receipts.filter(function (r) { return r.id === id; })[0];
      if (prior) { if (prior.sha !== sha || prior.label !== label) fail(res, 409, 'REQUEST_REUSE'); else send(res, 200, prior.result); finish(); return; }
      Promise.resolve().then(function () { if (closed || job.cancelled) throw error('CLOSED'); return onImport({ bytes: job.bytes, label: label, requestId: id, width: dimensions.width, height: dimensions.height }); }).then(function (result) {
        if (!result || ['layer', 'document'].indexOf(result.mode) < 0) throw error('NATIVE_RECEIPT', 'Photoshop chưa xác nhận ảnh; kiểm tra Photoshop trước khi gửi lại.');
        var value = { ok: true, mode: result.mode, requestId: id };
        receipts.push({ id: id, sha: sha, label: label, result: value, at: now() }); if (receipts.length > 32) receipts.shift(); finish(); send(res, 200, value);
      }).catch(function (e) { finish(); fail(res, 500, 'IMPORT_FAILED', String(e && e.message || 'Photoshop chưa nhận ảnh.').slice(0, 240)); });
    });
  }
  return {
    start: function () {
      if (closed) return Promise.reject(error('CLOSED'));
      if (starting) return starting;
      var version = String(options.nodeVersion || process.versions.node).split('.').map(Number);
      if (!(version[0] > 14 || version[0] === 14 && version[1] >= 5 || version[0] === 12 && version[1] >= 19)) return Promise.reject(error('RUNTIME', 'Cần Photoshop có Node 12.19+/14.5+ để nhận PNG an toàn.'));
      starting = new Promise(function (resolve, reject) {
        server = http.createServer(function (req, res) { try { handle(req, res); } catch (_) { fail(res, 500, 'RECEIVER_ERROR'); req.resume(); } });
        server.requestTimeout = 30000; server.headersTimeout = 10000; server.keepAliveTimeout = 1000; server.maxHeadersCount = 40;
        server.on('connection', function (socket) { sockets.add(socket); socket.on('close', function () { sockets.delete(socket); }); });
        server.once('error', function () { starting = null; reject(error('PORT_UNAVAILABLE', 'Cổng MITOM Web đang được panel khác dùng; không dừng ứng dụng nào.')); });
        server.listen(PORT, '127.0.0.1', function () { resolve({ port: PORT, token: token }); });
      }); return starting;
    },
    dispose: function () { closed = true; token = ''; receipts.length = 0; if (active && active.reading) { active.cancelled = true; active.chunks.forEach(wipe); active.chunks.length = 0; active.settled = true; active = null; } sockets.forEach(function (s) { s.destroy(); }); if (server) server.close(); },
    status: function () { return { listening: !!(server && server.listening), busy: !!active }; }
  };
}
module.exports = { create: create, validatePng: validatePng, port: PORT, origin: ORIGIN, maxBytes: MAX_BYTES };
