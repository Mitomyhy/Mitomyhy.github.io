/* Narrow PNG import. Trusted panel supplies its owned temp path and plain label.
 * No save, action, expression, linked placement, or source-document close.
 */
function mitomWebImport(resultPath, label) {
    var original = null, originalId = null, oldLayer = null, created = null, opened = null, detached = null, success = false;
    var dialogs = app.displayDialogs;
    function stillOpen(doc, id) {
        for (var i = 0; i < app.documents.length; i++) try { if (app.documents[i] === doc || app.documents[i].id === id) return true; } catch (_) {}
        return false;
    }
    try {
        var file = new File(resultPath), parent = file.parent;
        if (file.name !== 'transfer.png' || !/^mitom-webtools-[a-z0-9]{6}$/i.test(parent.name) || !parent.exists || parent.alias ||
            parent.parent.fsName.toLowerCase() !== Folder.temp.fsName.toLowerCase() || file.alias || !file.exists) throw new Error('MITOM_TEMP_PATH');
        label = String(label || 'MITOM Tools');
        if (!label.length || label.length > 80 || /[\x00-\x1f\x7f]/.test(label)) throw new Error('MITOM_LABEL');
        if (app.documents.length) { original = app.activeDocument; originalId = original.id; oldLayer = original.activeLayer; }
        app.displayDialogs = DialogModes.NO;
        opened = app.open(file);
        if (original) {
            if (!stillOpen(original, originalId)) throw new Error('Tai lieu dich da dong; khong chuyen sang tai lieu khac.');
            var layer = opened.activeLayer;
            if (!layer || layer.typename !== 'ArtLayer' || layer.kind !== LayerKind.NORMAL) throw new Error('MITOM_PIXEL_LAYER');
            created = layer.duplicate(original, ElementPlacement.PLACEATBEGINNING);
            app.activeDocument = original; original.activeLayer = created; created.name = 'MITOM - ' + label;
            if (created.kind !== LayerKind.NORMAL || created.parent.typename !== 'Document' || created.parent.id !== originalId) throw new Error('MITOM_TARGET_LAYER');
            var b = created.bounds, left = b[0].as('px'), top = b[1].as('px'), width = b[2].as('px') - left, height = b[3].as('px') - top;
            var dw = original.width.as('px'), dh = original.height.as('px');
            if (!isFinite(left) || !isFinite(top) || !isFinite(width) || !isFinite(height) || width <= 0 || height <= 0 || !isFinite(dw) || !isFinite(dh) || dw <= 0 || dh <= 0) throw new Error('MITOM_BOUNDS');
            created.translate(new UnitValue(Math.round((dw - width) / 2 - left), 'px'), new UnitValue(Math.round((dh - height) / 2 - top), 'px'));
            opened.close(SaveOptions.DONOTSAVECHANGES); opened = null;
            app.activeDocument = original; original.activeLayer = created; success = true; return 'OK:LAYER';
        }
        detached = opened.duplicate('MITOM - ' + label, true);
        opened.close(SaveOptions.DONOTSAVECHANGES); opened = null;
        app.activeDocument = detached; success = true; return 'OK:DOCUMENT';
    } catch (e) { return 'ERR:' + e.toString(); }
    finally {
        try { if (!success && created && stillOpen(original, originalId)) { app.activeDocument = original; created.remove(); } } catch (_) {}
        try { if (opened) opened.close(SaveOptions.DONOTSAVECHANGES); } catch (_) {}
        try { if (!success && detached) detached.close(SaveOptions.DONOTSAVECHANGES); } catch (_) {}
        try { if (!success && original && stillOpen(original, originalId)) { app.activeDocument = original; if (oldLayer) original.activeLayer = oldLayer; } } catch (_) {}
        app.displayDialogs = dialogs;
    }
}
