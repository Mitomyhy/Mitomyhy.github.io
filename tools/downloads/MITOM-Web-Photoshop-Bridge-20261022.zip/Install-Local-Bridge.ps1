[CmdletBinding()]
param(
    [string]$PanelPath = (Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.uoy.orderpanel'),
    [switch]$Apply
)
$ErrorActionPreference = 'Stop'
$sourceRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$panelRoot = [IO.Path]::GetFullPath($PanelPath).TrimEnd('\')
function Sha([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function SafeFile([string]$FilePath, [string]$Root) {
    $full = [IO.Path]::GetFullPath($FilePath)
    $prefix = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    if (-not $full.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path is outside exact target root.' }
    $walk = $full
    while ($walk -and $walk.Length -ge $prefix.TrimEnd('\').Length) {
        if (Test-Path -LiteralPath $walk) {
            $item = Get-Item -LiteralPath $walk -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Alias/reparse-point path refused.' }
        }
        $parent = [IO.Path]::GetDirectoryName($walk)
        if ($parent -eq $walk) { break }
        $walk = $parent
    }
    return $full
}
if (-not (Test-Path -LiteralPath $panelRoot -PathType Container)) { throw 'Existing panel folder is required; no application will be installed elsewhere.' }
$manifest = Get-Content -LiteralPath (Join-Path $sourceRoot 'payload-manifest.json') -Raw | ConvertFrom-Json
if ($manifest.scope -ne 'mitom-web-tools-image-import' -or $manifest.version -ne 1 -or @($manifest.files).Count -ne 3) { throw 'Wrong payload manifest.' }
$allowed = @('js/web-tools-bridge.js', 'js/web-tools-panel.js', 'jsx/web-tools-import.jsx')
$indexPath = SafeFile (Join-Path $panelRoot 'index.html') $panelRoot
$indexBytes = [IO.File]::ReadAllBytes($indexPath)
$indexBefore = Sha $indexBytes
$ascii = [Text.Encoding]::ASCII.GetString($indexBytes)
$tag = '  <script src="./js/web-tools-panel.js"></script>' + "`r`n"
$needle = '</body>'
$offset = $ascii.LastIndexOf($needle, [StringComparison]::OrdinalIgnoreCase)
if ($offset -lt 0) { throw 'Panel index is not a complete HTML document.' }
if ($ascii.Contains('web-tools-panel.js') -and -not $ascii.Contains('<script src="./js/web-tools-panel.js"></script>')) { throw 'An unknown MITOM Web integration already exists; inspect instead of overwriting.' }
$newIndex = $indexBytes
if (-not $ascii.Contains('<script src="./js/web-tools-panel.js"></script>')) {
    $insert = [Text.Encoding]::UTF8.GetBytes($tag)
    $newIndex = New-Object byte[] ($indexBytes.Length + $insert.Length)
    [Array]::Copy($indexBytes, 0, $newIndex, 0, $offset)
    [Array]::Copy($insert, 0, $newIndex, $offset, $insert.Length)
    [Array]::Copy($indexBytes, $offset, $newIndex, $offset + $insert.Length, $indexBytes.Length - $offset)
}
$planned = @()
foreach ($entry in $manifest.files) {
    if ($entry.path -notin $allowed -or $entry.sha256 -notmatch '^[a-f0-9]{64}$') { throw 'Unexpected payload file.' }
    $src = SafeFile (Join-Path (Join-Path $sourceRoot 'panel') $entry.path) (Join-Path $sourceRoot 'panel')
    $dst = SafeFile (Join-Path $panelRoot $entry.path) $panelRoot
    $bytes = [IO.File]::ReadAllBytes($src)
    if ($bytes.Length -ne $entry.bytes -or (Sha $bytes) -ne $entry.sha256) { throw 'Payload hash mismatch.' }
    if (Test-Path -LiteralPath $dst) {
        if ((Sha ([IO.File]::ReadAllBytes($dst))) -ne $entry.sha256) { throw 'Different bridge version already exists. Refusing to overwrite unknown code.' }
    }
    $planned += [pscustomobject]@{ name = $entry.path; target = $dst; bytes = $bytes; sha = $entry.sha256; existed = (Test-Path -LiteralPath $dst) }
}
if (-not $Apply) {
    [pscustomobject]@{ dryRun = $true; panel = $panelRoot; currentIndexSHA256 = $indexBefore; files = $allowed; change = 'Three new bridge files + one additive script tag only'; noApplicationStopped = $true } | ConvertTo-Json -Depth 4
    return
}
if ((Sha ([IO.File]::ReadAllBytes($indexPath))) -ne $indexBefore) { throw 'Panel index changed during validation; no changes made.' }
$backup = Join-Path (Join-Path $sourceRoot 'backup') ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($backup) | Out-Null
[IO.File]::WriteAllBytes((Join-Path $backup 'index.html'), $indexBytes)
if ((Sha ([IO.File]::ReadAllBytes((Join-Path $backup 'index.html')))) -ne $indexBefore) { throw 'Recovery backup hash verification failed; no panel changes made.' }
$created = @(); $indexWritten = $false
try {
    foreach ($item in $planned) {
        if ($item.existed) { continue }
        $stream = [IO.File]::Open($item.target, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($item.bytes, 0, $item.bytes.Length) } finally { $stream.Dispose() }
        $created += $item
    }
    if ((Sha ([IO.File]::ReadAllBytes($indexPath))) -ne $indexBefore) { throw 'Panel index changed before patch; aborting.' }
    if ((Sha $newIndex) -ne $indexBefore) {
        $staged = Join-Path $panelRoot ('.mitom-webtools-index-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        [IO.File]::WriteAllBytes($staged, $newIndex)
        # Stage and destination are in the same CEP folder. The independent,
        # hash-verified recovery backup above may be on another drive. Passing
        # it to File.Replace would make replacement fail across C:/D: volumes.
        # NullString is a real .NET null string in PowerShell 5/7; plain $null
        # can bind as an empty path and fail before the replacement.
        [IO.File]::Replace($staged, $indexPath, [NullString]::Value)
        $indexWritten = $true
    }
    foreach ($item in $planned) { if ((Sha ([IO.File]::ReadAllBytes($item.target))) -ne $item.sha) { throw 'Installed payload verification failed.' } }
    if ((Sha ([IO.File]::ReadAllBytes($indexPath))) -ne (Sha $newIndex)) { throw 'Installed index verification failed.' }
} catch {
    if ($indexWritten -and (Sha ([IO.File]::ReadAllBytes($indexPath))) -eq (Sha $newIndex)) { [IO.File]::WriteAllBytes($indexPath, $indexBytes) }
    if ($staged -and (Test-Path -LiteralPath $staged) -and (Sha ([IO.File]::ReadAllBytes($staged))) -eq (Sha $newIndex)) { [IO.File]::Delete($staged) }
    foreach ($item in $created) { if ((Test-Path -LiteralPath $item.target) -and (Sha ([IO.File]::ReadAllBytes($item.target))) -eq $item.sha) { [IO.File]::Delete($item.target) } }
    throw
}
$receipt = [pscustomobject]@{ build = $manifest.build; panel = $panelRoot; backup = $backup; indexBeforeSHA256 = $indexBefore; indexAfterSHA256 = (Sha $newIndex); files = $allowed; requiresPanelReload = $true; noApplicationStopped = $true; customerFilesChanged = 0; existingWorkflowsChanged = 0 }
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $backup 'install-receipt.json') -Encoding UTF8
$receipt | ConvertTo-Json -Depth 4
