MITOM WEB → PHOTOSHOP — BẢN BỔ SUNG 20261022-R1

MỤC ĐÍCH
Thêm kết quả PNG từ 3D Tool, Scrabble, Sky Starmap hoặc Moon Phase trên
https://mitomyhy.github.io/#tools/depth vào Photoshop trên chính máy này.
Không thay các workflow đang có trong panel. Không đổi Launcher/update feed.

CÀI ĐẶT
1. Máy phải có Photoshop và MITOM/UOY Order Panel trước. Đây là bản bổ sung,
   không phải bộ cài Photoshop hay panel đầy đủ.
2. Giải nén toàn bộ ZIP vào một thư mục riêng. Không chạy trực tiếp trong ZIP.
3. Chạy Install.cmd bằng tài khoản Windows đang dùng Photoshop. Không cần
   Run as administrator, không nhập mật khẩu hay token GitHub.
4. Nếu cài thành công, đóng/mở lại panel. Nếu chưa hiện nút, lưu công việc rồi
   khởi động lại Photoshop vào lúc thuận tiện. Bộ cài không tự đóng ứng dụng.

KẾT NỐI VÀ DÙNG
1. Trong panel, bấm “MITOM Web · kết nối Photoshop” ngay dưới các tab công cụ.
2. Bấm “Copy mã kết nối”. Mã chỉ dùng cho phiên panel hiện tại, không chia sẻ.
3. Trên web MITOM, mở TOOLS → chọn công cụ → “Kết nối Photoshop” và dán mã.
4. Nếu trình duyệt hỏi truy cập mạng cục bộ, tự xem và cho phép để nối máy này.
5. Tạo kết quả, bấm “Thêm vào Photoshop”. Tool thêm một layer pixel vào tài
   liệu đang mở; nếu chưa mở tài liệu, tạo tài liệu mới chưa lưu.
6. Sau khi mở lại trang/panel, lấy mã và kết nối lại. Mã không được lưu lên web.

LƯU Ý
- Chỉ nhận kết quả PNG từ đúng https://mitomyhy.github.io, không nhận JSX,
  lệnh Photoshop, đường dẫn file hay link ảnh bất kỳ.
- Không tự lưu/ghi đè/đóng PSD gốc. Kết quả web là ảnh PNG; các flow Photoshop
  như Smart Object, layer và template chuyên dụng vẫn làm ở panel.
- Nếu mất xác nhận, kiểm tra Photoshop trước khi bấm thêm lại để tránh ảnh đôi.
- Nếu chưa cài được cầu nối, bạn vẫn tải PNG trên web rồi kéo vào Photoshop.
- Chỉ thêm 3 file cầu nối và một dòng script vào index.html. Không đổi config,
  tài khoản, template, Save Task, Base hay Launcher.
- Bản sao index và biên nhận cài đặt nằm trong thư mục backup cạnh bộ cài.
  Không tự ghi đè index bằng backup nếu sau đó bạn đã cài bản panel khác.
- Nếu báo một phiên bản cầu nối khác đã có, dừng và gửi thông báo cho người
  phát hành; bộ cài không thay mã nguồn không xác định.

PHÁT HÀNH
Mã nguồn công khai, không kèm mã ghép nối, dữ liệu khách, local-config hay khóa ký.
