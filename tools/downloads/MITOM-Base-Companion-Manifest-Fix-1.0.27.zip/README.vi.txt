BASE COMPANION 1.0.27 — THAY FILE MANIFEST DUNG DINH DANG

Goi nay chi co manifest.json nguyen ban va huong dan nay. Khong doi version,
key/ma tien ich, quyen truy cap, ghep noi, background.js hoac file nao khac.

1. Giai nen ZIP vao mot thu muc tam.
2. Trong thu muc tien ich Chrome DANG NAP, giu ban sao manifest.json cu
   thanh manifest.json.bak, roi thay bang manifest.json trong ZIP nay.
   Thu muc ban dang dung: C:\Users\ADMIN\AppData\Local\UOY\Companion
   Phai thay ngay trong thu muc co background.js, core.js va popup.html;
   khong tao them mot thu muc Companion long ben trong.
3. Mo chrome://extensions, bam Tai lai o UOY Base Companion dang co.
   Neu dang mo tab Base, tai lai rieng tab do mot lan.
4. Khong bam Xoa, Quen hoac ghep lai chi vi thay ma.

Ba URL phai la chuoi URL thuan, KHONG phai [URL](URL), khong them dau \:
http://127.0.0.1/*
https://*.larksuite.com/*
https://*.feishu.cn/*

SHA256 manifest.json:
862089f33dc5478648bc00de283d420813ef4a982333d073861351b5d04bc76e

Gioi han: file nay trung byte voi goi1.0.27 da phat hanh. Neu file tren may
da co SHA nay/current_valid, thay lai KHONG sua duoc mot loi runtime khac.
No chi sua file manifest bi dinh dang lai khi sao chep. Bao cao kiem tra
truoc do da xac nhan thu muc duoc kiem tra co file dung; chua xac nhan
duoc loi runtime cua Chrome tren may nhan.
