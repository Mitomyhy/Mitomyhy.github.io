"""Six-target managed-panel repair; no downloads or runtime/configuration writes.

The builder embeds exact approved output pins below. installer_guard.py is the
unchanged audited Launcher installer, reused only for its canonical ownership,
process, mutex, path, transaction and rollback guards. No install() is called.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import time
import uuid
import installer_guard as guard

VERSION = '2026.10.27.1'
BEFORE = {
    'panel/js/main.js': '89592a0b46508cf292fe948a9b39e9076544b5fcd7d82c69b112c75883a8b3f5',
    'panel/js/lark-base-watch.js': 'a042643962d37b4db2d54f31578dbef13cf1422f3006769d5ffe855e60404bbd',
    'panel/js/lark-live-status.js': 'cd79f4904c40b4ec6934e49f9891b8c524160d561549312c87722d1390bf297f',
    'panel/js/lark-base-bridge.js': 'a871152461c3074250e926f65661d2fdf77a08ce83318e357635c21c874bf4d9',
    'coexist/coexist-client.js': '7968190a2f849ef3678e48a7cd493945bdb19c36356c86e94910db33eafc5253',
    'coexist/coexist-host.js': '86034515f5cda3367fb3e6dac629867e8812c105e7c4cec1da94bd5a16c5f296',
}
LEGACY_OWNED = {
    'panel/js/main.js': 'f9c4e9b0b75a15a2f3c00051bd007d4101dc59114cab019fe6633c853cc823b9',
    'panel/js/lark-base-watch.js': '4e317422e0ef86026431736ff7a092b0bd4baefcad6a8c1712fd54d550d3b3f6',
    'panel/js/lark-live-status.js': 'bdc7e5fc562b6456e574a98c811422f22cbf13be16791d24f442e513b561afb4',
    'panel/js/lark-base-bridge.js': BEFORE['panel/js/lark-base-bridge.js'],
    'coexist/coexist-client.js': BEFORE['coexist/coexist-client.js'],
    'coexist/coexist-host.js': BEFORE['coexist/coexist-host.js'],
}
SUPPORTED_BEFORE = {version: dict(LEGACY_OWNED) for version in ('2026.10.25.1', '2026.10.26.1', '2026.10.26.2')}
SUPPORTED_BEFORE['2026.10.26.3'] = dict(BEFORE)
# Replaced only by the release builder after both source approval gates pass.
APPROVED_OUTPUT = {'coexist/coexist-client.js': {'size': 16904, 'sha256': '26a2053ad63dedafa57d9a2ce9c10383a599f08dfa881bf30103aef0d7af332e'}, 'coexist/coexist-host.js': {'size': 32318, 'sha256': '2df221a867f6676b2261c5faa64ec85eed123859154eb99e080f40d35785a0cc'}, 'panel/js/lark-base-bridge.js': {'size': 104812, 'sha256': 'bae74c22ac29bbe1c3d0139af571712fd4cfede68d59159067cbe90058f058d7'}, 'panel/js/lark-base-watch.js': {'size': 29489, 'sha256': 'a82505f1d46268b8d8ac39a7896ea3c85383cb208fde167b92a9aa1bb4ae3b4a'}, 'panel/js/lark-live-status.js': {'size': 44333, 'sha256': '04f31f6fc63c4e87a50103293f3da491783407d09ad350b1dac060c59e2aae9b'}, 'panel/js/main.js': {'size': 540471, 'sha256': 'a343d532edc52f857723b6d784c8295f3278ad0c0a0c55451e077b78122264a9'}}

def _digest(data):
    return hashlib.sha256(data).hexdigest()

def _package(package):
    package = guard._plain(package)
    if not isinstance(APPROVED_OUTPUT, dict) or set(APPROVED_OUTPUT) != set(BEFORE):
        raise guard.InstallError('This is an unsealed repair source, not an installable package.')
    manifest = guard._read_json(package / 'patch-manifest.json')
    if (manifest.get('schema') != 4 or manifest.get('version') != VERSION or
            manifest.get('base_versions') != SUPPORTED_BEFORE or manifest.get('disk_preimage') != BEFORE or
            manifest.get('files') != APPROVED_OUTPUT):
        raise guard.InstallError('Repair manifest differs from the approved six-file package.')
    payload = {}
    for name, expected in APPROVED_OUTPUT.items():
        if (not isinstance(expected, dict) or set(expected) != {'size', 'sha256'} or
                type(expected['size']) is not int or not 0 < expected['size'] <= 1024 * 1024):
            raise guard.InstallError('Invalid approved repair pin.')
        source = guard._child(package / 'payload', name)
        if guard._hash(source) is None:
            raise guard.InstallError('Repair payload integrity failed: ' + name)
        data = source.read_bytes()
        if len(data) != expected['size'] or _digest(data) != expected['sha256']:
            raise guard.InstallError('Repair payload integrity failed: ' + name)
        payload[name] = data
    return payload

def _target(roots, name):
    if name not in BEFORE:
        raise guard.InstallError('Target is not in the exact reviewed Base/coexist repair allowlist.')
    component, relative = name.split('/', 1)
    if component not in ('panel', 'coexist'):
        raise guard.InstallError('Unapproved repair component root.')
    return guard._child(roots[component], relative)

def apply(package, base_root=None):
    payload = _package(Path(package))
    roots, local, sandbox = guard._roots(base_root)
    guard._closed(sandbox)
    with guard._lock(roots, sandbox):
        pending = roots['launcher'] / 'pending-transaction.json'
        if guard._hash(pending) is not None:
            raise guard.InstallError('An unfinished Launcher update was preserved. Use Restore previous version first; no repair files changed.')
        guard._closed(sandbox)
        receipt_path = roots['launcher'] / 'install-receipt.json'
        receipt_hash = guard._hash(receipt_path)
        receipt = guard._read_json(receipt_path)
        identity = guard._identity(roots)
        receipt_version = receipt.get('version')
        if (receipt.get('schema') != 1 or not isinstance(receipt_version, str) or
                receipt_version not in SUPPORTED_BEFORE or
                receipt.get('identity') != identity):
            raise guard.InstallError('This repair requires the current user\'s exact Panel26.3 receipt, or a known25.1/26.1/26.2 receipt already carrying the complete R70 Base repair. Use the cumulative Launcher update for older unpatched versions. Existing files were preserved.')
        preimage = SUPPORTED_BEFORE[receipt_version]
        recorded = receipt.get('files')
        if not isinstance(recorded, list):
            raise guard.InstallError('The existing full-install receipt was preserved: invalid inventory.')
        owned = {}
        for row in recorded:
            if not isinstance(row, dict) or not isinstance(row.get('path'), str) or row['path'] in owned:
                raise guard.InstallError('The existing receipt has invalid or duplicate paths.')
            owned[row['path']] = row
        changes = []
        for name in sorted(BEFORE):
            if owned.get(name, {}).get('sha256') != preimage[name]:
                raise guard.InstallError('The full-install receipt does not own the supported preimage: ' + name)
            target = _target(roots, name)
            before = guard._hash(target)
            if before == APPROVED_OUTPUT[name]['sha256']:
                continue
            # A prior run of this Base-only repair retains the full receipt;
            # its exact sealed output is accepted by the equality check above.
            if before != BEFORE[name]:
                raise guard.InstallError('An old unpatched, newer or custom panel file was preserved; use the cumulative Launcher update: ' + name)
            changes.append({'entry': {'path': name, **APPROVED_OUTPUT[name]}, 'target': target,
                            'before': before, 'data': payload[name]})
        if not changes:
            return {'updated': False, 'already_current': True, 'patch_version': VERSION,
                    'full_install_receipt_preserved': True}
        guard._space_preflight(changes, roots)
        backup = guard._child(roots['launcher'], 'backups/' + time.strftime('%Y%m%d-%H%M%S') + '-base-manual-status-' + uuid.uuid4().hex)
        backup.mkdir(parents=True, exist_ok=False)
        journal = {'schema': 1, 'identity': identity, 'version': VERSION, 'status': 'preparing',
                   'files': [], 'registry': []}
        for index, change in enumerate(changes):
            if guard._hash(change['target']) != change['before']:
                raise guard.InstallError('A target changed during repair preflight; no panel file changed.')
            stored = 'files/' + str(index) + '.bin'
            guard._atomic(guard._child(backup, stored), guard._FileSource(change['target'], change['before']), None)
            journal['files'].append({'path': change['entry']['path'], 'before': change['before'],
                                     'after': change['entry']['sha256'], 'backup': stored, 'applied': True})
        guard._write_journal(backup / 'transaction.json', journal)
        guard._atomic(pending, guard._json_bytes({'schema': 1, 'identity': identity,
                                                'backup': backup.relative_to(roots['launcher']).as_posix()}), None)
        try:
            for change in changes:
                guard._closed(sandbox)
                if guard._hash(receipt_path) != receipt_hash:
                    raise guard.InstallError('The full-install receipt changed during repair.')
                guard._atomic(change['target'], change['data'], change['before'])
            if guard._hash(receipt_path) != receipt_hash:
                raise guard.InstallError('The full-install receipt changed during repair.')
            journal['status'] = 'installed'
            guard._write_journal(backup / 'transaction.json', journal)
            guard._plain(pending).unlink()
        except BaseException as error:
            retained = guard._restore(journal, backup, roots, sandbox)
            journal['status'] = 'recovery_required' if retained else 'rolled_back'
            journal['retained'] = retained
            guard._write_journal(backup / 'transaction.json', journal)
            if not retained:
                guard._plain(pending).unlink(missing_ok=True)
            raise guard.InstallError('Repair stopped. ' + ('Later edits retained; use Restore previous version.' if retained else 'Previous panel files restored.') + ' Backup: ' + str(backup)) from error
        return {'updated': True, 'patch_version': VERSION, 'files': len(changes), 'backup': str(backup),
                'full_install_receipt_preserved': guard._hash(receipt_path) == receipt_hash,
                'settings_models_runtimes_unchanged': True, 'gpu_setup_or_inference_started': False}

def main():
    result = apply(Path(__file__).resolve().parent)
    print('Base manual-status repair complete. Reopen Photoshop when convenient. No CUDA installation or generation was started.')
    print(json.dumps(result, ensure_ascii=False))

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('Repair stopped: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
