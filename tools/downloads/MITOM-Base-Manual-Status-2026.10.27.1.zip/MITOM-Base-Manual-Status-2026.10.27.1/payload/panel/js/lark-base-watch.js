/* Read-only Base helpers and explicit current-order status control.
 * Production initialization never starts a watcher or reads Base. The separate
 * button delegates one selected-order read only after a user click. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root){root.UOYLarkBaseWatch=api;if(root.document)api.autoInit(root);}})(typeof window==='undefined'?null:window,function(){
  'use strict';
  var INTERVAL=300000,MAX_RECORDS=20000,MAX_EVENTS=200,MAX_BYTES=8*1024*1024;
  var HEADERS=['Order Number','SKU','Record ID','Product Type','Design Link','Personalized/File','Note','Personalized/Options','Variation','Quantity','Personalized','Name fullprint','Working Status','Listing URL'];
  function fail(code,message){var e=new Error(message);e.code=code;throw e;}
  function trim(value){return value.replace(/^\s+|\s+$/g,'');}
  function working(value){return trim(value.replace(/[\u200b-\u200d\u2060\ufeff]/g,'').replace(/[_\-]+/g,' ').replace(/\s+/g,' ')).toUpperCase().replace(/^TO DO$/,'TODO');}
  function recordId(value){return typeof value==='string'&&/^\w[\w-]{0,159}$/.test(value);}
  function line(value,max){return typeof value==='string'&&value.length<=max&&!/[\x00-\x1f\x7f]/.test(value);}
  function count(value){return Number.isSafeInteger(value)&&value>=0;}
  function project(snapshot){
    function bad(){fail('BASE_WATCH_SNAPSHOT','Lần quét Base chưa có dữ liệu đầy đủ; giữ nguyên lần kiểm tra trước.');}
    if(!snapshot||snapshot.version!==1||!snapshot.source||!Number.isInteger(snapshot.count)||snapshot.count<0||snapshot.count>5000||!Array.isArray(snapshot.rows)||snapshot.rows.length!==snapshot.count+1||JSON.stringify(snapshot.rows[0])!==JSON.stringify(HEADERS))bad();
    var source=snapshot.source,url;
    try{url=new URL(source.url);}catch(_){bad();}
    if(url.protocol!=='https:'||url.username||url.password||url.port||!/(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(url.hostname)||url.pathname==='/'||!recordId(source.tableId)||!recordId(source.viewId))bad();
    var base=url.origin+url.pathname.replace(/\/$/,''),scope=base+'|'+source.tableId+'|'+source.viewId,seen=Object.create(null),rows=[],counts={todo:0,fix:0,other:0};
    snapshot.rows.slice(1).forEach(function(row){
      if(!Array.isArray(row)||row.length!==HEADERS.length)bad();
      row.forEach(function(cell){if(typeof cell!=='string'||cell.length>100000||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(cell))bad();});
      var id=row[2],sku=trim(row[1]),raw=trim(row[12]),status=working(raw);
      if(!recordId(id)||seen[id]||!line(sku,240)||!line(raw,160))bad();seen[id]=true;
      rows.push({id:id,sku:sku,status:status,workingStatus:raw});
      if(status==='TODO')counts.todo++;else if(status==='FIX FILE')counts.fix++;else counts.other++;
    });
    var encoded=JSON.stringify(snapshot);
    if((typeof Buffer!=='undefined'?Buffer.byteLength(encoded,'utf8'):encoded.length)>MAX_BYTES)bad();
    return {scope:scope,source:{base:base,tableId:source.tableId,viewId:source.viewId,viewName:line(source.viewName||'',240)?source.viewName||'':''},rows:rows,counts:counts};
  }
  function validateState(value,scope){
    function bad(){fail('BASE_WATCH_HISTORY','Lịch sử quét Base riêng chưa hợp lệ; không tự bỏ lịch sử hoặc báo đơn mới sai.');}
    if(!value||value.version!==1||value.scope!==scope||!count(value.sequence)||!count(value.acknowledged)||value.acknowledged>value.sequence||!count(value.lastScan)||!Array.isArray(value.records)||value.records.length>MAX_RECORDS||!Array.isArray(value.events)||value.events.length>MAX_EVENTS)bad();
    var ids=Object.create(null),last=0;
    value.records.forEach(function(row){if(!row||!recordId(row.id)||ids[row.id]||!line(row.sku,240)||!line(row.workingStatus,160)||row.status!==working(row.workingStatus))bad();ids[row.id]=true;});
    value.events.forEach(function(event){if(!event||!count(event.sequence)||!event.sequence||event.sequence<=last||event.sequence>value.sequence||!recordId(event.recordId)||!line(event.sku,240)||['new','fix'].indexOf(event.kind)<0||!count(event.time))bad();last=event.sequence;});
    return value;
  }
  function createTracker(options){
    options=options||{};var store=options.store,now=options.now||Date.now,current=null;
    if(!store||typeof store.load!=='function'||typeof store.save!=='function')fail('BASE_WATCH_STORE','Chưa có nơi lưu lịch sử quét Base riêng.');
    function display(state,projection,first){
      var byId=Object.create(null);projection.rows.forEach(function(row){byId[row.id]=row;});
      return {scope:state.scope,source:projection.source,counts:projection.counts,lastScan:state.lastScan,baseline:first,unread:state.sequence-state.acknowledged,events:state.events.slice().reverse().map(function(event){var row=byId[event.recordId];return {sequence:event.sequence,recordId:event.recordId,sku:row?row.sku:event.sku,kind:event.kind,time:event.time,present:!!row,workingStatus:row?row.workingStatus:'Không còn trong view đang quét'};})};
    }
    function ingest(snapshot){
      var projection=project(snapshot),saved=store.load(projection.scope),first=!saved;
      if(saved)validateState(saved,projection.scope);
      var next=saved?JSON.parse(JSON.stringify(saved)):{version:1,scope:projection.scope,sequence:0,acknowledged:0,lastScan:0,records:[],events:[]},byId=Object.create(null);
      next.records.forEach(function(row){byId[row.id]=row;});
      var stamp=now();if(!count(stamp))fail('BASE_WATCH_CLOCK','Thời gian quét không hợp lệ.');
      projection.rows.forEach(function(row){
        var previous=byId[row.id],kind='';
        if(!first){if(row.status==='FIX FILE'&&(!previous||previous.status!=='FIX FILE'))kind='fix';else if(!previous&&row.status==='TODO')kind='new';}
        if(kind){next.sequence++;if(!Number.isSafeInteger(next.sequence))fail('BASE_WATCH_HISTORY','Lịch sử quét vượt giới hạn.');next.events.push({sequence:next.sequence,recordId:row.id,sku:row.sku,kind:kind,time:stamp});}
        byId[row.id]={id:row.id,sku:row.sku,status:row.status,workingStatus:row.workingStatus};
      });
      next.records=Object.keys(byId).map(function(id){return byId[id];});
      if(next.records.length>MAX_RECORDS)fail('BASE_WATCH_HISTORY_LIMIT','Lịch sử view vượt giới hạn an toàn; giữ nguyên lịch sử cũ.');
      next.events=next.events.slice(-MAX_EVENTS);next.lastScan=stamp;
      store.save(projection.scope,next);current={state:next,projection:projection};
      return display(next,projection,first);
    }
    function acknowledge(){
      if(!current)return null;
      var saved=store.load(current.state.scope);if(!saved)fail('BASE_WATCH_HISTORY','Lịch sử đã thay đổi; quét lại trước khi đánh dấu đã xem.');
      validateState(saved,current.state.scope);var next=JSON.parse(JSON.stringify(saved));next.acknowledged=Math.max(next.acknowledged,Math.min(current.state.sequence,next.sequence));
      store.save(next.scope,next);
      // Acknowledge only what this Panel actually displayed. Another Panel's
      // newer cache must not make old local counts look freshly re-scanned.
      var visible=JSON.parse(JSON.stringify(current.state));visible.acknowledged=Math.min(next.acknowledged,visible.sequence);current.state=visible;
      return display(visible,current.projection,false);
    }
    return {ingest:ingest,acknowledge:acknowledge};
  }
  function createFileStore(options){
    var fs=options.fs,path=options.path,crypto=options.crypto,root=path.resolve(options.root);
    function safe(value){var cursor=path.resolve(value);while(true){try{var stat=fs.lstatSync(cursor);if(stat.isSymbolicLink()||path.resolve(fs.realpathSync(cursor)).toLowerCase()!==cursor.toLowerCase())fail('BASE_WATCH_REPARSE','Không dùng đường dẫn liên kết để lưu lịch sử Base.');}catch(e){if(e.code!=='ENOENT')throw e;}var parent=path.dirname(cursor);if(parent===cursor)break;cursor=parent;}return path.resolve(value);}
    function filename(scope){if(typeof scope!=='string'||!scope||scope.length>2048)fail('BASE_WATCH_SCOPE','View Base không hợp lệ.');return path.join(root,crypto.createHash('sha256').update(scope).digest('hex')+'.json');}
    function loadFile(file){safe(file);if(!fs.existsSync(file))return null;var stat=fs.lstatSync(file);if(!stat.isFile()||stat.size>MAX_BYTES)fail('BASE_WATCH_HISTORY','Lịch sử Base riêng vượt giới hạn.');try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch(_){fail('BASE_WATCH_HISTORY','Không đọc được lịch sử Base riêng; giữ nguyên file cũ.');}}
    function saveFile(file,value){
      safe(root);fs.mkdirSync(root,{recursive:true});safe(file);
      var bytes=JSON.stringify(value),temporary=file+'.tmp-'+crypto.randomBytes(12).toString('hex');
      if(Buffer.byteLength(bytes,'utf8')>MAX_BYTES)fail('BASE_WATCH_HISTORY_LIMIT','Lịch sử Base vượt giới hạn an toàn.');
      var fd=null,owned=false;
      try{fd=fs.openSync(temporary,'wx',384);owned=true;fs.writeFileSync(fd,bytes,'utf8');fs.fsyncSync(fd);fs.closeSync(fd);fd=null;safe(file);fs.renameSync(temporary,file);owned=false;}
      finally{if(fd!==null)fs.closeSync(fd);if(owned&&fs.existsSync(temporary)){safe(temporary);fs.unlinkSync(temporary);}}
    }
    return {load:function(scope){return loadFile(filename(scope));},save:function(scope,value){if(value.scope!==scope)fail('BASE_WATCH_SCOPE','Lịch sử không khớp view.');validateState(value,scope);saveFile(filename(scope),value);},
      enabled:function(){var value=loadFile(path.join(root,'settings.json'));if(value===null)return true;if(!value||value.version!==1||typeof value.enabled!=='boolean'||Object.keys(value).length!==2)fail('BASE_WATCH_HISTORY','Thiết lập quét Base chưa hợp lệ.');return value.enabled;},
      setEnabled:function(value){if(typeof value!=='boolean')fail('BASE_WATCH_HISTORY','Thiết lập quét chưa hợp lệ.');saveFile(path.join(root,'settings.json'),{version:1,enabled:value});}};
  }
  function cleanSource(value){
    if(!value||typeof value.url!=='string'||!recordId(value.tableId)||!recordId(value.viewId))return null;
    var url;try{url=new URL(value.url);}catch(_){return null;}
    if(url.protocol!=='https:'||url.username||url.password||url.port||!/(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(url.hostname)||url.pathname==='/')return null;
    return {url:url.origin+url.pathname.replace(/\/$/,''),tableId:value.tableId,viewId:value.viewId};
  }
  function sameSource(a,b){a=cleanSource(a);b=cleanSource(b);return !!a&&!!b&&a.url===b.url&&a.tableId===b.tableId&&a.viewId===b.viewId;}
  function planQueue(existing,incoming,snapshot,selected,meta){
    project(snapshot);var source=cleanSource(snapshot.source),previous=cleanSource(meta&&meta.previousSource),oldSource=existing.length&&cleanSource(existing[0].baseSource);
    if(!oldSource||!source||existing.some(function(record){return !sameSource(record.baseSource,oldSource);}))return null;
    // Automatic view following is limited to the SDK-confirmed table already
    // loaded. A different Base/table must not silently rebind a working PSD.
    if(!sameSource(oldSource,source)&&(!previous||!sameSource(previous,oldSource)||oldSource.url!==source.url||oldSource.tableId!==source.tableId))return null;
    var old=Object.create(null),fresh=Object.create(null),rows=Object.create(null),records=[],updates=[];
    existing.forEach(function(record){if(!recordId(record.recordId)||old[record.recordId])fail('BASE_VIEW_QUEUE','Record đang nạp trống hoặc trùng.');old[record.recordId]=record;});
    incoming.forEach(function(record){if(!record||!recordId(record.recordId)||fresh[record.recordId])fail('BASE_VIEW_QUEUE','Record mới trống hoặc trùng.');fresh[record.recordId]=record;});
    snapshot.rows.slice(1).forEach(function(row){
      var id=row[2],record=old[id]||fresh[id];rows[id]=row;
      if(record){records.push(record);updates.push({record:record,fresh:fresh[id]||null,row:row,isNew:!old[id]});}
    });
    incoming.forEach(function(record){var row=rows[record.recordId];if(!row||row[1].trim()!==record.sku||row[11].trim()!==record.name||!sameSource(record.baseSource,source))fail('BASE_VIEW_QUEUE','Đơn mới không khớp dữ liệu của đúng view.');});
    // Keep the current PSD's record visible as an explicitly departed order.
    // No automatic navigation, PSD open, export or upload occurs here.
    if(selected&&existing.indexOf(selected)>=0&&!rows[selected.recordId]){records.splice(Math.min(existing.indexOf(selected),records.length),0,selected);updates.push({record:selected,fresh:null,row:null,isNew:false});}
    return {source:source,records:records,updates:updates,index:selected?records.indexOf(selected):-1,sourceChanged:!sameSource(source,oldSource)};
  }
  function createController(options){
    var bridge=options.bridge,tracker=options.tracker,emit=options.onState||function(){},clock=options.clock||{setTimeout:setTimeout,clearTimeout:clearTimeout},enabled=options.enabled!==false;
    var closed=false,started=false,running=false,generation=0,timer=null,reconcileTimer=null,reconcilePending=false,unsubscribe=null,lastGood=null,currentPhase='idle',currentMessage='',source=null,previousSource=null;
    var due=true,full=true,dirtyIds=Object.create(null),intent=0,failures=0,lastSnapshot=null,manualWaiting=false,hiddenReaderWaiting=false,activeRead=null,nextAutomaticAt=0,manualScanPending=false;
    var now=options.now||Date.now;
    var reconcileInterval=options.reconcileIntervalMs===undefined?INTERVAL:options.reconcileIntervalMs;
    if(!Number.isInteger(reconcileInterval)||reconcileInterval!==0&&(reconcileInterval<2000||reconcileInterval>300000))fail('BASE_WATCH_INTERVAL','Chu kỳ đối chiếu Base chưa hợp lệ.');
    function update(phase,message){if(phase!==undefined)currentPhase=phase;if(message!==undefined)currentMessage=message;emit({phase:currentPhase,message:currentMessage,enabled:enabled,scanning:running,result:lastGood});}
    function automaticDelay(){return reconcileInterval?Math.max(0,nextAutomaticAt-now()):0;}
    function cooldown(){if(reconcileInterval)nextAutomaticAt=Math.max(nextAutomaticAt,now()+reconcileInterval);}
    function schedule(delay){if(closed||!enabled||manualWaiting||running||!due||timer!==null)return;var wait=delay===undefined?250:delay;if(!manualScanPending)wait=Math.max(wait,automaticDelay());timer=clock.setTimeout(function(){timer=null;void drain();},wait);}
    function stopTimer(){if(timer!==null)clock.clearTimeout(timer);timer=null;}
    function stopReconcile(){if(reconcileTimer!==null)clock.clearTimeout(reconcileTimer);reconcileTimer=null;reconcilePending=false;}
    function armReconcile(){
      if(closed||!enabled||!started||manualWaiting||!reconcileInterval||reconcileTimer!==null)return;
      reconcileTimer=clock.setTimeout(function(){
        reconcileTimer=null;
        if(closed||!enabled||manualWaiting)return;
        // A timer is not a dirty SDK event. Keep one pending full intent, but
        // never catch up elapsed ticks with back-to-back SDK reads: every
        // settled attempt receives a full automatic cooldown below.
        if(running)reconcilePending=true;
        else {due=true;full=true;if(!failures)schedule(0);}
        armReconcile();
      },reconcileInterval);
    }
    function queue(value,force){
      if(closed||!enabled)return;
      var old=cleanSource(value&&value.source),candidate=cleanSource(value&&value.currentSource),changes=value&&value.dirty;
      if(source&&old&&!sameSource(old,source)&&!sameSource(old,previousSource))return;
      // A selected-reader hint is only a candidate. The broker must separately
      // prove the same browser page and the SDK result before we commit it.
      if(candidate&&(!source||candidate.url===source.url)&&(!old||candidate.url===old.url)&&!sameSource(candidate,source)){
        previousSource=previousSource||source;source=candidate;full=true;dirtyIds=Object.create(null);
      }
      else if(!source&&old)source=old;
      if(force||!changes||changes.full===true)full=true;
      if(changes&&Array.isArray(changes.recordIds))changes.recordIds.forEach(function(id){if(recordId(id))dirtyIds[id]=true;else full=true;});
      if(Object.keys(dirtyIds).length>500){full=true;dirtyIds=Object.create(null);}
      due=true;intent++;if(failures||hiddenReaderWaiting)stopTimer();schedule();
    }
    function publish(snapshot,meta){
      var projection=project(snapshot),accepted=cleanSource(snapshot.source);
      if(!accepted||source&&!sameSource(source,accepted))fail('BASE_WATCH_SOURCE','View trả về khác nguồn đang theo dõi; giữ nguyên dữ liệu.');
      var receiptGeneration=generation,receiptIntent=intent,info;try{info=bridge.status();}catch(_){}
      var revision=info&&info.liveRevision;
      meta=Object.assign({},meta||{},{isCurrent:function(){
        if(closed||!enabled||receiptGeneration!==generation||receiptIntent!==intent||!sameSource(source,accepted))return false;
        var state;try{state=bridge.status();}catch(_){return false;}
        return !!state&&state.connected!==false&&(!Number.isSafeInteger(revision)||state.liveRevision===revision);
      }});
      lastGood=tracker.ingest(snapshot);source=accepted;lastSnapshot=snapshot;failures=0;update('ready',reconcileInterval?'Đối chiếu SDK mỗi 5 phút; thay đổi làm dữ liệu cũ mất hiệu lực ngay, không quét dồn.':'Đang theo dõi thay đổi của view bằng sự kiện.');
      if(typeof options.onSnapshot==='function')try{options.onSnapshot(snapshot,meta||{});}catch(_){}
      previousSource=null;return lastGood;
    }
    function drain(){
      if(closed||!enabled||manualWaiting||running||!due)return Promise.resolve(null);
      if(!manualScanPending&&automaticDelay()>0){schedule(0);return Promise.resolve(null);}
      var status;try{status=bridge.status();}catch(e){status=null;}
      if(options.isBusy&&options.isBusy()||status&&status.busy){update('waiting','Đang chờ thao tác hiện tại; thay đổi Base vẫn được giữ trong hàng đợi.');schedule(1000);return Promise.resolve(null);}
      if(typeof bridge.fetchBackgroundView!=='function'||typeof bridge.subscribe!=='function'){update('error','Thiếu cầu nối sự kiện R48; chưa tự đọc lặp lại hoặc dùng dữ liệu giả.');return Promise.resolve(null);}
      var mine=generation,stamp=intent,request=source?{source:cleanSource(source),recordIds:Object.keys(dirtyIds),full:full}:undefined,transition=previousSource;
      dirtyIds=Object.create(null);full=false;due=false;hiddenReaderWaiting=false;manualScanPending=false;activeRead={generation:mine,intent:stamp,source:request&&cleanSource(request.source),revision:status&&status.liveRevision};running=true;update('scanning',request&&!request.full?'Đang cập nhật các đơn vừa thay đổi…':'Đang nhận đầy đủ view hiện tại…');
      return Promise.resolve().then(function(){if(closed||!enabled||mine!==generation)return null;return bridge.fetchBackgroundView(request);}).then(function(snapshot){
        if(!snapshot||closed||!enabled||mine!==generation)return null;
        if(stamp!==intent){due=true;return null;}
        return publish(snapshot,{previousSource:transition,reason:request&&request.full?'reconcile':'event'});
      }).catch(function(e){
        if(!closed&&enabled&&mine===generation){due=true;full=full||!!(request&&request.full);if(request)request.recordIds.forEach(function(id){dirtyIds[id]=true;});hiddenReaderWaiting=!!e&&e.code==='BASE_COMPANION_STANDBY';if(hiddenReaderWaiting){failures=0;update('waiting','Đang chờ tab Base hiện lên để khởi động reader; reader đã giữ vẫn được đọc nền.');}else{failures=Math.min(failures+1,5);update(e&&/BUSY|CANCELLED/.test(e.code||'')?'waiting':'error',String(e.message||'Mất kết nối Base; giữ dữ liệu lần cuối.').slice(0,700));}}
        return null;
      }).then(function(value){activeRead=null;running=false;cooldown();stopTimer();var immediate=false;if(!closed&&enabled&&!manualWaiting&&reconcilePending){reconcilePending=false;due=true;full=true;immediate=!failures&&!hiddenReaderWaiting;}if(!closed&&enabled&&due&&!manualWaiting)schedule(hiddenReaderWaiting?INTERVAL:immediate?0:Math.min(15000,failures?Math.pow(2,failures-1)*1000:250));if(!closed)update();return value;});
    }
    function sameSourceReadConnection(event){
      var info=event&&event.status,read=activeRead,connectedSource=cleanSource(info&&info.readerSource);
      // A source-bound read may itself replace/rebind its transport. The broker
      // emits "connected" after accepting that SDK/page ticket, before returning
      // this same read's result. This is not a record/view mutation. Preserve
      // the current receipt only while every original
      // read/source/revision fence is still intact. Unknown/cold/foreign sources,
      // disconnects, dirty revisions and manual priority retain normal fencing.
      return !!read&&running&&read.generation===generation&&read.intent===intent&&
        sameSource(read.source,source)&&sameSource(read.source,connectedSource)&&
        info.connected===true&&info.busy===true&&
        ['opening','waitingReader','reading'].indexOf(info.readStage)>=0&&
        Number.isSafeInteger(read.revision)&&info.liveRevision===read.revision;
    }
    function attach(){
      if(unsubscribe||typeof bridge.subscribe!=='function')return;
      unsubscribe=bridge.subscribe(function(event){
        if(closed||!enabled||!event)return;
        if(event.type==='dirty')queue(event,false);
        else if(event.type==='state'){
          if(event.reason==='disconnected'||event.reason==='closed'){generation++;due=true;full=true;stopTimer();update('stale','Kết nối Base đã ngắt; đang hiển thị dữ liệu lần cuối, chưa nhận thay đổi mới.');schedule(1000);}
          else if(event.reason==='connected'&&sameSourceReadConnection(event)){
            // The active read already covers this transport bind. Do not add a
            // duplicate read intent; existing timer/dirty work stays untouched.
          }
          else if(event.reason==='connected'||event.reason==='source-changed'){queue(event,true);}
          else if(event.reason==='ready'){if(event.status&&event.status.readerEventReady===false){generation++;due=true;full=true;update('stale','Reader chưa xác nhận đang nghe sự kiện SDK; giữ dữ liệu lần cuối.');schedule(1000);}else if(due&&!running)schedule(0);}
          else if(event.reason==='idle'){
            var idleState;try{idleState=bridge.status();}catch(_){}
            // A failed manual import must release its temporary priority hold.
            // Idle notifications emitted while cancellation/foreground work is
            // still busy cannot restart the watcher or steal that request.
            if(manualWaiting&&idleState&&idleState.busy===false){manualWaiting=false;due=true;full=true;failures=0;intent++;cooldown();armReconcile();}
            if(due)schedule(250);
          }
        }
      });
    }
    function start(){if(closed)return;if(!enabled){update('paused','Đã tạm dừng theo dõi Base.');return;}attach();if(started)return;started=true;due=true;full=true;schedule(options.initialDelay===undefined?500:options.initialDelay);armReconcile();update('idle',reconcileInterval?'Base · đối chiếu SDK mỗi 5 phút; Nạp thủ công chạy ngay.':'Base · đồng bộ bằng sự kiện.');}
    function manualPriority(){if(manualWaiting)return;generation++;stopTimer();stopReconcile();due=false;manualWaiting=true;manualScanPending=false;dirtyIds=Object.create(null);full=true;}
    function setEnabled(value){if(typeof value!=='boolean')return;if(options.saveEnabled)options.saveEnabled(value);enabled=value;if(!enabled){manualPriority();if(typeof bridge.cancelBackgroundRead==='function')Promise.resolve().then(function(){return bridge.cancelBackgroundRead();}).catch(function(){});update('paused','Đã tạm dừng theo dõi Base.');}else {manualWaiting=false;started=false;start();}}
    return {start:start,scan:function(){full=true;due=true;intent++;manualScanPending=true;stopTimer();return drain();},manualPriority:manualPriority,setEnabled:setEnabled,
      acknowledge:function(){var value=tracker.acknowledge();if(value)lastGood=value;update(enabled?'ready':'paused','');},
      observe:function(snapshot){if(!closed&&enabled){project(snapshot);var nextSource=cleanSource(snapshot.source);if(!nextSource)fail('BASE_WATCH_SOURCE','Nguồn view chưa hợp lệ.');generation++;stopTimer();reconcilePending=false;due=false;manualWaiting=false;manualScanPending=false;full=false;dirtyIds=Object.create(null);source=nextSource;var result=publish(snapshot,{reason:'manual'});cooldown();armReconcile();return result;}return lastGood;},
      snapshot:function(){return lastSnapshot;},
      close:function(){if(closed)return;closed=true;generation++;stopTimer();stopReconcile();if(typeof unsubscribe==='function')unsubscribe();unsubscribe=null;}};
  }
  var mounted=null,latestSnapshot=null,latestSnapshotMeta=null,snapshotListeners=[];
  function notifySnapshot(snapshot,meta){latestSnapshot=snapshot;latestSnapshotMeta=meta;snapshotListeners.slice().forEach(function(listener){try{listener(snapshot,meta||{});}catch(_){}});}
  function autoInit(win){
    function mount(){
      var doc=win.document,load=doc.getElementById('aLoadClip'),anchor=doc.getElementById('aClipboardActions');
      if(!load||!anchor||mounted||doc.getElementById('uoyBaseWatch'))return;
      var box=doc.createElement('div'),actions=doc.createElement('div'),check=doc.createElement('button'),status=doc.createElement('div'),busy=false,closed=false;
      box.id='uoyBaseWatch';box.style.cssText='margin:6px 0;font-size:11px';actions.style.cssText='display:flex;justify-content:flex-end';
      check.id='uoyBaseScanCurrent';check.type='button';check.textContent='Quét trạng thái đơn hiện tại';check.title='Chỉ đọc trạng thái đơn đang chọn khi bấm; không tự quét hoặc thay đổi thư mục lưu.';check.style.cssText='padding:5px 8px;font-size:11px;border:1px solid #56616d;border-radius:4px;background:#35424e;color:#fff;cursor:pointer';
      status.hidden=true;status.setAttribute('aria-live','polite');status.style.cssText='margin:5px 0;color:#aebdca;overflow-wrap:anywhere';actions.appendChild(check);box.appendChild(actions);box.appendChild(status);anchor.parentNode.insertBefore(box,anchor.nextSibling);
      function feedback(message,error){if(closed)return;status.hidden=false;status.textContent=String(message||'Đã quét trạng thái đơn hiện tại.').slice(0,700);status.style.color=error?'#ffad9e':'#aebdca';}
      function finish(){busy=false;if(!closed){check.disabled=false;check.setAttribute('aria-busy','false');}}
      // Do not instantiate the legacy tracker/controller, load its enabled
      // preference, subscribe to SDK events, or attach Save/import hooks here.
      // main.js alone captures the selected record and validates this request.
      check.addEventListener('click',function(){
        if(closed||busy)return;
        busy=true;check.disabled=true;check.setAttribute('aria-busy','true');feedback('Đang quét trạng thái đơn hiện tại…',false);
        var request;
        try{
          var manual=win.UOYManualBaseStatus;
          if(!manual||typeof manual.scanCurrent!=='function')fail('BASE_MANUAL_STATUS_API','Chưa có bộ quét thủ công; cập nhật Panel trước khi kiểm tra trạng thái.');
          request=manual.scanCurrent();
        }catch(e){feedback(e&&e.message||'Không quét được trạng thái đơn hiện tại.',true);finish();return;}
        Promise.resolve(request).then(function(result){
          var message=result&&typeof result.message==='string'?result.message:result&&typeof result.workingStatus==='string'?'Working Status: '+result.workingStatus:'Đã quét trạng thái đơn hiện tại.';
          feedback(message,false);finish();
        },function(e){feedback(e&&e.message||'Không quét được trạng thái đơn hiện tại.',true);finish();});
      });
      mounted={manualPriority:function(){},observe:function(){return null;},close:function(){closed=true;}};
      win.addEventListener('beforeunload',function(){if(mounted)mounted.close();mounted=null;},{once:true});
    }
    if(win.document.readyState==='loading')win.document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
  }
  return {INTERVAL_MS:INTERVAL,project:project,workingStatus:working,cleanSource:cleanSource,sameSource:sameSource,planQueue:planQueue,createTracker:createTracker,createFileStore:createFileStore,createController:createController,autoInit:autoInit,
    subscribeSnapshots:function(listener){if(typeof listener!=='function')throw new Error('Snapshot listener required');snapshotListeners.push(listener);return function(){var i=snapshotListeners.indexOf(listener);if(i>=0)snapshotListeners.splice(i,1);};},
    snapshot:function(){return latestSnapshot;},snapshotMeta:function(){return latestSnapshotMeta;},manualPriority:function(){if(mounted)mounted.manualPriority();},observeSnapshot:function(snapshot){if(mounted)return mounted.observe(snapshot);return null;}};
});


