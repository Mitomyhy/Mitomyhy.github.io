/* Authenticated loopback bridge. It only returns fresh read-only Base views
 * and targeted live cell proofs to the existing Order Custom loader. Never runs
 * Photoshop, writes Base cells, reads cookies, or substitutes clipboard. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.UOYLarkBaseBridge=api;})(typeof window==='undefined'?null:window,function(){
  'use strict';
  var MAX_BYTES=8*1024*1024,MAX_RECORDS=5000,CLIENT_BUILD='20261021-R54',LAUNCHER_BUILD='20261023-R55',LAUNCHER_EXTENSION_ID='nbmhofblkjlmlijiokgdeojjomjcphhj';
  function error(code,message){var e=new Error(message);e.code=code;return e;}
  // Named SDK causes only: no raw exception/customer text crosses app IPC.
  var SDK_READ_ERRORS={"NO_VIEW":"Chưa chọn view trong Base. Chọn view đã lưu rồi quét lại.","SDK_VERSION":"Base SDK trong Order chưa hỗ trợ bộ đọc hiện tại. Đóng riêng phần mở rộng Order rồi mở lại.","SDK_TIMEOUT":"Base SDK chưa trả thông tin view đúng hạn. Giữ tab Base mở rồi quét lại.","SDK_SELECTION_TIMEOUT":"Base SDK chưa trả bảng và view đang chọn đúng hạn. Giữ tab Base mở, đợi tải xong rồi quét lại.","SDK_SOURCE_URL_TIMEOUT":"Base SDK chưa xác nhận liên kết của nguồn view đúng hạn. Chưa nhập dữ liệu; đợi Base tải xong rồi quét lại.","SDK_SELECTION_VERIFY_TIMEOUT":"Base SDK chưa xác minh lại bảng và view đúng hạn. Chưa nhập dữ liệu của nguồn chưa xác nhận.","SDK_OBSERVER_SOURCE_TIMEOUT":"Base SDK chưa xác nhận nguồn để theo dõi cập nhật đúng hạn. Chưa dùng trạng thái cũ; thử quét lại.","SDK_OBSERVER_TABLE_TIMEOUT":"Base SDK chưa mở bảng để theo dõi cập nhật đúng hạn. Chưa dùng dữ liệu bảng cũ; thử quét lại.","SDK_OBSERVER_CONFIG_TIMEOUT":"Base SDK chưa xác nhận cấu hình view để theo dõi cập nhật đúng hạn. Đợi view ổn định rồi quét lại.","SDK_PERMISSION":"Base SDK chưa cấp quyền đọc dữ liệu của view cho Order. Kiểm tra quyền truy cập Base rồi quét lại.","SDK_NOT_FOUND":"Base SDK không còn tìm thấy bảng, view hoặc cột. Chọn lại view đã lưu và kiểm tra ánh xạ cột.","SDK_FAILURE":"Base SDK chưa hoàn tất thao tác đọc; chưa xác định nguyên nhân và chưa nhận dữ liệu mới.","FIELD_MAPPING":"Ánh xạ của Order đang trỏ tới cột không còn tồn tại. Mở phần Ánh xạ trong Order và chọn lại cột.","FIELD_AMBIGUOUS":"Có nhiều cột cùng khớp một trường đơn hàng. Mở phần Ánh xạ trong Order và chọn đúng cột.","FIELD_SCHEMA":"Base SDK trả danh sách hoặc định danh cột không hợp lệ. Mở lại phần mở rộng Order rồi quét lại.","FIELD_REQUIRED":"Bộ đọc chưa xác định được cột SKU và Name fullprint. Kiểm tra hai cột trong phần Ánh xạ của Order.","PAGE_SCHEMA":"Base SDK trả trang dữ liệu sai cấu trúc hoặc vượt giới hạn 5000 dòng; chưa nhập bản thiếu.","PAGE_INCOMPLETE":"Base SDK chưa trả đủ các trang của view; chưa nhập bản thiếu. Đợi view ổn định rồi quét lại.","RECORD_SCHEMA":"Base SDK trả Record ID hoặc cấu trúc dòng không hợp lệ; chưa nhập dữ liệu.","CELL_FORMAT":"Base SDK trả một ô không đúng dạng văn bản; chưa nhập dữ liệu để giữ nguyên nội dung khách.","CELL_LIMIT":"Một ô trong Base vượt giới hạn hoặc chứa ký tự điều khiển; chưa nhập dữ liệu.","READ_LIMIT":"View Base vượt giới hạn 5000 dòng hoặc 8 MB. Giảm số dòng trong view cần quét.","READ_TIMEOUT":"Base SDK chưa đọc xong view đúng hạn; chưa nhập bản thiếu. Đợi view ổn định rồi quét lại.","BASE_IDENTITY":"Base SDK chưa xác nhận được đúng nguồn Base đã lưu; chưa nhập dữ liệu.","VIEW_CONFIG":"Bộ đọc chưa xác minh được cấu hình view Base. Chưa nhập dữ liệu; kiểm tra bản cập nhật reader Order.","VIEW_CONFIG_BUSY":"Cấu hình view Base đang thay đổi trong lúc kiểm tra. Đợi view ổn định rồi quét lại.","DIRTY_REQUEST":"Yêu cầu cập nhật Base chưa đúng nguồn hoặc cấu trúc đã xác nhận; chưa nhập dữ liệu.","STATUS_REQUEST":"Yêu cầu kiểm tra Working Status chưa có nguồn hoặc Record ID hợp lệ; chưa xác nhận trạng thái đơn.","FIELD_MISSING":"Bộ đọc chưa tìm thấy cột cần dùng để kiểm tra trạng thái. Kiểm tra ánh xạ cột trong Order.","STATUS_CELL":"Working Status chưa trả chuỗi hợp lệ. Tool chưa tự xác nhận đơn đã hoàn tất.","MEMBERSHIP_UNAVAILABLE":"Base SDK chưa xác nhận đủ danh sách và bộ lọc của view; chưa suy đoán đơn đã rời view.","STATUS_INSTANCE":"Phiên kiểm tra Working Status chưa hợp lệ. Quét lại để xác nhận dữ liệu hiện tại.","SDK_EVENTS":"Base SDK chưa hỗ trợ đủ sự kiện theo dõi dữ liệu. Chưa xác nhận cập nhật nền; thử quét thủ công.","STATUS_LINK":"Base SDK chưa xác nhận một Design Link hợp lệ cho đơn. Kiểm tra link hiện tại trong Base."};
  SDK_READ_ERRORS.SDK_METADATA_STALLED='SDK Base chưa kết thúc các lượt metadata cũ; reader chưa xác minh được dữ liệu mới. Đợi Base phục hồi hoặc tải lại riêng Order.';
  SDK_READ_ERRORS.READ_CANCELLED='Lượt đọc Base đã được hủy; chưa nhận dữ liệu mới.';
  SDK_READ_ERRORS.READ_CONTROL_STALE='Cầu nối local từ chối lượt đọc vì phiên hoặc nguồn view không còn khớp. Chưa nhận dữ liệu mới; bấm Nạp để xác nhận lại đúng view.';
  SDK_READ_ERRORS.READ_CONTROL_UNAVAILABLE='Cầu nối local chưa xác nhận thao tác điều khiển lượt đọc. Chưa nhận dữ liệu mới; kiểm tra Panel và kết nối Chrome.';
  SDK_READ_ERRORS.SDK_NOT_LOADED='Base chưa tải xong bảng cho Order; đợi bảng tải xong rồi bấm Nạp lại. Chưa nhận dữ liệu mới.';
  SDK_READ_ERRORS.SDK_UNSUPPORTED='Base SDK chưa hỗ trợ thao tác đọc này trên view hiện tại; chưa nhận dữ liệu mới.';
  SDK_READ_ERRORS.SDK_PARAMETER='Base SDK từ chối tham số của thao tác đọc; cần kiểm tra tương thích reader, chưa nhận dữ liệu mới.';
  SDK_READ_ERRORS.SDK_HOST_NOT_READY='Khung phần mở rộng Base chưa sẵn sàng cho thao tác đọc; chưa nhận dữ liệu mới.';
  SDK_READ_ERRORS.SDK_UNKNOWN='Base SDK báo lỗi nội bộ ở thao tác đọc; chưa nhận dữ liệu mới.';
  SDK_READ_ERRORS.SDK_LIMIT='Thao tác đọc vượt giới hạn Base SDK; chưa nhận bản thiếu.';
  // Only a bounded SDK number and a fixed operation label may accompany a
  // reader error. Never forward its message prefix, request data or stack.
  function sdkDiagnostic(value){var descriptor=value&&Object.getOwnPropertyDescriptor(value,'message'),message=descriptor&&Object.prototype.hasOwnProperty.call(descriptor,'value')?descriptor.value:null;if(typeof message!=='string'||message.length>700||/[\x00-\x1f\x7f]/.test(message))return '';var operation='selection|source-url|table|field-meta|view|view-meta|view-filter|visible-records|bulk-records|cell-string|cell-value|event-subscription',match=new RegExp('\\[SDK (?:(102\\d{5})(?:; ('+operation+'))?|('+operation+'))\\]$').exec(message);return match?' '+match[0]:'';}
  // Compatibility with already-open R48 frames which sent fixed reader text
  // without its code. Exact local literals only; never display received text.
  var SDK_READ_LITERALS={"Chọn một view trong Base trước khi bấm Nạp ở Photoshop.":"NO_VIEW","SDK chưa trả giá trị ô dạng chuỗi. Chưa nạp dữ liệu để tránh sai nội dung.":"CELL_FORMAT","Một ô dữ liệu vượt giới hạn hoặc chứa ký tự không hợp lệ.":"CELL_LIMIT","Nguồn view Base chưa được xác nhận.":"BASE_IDENTITY","Cấu hình view vượt giới hạn xác minh.":"VIEW_CONFIG","Cấu hình view chưa trả dữ liệu tường minh.":"VIEW_CONFIG","Cấu hình view chưa đầy đủ.":"VIEW_CONFIG","SDK chưa xác nhận metadata của đúng view.":"VIEW_CONFIG","SDK chưa xác nhận bộ lọc tường minh của view.":"VIEW_CONFIG","Lượt xác minh cấu hình view trước chưa kết thúc.":"VIEW_CONFIG_BUSY","Chưa có bộ đọc Base hợp lệ.":"SDK_VERSION","Cần SDK đọc đúng danh sách view và các ô theo Record ID.":"SDK_VERSION","SDK chưa hỗ trợ phân trang danh sách ID của đúng view.":"SDK_VERSION","Yêu cầu đọc thay đổi không thuộc đúng view.":"DIRTY_REQUEST","Record ID thay đổi trống, trùng hoặc không hợp lệ.":"DIRTY_REQUEST","View vượt số trang cho phép.":"PAGE_INCOMPLETE","Danh sách ID của view không hợp lệ hoặc vượt 5000 dòng.":"PAGE_SCHEMA","ID của view trống, trùng hoặc chưa đầy đủ.":"RECORD_SCHEMA","Số dòng của view chưa khớp.":"PAGE_INCOMPLETE","Thiếu hoặc lặp mã phân trang; chưa nạp view không đầy đủ.":"PAGE_INCOMPLETE","Chưa nhận đủ số dòng của view. Không nạp một phần.":"PAGE_INCOMPLETE","Trang seed ô Base không hợp lệ.":"PAGE_SCHEMA","Record của trang seed trống, trùng hoặc chưa hợp lệ.":"RECORD_SCHEMA","Ô seed chưa trả dữ liệu tường minh.":"RECORD_SCHEMA","Cột Record ID không khớp ID thật của SDK.":"RECORD_SCHEMA","Số record seed vượt tổng SDK xác nhận.":"PAGE_SCHEMA","Mã phân trang seed trống, lặp hoặc chưa hợp lệ.":"PAGE_INCOMPLETE","Cột Record ID không khớp ID thật của SDK; chưa nạp đơn để tránh nhầm record.":"RECORD_SCHEMA","JSON của view vượt 8 MB. Giảm số dòng của view.":"READ_LIMIT"};
  function sdkReadError(value){var code=value&&value.code;if(value&&(code===undefined||code==='BASE_READ')&&typeof value.message==='string'&&Object.prototype.hasOwnProperty.call(SDK_READ_LITERALS,value.message))code=SDK_READ_LITERALS[value.message];if(code==='VIEW_CHANGED')return error('BASE_VIEW_CHANGED','View Base thay đổi trong lúc đọc.');if(typeof code==='string'&&Object.prototype.hasOwnProperty.call(SDK_READ_ERRORS,code))return error('BASE_SDK_'+code,SDK_READ_ERRORS[code]+(/^SDK_/.test(code)?sdkDiagnostic(value):''));return error('BASE_READ','Base SDK báo lỗi đọc; chưa nhận dữ liệu.');}

  function validOrigin(value){try{var u=new URL(value);if(u.username||u.password||u.search||u.hash||u.pathname!=='/'||u.protocol!=='https:'||u.hostname==='localhost'||/^\d+(?:\.\d+){3}$/.test(u.hostname))return false;return u.origin===value;}catch(_){return false;}}
  function canonicalBase(value){try{var u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||!/(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(u.hostname)||u.pathname==='/'||u.pathname.length>1024)return '';return u.origin+u.pathname.replace(/\/$/,'');}catch(_){return '';}}
  function validateTrust(records){if(!Array.isArray(records)||records.length>32)throw new Error('Invalid registry');var bases={},tokens={};return records.map(function(r){if(!r||canonicalBase(r.base)!==r.base||typeof r.token!=='string'||!/^[a-f0-9]{64}$/.test(r.token)||bases[r.base]||tokens[r.token])throw new Error('Invalid registry');bases[r.base]=true;tokens[r.token]=true;return {base:r.base,token:r.token};});}
  function validateSnapshot(s){
    if(!s||s.version!==1||!s.source||!/^https:\/\/[a-z0-9.-]+(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)\//i.test(s.source.url||'')||!/^\w[\w-]{0,159}$/.test(s.source.tableId||'')||!/^\w[\w-]{0,159}$/.test(s.source.viewId||''))throw error('BASE_SNAPSHOT','Nguồn JSON Base không hợp lệ.');
    if(!Number.isInteger(s.count)||s.count<0||s.count>MAX_RECORDS||!Array.isArray(s.rows)||s.rows.length!==s.count+1||!Array.isArray(s.rows[0])||s.rows[0].length!==14)throw error('BASE_SNAPSHOT','JSON không đủ các dòng/cột của view.');
    var header=['Order Number','SKU','Record ID','Product Type','Design Link','Personalized/File','Note','Personalized/Options','Variation','Quantity','Personalized','Name fullprint','Working Status','Listing URL'];
    if(JSON.stringify(s.rows[0])!==JSON.stringify(header))throw error('BASE_SNAPSHOT','Tên cột JSON không khớp cấu trúc đơn.');
    // Authenticate and validate the immutable full view here. Production-field
    // requirements belong to the provider's eligibility-first import preflight.
    var seen={};for(var i=1;i<s.rows.length;i++){var row=s.rows[i];if(!Array.isArray(row)||row.length!==14)throw error('BASE_SNAPSHOT','Thiếu ô trong record.');for(var j=0;j<row.length;j++)if(typeof row[j]!=='string'||row[j].length>100000||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(row[j]))throw error('BASE_SNAPSHOT','Nội dung ô không hợp lệ.');if(!/^\w[\w-]{0,159}$/.test(row[2])||seen[row[2]])throw error('BASE_SNAPSHOT','Record ID trống, trùng hoặc không hợp lệ.');seen[row[2]]=true;}
    if(Buffer.byteLength(JSON.stringify(s),'utf8')>MAX_BYTES)throw error('BASE_SNAPSHOT','JSON Base vượt 8 MB.');
    return s;
  }
  function validateStatusRequest(value){
    if(!value||Object.keys(value).sort().join('|')!=='recordIds|source'||!value.source||!Array.isArray(value.recordIds)||!value.recordIds.length||value.recordIds.length>MAX_RECORDS)throw error('BASE_STATUS_REQUEST','Yêu cầu kiểm tra Working Status không hợp lệ.');
    var s=value.source,seen=Object.create(null);
    if(typeof s!=='object'||Array.isArray(s)||Object.keys(s).sort().join('|')!=='tableId|url|viewId'||typeof s.url!=='string'||s.url.length>4096||typeof s.tableId!=='string'||typeof s.viewId!=='string')throw error('BASE_STATUS_REQUEST','Nguồn Base của đợt đơn chưa xác định. Nạp Base lại.');
    var base=canonicalBase(s.url);
    if(!base||!/^[A-Za-z0-9_-]{1,160}$/.test(s.tableId)||!/^[A-Za-z0-9_-]{1,160}$/.test(s.viewId))throw error('BASE_STATUS_REQUEST','Nguồn Base của đợt đơn chưa xác định. Nạp Base lại.');
    var ids=Array.from(value.recordIds,function(id){if(typeof id!=='string'||!/^[A-Za-z0-9_-]{1,160}$/.test(id)||seen[id])throw error('BASE_STATUS_REQUEST','Record ID trống hoặc trùng.');seen[id]=true;return id;});
    return {source:{url:base,tableId:s.tableId,viewId:s.viewId},recordIds:ids};
  }
  function validateStatusSnapshot(value,request){
    // Cell values and exact loaded-view membership belong to one SDK-verified
    // v3 result. Old v1/v2 replies cannot assert membership; unknown is explicit.
    if(!value||Array.isArray(value)||Object.keys(value).sort().join('|')!=='kind|records|source|version'||value.version!==3||value.kind!=='record-statuses'||!value.source||Array.isArray(value.source)||Object.keys(value.source).sort().join('|')!=='tableId|url|viewId'||typeof value.source.url!=='string'||!Array.isArray(value.records)||value.records.length!==request.recordIds.length||canonicalBase(request.source.url)!==canonicalBase(value.source.url)||request.source.tableId!==value.source.tableId||request.source.viewId!==value.source.viewId)throw error('BASE_SNAPSHOT','Working Status/Design Link/vị trí trong view không khớp nguồn đợt đơn.');
    var wanted=Object.create(null);request.recordIds.forEach(function(id){wanted[id]=true;});
    value.records.forEach(function(row){if(!row||Array.isArray(row)||Object.keys(row).sort().join('|')!=='designLink|recordId|viewMembership|workingStatus'||typeof row.recordId!=='string'||!wanted[row.recordId]||typeof row.workingStatus!=='string'||row.workingStatus.length>256||/[\x00-\x1f\x7f]/.test(row.workingStatus)||typeof row.designLink!=='string'||row.designLink.length>8192||/[\x00-\x1f\x7f]/.test(row.designLink)||typeof row.viewMembership!=='string'||['in','out','unknown'].indexOf(row.viewMembership)<0)throw error('BASE_SNAPSHOT','Kết quả Working Status/Design Link/vị trí trong view thiếu, trùng ID hoặc sai định dạng.');delete wanted[row.recordId];});
    if(Object.keys(wanted).length)throw error('BASE_SNAPSHOT','Kết quả thiếu Record ID; không dùng một phần danh sách để xác nhận view.');
    return {version:3,kind:'record-statuses',source:{url:request.source.url,tableId:request.source.tableId,viewId:request.source.viewId},records:value.records.map(function(row){return{recordId:row.recordId,workingStatus:row.workingStatus,designLink:row.designLink,viewMembership:row.viewMembership};})};
  }
  function validateSource(value){
    if(!value||Array.isArray(value)||Object.keys(value).sort().join('|')!=='tableId|url|viewId'||typeof value.url!=='string'||value.url.length>4096||!canonicalBase(value.url)||typeof value.tableId!=='string'||typeof value.viewId!=='string'||!/^\w[\w-]{0,159}$/.test(value.tableId)||!/^\w[\w-]{0,159}$/.test(value.viewId))throw error('BASE_STATUS_REQUEST','Nguồn Base chưa xác định.');
    var url=new URL(value.url);if(url.searchParams.has('table')&&(url.searchParams.getAll('table').length!==1||url.searchParams.get('table')!==value.tableId)||url.searchParams.has('view')&&(url.searchParams.getAll('view').length!==1||url.searchParams.get('view')!==value.viewId))throw error('BASE_STATUS_REQUEST','URL không khớp bảng/view.');
    return {url:canonicalBase(value.url),tableId:value.tableId,viewId:value.viewId};
  }
  function validateIds(values,limit){var seen=Object.create(null);if(!Array.isArray(values)||values.length>limit)throw error('BASE_STATUS_REQUEST','Danh sách thay đổi vượt giới hạn.');return Array.from(values,function(id){if(typeof id!=='string'||!/^\w[\w-]{0,159}$/.test(id)||seen[id])throw error('BASE_STATUS_REQUEST','ID thay đổi không hợp lệ.');seen[id]=true;return id;});}
  function validateDirty(value){
    var kinds=['record-modify','record-add','record-delete','field','selection','permission','view','unknown','ready','unavailable'];
    if(!value||Array.isArray(value)||Object.keys(value).sort().join('|')!=='fieldIds|full|kinds|recordIds'||typeof value.full!=='boolean'||!Array.isArray(value.kinds)||!value.kinds.length||value.kinds.length>kinds.length||Array.from(value.kinds).some(function(kind,index){return kinds.indexOf(kind)<0||value.kinds.indexOf(kind)!==index;}))throw error('BASE_STATUS_REQUEST','Tín hiệu thay đổi không hợp lệ.');
    return {recordIds:validateIds(value.recordIds,MAX_RECORDS),fieldIds:validateIds(value.fieldIds,1000),kinds:value.kinds.slice(),full:value.full};
  }
  function validateDirtyRequest(value){if(!value||Array.isArray(value)||Object.keys(value).sort().join('|')!=='full|recordIds|source'||typeof value.full!=='boolean')throw error('BASE_STATUS_REQUEST','Yêu cầu đọc view không hợp lệ.');return {source:validateSource(value.source),recordIds:validateIds(value.recordIds,MAX_RECORDS),full:value.full};}
  function createBroker(options){
    options=options||{};var http=options.http||require('http'),crypto=options.crypto||require('crypto'),fs=options.fs||require('fs'),path=options.path||require('path'),now=options.now||Date.now;
    var port=options.port===undefined?17541:options.port,server=null,startPromise=null,pending=null,poll=null,closed=false,owner=null,ownerReady=false,lastSeen=0,ownerBase='',ownerToken='',ownerBuild='',staleBuild=null;
    var token=crypto.randomBytes(32).toString('hex'),origin='',endpoint='',instance=crypto.randomBytes(16).toString('hex'),configuredOrigin=options.origin||'',staticRoot=options.staticRoot||null;
    var requireReaderBinding=options.requireReaderBinding===undefined?!!staticRoot:options.requireReaderBinding===true,ownerDocument='',ownerSource=null,readerEventReady=false,liveRevision=0,liveSource=null,liveAt=0,currentSourceHint=null,ownerExpiry=null,listeners=[];
    var requiredBuild=options.requiredClientBuild===undefined?(staticRoot?CLIENT_BUILD:''):options.requiredClientBuild;
    if(typeof requiredBuild!=='string'||(requiredBuild&&!/^[A-Za-z0-9_-]{1,64}$/.test(requiredBuild)))throw error('CLIENT_VERSION','Phiên bản extension cấu hình không hợp lệ.');
    var trustStore=options.trustStore||null,trusted=[],storeAvailable=false,trustQueue=Promise.resolve(),trustEpoch=0,helloBusy=0;
    // The companion may only open/close the public Order UI. Its credential
    // cannot access reader endpoints, order payloads or reader credentials.
    var launcherStore=options.launcherTrustStore||null,launcherTrusted=[],launcherStoreAvailable=false,launcherBootstrap=crypto.randomBytes(32).toString('hex'),launcherEpoch=0,launcher=null,launcherCommand=null,launcherState='unpaired',launcherError='',launcherQueue=Promise.resolve(),launcherHelloBusy=false,launcherStaleBuild=null;
    var launcherOrigin='chrome-extension://'+LAUNCHER_EXTENSION_ID,metadataTTL=options.launcherMetadataTTL||45000,commandTTL=options.launcherCommandTimeoutMs||20000,readerSessionBases={};
    var standbyAttempts={},standbyAttemptCount=0,launcherStaleAt=0;
    // At most three unsolicited starts for a page, and only a certified
    // zero-action refusal can authorize its next attempt. Normal authenticated
    // metadata polls drive these deadlines; there is no independent retry loop.
    var standbyRetryDelays=[2000,5000],standbyMaxAttempts=3;
    // R31: background reads are private application calls, never new HTTP
    // endpoints. Reserve a call synchronously, including before start() settles.
    var readCall=null,foregroundWaiting=false,manualCallPromise=null;
    function sourceOf(source){return source?{url:source.baseIdentity,tableId:source.tableId,viewId:source.viewId}:null;}
    function status(){var info={started:!!endpoint,connected:connected(),busy:!!pending||!!readCall||foregroundWaiting||!!(launcherCommand&&launcherCommand.value.op==='closeOrder'),eventCapable:true,readerEventReady:readerEventReady&&connected(),liveRevision:liveRevision,liveAt:liveAt,liveSource:liveSource,readerSource:sourceOf(ownerSource),readStage:pending?pending.stage:readCall&&readCall.waitingLauncher?'waitingClose':'',readDetail:pending?pending.detail:'',readElapsedMs:pending?Math.max(0,now()-pending.startedAt):0,readRecords:pending?pending.readRecords:0},version=versionInfo(),launchInfo=launcherInfo();for(var key in version)info[key]=version[key];for(var name in launchInfo)if(name!=='launcherCode')info[name]=launchInfo[name];return info;}
    function publish(event){listeners.slice().forEach(function(listener){try{listener(JSON.parse(JSON.stringify(event)));}catch(_){}});}
    function stateEvent(reason){publish({type:'state',reason:reason,at:now(),status:status()});}
    function touchOwner(){var was=connected();lastSeen=now();if(ownerExpiry!==null)clearTimeout(ownerExpiry);ownerExpiry=setTimeout(function(){ownerExpiry=null;if(!closed&&owner&&!connected())clearOwner('Reader đã hết hạn kết nối; đang tự xác nhận lại phiên trang hiện tại.');},40001);if(ownerExpiry&&typeof ownerExpiry.unref==='function')ownerExpiry.unref();if(!was&&owner)stateEvent('connected');}
    function subscribe(listener){if(typeof listener!=='function')throw error('BASE_CONFIG','Listener Base không hợp lệ.');if(closed)return function(){};listeners.push(listener);var active=true;return function(){if(!active)return;active=false;var index=listeners.indexOf(listener);if(index>=0)listeners.splice(index,1);};}
    function deadline(name,fallback){var value=options[name]===undefined?(options.timeoutMs===undefined?fallback:options.timeoutMs):options[name];if(!Number.isInteger(value)||value<1||value>360000)throw error('BASE_CONFIG','Thời gian chờ Base không hợp lệ.');return value;}
    var metadataWaitMs=deadline('metadataTimeoutMs',10000),coldMetadataWaitMs=options.coldMetadataTimeoutMs===undefined&&options.metadataTimeoutMs!==undefined?metadataWaitMs:deadline('coldMetadataTimeoutMs',45000),readerWaitMs=deadline('readerConnectTimeoutMs',10000),readIdleMs=deadline('readIdleTimeoutMs',20000),readMaxMs=deadline('readTimeoutMs',120000),progressEveryMs=5000;
    if(configuredOrigin&&!validOrigin(configuredOrigin))throw error('BASE_ORIGIN','Origin extension phải là HTTPS chính xác, không kèm path.');
    function matches(a,b){return crypto.timingSafeEqual(Buffer.from(a,'ascii'),Buffer.from(b,'ascii'));}
    function authentication(value){if(typeof value!=='string'||!/^Bearer [a-f0-9]{64}$/.test(value))return null;var secret=value.slice(7);if(matches(secret,token))return {token:secret,base:''};for(var i=0;i<trusted.length;i++)if(matches(secret,trusted[i].token))return {token:secret,base:trusted[i].base};return null;}
    function sameSecret(value){return !!authentication(value);}
    function launcherAuthentication(value){if(typeof value!=='string'||!/^Bearer [a-f0-9]{64}$/.test(value))return null;var secret=value.slice(7);if(matches(secret,launcherBootstrap))return {token:secret,base:''};for(var i=0;i<launcherTrusted.length;i++)if(matches(secret,launcherTrusted[i].token))return {token:secret,base:launcherTrusted[i].base};return null;}
    function launcherStoreOperation(fn){var result=launcherQueue.then(fn);launcherQueue=result.catch(function(){});return result;}
    function readerAllowsBase(base){return trusted.some(function(r){return r.base===base;})||readerSessionBases[base]===true||connected()&&ownerBase===base;}
    function launcherFresh(){return !!launcher&&!launcher.paused&&!!launcher.metadata&&now()-launcher.lastSeen<metadataTTL&&readerAllowsBase(launcher.base)&&launcher.build===LAUNCHER_BUILD;}
    function launcherInfo(){return {launcherCode:JSON.stringify({version:1,role:'uoy-base-launcher',endpoint:endpoint,token:launcherBootstrap,extensionId:LAUNCHER_EXTENSION_ID}),launcherExtensionId:LAUNCHER_EXTENSION_ID,launcherConnected:launcherFresh(),launcherRememberedBases:launcherTrusted.length,launcherRememberAvailable:launcherStoreAvailable,launcherState:launcherState,launcherError:launcherError,requiredLauncherBuild:LAUNCHER_BUILD,launcherClientBuild:launcher?launcher.build:(launcherStaleBuild||''),launcherCompatible:launcherStaleBuild!==null?false:launcher?launcher.build===LAUNCHER_BUILD:null};}
    function launcherVersionError(){var e=error('LAUNCHER_VERSION','UOY Base Companion đang chạy bản '+(launcherStaleBuild||'không rõ')+'; cần '+LAUNCHER_BUILD+'. Bấm Tải lại UOY Base Companion trong trang tiện ích Chrome rồi thử lại. Ghép nối vẫn được giữ.');e.clientBuild=launcherStaleBuild||'';e.requiredClientBuild=LAUNCHER_BUILD;e.launcherClientBuild=e.clientBuild;e.requiredLauncherBuild=LAUNCHER_BUILD;return e;}
    function calibrationError(){return error('BASE_COMPANION_CALIBRATION','UOY Base Companion chưa được dạy đủ nút mở/đóng Order trên máy này. Mở popup tiện ích Chrome và thiết lập thanh công cụ, Order, quay lại danh sách và X danh sách cho Base đang dùng. Có thể mở Order bằng tay để Nạp qua SDK trong lúc thiết lập. Ghép nối Base đã lưu vẫn được giữ.');}
    // R27: named, authenticated local diagnostics only. Never accept a URL,
    // snapshot, Chrome exception text or selected view from this channel.
    function chromeDiagnostic(code){
      var values={
        CHROME_API_TIMEOUT:['BASE_CHROME_TIMEOUT','Chrome chưa trả phản hồi kiểm tra tab đúng hạn. Companion sẽ tự nối lại; giữ tab Base mở và Nạp lại sau vài giây.'],
        TAB_REQUIRED:['BASE_CHROME_TAB','Companion chưa thấy tab Base đã ghép. Mở đúng Base trong cùng hồ sơ Chrome đã cài Companion, rồi chọn view.'],
        MULTIPLE_TABS:['BASE_CHROME_MULTIPLE_TABS','Có nhiều tab Base nhưng chưa có nguồn được xác nhận. Chọn tab Base cần dùng một lần; sau đó có thể chuyển sang tab Chrome khác. Không cần mở Tùy chỉnh hay ghép lại.'],
        VIEW_REQUIRED:['BASE_CHROME_VIEW','Tab Base chưa xác định được table/view trong URL. Chọn view cần nạp và đợi Companion tự xác nhận lại.'],
        PERMISSION:['BASE_CHROME_PERMISSION','Chrome chưa cấp quyền cho Companion ở Base này. Bạn kiểm tra quyền của tiện ích trên đúng Base; tool không tự đổi quyền hay ghép nối.'],
        CONTENT_UNAVAILABLE:['BASE_CHROME_CONTENT','Bộ kiểm tra tab Chrome chưa phản hồi. Companion sẽ tự nối lại, không cần mở/đóng phần mở rộng Order.'],
        CONTENT_VERSION:['BASE_CHROME_CONTENT_VERSION','Mã kiểm tra trong tab Base còn là bản cũ. Lưu thao tác rồi tải lại riêng tab Base một lần; không cần ghép lại tiện ích.'],
        VIEW_CHANGED:['BASE_CHROME_VIEW_CHANGED','Base/view đang chuyển trong lúc kiểm tra. Đợi view ổn định rồi Nạp lại; chưa đọc dữ liệu cũ.']
      };
      return Object.prototype.hasOwnProperty.call(values,code)?error(values[code][0],values[code][1]):null;
    }
    // Only named outcomes cross the application IPC boundary. Raw browser/DOM
    // exceptions are never relayed as instructions or as customer data.
    function launcherResultError(value){
      var values={
        VIEW_CHANGED:['BASE_CHROME_VIEW_CHANGED','Base/table/view hoặc phiên trang nguồn đã thực sự đổi trong lúc đọc. Chưa nhận dữ liệu cũ; Nạp lại để xác nhận nguồn mới.'],
        CALIBRATION:['BASE_COMPANION_ROUTE','Chưa xác định được duy nhất nút mở Order trong giao diện Base. Ghép nối vẫn còn; kiểm tra Companion, không cần mở lại cài đặt kết nối.'],
        UI_AMBIGUOUS:['BASE_COMPANION_AMBIGUOUS','Có nhiều nút hoặc khung Order phù hợp. Chưa bấm nhầm hoặc nhận dữ liệu; cần giữ một khung Order cho tab nguồn.'],
        AMBIGUOUS:['BASE_COMPANION_AMBIGUOUS','Có nhiều nút hoặc khung Order phù hợp. Chưa bấm nhầm hoặc nhận dữ liệu; cần giữ một khung Order cho tab nguồn.'],
        FOREIGN_SIDEBAR:['BASE_COMPANION_FOREIGN_UI','Một khung web khác đang che giao diện Order. Tool không đóng hoặc điều khiển khung khác; đóng khung đó rồi Nạp lại.'],
        OCCLUDED:['BASE_COMPANION_OCCLUDED','Nút Order bị hộp thoại hoặc giao diện khác che. Tool chưa bấm; xử lý hộp thoại đó rồi Nạp lại.'],
        DOM_TIMEOUT:['BASE_COMPANION_DOM_TIMEOUT','Giao diện Base chưa mở/thu gọn Order đúng hạn. Không bấm lặp thao tác chưa rõ kết quả; ghép nối vẫn được giữ.'],
        READER_REMOVED:['BASE_COMPANION_READER_REMOVED','Base đã dừng reader Order khi thu gọn. Chưa nhận bản thiếu; Companion sẽ xác nhận lại khi Nạp lần tiếp theo.'],
        READER_OWNERSHIP:['BASE_COMPANION_READER_OWNER','Chưa xác minh được reader thuộc đúng tab nguồn. Đã giữ nguyên khung Order, không đóng khung ở tab khác.'],
        STANDBY_HIDDEN:['BASE_COMPANION_STANDBY','Đã bỏ qua tự khởi động khi tab Base bị ẩn. Nạp thủ công và quét nền vẫn có thể dùng tab nguồn đã xác nhận.'],
        CONTENT_UNAVAILABLE:['BASE_CHROME_CONTENT','Tab nguồn chưa phản hồi Companion. Chưa thử bấm lặp; ghép nối và dữ liệu cũ vẫn được giữ.'],
        READER_BINDING:['BASE_READER_BINDING','Reader chưa xác minh thuộc đúng trang/view Base đã chọn. Chưa nhận dữ liệu của tab khác; ghép nối vẫn được giữ.'],
        CANCELLED:['BASE_CANCELLED','Thao tác Companion đã được dừng; chưa nhận dữ liệu mới.']
      },entry=value&&Object.prototype.hasOwnProperty.call(values,value.code)?values[value.code]:null;
      return entry?error(entry[0],entry[1]):error('BASE_LAUNCHER','Companion chưa xác minh được thao tác mở/thu gọn Order. Ghép nối vẫn còn; không bấm lặp thao tác chưa rõ kết quả.');
    }
    function launcherFailure(code,message){launcherState='error';launcherError=message;cancelLauncherCommand(error(code,message));if(pending&&(pending.expectedSource||pending.waitingMetadata||pending.waitingOpen))finish(error(code,message));}
    function recoverHiddenStandby(command,value){
      // STANDBY_HIDDEN is a definitive no-action result. A user-requested read
      // may replace its adopted warmup with one explicit, source-bound open.
      // Never replay uncertain DOM actions, background reads or another page.
      if(!pending||pending.kind!=='manual'||pending.delivered||pending.adoptCommandId!==command.commandId||command.op!=='openOrder'||command.purpose!=='standby'||!value||value.code!=='STANDBY_HIDDEN'||value.noAction!==true)return false;
      if(pending.expectedSource&&!exactPageSource(command,pending.expectedSource))return false;
      cancelLauncherCommand(null);pending.adoptCommandId='';pending.adoptedOpenDone=false;
      if(pending.expectedSource){
        if(requireReaderBinding)issueReaderBinding(pending.expectedSource);
        pending.waitingOpen=true;armPhase('opening',commandTTL,'BASE_LAUNCHER_TIMEOUT','Chrome chưa mở được Order đúng hạn.');
        if(!queueLauncherCommand('openOrder',pending.expectedSource))launcherFailure('BASE_LAUNCHER_NOT_READY','Chrome companion chưa sẵn sàng.');
      }
      // Before fresh metadata, retain the original metadata deadline. Its next
      // authenticated poll chooses the exact source and issues the explicit open.
      return true;
    }
    function cancelLauncherCommand(reason){if(launcherCommand){var command=launcherCommand;clearTimeout(command.timer);launcherCommand=null;var result=reason===null?null:reason||error('BASE_CANCELLED','Thao tác Companion đã bị hủy; chưa xác minh trạng thái mới.');command.waiters.splice(0).forEach(function(done){done(result);});stateEvent('idle');}}
    function queueLauncherCommand(op,source,purpose){if(!launcherFresh())return false;if(launcherCommand)return false;var command={commandId:crypto.randomBytes(16).toString('hex'),instance:instance,op:op,baseIdentity:source.baseIdentity,tableId:source.tableId,viewId:source.viewId,deadline:now()+commandTTL};if(source.pageId)command.pageId=source.pageId;if(purpose==='standby'){if(op!=='openOrder'||!/^[a-f0-9]{32}$/.test(source.pageId||''))return false;command.purpose='standby';}else if(op==='openOrder'&&pending&&pending.readerBinding&&exactPageSource(source,pending.expectedSource)){command.readerBinding=Object.assign({},pending.readerBinding);}launcherCommand={value:command,client:launcher.client,token:launcher.token,waiters:[],timer:setTimeout(function(){launcherFailure('BASE_LAUNCHER_TIMEOUT','Chrome chưa mở/đóng được Order đúng hạn. Kiểm tra tab Base và tiện ích UOY Base Companion rồi bấm Nạp lại.');},commandTTL)};launcherState=op==='openOrder'?'opening':'closing';launcherError='';return true;}
    function waitForLauncherClose(call){
      if(closed)return Promise.reject(error('BASE_CLOSED','Cầu nối đã đóng.'));
      if(call.cancelRequested)return Promise.reject(error('BASE_CANCELLED','Đã hủy lượt xác minh Base.'));
      var command=launcherCommand;
      if(!command||command.value.op!=='closeOrder')return Promise.resolve();
      // A completed SDK read is not the end of the companion lifecycle. Wait
      // for this exact close ACK under its ORIGINAL deadline; never replay,
      // cancel or extend an uncertain DOM operation to make another read fit.
      return new Promise(function(resolve,reject){
        var ended=false,timer;
        function done(reason){if(ended)return;ended=true;clearTimeout(timer);var index=command.waiters.indexOf(done);if(index>=0)command.waiters.splice(index,1);if(call.closeWaitCancel===cancel)call.closeWaitCancel=null;call.waitingLauncher=false;if(reason)reject(reason);else resolve();}
        function cancel(reason){done(reason||error('BASE_CANCELLED','Đã hủy lượt chờ xác minh Base.'));}
        call.waitingLauncher=true;call.closeWaitCancel=cancel;command.waiters.push(done);
        timer=setTimeout(function(){done(error('BASE_LAUNCHER_TIMEOUT','Companion chưa xác nhận thu gọn Order đúng hạn; chưa dùng dữ liệu cũ để Save.'));},Math.max(1,command.value.deadline-now()));
      });
    }
    function exactSource(a,b){return !!a&&!!b&&a.baseIdentity===b.baseIdentity&&a.tableId===b.tableId&&a.viewId===b.viewId;}
    function exactPageSource(a,b){return exactSource(a,b)&&(!a.pageId||a.pageId===b.pageId);}
    function readerReadyFor(source){return connected()&&(!requireReaderBinding||!!ownerDocument&&!!ownerSource&&exactPageSource(source,ownerSource)&&source.pageId===ownerSource.pageId&&(!pending||!pending.readerBinding||pending.bindingClient===owner&&pending.bindingDocument===ownerDocument));}
    function issueReaderBinding(source){if(!pending||!/^[a-f0-9]{32}$/.test(source.pageId||''))throw error('BASE_READER_BINDING','Chưa xác nhận được phiên trang để gắn Reader.');pending.readerBinding={version:1,nonce:crypto.randomBytes(32).toString('hex'),instance:instance,requestId:pending.id,expiresAt:now()+30000,baseIdentity:source.baseIdentity,tableId:source.tableId,viewId:source.viewId,pageId:source.pageId};pending.bindingClient='';pending.bindingDocument='';}
    function bindingError(req,value,client,auth){
      var doc=value&&value.readerDocument,header=req.headers['x-uoy-reader-document'],ticket=value&&value.readerBinding;
      if(requireReaderBinding||doc!==undefined||header!==undefined||ticket!==undefined){if(typeof doc!=='string'||!/^[a-f0-9]{32}$/.test(doc)||header!==doc)return 'READER_BINDING_INVALID';}
      var same=owner===client&&ownerToken===auth.token&&ownerDocument===doc;
      if(ticket!==undefined){
        if(!ticket||typeof ticket!=='object'||Array.isArray(ticket)||Object.keys(ticket).sort().join(',')!=='baseIdentity,expiresAt,instance,nonce,pageId,requestId,tableId,version,viewId')return 'READER_BINDING_INVALID';
        var expected=pending&&pending.readerBinding;
        if(!expected||pending.delivered||ticket.expiresAt<=now()||ticket.expiresAt>now()+30000||!Number.isSafeInteger(ticket.expiresAt))return 'READER_BINDING_EXPIRED';
        if(typeof ticket.nonce!=='string'||!/^[a-f0-9]{64}$/.test(ticket.nonce)||!matches(ticket.nonce,expected.nonce)||Object.keys(expected).some(function(k){return k!=='nonce'&&ticket[k]!==expected[k];})||ticket.baseIdentity!==value.baseIdentity||auth.base&&auth.base!==ticket.baseIdentity)return 'READER_BINDING_INVALID';
        if(pending.bindingClient&&(pending.bindingClient!==client||pending.bindingDocument!==doc))return 'READER_BINDING_INVALID';
      }else if(requireReaderBinding&&pending&&pending.expectedSource&&(!same||!readerReadyFor(pending.expectedSource)))return 'READER_BINDING_REQUIRED';
      else if(requireReaderBinding&&ownerSource&&!same)return 'READER_NOT_SELECTED';
      return '';
    }
    function readLauncherMetadata(value){if(!value||value.ready!==true||canonicalBase(value.baseIdentity)!==value.baseIdentity||!/^\w[\w-]{0,159}$/.test(value.tableId||'')||!/^\w[\w-]{0,159}$/.test(value.viewId||''))throw error('BASE_METADATA','Chưa xác định được duy nhất tab/view Base.');var u;try{u=new URL(value.url);}catch(_){throw error('BASE_METADATA','URL Base không hợp lệ.');}if(canonicalBase(value.url)!==value.baseIdentity||u.searchParams.getAll('table').length!==1||u.searchParams.getAll('view').length!==1||u.searchParams.get('table')!==value.tableId||u.searchParams.get('view')!==value.viewId)throw error('BASE_METADATA','URL Base không khớp table/view.');var metadata={baseIdentity:value.baseIdentity,tableId:value.tableId,viewId:value.viewId};if(requireReaderBinding&&value.pageId===undefined)throw error('BASE_METADATA','Companion chưa xác nhận được phiên trang để gắn Reader.');if(value.pageId!==undefined){if(typeof value.pageId!=='string'||!/^[a-f0-9]{32}$/.test(value.pageId))throw error('BASE_METADATA','Phiên trang Base không hợp lệ.');metadata.pageId=value.pageId;}if(value.documentVisible!==undefined){if(typeof value.documentVisible!=='boolean')throw error('BASE_METADATA','Trạng thái hiển thị trang Base không hợp lệ.');metadata.documentVisible=value.documentVisible;}return metadata;}
    function standbyKey(source){return source.baseIdentity+'|'+source.tableId+'|'+source.viewId+'|'+source.pageId;}
    function rearmUnusedStandby(command,value){
      // Called only after the result route authenticates the exact live
      // command, owner and page. Never infer no-action from an error name or
      // timeout, and never release an uncertain/partially-clicked operation.
      var codes=['CALIBRATION','UI_AMBIGUOUS','OCCLUDED','FOREIGN_SIDEBAR','STANDBY_HIDDEN'];
      if(!command||command.op!=='openOrder'||command.purpose!=='standby'||!value||value.noAction!==true||codes.indexOf(value.code)<0||!launcherFresh()||!exactPageSource(command,launcher.metadata))return false;
      var entry=standbyAttempts[standbyKey(command)];
      if(!entry||entry.commandId!==command.commandId||entry.retryable||entry.attempts>=standbyMaxAttempts)return false;
      entry.retryable=true;entry.retryAt=now()+standbyRetryDelays[entry.attempts-1];return true;
    }
    // R71: remembered pairing and authenticated metadata are passive. Only an
    // explicit application read may open Order and close its own read after
    // completion. Idle polls/hello must never warm or collapse the Base UI.
    function forgetLauncherPairings(){return start().then(function(){var count=launcherTrusted.length;launcherEpoch++;launcherTrusted=[];launcherBootstrap=crypto.randomBytes(32).toString('hex');launcher=null;launcherStaleBuild=null;launcherState='unpaired';launcherError='';cancelLauncherCommand();if(pending&&(pending.expectedSource||pending.waitingMetadata))finish(error('BASE_LAUNCHER_REVOKED','Đã quên ghép nối Chrome.'));return launcherStoreOperation(function(){if(launcherStore)launcherStore.clear();launcherStoreAvailable=!!launcherStore;return {cleared:count};}).catch(function(){throw error('BASE_STORE','Chưa xóa được ghép nối Chrome mã hóa trên máy.');});});}
    function storeOperation(fn){var result=trustQueue.then(fn);trustQueue=result.catch(function(){});return result;}
    function compatible(build){return !requiredBuild||build===requiredBuild;}
    function versionError(){return error('CLIENT_VERSION','Extension Order ở Lark vẫn đang chạy bản '+(staleBuild||ownerBuild||'cũ')+'. Chỉ cho lần cập nhật này: bấm X ngay ở tiêu đề Order rồi mở lại UOY Order để tải bản '+requiredBuild+'; quay về danh sách rồi ẩn danh sách sẽ giữ bản cũ. Không cần dán mã hay ghép nối lại nếu chưa bấm Quên. Không đóng trang Base.');}
    function versionInfo(){return {serverBuild:CLIENT_BUILD,requiredClientBuild:requiredBuild,clientBuild:owner?ownerBuild:(staleBuild===null?'':staleBuild),clientCompatible:owner?compatible(ownerBuild):(staleBuild===null?null:false)};}
    function clearOwner(message){owner=null;ownerReady=false;ownerBase='';ownerToken='';ownerBuild='';ownerDocument='';ownerSource=null;readerEventReady=false;currentSourceHint=null;lastSeen=0;if(ownerExpiry!==null)clearTimeout(ownerExpiry);ownerExpiry=null;rejectPoll();if(!pending||!pending.waitingReader||pending.delivered)finish(error('BASE_DISCONNECTED',message||'Extension Base đã ngắt kết nối.'));stateEvent('disconnected');}
    function revokeAll(){var count=trusted.length;trustEpoch++;trusted=[];readerSessionBases={};token=crypto.randomBytes(32).toString('hex');staleBuild=null;cancelLauncherCommand();finish(error('BASE_DISCONNECTED','Đã quên ghép nối Base. Kết nối lại trước khi Nạp.'));clearOwner('Đã quên ghép nối Base. Kết nối lại trước khi Nạp.');return count;}
    function forgetRememberedPairings(){return start().then(function(){var count=revokeAll();return storeOperation(function(){if(trustStore)trustStore.clear();storeAvailable=!!trustStore;return {cleared:count};}).catch(function(){throw error('BASE_STORE','Đã ngắt phiên hiện tại nhưng chưa xóa được ghép nối lưu trên máy. Kiểm tra quyền thư mục dữ liệu UOY rồi thử lại.');});});}
    function acceptHello(req,res,requestOrigin,client,auth,value){
      if(!authentication('Bearer '+auth.token)){answer(res,401,{error:'AUTH'},requestOrigin);return;}
      var version=value&&value.version===2?2:1,base='',remember=false,epoch=trustEpoch,clientBuild='';
      if(version===2){base=canonicalBase(value.baseIdentity);if(!base||base!==value.baseIdentity||typeof value.remember!=='boolean'){answer(res,400,{error:'BASE_IDENTITY'},requestOrigin);return;}remember=value.remember;}
      if(value&&typeof value.clientBuild==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(value.clientBuild))clientBuild=value.clientBuild;
      if(auth.base&&(version!==2||base!==auth.base)){answer(res,403,{error:'BASE_IDENTITY'},requestOrigin);return;}
      if(pending&&pending.expectedSource&&base!==pending.expectedSource.baseIdentity){answer(res,403,{error:'BASE_IDENTITY'},requestOrigin);return;}
      if(requireReaderBinding&&!compatible(clientBuild)){answer(res,409,{error:'CLIENT_VERSION',requiredClientBuild:requiredBuild,message:'Reader và cầu nối khác phiên bản. Nạp lại mã Reader sau cập nhật; không cần xóa ghép nối.'},requestOrigin);return;}
      var proofError=bindingError(req,value,client,auth);if(proofError){answer(res,409,{error:proofError,message:'Reader này chưa được chọn cho đúng trang/view đang đọc; ghép nối vẫn được giữ.'},requestOrigin);return;}
      // A bootstrap hello queued before this read cannot starve the selected
      // ticket holder. The trust queue serializes both; each revalidates proof
      // just before mutation. Bound concurrency remains deliberately small.
      if(helloBusy&&(!value||!value.readerBinding)||helloBusy>=4){answer(res,409,{error:'CONNECT_BUSY'},requestOrigin);return;}
      if(connected()&&(owner!==client||ownerDocument!==(value&&value.readerDocument||''))&&!(pending&&pending.waitingReader&&!pending.delivered)){answer(res,409,{error:'OTHER_EXTENSION'},requestOrigin);return;}
      helloBusy++;
      storeOperation(function(){
        if(closed||epoch!==trustEpoch||!authentication('Bearer '+auth.token))throw error('REVOKED','Revoked');
        var queuedProofError=bindingError(req,value,client,auth);if(queuedProofError)throw error(queuedProofError,'Reader proof is no longer current.');
        var entry=null,persistent=false;
        if(version===2&&remember&&storeAvailable){
          for(var i=0;i<trusted.length;i++)if(trusted[i].base===base)entry=trusted[i];
          if(!entry){if(trusted.length>=32)throw error('TRUST_LIMIT','Trust limit');entry={base:base,token:crypto.randomBytes(32).toString('hex')};var next=trusted.concat([entry]);try{trustStore.save(next);trusted=next;persistent=true;}catch(_){storeAvailable=false;entry=null;}}
          else persistent=true;
        }
        if(closed||epoch!==trustEpoch)throw error('REVOKED','Revoked');
        var lateProofError=bindingError(req,value,client,auth);if(lateProofError)throw error(lateProofError,'Reader proof is no longer current.');
        var documentId=value&&value.readerDocument||'',proof=value&&value.readerBinding,keepProof=owner===client&&ownerDocument===documentId&&ownerToken===auth.token;
        if(owner!==client||ownerDocument!==documentId){ownerReady=false;rejectPoll();if(!pending||!pending.waitingReader||pending.delivered)finish(error('BASE_RECONNECTED','Base extension vừa đổi kết nối. Bấm Nạp lại.'));}
        owner=client;ownerBase=base;ownerToken=persistent?entry.token:auth.token;ownerBuild=clientBuild;ownerDocument=documentId;ownerSource=proof?Object.assign({},pending.expectedSource):(keepProof?ownerSource:null);readerEventReady=false;if(!keepProof)currentSourceHint=null;staleBuild=compatible(clientBuild)?null:clientBuild;touchOwner();stateEvent('connected');
        if(proof){pending.bindingClient=client;pending.bindingDocument=documentId;}
        if(base)readerSessionBases[base]=true;
        // A reader reopened for Nạp must stay visible on read failure; do not
        // mistake it for the first manual connection and auto-close it later.
        if(pending&&pending.expectedSource&&launcher)launcher.closedReader=client;
        if(staleBuild!==null){rejectPoll();finish(versionError());}
        var payload={ok:true,instance:instance,remembered:persistent,serverBuild:CLIENT_BUILD,requiredClientBuild:requiredBuild,clientCompatible:compatible(clientBuild)};
        if(proof){payload.readerBindingAccepted=true;payload.readerDocument=documentId;payload.bindingRequestId=proof.requestId;}
        if(persistent)payload.trust={version:2,endpoint:endpoint,token:entry.token,baseIdentity:base};
        answer(res,200,payload,requestOrigin);
        if(!finishSourceReconciliation()){deliver();}
      }).catch(function(e){var safeCode=['READER_BINDING_INVALID','READER_BINDING_EXPIRED','READER_BINDING_REQUIRED','READER_NOT_SELECTED'].indexOf(e.code)>=0?e.code:e.code==='TRUST_LIMIT'?'TRUST_LIMIT':'REVOKED';answer(res,safeCode==='REVOKED'?403:409,{error:safeCode},requestOrigin);}).then(function(){helloBusy=Math.max(0,helloBusy-1);});
    }
    function finish(err,value){if(!pending)return;var p=pending;pending=null;clearTimeout(p.timer);clearTimeout(p.hardTimer);if(err){if(p.expectedSource)cancelLauncherCommand();p.reject(err);}else p.resolve(value);}
    function armPhase(stage,ms,code,message){if(!pending)return;var request=pending;clearTimeout(request.timer);request.stage=stage;request.timer=setTimeout(function(){if(pending===request)finish(stage==='waitingMetadata'&&launcherStaleBuild!==null&&now()-launcherStaleAt<metadataTTL?launcherVersionError():error(code,message));},ms);}
    function waitingReader(){armPhase('waitingReader',readerWaitMs,'BASE_READER_TIMEOUT','Order chưa kết nối SDK hoặc chưa gửi yêu cầu đọc sau khi mở. Giữ tab Base đã đăng nhập; mở lại UOY Order để tải bản '+requiredBuild+' rồi bấm Nạp lại. Ghép nối đã lưu vẫn được giữ.');}
    function unboundManual(request){return !!request&&request.kind==='manual'&&!request.statusRequest&&request.waitingMetadata&&!request.expectedSource&&!request.delivered&&!request.waitingOpen&&!launcherCommand;}
    function beginExpectedSource(metadata){
      if(!pending)return;
      if(pending.statusRequest&&!exactSource({baseIdentity:canonicalBase(pending.statusRequest.source.url),tableId:pending.statusRequest.source.tableId,viewId:pending.statusRequest.source.viewId},metadata)){launcherFailure('BASE_VIEW_CHANGED','Nguồn Base hiện tại khác đợt đơn đã nạp. Chưa cập nhật Working Status từ tab khác.');return;}
      if(pending.dirtyRequest){
        var requested=pending.dirtyRequest.source,scope={baseIdentity:requested.url,tableId:requested.tableId,viewId:requested.viewId};
        if(pending.requiredPageId&&metadata.pageId!==pending.requiredPageId){launcherFailure('BASE_VIEW_CHANGED','Phiên trang không khớp nguồn đang theo dõi. Chưa nhận dữ liệu tab khác.');return;}
        if(!exactSource(scope,metadata)){
          // Chrome identifies only a candidate. Resolve an unmounted reader's
          // old-view/new-view deadlock using a fresh SDK ownership ticket; never
          // deliver the new view's rows to the old request. Different tables and
          // Bases still require the user's explicit import.
          if(!requireReaderBinding||scope.baseIdentity!==metadata.baseIdentity||scope.tableId!==metadata.tableId){launcherFailure('BASE_VIEW_CHANGED','View không khớp nguồn đang theo dõi. Chưa nhận dữ liệu bảng khác.');return;}
          pending.reconcileSource=sourceOf(scope);
        }
      }
      if(pending.baseHint&&pending.baseHint!==metadata.baseIdentity){launcherFailure('BASE_IDENTITY','Tab Base đã đổi trong lúc Nạp.');return;}
      if(!requireReaderBinding&&connected()&&ownerBase!==metadata.baseIdentity){launcherFailure('BASE_IDENTITY','Order đang mở ở Base khác tab Chrome được ghép.');return;}
      pending.expectedSource=Object.assign({},metadata);pending.waitingMetadata=false;
      // Reuse only a source-bound SDK-ready reader actively waiting on its
      // authenticated long poll. A cached connected flag alone is insufficient.
      var reuseBound=!pending.reconcileSource&&requireReaderBinding&&readerReadyFor(metadata)&&readerEventReady&&poll&&!poll.res.destroyed&&!poll.res.writableEnded;
      pending.reusedReader=!!reuseBound;
      pending.waitingReader=!reuseBound&&(requireReaderBinding||!readerReadyFor(metadata));
      if(requireReaderBinding&&!reuseBound)issueReaderBinding(metadata);
      var adopting=launcherCommand&&pending.adoptCommandId===launcherCommand.value.commandId&&launcherCommand.value.purpose==='standby'&&exactPageSource(launcherCommand.value,metadata);
      pending.waitingOpen=!reuseBound&&(requireReaderBinding||!!adopting||pending.waitingReader&&!pending.adoptedOpenDone);
      if(pending.waitingOpen){armPhase('opening',commandTTL,'BASE_LAUNCHER_TIMEOUT','Chrome chưa mở được Order đúng hạn. Kiểm tra tab Base và các nút mở Order trong UOY Base Companion rồi bấm Nạp lại.');if(!adopting&&!queueLauncherCommand('openOrder',pending.expectedSource))launcherFailure('BASE_LAUNCHER_NOT_READY','Chrome companion chưa sẵn sàng.');}
      else{launcher.closedReader=owner;waitingReader();deliver();}
    }
    function finishSourceReconciliation(){
      if(!pending||!pending.reconcileSource||pending.reconcileAck!==true||!pending.readerBinding||!readerReadyFor(pending.expectedSource))return false;
      var previous=pending.reconcileSource,current=sourceOf(ownerSource);
      liveRevision++;if(!Number.isSafeInteger(liveRevision))liveRevision=1;
      liveSource=current;liveAt=now();currentSourceHint={source:current,pageId:ownerSource.pageId,document:ownerDocument};
      // Only the authenticated SDK hello plus the matching completed page
      // command can emit this candidate. No records or customer cells cross it.
      publish({type:'dirty',revision:liveRevision,at:liveAt,source:previous,currentSource:current,dirty:{recordIds:[],fieldIds:[],kinds:['selection'],full:true}});
      finish(error('BASE_VIEW_CHANGED','Đã xác nhận view mới bằng SDK; đang tự đồng bộ lại đúng nguồn, không cần mở Order bằng tay.'));
      launcherState='ready';return true;
    }
    function beginReading(){if(!pending)return;var request=pending;request.statusRevision=liveRevision;request.readStartedAt=now();request.detail='initializing';armPhase('reading',readIdleMs,'BASE_READ_TIMEOUT','SDK Base chưa trả tiến trình đọc. Kiểm tra Order còn mở và tab Base đã đăng nhập rồi bấm Nạp lại. Đợt đơn cũ vẫn được giữ.');request.hardTimer=setTimeout(function(){if(pending===request)finish(error('BASE_READ_DEADLINE','View Base chưa đọc xong trong thời gian cho phép. Giảm số dòng trong view hoặc thử lại. Đợt đơn cũ vẫn được giữ.'));},readMaxMs);}
    function connected(){return !!owner&&now()-lastSeen<40000;}
    function answer(res,status,payload,requestOrigin){if(res.destroyed||res.writableEnded)return;var headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};if(requestOrigin&&(requestOrigin===origin||requestOrigin===configuredOrigin||requestOrigin===launcherOrigin)){headers['Access-Control-Allow-Origin']=requestOrigin;headers.Vary='Origin';}res.writeHead(status,headers);res.end(JSON.stringify(payload));}
    function deliver(){if(!pending||pending.reconcileSource||pending.delivered||!poll||!connected()||pending.waitingOpen||pending.waitingMetadata||pending.expectedSource&&(!readerReadyFor(pending.expectedSource)||ownerBase!==pending.expectedSource.baseIdentity))return;if(requireReaderBinding&&!pending.expectedSource){finish(error('BASE_READER_BINDING','Chưa xác nhận nguồn và phiên trang của Reader; chưa gửi yêu cầu đọc SDK.'));return;}var p=poll;poll=null;clearTimeout(p.timer);var job={requestId:pending.id,instance:instance,op:'readCurrentView',requiredClientBuild:requiredBuild,progressEveryMs:progressEveryMs,readTimeoutMs:readMaxMs};if(pending.statusRequest){job.op='readRecordStatuses';job.statusRequest=pending.statusRequest;}else if(pending.dirtyRequest)job.dirtyRequest=pending.dirtyRequest;if(pending.expectedSource){job.expectedSource={baseIdentity:pending.expectedSource.baseIdentity,tableId:pending.expectedSource.tableId,viewId:pending.expectedSource.viewId};launcherState='reading';}pending.delivered=true;pending.waitingReader=false;pending.readerClient=owner;pending.readerDocument=ownerDocument;beginReading();answer(p.res,200,job,p.origin);}
    function rejectPoll(){if(poll){var old=poll;poll=null;clearTimeout(old.timer);answer(old.res,200,{idle:true},old.origin);}}
    function body(req,cb,limit){var chunks=[],size=0,finished=false;req.on('data',function(chunk){if(finished)return;size+=chunk.length;if(size>(limit||MAX_BYTES+4096)){finished=true;cb(error('BODY_LIMIT','Payload quá lớn.'));req.destroy();}else chunks.push(chunk);});req.on('end',function(){if(finished)return;try{cb(null,JSON.parse(Buffer.concat(chunks,size).toString('utf8')));}catch(_){cb(error('BODY_JSON','JSON không hợp lệ.'));}});req.on('error',function(){if(!finished){finished=true;cb(error('BODY_READ','Không nhận đủ payload.'));}});}
    function launcherRoute(req,res,requestOrigin){
      var paths=['/launcher/v1/hello','/launcher/v1/poll','/launcher/v1/result','/launcher/v1/forget','/launcher/v1/state'];
      if(paths.indexOf(req.url)<0){answer(res,404,{error:'PATH'},requestOrigin);return;}
      var auth=launcherAuthentication(req.headers.authorization),noOrigin=req.headers.origin===undefined&&req.headers['sec-fetch-site']==='none'&&req.headers['sec-fetch-mode']==='cors'&&req.headers['sec-fetch-dest']==='empty'&&!!auth;
      if(requestOrigin!==launcherOrigin&&!noOrigin){answer(res,403,{error:'ORIGIN'},'');return;}
      if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':launcherOrigin,'Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type, X-Uoy-Client','Access-Control-Allow-Private-Network':'true','Access-Control-Max-Age':'300','Vary':'Origin','Cache-Control':'no-store'});res.end();return;}
      if(!auth){answer(res,401,{error:'AUTH'},requestOrigin);return;}
      var client=req.headers['x-uoy-client'];if(typeof client!=='string'||!/^[a-f0-9]{32}$/.test(client)){answer(res,403,{error:'CLIENT'},requestOrigin);return;}
      if(req.method!=='POST'){answer(res,405,{error:'METHOD'},requestOrigin);return;}
      if(!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||'')){answer(res,415,{error:'TYPE'},requestOrigin);return;}
      if(Number(req.headers['content-length']||0)>8192){answer(res,413,{error:'BODY_LIMIT'},requestOrigin);return;}
      body(req,function(err,value){
        if(err){answer(res,400,{error:err.code},requestOrigin);return;}
        if(!value||Buffer.byteLength(JSON.stringify(value),'utf8')>8192){answer(res,400,{error:'BODY_LIMIT'},requestOrigin);return;}
        if(req.url==='/launcher/v1/hello'){
          var base=canonicalBase(value.baseIdentity),epoch=launcherEpoch;
          if(value.version!==1||value.extensionId!==LAUNCHER_EXTENSION_ID||value.remember!==true||!base||base!==value.baseIdentity||auth.base&&auth.base!==base){answer(res,400,{error:'BASE_IDENTITY'},requestOrigin);return;}
          if(!readerAllowsBase(base)){answer(res,403,{error:'READER_NOT_PAIRED'},requestOrigin);return;}
          if(pending&&pending.baseHint&&base!==pending.baseHint){answer(res,403,{error:'BASE_IDENTITY'},requestOrigin);return;}
          if(launcherHelloBusy||launcher&&launcher.client!==client&&now()-launcher.lastSeen<40000){answer(res,409,{error:'OTHER_LAUNCHER'},requestOrigin);return;}
          if(value.clientBuild!==LAUNCHER_BUILD){var observed=typeof value.clientBuild==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(value.clientBuild)?value.clientBuild:'unknown';if(!launcherFresh()){launcherStaleBuild=observed;launcherStaleAt=now();launcherState='waiting';launcherError=launcherVersionError().message;}answer(res,409,{error:'LAUNCHER_VERSION',clientBuild:observed,requiredClientBuild:LAUNCHER_BUILD,message:'Companion '+observed+'; cần '+LAUNCHER_BUILD+'. Ghép nối vẫn được giữ.'},requestOrigin);return;}
          launcherStaleBuild=null;
          launcherHelloBusy=true;
          launcherStoreOperation(function(){if(closed||epoch!==launcherEpoch||!launcherAuthentication('Bearer '+auth.token)||!readerAllowsBase(base))throw error('REVOKED','Revoked');var entry=null,persistent=false;
            if(launcherStoreAvailable&&trusted.some(function(r){return r.base===base;})){entry=launcherTrusted.find(function(r){return r.base===base;});if(!entry){if(launcherTrusted.length>=32)throw error('TRUST_LIMIT','Trust limit');entry={base:base,token:crypto.randomBytes(32).toString('hex')};var next=launcherTrusted.concat([entry]);try{launcherStore.save(next);launcherTrusted=next;persistent=true;}catch(_){launcherStoreAvailable=false;entry=null;}}else persistent=true;}
            if(closed||epoch!==launcherEpoch)throw error('REVOKED','Revoked');
            if(launcher&&(launcher.client!==client||launcher.base!==base)){cancelLauncherCommand();if(pending&&pending.expectedSource)finish(error('BASE_LAUNCHER_CHANGED','Chrome companion vừa đổi kết nối. Bấm Nạp lại.'));}
            var resolvedToken=persistent?entry.token:auth.token;
            if(!launcher||launcher.client!==client||launcher.base!==base||launcher.token!==resolvedToken){launcher={client:client,token:resolvedToken,base:base,build:value.clientBuild,lastSeen:now(),metadata:null,closedReader:null};launcherState='waiting';launcherError='';}
            var payload={ok:true,instance:instance,remembered:persistent,serverBuild:CLIENT_BUILD,requiredClientBuild:LAUNCHER_BUILD};if(persistent)payload.trust={version:1,role:'uoy-base-launcher',endpoint:endpoint,token:entry.token,baseIdentity:base,extensionId:LAUNCHER_EXTENSION_ID};answer(res,200,payload,requestOrigin);
          }).catch(function(e){answer(res,e.code==='TRUST_LIMIT'?409:403,{error:e.code||'REVOKED'},requestOrigin);}).then(function(){launcherHelloBusy=false;});return;
        }
        if(req.url==='/launcher/v1/forget'){
          if(!auth.base){answer(res,403,{error:'BASE_IDENTITY'},requestOrigin);return;}var forgotten=auth.base,secret=auth.token,forgetEpoch=launcherEpoch;
          launcherStoreOperation(function(){if(forgetEpoch!==launcherEpoch)throw error('REVOKED','Revoked');var next=launcherTrusted.filter(function(r){return r.base!==forgotten||r.token!==secret;});if(launcherStore)launcherStore.save(next);launcherTrusted=next;if(launcher&&launcher.base===forgotten){launcher=null;launcherState='unpaired';cancelLauncherCommand();}if(pending&&(pending.expectedSource&&pending.expectedSource.baseIdentity===forgotten||pending.waitingMetadata&&pending.baseHint===forgotten))finish(error('BASE_LAUNCHER_REVOKED','Đã quên ghép nối Chrome.'));answer(res,200,{ok:true},requestOrigin);}).catch(function(){answer(res,500,{error:'TRUST_STORE'},requestOrigin);});return;
        }
        // A retained Companion can be between hello and metadata poll when
        // Photoshop restarts. Only an already saved, reader-approved Base may
        // receive this recovery hint. It never establishes a launcher owner,
        // applies metadata, returns a command, or revives revoked credentials.
        if(req.url==='/launcher/v1/poll'&&!launcher&&auth.base&&readerAllowsBase(auth.base)){
          if(canonicalBase(value.baseIdentity)!==value.baseIdentity||value.baseIdentity!==auth.base){answer(res,400,{error:'BASE_IDENTITY'},requestOrigin);return;}
          if(value.paused===true){if(value.ready!==false){answer(res,400,{error:'BASE_METADATA'},requestOrigin);return;}}
          else if(value.ready===false&&value.calibrationReady===false){
            var restartSteps=['toolbar','order','back','listClose'],restartMissing=value.missingSteps;
            if(!Array.isArray(restartMissing)||!restartMissing.length||restartMissing.length>restartSteps.length||restartMissing.some(function(step,index){return restartSteps.indexOf(step)<0||restartMissing.indexOf(step)!==index;})){answer(res,400,{error:'BASE_METADATA'},requestOrigin);return;}
          }else{try{readLauncherMetadata(value);}catch(restartError){answer(res,400,{error:restartError.code},requestOrigin);return;}}
          answer(res,409,{error:'SESSION_RESTARTED',message:'Photoshop vừa mở lại. Companion sẽ tự kết nối bằng ghép nối đã lưu của đúng Base; không cần dán mã mới.'},requestOrigin);return;
        }
        if(!launcher||launcher.client!==client||launcher.token!==auth.token||!readerAllowsBase(launcher.base)){answer(res,403,{error:'CLIENT'},requestOrigin);return;}
        if(req.url==='/launcher/v1/state'){
          var diagnostic=chromeDiagnostic(value.diagnosticCode),fields=Object.keys(value);
          if(value.ready!==false||canonicalBase(value.baseIdentity)!==value.baseIdentity||value.baseIdentity!==launcher.base||!diagnostic||fields.length!==3||fields.some(function(name){return ['baseIdentity','ready','diagnosticCode'].indexOf(name)<0;})){answer(res,400,{error:'BASE_DIAGNOSTIC'},requestOrigin);return;}
          if(launcherCommand||pending&&(pending.delivered||pending.expectedSource)){answer(res,409,{error:'STATE_BUSY'},requestOrigin);return;}
          if(pending&&(pending.baseHint&&pending.baseHint!==launcher.base||pending.expectedSource&&pending.expectedSource.baseIdentity!==launcher.base)){answer(res,409,{error:'BASE_IDENTITY'},requestOrigin);return;}
          var stabilizing=value.diagnosticCode==='VIEW_CHANGED'&&unboundManual(pending);
          // Before any source/page/job is bound, an explicit manual import can
          // wait for Chrome's fresh selection proof under its ORIGINAL timer.
          // This acknowledgement releases only an obsolete Companion lock;
          // it does not grant a source, a command, rows or a new read attempt.
          var releaseLock=value.diagnosticCode==='VIEW_CHANGED'&&(!pending||stabilizing);
          launcher.metadata=null;launcher.lastSeen=now();launcher.diagnosticCode=value.diagnosticCode;launcherState=stabilizing?'waiting':'error';launcherError=diagnostic.message;
          if(pending&&pending.waitingMetadata&&!stabilizing)finish(diagnostic);
          var diagnosticAck={idle:true,instance:instance};if(releaseLock)diagnosticAck.sourceLocked=false;
          answer(res,200,diagnosticAck,requestOrigin);return;
        }
        if(req.url==='/launcher/v1/poll'){
          if(value.selectionFresh!==undefined&&typeof value.selectionFresh!=='boolean'){answer(res,400,{error:'BASE_METADATA'},requestOrigin);return;}
          if(value.paused===true){
            if(value.ready!==false||value.baseIdentity!==launcher.base){answer(res,400,{error:'BASE_IDENTITY'},requestOrigin);return;}
            launcher.paused=true;launcher.metadata=null;launcher.lastSeen=now();cancelLauncherCommand();if(pending&&(pending.waitingMetadata||pending.expectedSource))finish(error('BASE_LAUNCHER_PAUSED','UOY Base Companion đang tạm dừng. Mở Order thủ công hoặc bật lại tiện ích trước khi Nạp.'));launcherState='paused';launcherError='';answer(res,200,{idle:true,instance:instance},requestOrigin);return;
          }
          if(value.ready===false&&value.calibrationReady===false){
            var steps=['toolbar','order','back','listClose'],missing=value.missingSteps;
            if(value.baseIdentity!==launcher.base||!Array.isArray(missing)||!missing.length||missing.length>steps.length||missing.some(function(step,index){return steps.indexOf(step)<0||missing.indexOf(step)!==index;})){answer(res,400,{error:'BASE_METADATA'},requestOrigin);return;}
            launcher.needsSetup=true;launcher.paused=false;launcher.metadata=null;launcher.lastSeen=now();var setupError=calibrationError();launcherFailure(setupError.code,setupError.message);launcherState='needsSetup';answer(res,200,{idle:true,instance:instance},requestOrigin);return;
          }
          var metadata;try{metadata=readLauncherMetadata(value);if(metadata.baseIdentity!==launcher.base)throw error('BASE_IDENTITY','Base đã đổi.');}catch(e){launcherFailure(e.code,e.message);launcher.metadata=null;answer(res,400,{error:e.code},requestOrigin);return;}
          // A new Nạp/watch may arrive just after an older read completes.
          // A poll pinned by the OLD read must not choose the NEW read's tab.
          // Ask R32 to refresh its active/bound choice before binding this job;
          // older launchers omit the optional bit and keep their old contract.
          if(pending&&pending.waitingMetadata&&value.selectionFresh===false){
            launcher.lastSeen=now();
            answer(res,200,{idle:true,instance:instance,sourceLocked:false,refreshSelection:true},requestOrigin);return;
          }
          if(pending&&pending.expectedSource&&!exactPageSource(pending.expectedSource,metadata)){launcherFailure('BASE_VIEW_CHANGED','View hoặc phiên trang Base đã đổi trong lúc Nạp. Bấm Nạp lại để đọc view mới.');launcher.metadata=metadata;launcher.lastSeen=now();answer(res,409,{error:'BASE_VIEW_CHANGED'},requestOrigin);return;}
          if(launcherCommand&&!exactPageSource(launcherCommand.value,metadata)){launcherFailure('BASE_VIEW_CHANGED','Tab/view hoặc phiên trang Base đã đổi trước khi mở Order.');launcher.metadata=metadata;launcher.lastSeen=now();answer(res,409,{error:'BASE_VIEW_CHANGED'},requestOrigin);return;}
          launcher.needsSetup=false;launcher.paused=false;launcher.diagnosticCode='';launcher.metadata=metadata;launcher.lastSeen=now();if(!launcherCommand){launcherState=pending?'reading':'ready';}
          if(pending&&pending.waitingMetadata){
            if(pending.baseHint&&pending.baseHint!==metadata.baseIdentity){launcherFailure('BASE_IDENTITY','Tab Base đã đổi trong lúc Nạp.');answer(res,409,{error:'BASE_IDENTITY'},requestOrigin);return;}
            if(!requireReaderBinding&&connected()&&ownerBase!==metadata.baseIdentity){launcherFailure('BASE_IDENTITY','Order đang mở ở Base khác tab Chrome được ghép.');answer(res,409,{error:'BASE_IDENTITY'},requestOrigin);return;}
            beginExpectedSource(metadata);
          }
          // Optional R32 hint: a launcher may refresh its selected tab only
          // BETWEEN reads. This bit conveys no rows or application identity.
          // Older launchers ignore it; every metadata poll is still validated.
          answer(res,200,launcherCommand?Object.assign({sourceLocked:true},launcherCommand.value):{idle:true,instance:instance,sourceLocked:!!pending},requestOrigin);return;
        }
        if(!launcherCommand||value.commandId!==launcherCommand.value.commandId||value.instance!==instance||launcherCommand.client!==client||launcherCommand.token!==auth.token||now()>launcherCommand.value.deadline){answer(res,409,{error:'STALE_COMMAND'},requestOrigin);return;}
        if(!launcherFresh()||!exactPageSource(launcherCommand.value,launcher.metadata)){launcherFailure('BASE_VIEW_CHANGED','Tab/view hoặc phiên trang Base đã đổi trước khi xác nhận thao tác Order.');answer(res,409,{error:'BASE_VIEW_CHANGED'},requestOrigin);return;}
        var command=launcherCommand.value;if(value.ok!==true&&value.ok!==false){answer(res,400,{error:'RESULT'},requestOrigin);return;}
        if(value.ok===false){if(!recoverHiddenStandby(command,value.error)){rearmUnusedStandby(command,value.error);var reportedError=launcherResultError(value.error);launcherFailure(reportedError.code,reportedError.message);}answer(res,200,{ok:true},requestOrigin);return;}
        cancelLauncherCommand(null);
        if(command.op==='openOrder'){if(pending&&pending.adoptCommandId===command.commandId)pending.adoptedOpenDone=true;if(pending&&exactPageSource(pending.expectedSource,command)){
          if(pending.reconcileSource)pending.reconcileAck=true;
          if(requireReaderBinding&&!readerReadyFor(pending.expectedSource)&&!command.readerBinding){issueReaderBinding(pending.expectedSource);pending.waitingOpen=true;armPhase('opening',commandTTL,'BASE_READER_BINDING','Reader chưa xác nhận đúng trang Base.');if(!queueLauncherCommand('openOrder',pending.expectedSource))finish(error('BASE_READER_BINDING','Chưa gửi được xác minh Reader.'));}
          else if(!finishSourceReconciliation()){pending.waitingOpen=false;launcherState='reading';waitingReader();deliver();}
        }else launcherState='ready';}
        else launcherState='ready';answer(res,200,{ok:true},requestOrigin);
      },8192);
    }
    function route(req,res){
      var host=req.headers.host,requestOrigin=req.headers.origin||'',expectedHost='127.0.0.1:'+port;
      if(host!==expectedHost){answer(res,403,{error:'HOST'},'');return;}
      if(req.url.indexOf('/launcher/')===0){launcherRoute(req,res,requestOrigin);return;}
      if(req.method==='GET'&&req.url.indexOf('/extension')===0){
        var files={'/extension/':'index.html','/extension/index.html':'index.html','/extension/extension.js':'extension.js','/extension/reader-adapter.js':'reader-adapter.js','/extension/reader-ownership.js':'reader-ownership.js','/extension/reader-live-status.js':'reader-live-status.js','/extension/extension.css':'extension.css','/extension/extension.js.LEGAL.txt':'extension.js.LEGAL.txt'},queryAt=req.url.indexOf('?'),assetPath=queryAt<0?req.url:req.url.slice(0,queryAt),query=queryAt<0?'':req.url.slice(queryAt),name=files[assetPath];
        if(query&&((name!=='extension.js'&&name!=='extension.css'&&name!=='reader-adapter.js'&&name!=='reader-ownership.js'&&name!=='reader-live-status.js')||!/^\?v=[a-f0-9]{64}$/.test(query))){answer(res,404,{error:'NO_EXTENSION'},'');return;}
        if(!name||!staticRoot){answer(res,404,{error:'NO_EXTENSION'},'');return;}
        try{var target=path.join(staticRoot,name),stat=fs.lstatSync(target);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>5*1024*1024)throw new Error();var bytes=fs.readFileSync(target);if(query&&query.slice(3)!==crypto.createHash('sha256').update(bytes).digest('hex'))throw new Error();res.writeHead(200,{'Content-Type':/\.html$/.test(name)?'text/html; charset=utf-8':/\.css$/.test(name)?'text/css; charset=utf-8':/\.txt$/.test(name)?'text/plain; charset=utf-8':'application/javascript; charset=utf-8','Cache-Control':'no-store','X-Uoy-Client-Build':CLIENT_BUILD,'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"frame-ancestors https://*.larksuite.com https://*.feishu.cn https://*.larkoffice.com"});res.end(bytes);}catch(_){answer(res,404,{error:'NO_EXTENSION'},'');}return;
      }
      // Browsers omit Origin on a same-origin GET. A retained iframe can make
      // its next poll before a restarted Photoshop broker has any owner. Only
      // a saved, Base-scoped reader credential may receive a reconnect signal;
      // this response never establishes ownership or returns a job/rows.
      // Actual poll delivery still requires an already accepted, exact owner.
      // Opaque/null, cross-site, bootstrap, unauthenticated and other paths fail.
      var sameOriginPoll=req.method==='GET'&&req.url==='/v1/poll'&&req.headers.origin===undefined&&req.headers['sec-fetch-site']==='same-origin'&&req.headers['sec-fetch-mode']==='cors'&&req.headers['sec-fetch-dest']==='empty'&&typeof req.headers['x-uoy-client']==='string'&&/^[a-f0-9]{32}$/.test(req.headers['x-uoy-client']);
      var pollAuth=sameOriginPoll?authentication(req.headers.authorization):null;
      if(sameOriginPoll&&owner===null&&pollAuth&&pollAuth.base){answer(res,409,{error:'SESSION_RESTARTED',message:'Photoshop vừa mở lại. Reader sẽ tự kết nối bằng ghép nối đã lưu của đúng Base; không cần dán mã mới.'},'');return;}
      // A saved same-Base spectator also needs a neutral ownership refusal,
      // not a misleading ORIGIN error. Authentication + exact owner/document
      // checks below remain mandatory before any job can be returned.
      var noOriginPoll=sameOriginPoll&&!!pollAuth&&(!!pollAuth.base||typeof owner==='string'&&req.headers['x-uoy-client']===owner);
      if(!noOriginPoll&&requestOrigin!==origin&&(!configuredOrigin||requestOrigin!==configuredOrigin)){answer(res,403,{error:'ORIGIN'},'');return;}
      if(req.method==='OPTIONS'){
        if(['/v1/hello','/v1/poll','/v1/result','/v1/progress','/v1/disconnect','/v1/forget','/v1/status-dirty'].indexOf(req.url)<0){answer(res,404,{error:'PATH'},requestOrigin);return;}
        res.writeHead(204,{'Access-Control-Allow-Origin':requestOrigin,'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type, X-Uoy-Client, X-Uoy-Reader-Document','Access-Control-Allow-Private-Network':'true','Access-Control-Max-Age':'300','Vary':'Origin','Cache-Control':'no-store'});res.end();return;
      }
      var auth=authentication(req.headers.authorization);if(!auth){answer(res,401,{error:'AUTH'},requestOrigin);return;}
      var client=req.headers['x-uoy-client'];if(typeof client!=='string'||!/^[a-f0-9]{32}$/.test(client)){answer(res,403,{error:'CLIENT'},requestOrigin);return;}
      if(req.method==='POST'&&req.url==='/v1/hello'){
        if(/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||'')){body(req,function(err,value){if(err){answer(res,400,{error:err.code},requestOrigin);return;}if(!value||value.version!==2){answer(res,400,{error:'BASE_IDENTITY'},requestOrigin);return;}acceptHello(req,res,requestOrigin,client,auth,value);});}else acceptHello(req,res,requestOrigin,client,auth,null);return;
      }
      if(req.method==='POST'&&req.url==='/v1/forget'){
        if(!auth.base){answer(res,403,{error:'BASE_IDENTITY'},requestOrigin);return;}
        var revokedBase=auth.base,revokedToken=auth.token,epoch=trustEpoch;
        delete readerSessionBases[revokedBase];
        if(pending&&(pending.expectedSource&&pending.expectedSource.baseIdentity===revokedBase||pending.waitingMetadata&&pending.baseHint===revokedBase)){cancelLauncherCommand();finish(error('BASE_DISCONNECTED','Đã quên ghép nối Base đang đọc.'));}
        if(ownerBase===revokedBase&&ownerToken===revokedToken)clearOwner('Đã quên ghép nối của Base này.');
        storeOperation(function(){if(epoch!==trustEpoch)throw new Error('Registry changed');var next=trusted.filter(function(r){return r.base!==revokedBase||r.token!==revokedToken;});if(trustStore&&next.length!==trusted.length)trustStore.save(next);trusted=next;answer(res,200,{ok:true},requestOrigin);}).catch(function(){answer(res,500,{error:'TRUST_STORE'},requestOrigin);});return;
      }
      if(owner!==client||ownerToken!==auth.token){answer(res,403,{error:requireReaderBinding?'READER_NOT_SELECTED':'CLIENT'},requestOrigin);return;}
      if(ownerDocument&&req.headers['x-uoy-reader-document']!==ownerDocument){answer(res,403,{error:'READER_NOT_SELECTED'},requestOrigin);return;}touchOwner();
      if(req.method==='POST'&&req.url==='/v1/status-dirty'){
        if(!compatible(ownerBuild)||!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||'')){answer(res,409,{error:'CLIENT_VERSION'},requestOrigin);return;}
        body(req,function(err,value){
          var dirty,source,candidate,healthOnly;try{if(err||!value||Object.keys(value).some(function(key){return ['instance','source','dirty','currentSource','eventReady'].indexOf(key)<0;}))throw error('BASE_STATUS_REQUEST','Tín hiệu không hợp lệ.');source=validateSource(value.source);dirty=value.dirty===undefined?{recordIds:[],fieldIds:[],kinds:['unknown'],full:true}:validateDirty(value.dirty);candidate=value.currentSource===undefined?null:validateSource(value.currentSource);healthOnly=dirty.kinds.length===1&&dirty.kinds[0]==='ready'&&!dirty.recordIds.length&&!dirty.fieldIds.length&&!dirty.full;if(value.eventReady!==undefined&&(typeof value.eventReady!=='boolean'||value.eventReady===true&&!healthOnly||value.eventReady===false&&(dirty.kinds.length!==1||dirty.kinds[0]!=='unavailable'||!dirty.full))||healthOnly&&value.eventReady!==true||dirty.kinds.indexOf('unavailable')>=0&&value.eventReady!==false)throw error('BASE_STATUS_REQUEST','SDK event health không hợp lệ.');}catch(_){answer(res,400,{error:'BASE_STATUS_REQUEST'},requestOrigin);return;}
          if(owner!==client||ownerToken!==auth.token||!compatible(ownerBuild)||ownerDocument&&req.headers['x-uoy-reader-document']!==ownerDocument||value.instance!==instance||!ownerSource||!exactSource(ownerSource,{baseIdentity:source.url,tableId:source.tableId,viewId:source.viewId})||candidate&&(candidate.url!==ownerSource.baseIdentity||dirty.kinds.indexOf('selection')<0&&dirty.kinds.indexOf('view')<0)){answer(res,409,{error:'STALE_REQUEST'},requestOrigin);return;}
          if(value.eventReady!==undefined){readerEventReady=value.eventReady;if(healthOnly){stateEvent('ready');answer(res,200,{ok:true},requestOrigin);return;}}
          liveRevision++;if(!Number.isSafeInteger(liveRevision))liveRevision=1;liveSource=sourceOf(ownerSource);liveAt=now();var event={type:'dirty',revision:liveRevision,at:liveAt,source:liveSource,dirty:dirty};if(candidate){event.currentSource=candidate;currentSourceHint={source:candidate,pageId:ownerSource.pageId,document:ownerDocument};}publish(event);if(value.eventReady===false)stateEvent('ready');answer(res,200,{ok:true},requestOrigin);
        },1024*1024);return;
      }
      if((req.url==='/v1/poll'||req.url==='/v1/result'||req.url==='/v1/progress')&&!compatible(ownerBuild)){staleBuild=ownerBuild;answer(res,409,{error:'CLIENT_VERSION',requiredClientBuild:requiredBuild,clientBuild:ownerBuild,message:versionError().message},requestOrigin);return;}
      if(req.method==='GET'&&req.url==='/v1/poll'){
        ownerReady=true;rejectPoll();poll={res:res,origin:requestOrigin,timer:setTimeout(function(){if(poll&&poll.res===res){poll=null;answer(res,200,{idle:true},requestOrigin);}},25000)};res.on('close',function(){if(poll&&poll.res===res){clearTimeout(poll.timer);poll=null;if(!res.writableEnded)clearOwner('Kết nối reader đã ngắt; đang tự xác nhận lại trang Base.');}});deliver();return;
      }
      if(req.method==='POST'&&req.url==='/v1/progress'){
        if(!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||'')){answer(res,415,{error:'TYPE'},requestOrigin);return;}
        if(Number(req.headers['content-length']||0)>2048){answer(res,413,{error:'BODY_LIMIT'},requestOrigin);return;}
        body(req,function(err,value){
          if(err){answer(res,400,{error:err.code},requestOrigin);return;}
          if(!pending||!pending.delivered||!value||value.requestId!==pending.id||value.instance!==instance||pending.readerClient!==client||pending.readerDocument!==ownerDocument||ownerDocument&&req.headers['x-uoy-reader-document']!==ownerDocument){answer(res,409,{error:'STALE_REQUEST'},requestOrigin);return;}
          if(!Number.isInteger(value.readRecords)||value.readRecords<0||value.readRecords>MAX_RECORDS||['initializing','metadata','reading','validating','sending'].indexOf(value.phase)<0||value.readRecords<pending.readRecords){answer(res,400,{error:'PROGRESS'},requestOrigin);return;}
          // Cancellation is cooperative: the authenticated reader fences its
          // current SDK await, posts the cancelled result, then polls again.
          // Do not discard a delivered job and wait its full 120-second budget.
          if(pending.cancelRequested){answer(res,200,{ok:true,cancelled:true},requestOrigin);return;}
          pending.readRecords=value.readRecords;pending.detail=value.phase;
          armPhase('reading',readIdleMs,'BASE_READ_TIMEOUT','SDK Base đã ngừng trả tiến trình đọc. Kiểm tra Order còn mở và tab Base đã đăng nhập rồi bấm Nạp lại. Đợt đơn cũ vẫn được giữ.');answer(res,200,{ok:true},requestOrigin);
        },2048);return;
      }
      if(req.method==='POST'&&req.url==='/v1/result'){
        if(!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']||'')){answer(res,415,{error:'TYPE'},requestOrigin);return;}
        body(req,function(err,value){if(err){answer(res,400,{error:err.code},requestOrigin);return;}if(!pending||!pending.delivered||!value||value.requestId!==pending.id||value.instance!==instance){answer(res,409,{error:'STALE_REQUEST'},requestOrigin);return;}
          if(pending.readerClient!==client||pending.readerDocument!==ownerDocument||ownerDocument&&req.headers['x-uoy-reader-document']!==ownerDocument){answer(res,409,{error:'STALE_REQUEST'},requestOrigin);return;}
          if(pending.cancelRequested){finish(error('BASE_CANCELLED','Đã dừng lượt đọc nền để ưu tiên Nạp.'));answer(res,200,{ok:true,cancelled:true},requestOrigin);return;}
          // A readiness POST may commit before its response times out. Most
          // failed jobs revoke that flag synchronously; a late HTTP ACK cannot
          // revive it. The narrow already-dirty exception below preserves only
          // listener health, never the rejected snapshot or an old receipt.
          if(value.error){
            // Snapshot validity and listener health are separate. An exact
            // background VIEW_CHANGED rejection may keep an already-ready
            // source-bound listener only after an authenticated dirty revision
            // has independently fenced every old data receipt. Never turn a
            // false flag back on, accept failed rows, or borrow another page.
            var keepEventHealth=value.error.code==='VIEW_CHANGED'&&
              pending.kind==='background'&&!pending.statusRequest&&requireReaderBinding&&
              readerEventReady===true&&pending.readerClient===owner&&pending.readerDocument===ownerDocument&&
              pending.expectedSource&&readerReadyFor(pending.expectedSource)&&
              launcherFresh()&&exactPageSource(pending.expectedSource,launcher.metadata)&&
              Number.isSafeInteger(pending.statusRevision)&&liveRevision!==pending.statusRevision&&
              liveSource&&exactSource(pending.expectedSource,{baseIdentity:canonicalBase(liveSource.url),tableId:liveSource.tableId,viewId:liveSource.viewId});
            if(!keepEventHealth)readerEventReady=false;
            finish(sdkReadError(value.error));stateEvent('ready');answer(res,200,{ok:true},requestOrigin);return;
          }
          if(pending.statusRequest&&pending.statusRevision!==liveRevision){finish(error('BASE_STATUS_CHANGED','Base vừa thay đổi trong lúc xác minh Working Status. Chưa gửi file; đợi trạng thái ổn định rồi thử lại.'));answer(res,200,{ok:true,discarded:true},requestOrigin);return;}
          try{var validated=pending.statusRequest?validateStatusSnapshot(value.snapshot,pending.statusRequest):validateSnapshot(value.snapshot);if(ownerBase&&canonicalBase(validated.source.url)!==ownerBase)throw error('BASE_IDENTITY','Base đã đổi. Xác nhận ghép nối với Base mới trước khi Nạp.');if(pending.dirtyRequest&&!exactSource({baseIdentity:pending.dirtyRequest.source.url,tableId:pending.dirtyRequest.source.tableId,viewId:pending.dirtyRequest.source.viewId},{baseIdentity:canonicalBase(validated.source.url),tableId:validated.source.tableId,viewId:validated.source.viewId}))throw error('BASE_VIEW_CHANGED','Kết quả không khớp view đang theo dõi.');var expected=pending.expectedSource,reused=pending.reusedReader;if(expected&&(!launcherFresh()||!readerReadyFor(expected)||!exactPageSource(expected,launcher.metadata)||!exactSource(expected,{baseIdentity:canonicalBase(validated.source.url),tableId:validated.source.tableId,viewId:validated.source.viewId})))throw error('BASE_VIEW_CHANGED','View Base đã đổi hoặc Chrome không còn xác nhận được tab nguồn. Bấm Nạp lại.');finish(null,validated);answer(res,200,{ok:true},requestOrigin);if(expected&&!reused)queueLauncherCommand('closeOrder',expected);}catch(e){finish(e);answer(res,400,{error:e.code},requestOrigin);}
        });return;
      }
      if(req.method==='POST'&&req.url==='/v1/disconnect'){clearOwner();answer(res,200,{ok:true},requestOrigin);return;}
      answer(res,404,{error:'PATH'},requestOrigin);
    }
    function start(){if(closed)return Promise.reject(error('BASE_CLOSED','Cầu nối đã đóng.'));if(startPromise)return startPromise;startPromise=storeOperation(function(){if(trustStore){try{trusted=validateTrust(trustStore.load());storeAvailable=true;}catch(_){trusted=[];storeAvailable=false;}}if(launcherStore){try{launcherTrusted=validateTrust(launcherStore.load());launcherStoreAvailable=true;}catch(_){launcherTrusted=[];launcherStoreAvailable=false;}}}).then(function(){if(closed)throw error('BASE_CLOSED','Cầu nối đã đóng.');return new Promise(function(resolve,reject){server=http.createServer(route);server.requestTimeout=30000;server.headersTimeout=30000;server.keepAliveTimeout=1000;server.once('error',function(e){startPromise=null;server=null;reject(error('BASE_PORT',e.code==='EADDRINUSE'?'Cổng Base đang được phiên panel khác dùng. Đóng panel cũ rồi thử lại.':'Không mở được cầu nối Base local.'));});server.listen(port,'127.0.0.1',function(){port=server.address().port;endpoint='http://127.0.0.1:'+port;origin=endpoint;resolve();});});});return startPromise;}
    function readCurrentView(call){return start().then(function(){
        if(call&&call.cancelRequested)throw error('BASE_CANCELLED','Đã hủy lượt quét nền.');
        if(pending)throw error('BASE_BUSY','Đang đọc Base view.');
        // Expired ownership is revoked, not reused as an eternal old-page
        // fence. Recovery still needs a fresh authenticated Companion poll and
        // a new exact SDK ticket; live owners keep their page guard unchanged.
        if(owner&&!connected())clearOwner('Reader cũ đã hết hạn; đang xác minh lại đúng trang Base.');
        if(call&&call.dirtyRequest&&ownerSource){var requested=call.dirtyRequest.source,same=exactSource(ownerSource,{baseIdentity:requested.url,tableId:requested.tableId,viewId:requested.viewId});if(requested.url!==ownerSource.baseIdentity||!same&&(!currentSourceHint||currentSourceHint.document!==ownerDocument||currentSourceHint.pageId!==ownerSource.pageId||!exactSource({baseIdentity:currentSourceHint.source.url,tableId:currentSourceHint.source.tableId,viewId:currentSourceHint.source.viewId},{baseIdentity:requested.url,tableId:requested.tableId,viewId:requested.viewId})))throw error('BASE_VIEW_CHANGED','Nguồn thay đổi chưa được đúng Reader xác nhận.');call.requiredPageId=ownerSource.pageId||'';}
        var readerConnected=connected(),hint=launcher&&!launcher.paused&&!launcher.needsSetup&&readerAllowsBase(launcher.base)&&(requireReaderBinding||!readerConnected||now()-launcher.lastSeen<metadataTTL)?launcher.base:'',known=launcherTrusted.filter(function(r){return readerAllowsBase(r.base);});
        // A connected Order frame proves transport authentication, not the
        // currently selected Chrome page/view. In binding mode, even a stale
        // authenticated Companion or matching remembered pairing is only a
        // hint to WAIT for a new metadata poll; never take the legacy unbound
        // SDK-job path or borrow the earlier ownerSource as a fresh proof.
        if(requireReaderBinding&&readerConnected&&known.some(function(record){return record.base===ownerBase;})&&(!hint||launcher&&launcher.base!==ownerBase&&!launcherFresh()))hint=ownerBase;
        if(!hint&&!readerConnected&&known.length===1)hint=known[0].base;
        // Multiple saved pairings do not identify a selected view. They only
        // authorize waiting for a fresh, authenticated Companion poll, which
        // must still confirm a unique tab and exact Base/table/view before any
        // command or reader job is issued. Never choose a saved Base by order.
        var eligible=!!hint||!readerConnected&&known.length>0;
        if(staleBuild!==null||owner&&!compatible(ownerBuild)){staleBuild=ownerBuild||staleBuild||'';throw versionError();}
        // A refused old worker is a diagnostic, not a permanent cold-start
        // latch. Wait for a current authenticated hello under the same budget.
        if(!readerConnected&&launcher&&launcher.diagnosticCode&&now()-launcher.lastSeen<metadataTTL){var reported=chromeDiagnostic(launcher.diagnosticCode),stabilize=call&&call.kind==='manual'&&!call.statusRequest&&eligible&&launcher.diagnosticCode==='VIEW_CHANGED';if(reported&&!stabilize)throw reported;}
        var applicableLauncher=launcher&&(hint?launcher.base===hint:!readerConnected||launcher.base===ownerBase);
        if(applicableLauncher&&launcher.needsSetup&&(!readerConnected||requireReaderBinding))throw calibrationError();
        if(applicableLauncher&&launcher.paused&&(!readerConnected||requireReaderBinding))throw error('BASE_LAUNCHER_PAUSED','UOY Base Companion đang tạm dừng. Bật lại tiện ích để xác nhận đúng tab/view trước khi Nạp.');
        var adopting=launcherCommand&&launcherCommand.value.op==='openOrder'&&launcherCommand.value.purpose==='standby'&&launcherFresh()&&exactPageSource(launcherCommand.value,launcher.metadata)&&(!readerConnected||ownerBase===launcherCommand.value.baseIdentity);
        if(launcherCommand&&!adopting)throw error('BASE_LAUNCHER_BUSY','Chrome đang mở/đóng Order. Đợi thao tác này hoàn tất rồi bấm Nạp.');
        if(requireReaderBinding&&!eligible)throw error('BASE_LAUNCHER_NOT_READY','Reader Order đã kết nối nhưng chưa có Companion được ghép để xác nhận tab/view hiện tại. Bật và ghép UOY Base Companion; dữ liệu đơn cũ vẫn được giữ.');
        if(!readerConnected&&!eligible)throw error(launcher||known.length?'BASE_LAUNCHER_NOT_READY':'BASE_NOT_CONNECTED',launcher||known.length?'Chrome chưa xác định được duy nhất tab/view Base đang mở. Kiểm tra tiện ích UOY Base Companion và tab Base; có thể mở Order bằng tay để đọc.':'Mở UOY Order Custom trong phần mở rộng Base và kết nối với Photoshop trước.');
        return new Promise(function(resolve,reject){
          var metadataCold=eligible&&!launcherFresh();
          pending={id:crypto.randomBytes(16).toString('hex'),resolve:resolve,reject:reject,kind:call&&call.kind||'',delivered:false,expectedSource:null,statusRequest:call&&call.statusRequest||null,dirtyRequest:call&&call.dirtyRequest||null,requiredPageId:call&&call.requiredPageId||'',baseHint:hint,waitingMetadata:eligible,waitingReader:!readerConnected,waitingOpen:false,adoptCommandId:adopting?launcherCommand.value.commandId:'',adoptedOpenDone:false,startedAt:now(),stage:'',detail:metadataCold?'coldStart':'',readRecords:0,timer:null,hardTimer:null};
          if(eligible){
            launcherState='waiting';launcherError='';
            // Require a poll received after this user request. A recent cached
            // view may belong to another tab before its selection changed.
            // A restarted broker has no live launcher yet. Chrome may need to
            // wake its saved Companion worker before the first authenticated
            // hello/poll. Allow one bounded cold-start wait, never cached rows
            // or an automatic retry; subsequent fresh sessions keep 10s.
            armPhase('waitingMetadata',metadataCold?coldMetadataWaitMs:metadataWaitMs,'BASE_METADATA_TIMEOUT','Chrome Companion chưa gửi bảng/view hiện tại đúng hạn. Giữ tab Base đã ghép mở và đăng nhập; kiểm tra UOY Base Companion đã bật và đúng bản '+LAUNCHER_BUILD+' rồi Nạp lại. Tool chưa nạp dữ liệu cũ; ghép nối đã lưu vẫn được giữ.');
          }else{waitingReader();deliver();}
        });
      });}
    function beginRead(kind,statusRequest,dirtyRequest){
      if(closed)return Promise.reject(error('BASE_CLOSED','Cầu nối đã đóng.'));
      if(readCall||foregroundWaiting)return Promise.reject(error('BASE_BUSY','Đang đọc Base view.'));
      var call={kind:kind,statusRequest:statusRequest||null,dirtyRequest:dirtyRequest||null,cancelRequested:false,complete:null,done:null,promise:null};
      call.done=new Promise(function(resolve){call.complete=resolve;});readCall=call;
      call.promise=Promise.resolve().then(function(){
        if(call.cancelRequested)throw error('BASE_CANCELLED','Đã hủy lượt quét nền.');
        return start().then(function(){return waitForLauncherClose(call);});
      }).then(function(){
        if(closed)throw error('BASE_CLOSED','Cầu nối đã đóng.');
        if(call.cancelRequested)throw error('BASE_CANCELLED','Đã hủy lượt quét nền.');
        return readCurrentView(call);
      }).then(function(value){
        if(call.cancelRequested)throw error('BASE_CANCELLED','Đã hủy lượt quét nền.');
        return value;
      });
      function complete(){if(readCall===call)readCall=null;call.complete();stateEvent('idle');}
      call.promise.then(complete,complete);return call.promise;
    }
    function cancelBackgroundRead(){
      var call=readCall;if(!call||call.kind!=='background')return Promise.resolve({cancelled:false});
      call.cancelRequested=true;
      if(call.closeWaitCancel)call.closeWaitCancel(error('BASE_CANCELLED','Đã hủy lượt chờ để ưu tiên thao tác người dùng.'));
      if(pending){
        if(!pending.delivered)finish(error('BASE_CANCELLED','Đã hủy lượt quét nền để ưu tiên Nạp.'));
        else pending.cancelRequested=true;
      }
      return call.done.then(function(){return {cancelled:true};});
    }
    function fetchCurrentView(){
      // Reserve synchronously. Repeated user clicks join the same current
      // request; they cannot cancel it or invalidate a successful first reply.
      if(manualCallPromise)return manualCallPromise;
      var work;
      if(readCall&&readCall.kind==='background'&&!foregroundWaiting){
        foregroundWaiting=true;
        work=cancelBackgroundRead().then(function(){foregroundWaiting=false;return beginRead('manual');},function(e){foregroundWaiting=false;throw e;});
      }else work=beginRead('manual');
      manualCallPromise=work;
      function release(){if(manualCallPromise===work)manualCallPromise=null;}
      work.then(release,release);return work;
    }
    return {
      start:start,
      getPairingInfo:function(){return start().then(function(){var info={url:endpoint+'/extension/',code:JSON.stringify({version:1,endpoint:endpoint,token:token}),connected:connected(),origin:configuredOrigin||origin,rememberAvailable:storeAvailable,rememberedBases:trusted.length},version=versionInfo(),launchInfo=launcherInfo();for(var key in version)info[key]=version[key];for(var name in launchInfo)info[name]=launchInfo[name];return info;});},
      fetchCurrentView:fetchCurrentView,
      fetchBackgroundView:function(request){try{return beginRead('background',null,request===undefined?null:validateDirtyRequest(request));}catch(e){return Promise.reject(e);}},
      fetchRecordStatuses:function(request){try{return beginRead('background',validateStatusRequest(request));}catch(e){return Promise.reject(e);}},
      cancelBackgroundRead:cancelBackgroundRead,
      status:status,subscribe:subscribe,
      forgetRememberedPairings:forgetRememberedPairings,
      forgetLauncherPairings:forgetLauncherPairings,
      // Private application IPC may cancel only its own outstanding request.
      // This is not exposed by any HTTP reader/launcher route.
      cancelCurrentRead:function(){if(readCall){readCall.cancelRequested=true;if(readCall.closeWaitCancel)readCall.closeWaitCancel(error('BASE_CANCELLED','Ứng dụng đã hủy lượt xác minh này.'));}finish(error('BASE_CANCELLED','Ứng dụng đã hủy lần Nạp này.'));},
      close:function(){closed=true;if(ownerExpiry!==null)clearTimeout(ownerExpiry);ownerExpiry=null;if(readCall&&readCall.closeWaitCancel)readCall.closeWaitCancel(error('BASE_CLOSED','Cầu nối đã đóng.'));rejectPoll();finish(error('BASE_CLOSED','Cầu nối đã đóng.'));cancelLauncherCommand(error('BASE_CLOSED','Cầu nối đã đóng.'));launcher=null;owner=null;stateEvent('closed');listeners=[];if(server)server.close();}
    };
  }
  var singleton=null;
  function configure(options){if(singleton)singleton.close();singleton=createBroker(options);return singleton;}
  function autoInit(win){if(singleton)return singleton;var req=win.require||require,path=req('path'),rootDir='',trustStore=null,launcherTrustStore=null;try{rootDir=path.dirname(decodeURI(win.location.pathname).replace(/^\/(?:([A-Za-z]:))/,'$1'));}catch(_){}try{var store=req(path.join(rootDir,'js','lark-pairing-store.js'));trustStore=store.createWindowsStore();launcherTrustStore=store.createWindowsStore({role:'launcher'});}catch(_){}var options={staticRoot:path.join(rootDir,'lark-base-extension'),trustStore:trustStore,launcherTrustStore:launcherTrustStore},localRoot=process.env.LOCALAPPDATA&&path.join(process.env.LOCALAPPDATA,'UOY','BaseCoexist'),localClient=null;if(localRoot&&req('fs').existsSync(path.join(localRoot,'active-v1.json'))){localClient=req(path.join(localRoot,'coexist-client.js')).createIfEnabled(options);}var owned=localClient||(configure(options));if(localClient)singleton=localClient;if(typeof win.addEventListener==='function')win.addEventListener('beforeunload',function(){owned.close();if(singleton===owned)singleton=null;},{once:true});return owned;}
  function backgroundCall(name,arg){if(!singleton&&typeof window!=='undefined')autoInit(window);if(!singleton)return Promise.reject(error('BASE_NOT_CONFIGURED','Chưa khởi tạo cầu nối Base.'));if(typeof singleton[name]!=='function')return Promise.reject(error('BASE_BACKGROUND_UNAVAILABLE','Cầu nối local cần cập nhật để quét nền. Nạp thủ công vẫn dùng được.'));return singleton[name](arg);}
  function subscribeSingleton(listener){if(!singleton&&typeof window!=='undefined')autoInit(window);if(!singleton||typeof singleton.subscribe!=='function')return function(){};return singleton.subscribe(listener);}
return {CLIENT_BUILD:CLIENT_BUILD,LAUNCHER_BUILD:LAUNCHER_BUILD,LAUNCHER_EXTENSION_ID:LAUNCHER_EXTENSION_ID,createBroker:createBroker,validateSnapshot:validateSnapshot,validateStatusRequest:validateStatusRequest,validateStatusSnapshot:validateStatusSnapshot,validateDirtyRequest:validateDirtyRequest,validateDirty:validateDirty,validateSource:validateSource,subscribe:subscribeSingleton,validOrigin:validOrigin,canonicalBase:canonicalBase,configure:configure,autoInit:autoInit,getPairingInfo:function(){if(!singleton&&typeof window!=='undefined')autoInit(window);if(!singleton)return Promise.reject(error('BASE_NOT_CONFIGURED','Chưa khởi tạo cầu nối Base.'));return singleton.getPairingInfo();},fetchCurrentView:function(){if(!singleton&&typeof window!=='undefined')autoInit(window);if(!singleton)return Promise.reject(error('BASE_NOT_CONFIGURED','Chưa khởi tạo cầu nối Base.'));return singleton.fetchCurrentView();},fetchBackgroundView:function(request){return backgroundCall('fetchBackgroundView',request);},fetchRecordStatuses:function(request){return backgroundCall('fetchRecordStatuses',request);},cancelBackgroundRead:function(){return backgroundCall('cancelBackgroundRead');},forgetRememberedPairings:function(){if(!singleton&&typeof window!=='undefined')autoInit(window);if(!singleton)return Promise.reject(error('BASE_NOT_CONFIGURED','Chưa khởi tạo cầu nối Base.'));return singleton.forgetRememberedPairings();},forgetLauncherPairings:function(){if(!singleton&&typeof window!=='undefined')autoInit(window);if(!singleton)return Promise.reject(error('BASE_NOT_CONFIGURED','Chưa khởi tạo cầu nối Base.'));return singleton.forgetLauncherPairings();},status:function(){return singleton?singleton.status():{started:false,connected:false,busy:false};}};
});
