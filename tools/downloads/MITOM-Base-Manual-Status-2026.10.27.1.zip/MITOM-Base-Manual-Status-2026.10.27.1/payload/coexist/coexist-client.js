/* Both apps use a single hidden, machine-local broker. No browser-control
 * endpoints are added. Closing this client never terminates another client. */
'use strict';
const common = require('./coexist-common.js');
const crypto = require('crypto');
const cp = require('child_process');
const fs = require('fs');
const path = require('path');
function bridgeHash(file) {
  if(typeof file!=='string'||!path.isAbsolute(file))throw common.fail('BASE_LOCAL_CONFIG','Đường dẫn mã cầu nối local không hợp lệ.');
  let cursor=path.resolve(file);
  while(true){const stat=fs.lstatSync(cursor);if(stat.isSymbolicLink()||path.resolve(fs.realpathSync(cursor)).toLowerCase()!==cursor.toLowerCase())throw common.fail('BASE_LOCAL_CONFIG','Không dùng đường dẫn liên kết cho mã cầu nối local.');const parent=path.dirname(cursor);if(parent===cursor)break;cursor=parent;}
  const stat=fs.lstatSync(file);
  if(!stat.isFile()||stat.size<1||stat.size>1024*1024)throw common.fail('BASE_LOCAL_CONFIG','Mã cầu nối local chưa hợp lệ.');
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}
function createClient(config, key, deps) {
  deps = deps || {}; const net = deps.net || require('net');
  const clock=deps.clock||{setTimeout:global.setTimeout,clearTimeout:global.clearTimeout},setTimeout=clock.setTimeout.bind(clock),clearTimeout=clock.clearTimeout.bind(clock),now=deps.now||Date.now;
  let socket = null, connecting = null, closed = false, session = null, sessionBridgeSHA256='',connectWaitCancel=null, sequence = 0, eventSequence = 0, last = {started:false,connected:false,busy:false}, subscribing = null, reconnectTimer = null, reconnectFailures = 0;
  const listeners = new Set();
  const requests = new Map();
  const opening = new Map();
  function error(code, text) { return common.fail(code, text); }
  function expectedBridgeHash(){const value=typeof deps.getBridgeSourceSHA256==='function'?deps.getBridgeSourceSHA256():deps.bridgeSourceSHA256||bridgeHash(config.bridgePath);if(typeof value!=='string'||!/^[a-f0-9]{64}$/.test(value))throw error('BASE_LOCAL_CONFIG','Không xác minh được mã cầu nối hiện tại.');return value;}
  function emit(value){for(const listener of Array.from(listeners))try{listener(JSON.parse(JSON.stringify(value)));}catch(_){}}
  function reconnect(){if(closed||!listeners.size||reconnectTimer!==null)return;const delay=Math.min(15000,500*Math.pow(2,Math.min(5,reconnectFailures++)));reconnectTimer=setTimeout(()=>{reconnectTimer=null;void activateSubscription().catch(()=>reconnect());},delay);if(reconnectTimer&&typeof reconnectTimer.unref==='function')reconnectTimer.unref();}
  function validError(value){return value&&typeof value.code==='string'&&typeof value.message==='string'&&Object.keys(value).every(k=>['code','message','clientBuild','requiredClientBuild','launcherClientBuild','requiredLauncherBuild'].includes(k))&&['clientBuild','requiredClientBuild','launcherClientBuild','requiredLauncherBuild'].every(k=>value[k]===undefined||typeof value[k]==='string'&&/^[A-Za-z0-9_-]{0,64}$/.test(value[k]));}
  function fromError(value){
    const failure=error(value.code||'BASE_LOCAL_REQUEST',String(value.message||'Cầu nối Base lỗi.').slice(0,700));
    for(const name of ['clientBuild','requiredClientBuild','launcherClientBuild','requiredLauncherBuild'])if(value[name]!==undefined)failure[name]=value[name];
    if(value.code==='LAUNCHER_VERSION'||value.code==='CLIENT_VERSION'){
      const observed=value.code==='LAUNCHER_VERSION'?'launcherClientBuild':'clientBuild',required=value.code==='LAUNCHER_VERSION'?'requiredLauncherBuild':'requiredClientBuild';
      if(typeof last[observed]==='string'&&/^[A-Za-z0-9_-]{0,64}$/.test(last[observed])){if(failure.clientBuild===undefined)failure.clientBuild=last[observed];if(failure[observed]===undefined)failure[observed]=last[observed];}
      if(typeof last[required]==='string'&&/^[A-Za-z0-9_-]{0,64}$/.test(last[required])){if(failure.requiredClientBuild===undefined)failure.requiredClientBuild=last[required];if(failure[required]===undefined)failure[required]=last[required];}
    }
    return failure;
  }
  function drop(e, target) {
    if (target && socket !== target) return;
    if (socket) socket.destroy(); socket = null; session = null; sessionBridgeSHA256='';last = {started:false,connected:false,busy:false};
    for (const entry of requests.values()) { clearTimeout(entry.timer); entry.reject(e); } requests.clear();
    emit({type:'state',reason:'disconnected',at:Date.now(),status:Object.assign({},last)});reconnect();
  }
  function launch() {
    if (deps.spawnHost) return deps.spawnHost(config);
    for (const name of ['nodePath','hostPath']) require('fs').lstatSync(config[name]);
    const child = cp.spawn(config.nodePath, [config.hostPath], {cwd:config.directory, detached:true, stdio:'ignore', windowsHide:true, shell:false});
    child.on('error', function() {}); child.unref();
  }
  function attempt(bridgeSourceSHA256,deadline) {
    return new Promise((resolve, reject) => {
      let pending = Buffer.alloc(0), established = false, challenge = '', clientNonce = '', done = false;
      const client = crypto.randomBytes(16).toString('hex');
      const current = net.createConnection(config.pipePath);
      const timer = setTimeout(() => abort(error('BASE_LOCAL_TIMEOUT','Cầu nối ứng dụng local chưa phản hồi.')), Math.max(1,Math.min(config.handshakeTimeoutMs||25000,deadline-now())));
      function abort(e) { if (done) return; done = true; opening.delete(current); clearTimeout(timer); current.destroy(); reject(e); }
      opening.set(current,abort);
      current.on('error', e => { if (!established) abort(e); else drop(error('BASE_LOCAL_DISCONNECTED','Cầu nối local vừa ngắt; bấm Nạp lại.'), current); });
      current.on('close', () => { if (!established) abort(error('BASE_LOCAL_DISCONNECTED','Cầu nối local vừa đóng.')); else drop(error('BASE_LOCAL_DISCONNECTED','Cầu nối local vừa ngắt; bấm Nạp lại.'), current); });
      current.on('data', chunk => {
        if (done && !established) return;
        pending = Buffer.concat([pending,chunk]);
        let at;
        while ((at = pending.indexOf(10)) >= 0) {
          if (at > common.MAX_BYTES) { if (!established) abort(error('BASE_LOCAL_PROTOCOL','Phản hồi cầu nối local quá lớn.')); else drop(error('BASE_LOCAL_PROTOCOL','Phản hồi cầu nối local quá lớn.'), current); return; }
          const raw = pending.subarray(0,at), line = raw.toString('utf8'); pending = pending.subarray(at+1);
          try {
            if (!Buffer.from(line,'utf8').equals(raw)) throw error('BASE_LOCAL_PROTOCOL','Phản hồi UTF-8 không hợp lệ.');
            const value = common.decodeFrame(line);
            if (!established) {
              if(value.type==='challenge'&&/^[a-f0-9]{32}$/.test(value.nonce)&&!challenge&&
                  (Object.keys(value).join(',')==='type,nonce'||Object.keys(value).join(',')==='type,nonce,bridgeSourceSHA256'&&typeof value.bridgeSourceSHA256==='string'&&/^[a-f0-9]{64}$/.test(value.bridgeSourceSHA256))){
                // No authenticated IPC frame may reach a cached/legacy host.
                // Its anonymous close starts the old host's15s idle exit;
                // connect() then stays completely quiet for at least16s.
                if(value.bridgeSourceSHA256!==bridgeSourceSHA256||expectedBridgeHash()!==bridgeSourceSHA256){abort(error('BASE_LOCAL_OLD_HOST','Cầu nối cũ chưa thoát; đóng các ứng dụng MITOM/OrderStudio còn mở rồi thử lại. Không cần ghép lại Base.'));return;}
                challenge=value.nonce; clientNonce=crypto.randomBytes(16).toString('hex');
                current.write(JSON.stringify({type:'auth',client,nonce:clientNonce,proof:common.mac(key,{role:'client',serverNonce:challenge,clientNonce,client,bridgeSourceSHA256})})+'\n');
              } else if (challenge && value.type === 'ready' && Object.keys(value).join(',') === 'type,proof' && common.equalMac(value.proof,common.mac(key,{role:'server',serverNonce:challenge,clientNonce,client,bridgeSourceSHA256}))) {
                if (closed) { abort(error('BASE_CLOSED','Ứng dụng đã ngắt cầu nối.')); return; }
                if(expectedBridgeHash()!==bridgeSourceSHA256){abort(error('BASE_LOCAL_OLD_HOST','Mã cầu nối vừa thay đổi; đóng các ứng dụng MITOM rồi thử lại.'));return;}
                session=Buffer.from(common.mac(key,{role:'session',serverNonce:challenge,clientNonce,client,bridgeSourceSHA256}),'hex');sessionBridgeSHA256=bridgeSourceSHA256;
                established=true; done=true; opening.delete(current); clearTimeout(timer); socket=current; sequence=0; eventSequence=0; resolve();
              } else if (challenge && value.type === 'error' && Object.keys(value).join(',') === 'type,error,proof' && validError(value.error) && common.equalMac(value.proof,common.mac(key,{role:'server-error',serverNonce:challenge,clientNonce,client,bridgeSourceSHA256,error:value.error}))) {
                abort(fromError(value.error));
                return;
              } else { abort(error('BASE_LOCAL_AUTH','Không xác thực được cầu nối của máy này.')); return; }
            } else {
              const proof=value.proof; delete value.proof;
              if(value.type==='event'){
                if(!common.equalMac(proof,common.mac(session,value))||Object.keys(value).sort().join('|')!=='event|eventSeq|state|type'||!Number.isSafeInteger(value.eventSeq)||value.eventSeq!==eventSequence+1||!value.state||typeof value.state!=='object'||Array.isArray(value.state))throw error('BASE_LOCAL_PROTOCOL','Tín hiệu cầu nối không khớp phiên.');
                const event=common.validateEvent(value.event);eventSequence=value.eventSeq;last=value.state;event.status=Object.assign({},last);emit(event);continue;
              }
              if (!common.equalMac(proof,common.mac(session,value)) || !Number.isSafeInteger(value.seq) || !requests.has(value.seq) || Object.keys(value).length !== 3 || Object.keys(value).some(k => !['seq','result','error','state'].includes(k)) || Object.prototype.hasOwnProperty.call(value,'result') === Object.prototype.hasOwnProperty.call(value,'error') || !value.state || typeof value.state !== 'object' || Array.isArray(value.state) || (value.error && !validError(value.error))) throw error('BASE_LOCAL_PROTOCOL','Phản hồi cầu nối không khớp yêu cầu.');
              const entry=requests.get(value.seq); requests.delete(value.seq); clearTimeout(entry.timer); last=value.state;
              if (value.error) entry.reject(fromError(value.error)); else entry.resolve(value.result);
            }
          } catch (_) { if (!established) abort(error('BASE_LOCAL_AUTH','Không xác thực được cầu nối của máy này.')); else drop(error('BASE_LOCAL_PROTOCOL','Phản hồi cầu nối local không hợp lệ.'), current); return; }
        }
        if (pending.length > common.MAX_BYTES) { if (!established) abort(error('BASE_LOCAL_PROTOCOL','Phản hồi cầu nối local quá lớn.')); else drop(error('BASE_LOCAL_PROTOCOL','Phản hồi cầu nối local quá lớn.'), current); }
      });
    });
  }
  function connect() {
    if (closed) return Promise.reject(error('BASE_CLOSED','Ứng dụng đã ngắt cầu nối.'));
    let expected;try{expected=expectedBridgeHash();}catch(e){return Promise.reject(e);}
    if(socket&&session&&sessionBridgeSHA256===expected)return Promise.resolve();
    if(socket&&session)drop(error('BASE_LOCAL_OLD_HOST','Mã cầu nối đổi; chưa dùng phiên cũ.'));
    if (connecting) return connecting;
    connecting=(async function() {
      const budget=config.startupTimeoutMs===undefined?45000:config.startupTimeoutMs;
      if(!Number.isInteger(budget)||budget<1||budget>45000)throw error('BASE_LOCAL_CONFIG','Thời gian khởi động cầu nối chưa hợp lệ.');
      const deadline=now()+budget;let launched=false,stale=false;
      function timeout(){return error(stale?'BASE_LOCAL_OLD_HOST':'BASE_LOCAL_TIMEOUT',stale?'Cầu nối cũ vẫn đang được ứng dụng khác giữ. Lưu việc và đóng các ứng dụng MITOM/OrderStudio còn mở, chờ một chút rồi thử lại; không ghép nối lại Base.':'Chưa mở được cầu nối Base dùng chung trên máy này.');}
      function wait(milliseconds){return new Promise((resolve,reject)=>{let settled=false;const timer=setTimeout(()=>{if(settled)return;settled=true;connectWaitCancel=null;resolve();},milliseconds);connectWaitCancel=function(e){if(settled)return;settled=true;clearTimeout(timer);connectWaitCancel=null;reject(e);};if(closed)connectWaitCancel(error('BASE_CLOSED','Ứng dụng đã ngắt cầu nối.'));});}
      while (!closed) {
        if(now()>=deadline)throw timeout();
        try { expected=expectedBridgeHash();await attempt(expected,deadline);return; }
        catch (e) {
          if(e.code==='BASE_LOCAL_OLD_HOST'){
            stale=true;const remaining=deadline-now();
            // A cached host resets its15s idle timer even on anonymous close.
            // Never probe again within that window or authenticate to keep it
            // alive. No spawn, file write, kill, retry SDK job or Base UI here.
            if(remaining<=16000){if(remaining>0)await wait(remaining);throw timeout();}
            await wait(16000);continue;
          }
          if (!['ENOENT','ECONNREFUSED'].includes(e.code)) throw e;
          if(now()>=deadline)throw timeout();
          if (!launched) { launch(); launched=true; }
          await wait(Math.min(150,deadline-now()));
        }
      }
      throw error('BASE_CLOSED','Ứng dụng đã ngắt cầu nối.');
    })().finally(() => { connecting=null; });
    return connecting;
  }
  async function call(op,args) {
    await connect();
    if (closed || !socket || !session) throw error('BASE_LOCAL_DISCONNECTED','Cầu nối local vừa ngắt; bấm Nạp lại.');
    if (requests.size >= 16) throw error('BASE_BUSY','Ứng dụng đang chờ cầu nối Base.');
    const seq=++sequence, body={seq,op};if(op==='fetchRecordStatuses'||op==='fetchBackgroundView'&&args!==undefined)body.args=args;
    return new Promise((resolve,reject) => {
      // Preserve the native cold-metadata + open + reader + full SDK budget.
      const timer=setTimeout(() => { drop(error('BASE_LOCAL_TIMEOUT','Cầu nối chưa trả kết quả; bấm Nạp lại.')); }, ['fetchCurrentView','fetchBackgroundView','fetchRecordStatuses','cancelBackgroundRead'].indexOf(op)>=0?240000:15000);
      requests.set(seq,{resolve,reject,timer}); socket.write(JSON.stringify(Object.assign(body,{proof:common.mac(session,body)}))+'\n');
    });
  }
  function activateSubscription(){
    if(closed||!listeners.size)return Promise.resolve();if(subscribing)return subscribing;
    subscribing=call('subscribe').then(()=>{reconnectFailures=0;emit({type:'state',reason:last.connected?'connected':'disconnected',at:Date.now(),status:Object.assign({},last)});},failure=>{last=Object.assign({},last,{connected:false,eventCapable:false});emit({type:'state',reason:'disconnected',at:Date.now(),status:Object.assign({},last)});if(failure.code!=='BASE_OPERATION'&&failure.code!=='BASE_BACKGROUND_UNAVAILABLE')reconnect();throw failure;}).finally(()=>{subscribing=null;});return subscribing;
  }
  return {
    start:() => call('start').then(() => undefined),
    getPairingInfo:() => call('getPairingInfo'), fetchCurrentView:() => call('fetchCurrentView'),
    fetchBackgroundView:request => call('fetchBackgroundView',request), cancelBackgroundRead:() => call('cancelBackgroundRead'),
    fetchRecordStatuses:request => call('fetchRecordStatuses',request),
    forgetRememberedPairings:() => call('forgetRememberedPairings'), forgetLauncherPairings:() => call('forgetLauncherPairings'),
    status:function() { return Object.assign({},last); },
    subscribe:function(listener){if(typeof listener!=='function')throw error('BASE_OPERATION','Listener không hợp lệ.');if(closed)return ()=>{};listeners.add(listener);void activateSubscription().catch(()=>{});return ()=>{listeners.delete(listener);if(!listeners.size&&reconnectTimer!==null){clearTimeout(reconnectTimer);reconnectTimer=null;}};},
    close:function() { closed=true;if(reconnectTimer!==null)clearTimeout(reconnectTimer);reconnectTimer=null;const e=error('BASE_CLOSED','Ứng dụng đã ngắt cầu nối.');if(connectWaitCancel)connectWaitCancel(e);for (const abort of opening.values()) abort(e);drop(e);listeners.clear(); }
  };
}
function createIfEnabled(options) { const config=common.loadConfig(); if (!config) return null; return createClient(config,common.readKey(config)); }
module.exports={createClient,createIfEnabled};
