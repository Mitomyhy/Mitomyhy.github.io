/* One opt-in, current-user Base broker. Application control is authenticated
 * on a private named pipe; SDK/Companion HTTP routes remain the original API.
 * No application's order rows or pairing codes are broadcast to another. */
'use strict';

const common = require('./coexist-common.js');
const crypto = require('crypto');
const net = require('net');
const fs = require('fs');
const path = require('path');

function bridgeBytes(file) {
  if(typeof file!=='string'||!path.isAbsolute(file))throw common.fail('BASE_LOCAL_CONFIG','Đường dẫn mã cầu nối local không hợp lệ.');
  let cursor=path.resolve(file);
  while(true){const stat=fs.lstatSync(cursor);if(stat.isSymbolicLink()||path.resolve(fs.realpathSync(cursor)).toLowerCase()!==cursor.toLowerCase())throw common.fail('BASE_LOCAL_CONFIG','Không dùng đường dẫn liên kết cho mã cầu nối local.');const parent=path.dirname(cursor);if(parent===cursor)break;cursor=parent;}
  const stat=fs.lstatSync(file);
  if(!stat.isFile()||stat.size<1||stat.size>1024*1024)throw common.fail('BASE_LOCAL_CONFIG','Mã cầu nối local chưa hợp lệ.');
  return fs.readFileSync(file);
}
function loadBridge(config,deps) {
  if(deps.api){if(typeof deps.bridgeSourceSHA256!=='string'||!/^[a-f0-9]{64}$/.test(deps.bridgeSourceSHA256))throw common.fail('BASE_LOCAL_CONFIG','Thiếu định danh mã cầu nối thử nghiệm.');return {api:deps.api,sha256:deps.bridgeSourceSHA256};}
  const before=bridgeBytes(config.bridgePath),resolved=require.resolve(config.bridgePath);
  // A cached module cannot be certified by hashing newer disk bytes. A fresh
  // host loads once; an unexpected existing cache fails before binding a pipe.
  if(require.cache[resolved])throw common.fail('BASE_LOCAL_CONFIG','Mã cầu nối đã được nạp trước; đóng các ứng dụng MITOM rồi mở lại.');
  const api=require(resolved),after=bridgeBytes(config.bridgePath);
  if(!before.equals(after)||!require.cache[resolved]||require.cache[resolved].exports!==api)throw common.fail('BASE_LOCAL_CONFIG','Mã cầu nối đổi trong lúc nạp; chưa khởi động phiên cũ.');
  return {api,sha256:crypto.createHash('sha256').update(before).digest('hex')};
}

const OPERATIONS = new Set(['start', 'status', 'subscribe', 'getPairingInfo', 'fetchCurrentView', 'fetchBackgroundView', 'fetchRecordStatuses', 'cancelBackgroundRead',
  'forgetRememberedPairings', 'forgetLauncherPairings']);
const ERROR_MESSAGES = {
  "BASE_SDK_SDK_METADATA_STALLED": "SDK Base chưa kết thúc các lượt metadata cũ; reader chưa xác minh được dữ liệu mới. Đợi Base phục hồi hoặc tải lại riêng Order.",
  "BASE_SDK_READ_CANCELLED": "Lượt đọc Base đã được hủy; chưa nhận dữ liệu mới.",
  "BASE_SDK_READ_CONTROL_STALE": "Cầu nối local từ chối lượt đọc vì phiên hoặc nguồn view không còn khớp. Chưa nhận dữ liệu mới; bấm Nạp để xác nhận lại đúng view.",
  "BASE_SDK_READ_CONTROL_UNAVAILABLE": "Cầu nối local chưa xác nhận thao tác điều khiển lượt đọc. Chưa nhận dữ liệu mới; kiểm tra Panel và kết nối Chrome.",
  "BASE_SDK_NO_VIEW": "Chưa chọn view trong Base. Chọn view đã lưu rồi quét lại. (NO_VIEW)",
  "BASE_SDK_SDK_VERSION": "Base SDK trong Order chưa hỗ trợ bộ đọc hiện tại. Đóng riêng phần mở rộng Order rồi mở lại. (SDK_VERSION)",
  "BASE_SDK_SDK_TIMEOUT": "Base SDK chưa trả thông tin view đúng hạn. Giữ tab Base mở rồi quét lại. (SDK_TIMEOUT)",
  "BASE_SDK_SDK_SELECTION_TIMEOUT": "Base SDK chưa trả bảng và view đang chọn đúng hạn. Giữ tab Base mở, đợi tải xong rồi quét lại. (SDK_SELECTION_TIMEOUT)",
  "BASE_SDK_SDK_SOURCE_URL_TIMEOUT": "Base SDK chưa xác nhận liên kết của nguồn view đúng hạn. Chưa nhập dữ liệu; đợi Base tải xong rồi quét lại. (SDK_SOURCE_URL_TIMEOUT)",
  "BASE_SDK_SDK_SELECTION_VERIFY_TIMEOUT": "Base SDK chưa xác minh lại bảng và view đúng hạn. Chưa nhập dữ liệu của nguồn chưa xác nhận. (SDK_SELECTION_VERIFY_TIMEOUT)",
  "BASE_SDK_SDK_OBSERVER_SOURCE_TIMEOUT": "Base SDK chưa xác nhận nguồn để theo dõi cập nhật đúng hạn. Chưa dùng trạng thái cũ; thử quét lại. (SDK_OBSERVER_SOURCE_TIMEOUT)",
  "BASE_SDK_SDK_OBSERVER_TABLE_TIMEOUT": "Base SDK chưa mở bảng để theo dõi cập nhật đúng hạn. Chưa dùng dữ liệu bảng cũ; thử quét lại. (SDK_OBSERVER_TABLE_TIMEOUT)",
  "BASE_SDK_SDK_OBSERVER_CONFIG_TIMEOUT": "Base SDK chưa xác nhận cấu hình view để theo dõi cập nhật đúng hạn. Đợi view ổn định rồi quét lại. (SDK_OBSERVER_CONFIG_TIMEOUT)",
  "BASE_SDK_SDK_PERMISSION": "Base SDK chưa cấp quyền đọc dữ liệu của view cho Order. Kiểm tra quyền truy cập Base rồi quét lại. (SDK_PERMISSION)",
  "BASE_SDK_SDK_NOT_FOUND": "Base SDK không còn tìm thấy bảng, view hoặc cột. Chọn lại view đã lưu và kiểm tra ánh xạ cột. (SDK_NOT_FOUND)",
  "BASE_SDK_SDK_FAILURE": "Base SDK chưa hoàn tất thao tác đọc; chưa xác định nguyên nhân và chưa nhận dữ liệu mới. (SDK_FAILURE)",
  "BASE_SDK_SDK_NOT_LOADED": "Base chưa tải xong bảng cho Order; đợi bảng tải xong rồi bấm Nạp lại. Chưa nhận dữ liệu mới. (SDK_NOT_LOADED)",
  "BASE_SDK_SDK_UNSUPPORTED": "Base SDK chưa hỗ trợ thao tác đọc này trên view hiện tại; chưa nhận dữ liệu mới. (SDK_UNSUPPORTED)",
  "BASE_SDK_SDK_PARAMETER": "Base SDK từ chối tham số của thao tác đọc; cần kiểm tra tương thích reader, chưa nhận dữ liệu mới. (SDK_PARAMETER)",
  "BASE_SDK_SDK_HOST_NOT_READY": "Khung phần mở rộng Base chưa sẵn sàng cho thao tác đọc; chưa nhận dữ liệu mới. (SDK_HOST_NOT_READY)",
  "BASE_SDK_SDK_UNKNOWN": "Base SDK báo lỗi nội bộ ở thao tác đọc; chưa nhận dữ liệu mới. (SDK_UNKNOWN)",
  "BASE_SDK_SDK_LIMIT": "Thao tác đọc vượt giới hạn Base SDK; chưa nhận bản thiếu. (SDK_LIMIT)",
  "BASE_SDK_FIELD_MAPPING": "Ánh xạ của Order đang trỏ tới cột không còn tồn tại. Mở phần Ánh xạ trong Order và chọn lại cột. (FIELD_MAPPING)",
  "BASE_SDK_FIELD_AMBIGUOUS": "Có nhiều cột cùng khớp một trường đơn hàng. Mở phần Ánh xạ trong Order và chọn đúng cột. (FIELD_AMBIGUOUS)",
  "BASE_SDK_FIELD_SCHEMA": "Base SDK trả danh sách hoặc định danh cột không hợp lệ. Mở lại phần mở rộng Order rồi quét lại. (FIELD_SCHEMA)",
  "BASE_SDK_FIELD_REQUIRED": "Bộ đọc chưa xác định được cột SKU và Name fullprint. Kiểm tra hai cột trong phần Ánh xạ của Order. (FIELD_REQUIRED)",
  "BASE_SDK_PAGE_SCHEMA": "Base SDK trả trang dữ liệu sai cấu trúc hoặc vượt giới hạn 5000 dòng; chưa nhập bản thiếu. (PAGE_SCHEMA)",
  "BASE_SDK_PAGE_INCOMPLETE": "Base SDK chưa trả đủ các trang của view; chưa nhập bản thiếu. Đợi view ổn định rồi quét lại. (PAGE_INCOMPLETE)",
  "BASE_SDK_RECORD_SCHEMA": "Base SDK trả Record ID hoặc cấu trúc dòng không hợp lệ; chưa nhập dữ liệu. (RECORD_SCHEMA)",
  "BASE_SDK_CELL_FORMAT": "Base SDK trả một ô không đúng dạng văn bản; chưa nhập dữ liệu để giữ nguyên nội dung khách. (CELL_FORMAT)",
  "BASE_SDK_CELL_LIMIT": "Một ô trong Base vượt giới hạn hoặc chứa ký tự điều khiển; chưa nhập dữ liệu. (CELL_LIMIT)",
  "BASE_SDK_READ_LIMIT": "View Base vượt giới hạn 5000 dòng hoặc 8 MB. Giảm số dòng trong view cần quét. (READ_LIMIT)",
  "BASE_SDK_READ_TIMEOUT": "Base SDK chưa đọc xong view đúng hạn; chưa nhập bản thiếu. Đợi view ổn định rồi quét lại. (READ_TIMEOUT)",
  "BASE_SDK_BASE_IDENTITY": "Base SDK chưa xác nhận được đúng nguồn Base đã lưu; chưa nhập dữ liệu. (BASE_IDENTITY)",
  "BASE_SDK_VIEW_CONFIG": "Bộ đọc chưa xác minh được cấu hình view Base. Chưa nhập dữ liệu; kiểm tra bản cập nhật reader Order. (VIEW_CONFIG)",
  "BASE_SDK_VIEW_CONFIG_BUSY": "Cấu hình view Base đang thay đổi trong lúc kiểm tra. Đợi view ổn định rồi quét lại. (VIEW_CONFIG_BUSY)",
  "BASE_SDK_DIRTY_REQUEST": "Yêu cầu cập nhật Base chưa đúng nguồn hoặc cấu trúc đã xác nhận; chưa nhập dữ liệu. (DIRTY_REQUEST)",
  "BASE_SDK_STATUS_REQUEST": "Yêu cầu kiểm tra Working Status chưa có nguồn hoặc Record ID hợp lệ; chưa xác nhận trạng thái đơn. (STATUS_REQUEST)",
  "BASE_SDK_FIELD_MISSING": "Bộ đọc chưa tìm thấy cột cần dùng để kiểm tra trạng thái. Kiểm tra ánh xạ cột trong Order. (FIELD_MISSING)",
  "BASE_SDK_STATUS_CELL": "Working Status chưa trả chuỗi hợp lệ. Tool chưa tự xác nhận đơn đã hoàn tất. (STATUS_CELL)",
  "BASE_SDK_MEMBERSHIP_UNAVAILABLE": "Base SDK chưa xác nhận đủ danh sách và bộ lọc của view; chưa suy đoán đơn đã rời view. (MEMBERSHIP_UNAVAILABLE)",
  "BASE_SDK_STATUS_INSTANCE": "Phiên kiểm tra Working Status chưa hợp lệ. Quét lại để xác nhận dữ liệu hiện tại. (STATUS_INSTANCE)",
  "BASE_SDK_SDK_EVENTS": "Base SDK chưa hỗ trợ đủ sự kiện theo dõi dữ liệu. Chưa xác nhận cập nhật nền; thử quét thủ công. (SDK_EVENTS)",
  "BASE_SDK_STATUS_LINK": "Base SDK chưa xác nhận một Design Link hợp lệ cho đơn. Kiểm tra link hiện tại trong Base. (STATUS_LINK)",

  BASE_PORT: 'Cổng Base trên máy này đang được một chương trình khác dùng; chưa kết nối cầu nối dùng chung.',
  BASE_BUSY: 'Một ứng dụng trên máy này đang đọc Base. Chờ lượt đó hoàn tất rồi thử lại.',
  BASE_BACKGROUND_UNAVAILABLE: 'Cầu nối local cần cập nhật để quét nền. Nạp thủ công vẫn dùng được.',
  BASE_OPERATION: 'Thao tác cầu nối không được phép.',
  BASE_CLOSED: 'Cầu nối dùng chung đã đóng. Chưa nhận dữ liệu Base.',
  BASE_CANCELLED: 'Đã hủy lượt đọc của ứng dụng đã ngắt kết nối.',
  BASE_NOT_CONNECTED: 'Mở Order trong Base và kiểm tra ghép nối đã lưu trên máy này.',
  BASE_NOT_CONFIGURED: 'Cầu nối trên máy này chưa được cấu hình.',
  BASE_METADATA_TIMEOUT: 'Chrome chưa xác nhận bảng/view hiện tại đúng hạn; chưa nhận dữ liệu cũ.',
  BASE_READER_TIMEOUT: 'Reader Order chưa kết nối đúng hạn; chưa nhận dữ liệu Base.',
  BASE_READER_BINDING: 'Reader chưa xác minh thuộc đúng trang/view Base đã chọn. Chưa nhận dữ liệu của tab khác; ghép nối vẫn được giữ.',
  BASE_READ_TIMEOUT: 'Base SDK ngừng trả tiến trình đọc; chưa nhận bản thiếu.',
  BASE_READ_DEADLINE: 'Base SDK chưa đọc xong trong thời gian cho phép; chưa nhận bản thiếu.',
  BASE_VIEW_CHANGED: 'Tab/view hoặc phiên trang Base đã đổi trong lúc đọc; chưa nhận dữ liệu.',
  BASE_IDENTITY: 'Base vừa đọc không khớp nguồn đã xác nhận; chưa nhận dữ liệu.',
  BASE_CHROME_TIMEOUT: 'Chrome chưa phản hồi đúng hạn. Kiểm tra lại kết nối trên máy này.',
  BASE_CHROME_CONTENT_VERSION: 'Mã Companion trong tab Base còn cũ. Lưu thao tác và tải lại riêng tab Base một lần; không cần ghép lại.',
  BASE_STATUS_REQUEST: 'Nguồn Base hoặc Record ID của đợt đơn chưa hợp lệ để xác nhận Working Status.',
  BASE_STATUS_CHANGED: 'Base vừa đổi dữ liệu trong lúc xác minh Working Status. Chưa gửi file; đợi trạng thái ổn định rồi thử lại.',
  BASE_CHROME_TAB: 'Chưa tìm thấy tab Base đã ghép trên máy này.',
  BASE_CHROME_MULTIPLE_TABS: 'Có nhiều tab Base nhưng chưa có nguồn xác nhận. Chọn tab Base cần dùng một lần; sau đó có thể chuyển tab khác, không cần mở Tùy chỉnh hay ghép lại.',
  BASE_CHROME_VIEW: 'Chưa xác nhận được table/view của tab Base hiện tại.',
  BASE_CHROME_PERMISSION: 'Companion chưa được cấp quyền trên Base này.',
  BASE_CHROME_CONTENT: 'Tab Base chưa phản hồi Companion đúng hạn.',
  BASE_CHROME_VIEW_CHANGED: 'Tab/view Base đang thay đổi; chưa đọc dữ liệu.',
  BASE_COMPANION_CALIBRATION: 'Companion trên máy này chưa được dạy đủ nút mở/thu gọn Order.',
  BASE_COMPANION_ROUTE: 'Companion chưa xác định được duy nhất nút mở Order trong giao diện Base. Ghép nối vẫn còn; kiểm tra nút trong Companion, không cần mở lại cài đặt kết nối.',
  BASE_COMPANION_AMBIGUOUS: 'Có nhiều nút hoặc khung Order phù hợp. Chưa bấm nhầm hoặc nhận dữ liệu; cần giữ một khung Order cho tab nguồn.',
  BASE_COMPANION_FOREIGN_UI: 'Một khung web khác đang che giao diện Order. Tool không đóng khung khác; đóng khung đó rồi Nạp lại.',
  BASE_COMPANION_OCCLUDED: 'Nút Order bị hộp thoại hoặc giao diện khác che. Tool chưa bấm; xử lý hộp thoại đó rồi Nạp lại.',
  BASE_COMPANION_DOM_TIMEOUT: 'Giao diện Base chưa mở/thu gọn Order đúng hạn. Không bấm lặp thao tác chưa rõ kết quả; ghép nối vẫn được giữ.',
  BASE_COMPANION_READER_REMOVED: 'Base đã dừng reader Order khi thu gọn. Chưa nhận bản thiếu; Companion sẽ xác nhận lại khi Nạp lần tiếp theo.',
  BASE_COMPANION_READER_OWNER: 'Chưa xác minh được reader thuộc đúng tab nguồn. Đã giữ nguyên khung Order, không đóng khung ở tab khác.',
  BASE_COMPANION_STANDBY: 'Đã bỏ qua tự khởi động khi tab Base bị ẩn. Nạp thủ công và quét nền vẫn có thể dùng tab nguồn đã xác nhận.',
  BASE_LAUNCHER_PAUSED: 'Companion trên máy này đang tạm dừng tự mở/thu gọn Order.',
  BASE_LAUNCHER_BUSY: 'Companion đang mở/thu gọn Order. Chờ thao tác hoàn tất.',
  BASE_LAUNCHER_TIMEOUT: 'Companion chưa mở/thu gọn được Order đúng hạn.',
  BASE_LAUNCHER_NOT_READY: 'Companion chưa xác nhận được nguồn Base hiện tại.',
  BASE_LAUNCHER_CHANGED: 'Phiên Companion đã đổi trong lúc đọc; chưa nhận dữ liệu.',
  BASE_LAUNCHER_REVOKED: 'Ghép nối Companion của Base này đã bị quên trên máy này.',
  BASE_LAUNCHER: 'Companion chưa xác nhận được thao tác mở/thu gọn Order.',
  BASE_DISCONNECTED: 'Reader Order đã ngắt kết nối; chưa nhận dữ liệu.',
  BASE_RECONNECTED: 'Reader Order đã đổi phiên kết nối; thử đọc lại.',
  BASE_SNAPSHOT: 'Dữ liệu Base không đủ cấu trúc xác nhận; chưa nhận bản thiếu.',
  BASE_READ: 'Base SDK báo lỗi đọc; chưa nhận dữ liệu.',
  BASE_STORE: 'Chưa hoàn tất cập nhật ghép nối mã hóa trên máy này.',
  CLIENT_VERSION: 'Reader Order và cầu nối trên máy này khác phiên bản.',
  LAUNCHER_VERSION: 'Companion và cầu nối trên máy này khác phiên bản.',
  BASE_INTERNAL: 'Cầu nối dùng chung chưa hoàn tất thao tác; chưa nhận dữ liệu.'
};
const BOOLEAN_STATE = new Set(['started', 'connected', 'busy', 'eventCapable', 'readerEventReady', 'rememberAvailable',
  'clientCompatible', 'launcherConnected', 'launcherRememberAvailable', 'launcherCompatible']);
const NUMBER_STATE = new Set(['rememberedBases', 'readElapsedMs', 'readRecords', 'launcherRememberedBases','liveRevision','liveAt']);
const STRING_STATE = new Set(['serverBuild', 'requiredClientBuild', 'clientBuild',
  'readStage', 'readDetail', 'launcherState', 'requiredLauncherBuild', 'launcherClientBuild']);

function sdkDiagnostic(value) {
  const descriptor=value&&Object.getOwnPropertyDescriptor(value,'message');
  const message=descriptor&&Object.prototype.hasOwnProperty.call(descriptor,'value')?descriptor.value:null;
  if(typeof message!=='string'||message.length>700||/[\x00-\x1f\x7f]/.test(message))return '';
  const operation='selection|source-url|table|field-meta|view|view-meta|view-filter|visible-records|bulk-records|cell-string|cell-value|event-subscription';
  const match=new RegExp('\\[SDK (?:(102\\d{5})(?:; ('+operation+'))?|('+operation+'))\\]$').exec(message);
  return match?' '+match[0]:'';
}

function safeError(value, includeBuilds) {
  const code = value && Object.prototype.hasOwnProperty.call(ERROR_MESSAGES, value.code)
    ? value.code : 'BASE_INTERNAL';
  const result={code, message: ERROR_MESSAGES[code]+(/^BASE_SDK_SDK_/.test(code)?sdkDiagnostic(value):'')};
  if(includeBuilds)for(const name of ['clientBuild','requiredClientBuild','launcherClientBuild','requiredLauncherBuild'])if(value&&typeof value[name]==='string'&&/^[A-Za-z0-9_-]{0,64}$/.test(value[name]))result[name]=value[name];
  return result;
}

function createHost(config, key, deps) {
  deps = deps || {};
  const transport = deps.net || net;
  const random = deps.crypto || crypto;
  const clock = deps.clock || {setTimeout, clearTimeout};
  if (!config || typeof config.pipePath !== 'string' || !config.pipePath ||
      typeof config.staticRoot !== 'string' || !Number.isInteger(config.port) ||
      config.port < 1 || config.port > 65535 || !Buffer.isBuffer(key) || key.length !== 32) {
    throw new Error('Invalid local broker configuration');
  }
  const loadedBridge = loadBridge(config,deps);
  const api = loadedBridge.api,bridgeSourceSHA256=loadedBridge.sha256;
  const stores = deps.stores || require(config.pairStorePath);

  let server = null;
  let broker = null;
  let starting = null;
  let brokerStarting = null;
  let closing = false;
  let closePromise = null;
  let ownPipe = false;
  let idleTimer = null;
  let hadClient = false;
  let activeRead = null;
  let priorityRead = null;
  let unsubscribe = null;
  const sockets = new Set();
  const clients = new Map();

  function clearIdle() {
    if (idleTimer !== null) clock.clearTimeout(idleTimer);
    idleTimer = null;
  }
  function armIdle(milliseconds) {
    clearIdle();
    if (closing || clients.size) return;
    idleTimer = clock.setTimeout(() => {
      idleTimer = null;
      if (!clients.size) void close();
    }, milliseconds);
  }
  function state() {
    let source;
    try { source = broker ? broker.status() : {}; } catch (_) { source = {}; }
    const out = {};
    if (!source || typeof source !== 'object') source = {};
    for (const name of BOOLEAN_STATE) {
      if (typeof source[name] === 'boolean' || source[name] === null) out[name] = source[name];
    }
    // Broker cancellation can become idle before the host has dispatched its
    // reserved manual successor. Never expose that gap as an available lane.
    out.busy = !!activeRead || !!priorityRead || source.busy === true;
    for (const name of NUMBER_STATE) {
      if (Number.isSafeInteger(source[name]) && source[name] >= 0) out[name] = source[name];
    }
    for (const name of STRING_STATE) {
      if (typeof source[name] === 'string' && /^[A-Za-z0-9_-]{0,160}$/.test(source[name])) out[name] = source[name];
    }
    for(const name of ['liveSource','readerSource']){const live=source[name];if(live&&typeof live==='object'&&typeof api.canonicalBase==='function'&&api.canonicalBase(live.url)&&/^[A-Za-z0-9_-]{1,160}$/.test(live.tableId||'')&&/^[A-Za-z0-9_-]{1,160}$/.test(live.viewId||''))out[name]={url:api.canonicalBase(live.url),tableId:live.tableId,viewId:live.viewId};}
    return out;
  }
  function write(socket, value) {
    if (socket.destroyed || !socket.writable) return false;
    let raw;
    try { raw = Buffer.from(JSON.stringify(value) + '\n', 'utf8'); }
    catch (_) { socket.destroy(); return false; }
    if (raw.length > common.MAX_BYTES + 1 || socket.writableLength + raw.length > 2 * common.MAX_BYTES) {
      socket.destroy(); return false;
    }
    socket.write(raw);
    return true;
  }
  function reply(session, seq, result, error, includeBuilds) {
    if (!session.authenticated || session.socket.destroyed) return;
    const body = {seq};
    if (error) body.error = safeError(error,includeBuilds);
    else body.result = result === undefined ? null : result;
    body.state = state();
    write(session.socket, {...body, proof: common.mac(session.key, body)});
  }
  function broadcast(raw) {
    let event;try{const value=Object.assign({},raw);delete value.status;event=common.validateEvent(value);}catch(_){return;}
    for(const session of clients.values())if(session.authenticated&&session.subscribed&&!session.socket.destroyed){const body={type:'event',eventSeq:++session.eventSeq,event,state:state()};write(session.socket,{...body,proof:common.mac(session.key,body)});}
  }
  function cancelOwnedRead(session) {
    if (activeRead && activeRead.session === session) {
      // No close/reconfigure is permitted here: other clients still own their
      // sessions. Only this explicit broker primitive can cancel this job.
      try { broker.cancelCurrentRead(); } catch (_) {}
    }
  }
  async function perform(session, request) {
    const seq = request.seq;
    try {
      if (!OPERATIONS.has(request.op)) throw {code: 'BASE_OPERATION'};
      if (closing) throw {code: 'BASE_CLOSED'};
      await brokerStarting;
      if (closing || !session.authenticated || session.socket.destroyed) throw {code: 'BASE_CLOSED'};
      let result;
      if (request.op === 'start' || request.op === 'status') result = state();
      else if(request.op==='subscribe'){if(typeof broker.subscribe!=='function')throw {code:'BASE_BACKGROUND_UNAVAILABLE'};session.subscribed=true;result=state();}
      else if (request.op === 'cancelBackgroundRead') {
        const mine = activeRead;
        if (!mine || mine.kind !== 'background' || mine.session !== session) result = {cancelled: false};
        else {
          await broker.cancelBackgroundRead();
          await mine.done.catch(() => {});
          result = {cancelled: true};
        }
      } else if (request.op === 'fetchCurrentView' || request.op === 'fetchBackgroundView' || request.op === 'fetchRecordStatuses') {
        const kind = request.op === 'fetchCurrentView' ? 'manual' : 'background';
        const statusRequest=request.op==='fetchRecordStatuses'?api.validateStatusRequest(request.args):null;
        const dirtyRequest=request.op==='fetchBackgroundView'&&request.args!==undefined?api.validateDirtyRequest(request.args):null;
        const method = request.op;
        if (typeof broker[method] !== 'function') throw {code: 'BASE_BACKGROUND_UNAVAILABLE'};
        async function launchRead() {
          if (closing || !session.authenticated || session.socket.destroyed) throw {code: 'BASE_CLOSED'};
          if (activeRead) throw {code: 'BASE_BUSY'};
          const mine = {session, seq, kind, done: null}; activeRead = mine;
          // Reserve before invoking the broker. Duplicate manual frames from
          // this session join this promise; another app can never join rows.
          mine.done = Promise.resolve().then(() => statusRequest?broker[method](statusRequest):dirtyRequest?broker[method](dirtyRequest):broker[method]());
          try { return await mine.done; }
          finally { if (activeRead === mine) activeRead = null;broadcast({type:'state',reason:'idle',at:Date.now()}); }
        }
        if (priorityRead) {
          if (kind !== 'manual' || priorityRead.session !== session) throw {code: 'BASE_BUSY'};
          result = await priorityRead.done;
        } else if (activeRead) {
          if (kind !== 'manual' || activeRead.session !== session) throw {code: 'BASE_BUSY'};
          if (activeRead.kind === 'manual') result = await activeRead.done;
          else {
            const earlier = activeRead, reservation = {session, seq, done: null}; priorityRead = reservation;
            reservation.done = Promise.resolve().then(async () => {
              await broker.cancelBackgroundRead();
              await earlier.done.catch(() => {});
              return launchRead();
            });
            try { result = await reservation.done; }
            finally { if (priorityRead === reservation) { priorityRead = null;broadcast({type:'state',reason:'idle',at:Date.now()}); } }
          }
        } else result = await launchRead();
      } else {
        if (activeRead && (request.op === 'forgetRememberedPairings' || request.op === 'forgetLauncherPairings')) {
          throw {code: 'BASE_BUSY'};
        }
        result = await broker[request.op]();
      }
      reply(session, seq, result, null);
    } catch (error) { reply(session, seq, null, error,request.op==='fetchRecordStatuses'); }
    finally { session.outstanding--; }
  }
  function exactKeys(value, names) {
    return value && typeof value === 'object' && !Array.isArray(value) &&
      Object.keys(value).length === names.length && names.every(name => Object.prototype.hasOwnProperty.call(value, name));
  }
  function frame(session, value) {
    if (closing || session.socket.destroyed) return;
    if (!session.authenticated) {
      if (session.authenticating || !exactKeys(value, ['type', 'client', 'nonce', 'proof']) ||
          value.type !== 'auth' || !/^[a-f0-9]{32}$/.test(value.client) ||
          !/^[a-f0-9]{32}$/.test(value.nonce) || typeof value.proof !== 'string' ||
          !common.equalMac(value.proof, common.mac(key, {role: 'client', serverNonce: session.serverNonce,
            clientNonce: value.nonce, client: value.client,bridgeSourceSHA256})) || clients.has(value.client)) {
        session.socket.destroy(); return;
      }
      session.authenticating = true;
      session.client = value.client;
      session.clientNonce = value.nonce;
      session.key = Buffer.from(common.mac(key, {role: 'session', serverNonce: session.serverNonce,
        clientNonce: value.nonce, client: value.client,bridgeSourceSHA256}), 'hex');
      clients.set(session.client, session);
      hadClient = true;
      clearIdle();
      // Five seconds limits the unauthenticated handshake, not DPAPI startup.
      clock.clearTimeout(session.handshakeTimer);
      session.handshakeTimer = null;
      Promise.resolve(brokerStarting).then(() => {
        if (closing || session.socket.destroyed) return;
        session.authenticated = true;
        write(session.socket, {type: 'ready', proof: common.mac(key, {role: 'server',
          serverNonce: session.serverNonce, clientNonce: session.clientNonce, client: session.client,bridgeSourceSHA256})});
      }, error => {
        if (session.socket.destroyed) return;
        const safe = safeError(error);
        write(session.socket, {type: 'error', error: safe, proof: common.mac(key, {role: 'server-error',
          serverNonce: session.serverNonce, clientNonce: session.clientNonce, client: session.client,bridgeSourceSHA256, error: safe})});
        session.socket.end();
      });
      return;
    }
    const targeted=value&&(value.op==='fetchRecordStatuses'||value.op==='fetchBackgroundView'&&Object.prototype.hasOwnProperty.call(value,'args'));
    const signed=targeted?{seq:value.seq,op:value.op,args:value.args}:{seq:value.seq,op:value.op};
    if (!exactKeys(value, targeted?['seq','op','args','proof']:['seq', 'op', 'proof']) || !Number.isSafeInteger(value.seq) ||
        value.seq !== session.nextSeq || typeof value.op !== 'string' || value.op.length > 64 ||
        typeof value.proof !== 'string' || !common.equalMac(value.proof, common.mac(session.key, signed))) {
      session.socket.destroy(); return;
    }
    session.nextSeq++;
    if (session.outstanding >= 16) { session.socket.destroy(); return; }
    session.outstanding++;
    void perform(session, value);
  }
  function accept(socket) {
    if (closing || sockets.size >= 8) { socket.destroy(); return; }
    sockets.add(socket);
    const session = {socket, serverNonce: random.randomBytes(16).toString('hex'),
      authenticated: false, authenticating: false, nextSeq: 1, eventSeq:0, subscribed:false, outstanding: 0, buffer: Buffer.alloc(0)};
    session.handshakeTimer = clock.setTimeout(() => socket.destroy(), 5000);
    socket.on('error', () => {});
    socket.on('close', () => {
      clock.clearTimeout(session.handshakeTimer);
      sockets.delete(socket);
      if (session.client && clients.get(session.client) === session) clients.delete(session.client);
      cancelOwnedRead(session);
      if (!clients.size && hadClient) armIdle(15000);
    });
    socket.on('data', chunk => {
      if (socket.destroyed || closing) return;
      session.buffer = Buffer.concat([session.buffer, chunk]);
      let newline;
      while ((newline = session.buffer.indexOf(10)) >= 0) {
        if (newline > common.MAX_BYTES) { socket.destroy(); return; }
        const raw = session.buffer.subarray(0, newline);
        session.buffer = session.buffer.subarray(newline + 1);
        let value;
        try {
          const text = raw.toString('utf8');
          if (!Buffer.from(text, 'utf8').equals(raw)) throw new Error();
          value = common.decodeFrame(text);
        } catch (_) { socket.destroy(); return; }
        frame(session, value);
        if (socket.destroyed) return;
      }
      if (session.buffer.length > common.MAX_BYTES) socket.destroy();
    });
    write(socket, {type: 'challenge', nonce: session.serverNonce,bridgeSourceSHA256});
  }
  function start() {
    if (starting) return starting;
    if (closing) return Promise.reject({code: 'BASE_CLOSED'});
    starting = new Promise((resolve, reject) => {
      server = transport.createServer(accept);
      const failed = error => {
        // In particular, EADDRINUSE means a winner already owns this pipe.
        // A losing process never constructs or binds the HTTP Base broker.
        if (!ownPipe) { closing = true; reject(error); }
      };
      server.on('error', failed);
      server.listen(config.pipePath, () => {
        ownPipe = true;
        armIdle(30000);
        brokerStarting = Promise.resolve().then(() => {
          if (closing) throw {code: 'BASE_CLOSED'};
          broker = api.createBroker({port: config.port, staticRoot: config.staticRoot,
            trustStore: stores.createWindowsStore(), launcherTrustStore: stores.createWindowsStore({role: 'launcher'})});
          if(typeof broker.subscribe==='function')unsubscribe=broker.subscribe(broadcast);
          return broker.start();
        });
        // Keep the winning pipe alive on an HTTP startup refusal long enough
        // for authenticated clients to receive its signed actionable error.
        brokerStarting.then(() => resolve(), reject);
      });
    });
    return starting;
  }
  function close() {
    if (closePromise) return closePromise;
    closing = true;
    clearIdle();
    if(unsubscribe){unsubscribe();unsubscribe=null;}
    closePromise = new Promise(resolve => {
      for (const socket of sockets) socket.destroy();
      if (broker) { try { broker.close(); } catch (_) {} }
      if (server && ownPipe) {
        try { server.close(() => resolve()); } catch (_) { resolve(); }
      } else resolve();
    });
    return closePromise;
  }
  return {start, close};
}

module.exports = {createHost, safeError};

if (require.main === module) {
  let host;
  try {
    const config = common.loadConfig();
    host = createHost(config, common.readKey(config));
  } catch (_) { process.exitCode = 1; }
  if (host) {
    host.start().catch(error => {
      if (error && error.code === 'EADDRINUSE') { void host.close(); process.exitCode = 0; }
      else if (error && ['EACCES', 'EINVAL', 'ENOENT'].includes(error.code)) { void host.close(); process.exitCode = 1; }
      // Other startup failures remain behind authenticated pipe replies until
      // the bounded idle shutdown. Never print tokens, paths or raw errors.
    });
    const shutdown = () => { void host.close(); };
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
    process.on('uncaughtException', () => { process.exitCode = 1; shutdown(); });
    process.on('unhandledRejection', () => { process.exitCode = 1; shutdown(); });
  }
}
