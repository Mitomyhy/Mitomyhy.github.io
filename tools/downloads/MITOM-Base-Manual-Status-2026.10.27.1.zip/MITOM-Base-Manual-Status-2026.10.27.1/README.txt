MITOM Base manual-status repair 2026.10.27.1

Save your work and close Photoshop and OrderStudio yourself before running Update Base Manual Status.cmd.
Requires managed Panel2026.10.26.3 with exact known Base/coexist code, or an owned25.1/26.1/26.2 receipt already carrying the exact R70 Base repair and known original coexist files. Changes at most six owned JS files.
Older unpatched Base code, unknown mixtures and custom/newer files are refused; use the cumulative Launcher update.
No models, CPU/GPU routing code or runtimes, local settings, pairing or full-install receipt are changed.
This Base-only repair does not upgrade an older CPU/GPU route. Use Launcher update for the full newest Panel. No package download, CUDA setup or generation starts.
A full backup is recorded under your own LOCALAPPDATA/UOY/Launcher/backups.
Use Launcher > Photoshop Panel > ... > Restore previous version if an update was interrupted.
Unknown/newer/custom files are preserved and require the cumulative release instead.
