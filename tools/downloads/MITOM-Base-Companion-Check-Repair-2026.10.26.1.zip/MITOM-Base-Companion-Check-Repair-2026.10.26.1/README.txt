UOY Base Companion file checker / explicit restore

Double-click Check Companion.cmd. Diagnosis is the default and changes no code.
If a narrowly recognized problem can be restored, type REPAIR to explicitly
approve restoration in the EXACT displayed folder. Otherwise press Enter.
The default folder is %LOCALAPPDATA%\UOY\Companion. A different source folder:

powershell.exe -NoProfile -File .\Check-Companion.ps1 -TargetPath "D:\Your Companion"

Explicit noninteractive restore adds -Repair. Optional -ReportPath must name a
new .json file in an existing safe local folder. No administrator is required.
The double-click wrapper sets execution policy only for this one PowerShell
process so this reviewed bundled script can run. It never calls Set-ExecutionPolicy
or changes registry, machine/user policy, GPO, antivirus, browser policy or
elevation. Enterprise policy still takes priority. If it blocks this script,
stop and ask your administrator; the tool does not work around enterprise GPO.

Only the eight bundled, SHA-256-pinned public1.0.27 files can be restored.
Recognized targets are exact known24/25/26/27 file vectors (including historical
diagnostic popups), exact canonical27 with missing files, or canonical27 code
with only exact URL Markdown/escaping corruption in an otherwise identical
manifest. Unknown/custom files, foreign identity, newer versions, broad roots,
browser profiles and reparse points are refused. Extra files are preserved.
Unreadable or missing manifest identity is diagnosis-only; it is never guessed.

Every existing named code file is backed up before replacement under
.uoy-companion-repair-backups in the target. Failures attempt hash-guarded
rollback; later edits are preserved and reported as pending. Keep that backup.
No Chrome profile, cookies, API key, pairing, browser policy or Photoshop file
is read or changed. Standard Chrome executable version metadata is read only.
No browser/app is launched, closed, removed, or automatically reloaded.

A file restore does NOT prove the colleague's unknown Chrome error is fixed.
Chrome must meet the package minimum120 and allow unpacked extensions under
your organization's policy. If restored, reload the SAME extension and refresh
the Base tab once. Never Remove, Forget, clear storage or copy another PC's
pairing. The stable extension ID remains nbmhofblkjlmlijiokgdeojjomjcphhj.
