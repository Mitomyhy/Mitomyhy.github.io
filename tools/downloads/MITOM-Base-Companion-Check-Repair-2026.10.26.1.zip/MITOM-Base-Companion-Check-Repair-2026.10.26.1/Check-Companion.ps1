[CmdletBinding()]
param([string]$TargetPath = '', [switch]$Repair, [switch]$Interactive, [string]$ReportPath = '')
$ErrorActionPreference = 'Stop'
$script:ToolRoot = $PSScriptRoot
$script:Names = @('README.txt','background.js','content.js','core.js','manifest.json','popup.css','popup.html','popup.js')
$script:VectorPin = '487684c5bb7cfea04b73dae17e59e413121747e1869cf7750ea5bab7c69280c1'
$script:Utf8 = New-Object System.Text.UTF8Encoding($false, $true)

function Fail([string]$Code) { throw $Code }
function Sha([byte[]]$Bytes) { $h=[Security.Cryptography.SHA256]::Create(); try { return ([BitConverter]::ToString($h.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() } finally { $h.Dispose() } }
function Safe-Path([string]$Path, [switch]$AllowMissing) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not [IO.Path]::IsPathRooted($Path)) { Fail 'ABSOLUTE_PATH_REQUIRED' }
    $full=[IO.Path]::GetFullPath($Path)
    if($full -match '(?i)\\(?:Google\\Chrome|Microsoft\\Edge|Chromium)\\User Data(?:\\|$)'){Fail 'BROWSER_PROFILE_REFUSED'}
    if ($full.StartsWith('\\') -or $full.Substring(2).Contains(':') -or $full.IndexOfAny([char[]]'*?') -ge 0) { Fail 'UNSAFE_PATH' }
    $cursor=$full
    while ($cursor) {
        if ([IO.File]::Exists($cursor) -or [IO.Directory]::Exists($cursor)) {
            $item=Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Fail 'REPARSE_PATH' }
        } elseif ($cursor -eq $full -and -not $AllowMissing) { Fail 'MISSING_PATH' }
        $parent=[IO.Directory]::GetParent($cursor)
        if ($null -eq $parent) { break }; $cursor=$parent.FullName
    }
    return $full
}
function Read-Bytes([string]$Path, [int]$Limit=4194304) {
    $safe=Safe-Path $Path
    $item=Get-Item -LiteralPath $safe -Force
    if ($item.PSIsContainer -or $item.Length -gt $Limit) { Fail 'FILE_SHAPE_OR_SIZE' }
    return ,([IO.File]::ReadAllBytes($safe))
}
function File-Hash([string]$Path) {
    $safe=Safe-Path $Path -AllowMissing
    if (-not [IO.File]::Exists($safe)) { if ([IO.Directory]::Exists($safe)) { Fail 'CODE_FILE_IS_DIRECTORY' }; return $null }
    return Sha (Read-Bytes $safe)
}
function Read-JsonBytes([byte[]]$Bytes) {
    $text=$script:Utf8.GetString($Bytes)
    # Check duplicate/case-colliding keys before ConvertFrom-Json can collapse them.
    $tokens=[regex]::Matches($text,'"(?:\\.|[^"\\])*"|[{}\[\]:,]')
    $stack=New-Object System.Collections.Stack
    for($i=0;$i -lt $tokens.Count;$i++) {
        $token=$tokens[$i].Value
        if($token -eq '{') { $stack.Push((New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase))) }
        elseif($token -eq '[') { $stack.Push($null) }
        elseif($token -eq '}' -or $token -eq ']') { if($stack.Count -eq 0){Fail 'INVALID_JSON'};[void]$stack.Pop() }
        elseif($token.StartsWith('"') -and $i+1 -lt $tokens.Count -and $tokens[$i+1].Value -eq ':') {
            if($stack.Count -eq 0 -or $null -eq $stack.Peek()){Fail 'INVALID_JSON'}
            $key=ConvertFrom-Json -InputObject $token
            if(-not $stack.Peek().Add($key)){Fail 'DUPLICATE_JSON_KEY'}
        }
    }
    if($stack.Count -ne 0){Fail 'INVALID_JSON'}
    try { return ConvertFrom-Json -InputObject $text } catch { Fail 'INVALID_JSON' }
}
function Canonical($Value) {
    if($null -eq $Value){return 'null'}
    if($Value -is [string]){return ConvertTo-Json -InputObject $Value -Compress}
    if($Value -is [System.Management.Automation.PSCustomObject]) {
        $keys=@($Value.PSObject.Properties.Name);[Array]::Sort($keys,[StringComparer]::Ordinal)
        $parts=@();foreach($key in $keys){$parts+=((ConvertTo-Json -InputObject $key -Compress)+':'+(Canonical $Value.$key))};return '{'+($parts -join ',')+'}'
    }
    if($Value -is [System.Collections.IEnumerable]) {$parts=@();foreach($item in $Value){$parts+=Canonical $item};return '['+($parts -join ',')+']'}
    return ConvertTo-Json -InputObject $Value -Compress
}
function Scan-Tree([string]$Root) {
    $queue=New-Object System.Collections.Queue;$queue.Enqueue(@($Root,0));$count=0
    while($queue.Count) {
        $node=$queue.Dequeue();if($node[1] -gt 16){Fail 'TARGET_TREE_LIMIT'}
        [void](Safe-Path $node[0])
        foreach($item in (Get-ChildItem -LiteralPath $node[0] -Force)) {
            $count++;if($count -gt 4096){Fail 'TARGET_TREE_LIMIT'}
            if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){Fail 'REPARSE_PATH'}
            if($item.PSIsContainer){$queue.Enqueue(@($item.FullName,($node[1]+1)))}
        }
    }
}
function Target-Root([string]$Path) {
    if(-not [IO.Path]::IsPathRooted($Path)){Fail 'ABSOLUTE_PATH_REQUIRED'}
    $full=[IO.Path]::GetFullPath($Path)
    # Never enter any browser profile, even if it contains an extension folder.
    if($full -match '(?i)\\(?:Google\\Chrome|Microsoft\\Edge|Chromium)\\User Data(?:\\|$)'){Fail 'BROWSER_PROFILE_REFUSED'}
    $full=Safe-Path $full
    $broad=@([IO.Path]::GetPathRoot($full),$env:USERPROFILE,$env:LOCALAPPDATA,$env:APPDATA,$env:ProgramFiles,${env:ProgramFiles(x86)},$env:WINDIR)
    foreach($root in $broad){if($root -and $full.TrimEnd('\') -ieq ([IO.Path]::GetFullPath($root)).TrimEnd('\')){Fail 'BROAD_ROOT_REFUSED'}}
    if(-not [IO.Directory]::Exists($full)){Fail 'NOT_DIRECTORY'}
    $source=[IO.Path]::GetFullPath((Join-Path $script:ToolRoot 'Chrome-Base-Companion'))
    if($full -ieq $source -or $full.StartsWith($source+'\',[StringComparison]::OrdinalIgnoreCase) -or $source.StartsWith($full+'\',[StringComparison]::OrdinalIgnoreCase)){Fail 'SOURCE_TARGET_OVERLAP'}
    Scan-Tree $full
    return $full
}
function Source-Data {
    $vectors=Read-Bytes (Join-Path $script:ToolRoot 'known-vectors.json') 65536
    if((Sha $vectors) -cne $script:VectorPin){Fail 'SOURCE_VECTOR_INTEGRITY'}
    $pins=Read-JsonBytes $vectors;$source=Safe-Path (Join-Path $script:ToolRoot 'Chrome-Base-Companion');$bytes=@{}
    foreach($name in $script:Names){$raw=Read-Bytes (Join-Path $source $name);$pin=$pins.target.$name;if($raw.Length -ne $pin.size -or (Sha $raw) -cne $pin.sha256){Fail 'SOURCE_INTEGRITY'};$bytes[$name]=$raw}
    $manifest=Read-JsonBytes $bytes['manifest.json']
    if($pins.extension_id -cne 'nbmhofblkjlmlijiokgdeojjomjcphhj' -or $manifest.version -cne '1.0.27'){Fail 'SOURCE_IDENTITY'}
    return @{Pins=$pins;Bytes=$bytes;Manifest=$manifest}
}
function Chrome-Version {
    $paths=@();foreach($root in @($env:ProgramFiles,${env:ProgramFiles(x86)},$env:LOCALAPPDATA)){if($root){$paths+=Join-Path $root 'Google\Chrome\Application\chrome.exe'}}
    $found=@();foreach($path in $paths){try{$safe=Safe-Path $path;if([IO.File]::Exists($safe)){$v=[Diagnostics.FileVersionInfo]::GetVersionInfo($safe);if($v.ProductVersion -match '^\d+(?:\.\d+){1,3}$'){$found+=$v.ProductVersion}}}catch{}}
    if(-not $found.Count){return [ordered]@{found=$false;minimumRequired=120;meetsMinimum=$null;activeBrowserVerified=$false}}
    $latest=$found|Sort-Object {[version]$_} -Descending|Select-Object -First 1
    return [ordered]@{found=$true;version=$latest;major=([version]$latest).Major;minimumRequired=120;meetsMinimum=([version]$latest).Major -ge 120;activeBrowserVerified=$false;versionSource='standard_executable_metadata'}
}
function Match-Patterns($Manifest,$Canonical) {
    foreach($field in @('host_permissions','optional_host_permissions')) {
        $actual=@($Manifest.$field);$expected=@($Canonical.$field)
        if($actual.Count -ne $expected.Count){return $false}
        for($i=0;$i -lt $expected.Count;$i++) {
            if($actual[$i] -isnot [string]){return $false}
            $plain=$expected[$i];$escaped=$plain.Replace('/','\/');$value=$actual[$i]
            if($value -cne $plain -and $value -cne ('['+$plain+']('+$plain+')') -and $value -cne $escaped -and $value -cne ('['+$escaped+']('+$escaped+')')){return $false}
        }
        $Manifest.$field=@($expected)
    }
    return (Canonical $Manifest) -ceq (Canonical $Canonical)
}
function Normalize-ExactManifestText([byte[]]$Bytes,$Canonical) {
    $text=$script:Utf8.GetString($Bytes)
    foreach($plain in @($Canonical.host_permissions)+@($Canonical.optional_host_permissions)) {
        # A literal Markdown backslash before * is invalid JSON. Repair ONLY
        # whole quoted wrappers whose label and target are the same known URL.
        $labels=@($plain,$plain.Replace('*','\*'),$plain.Replace('*','\\*'))
        foreach($label in $labels){$text=$text.Replace(('"['+$label+']('+$plain+')"'),('"'+$plain+'"'))}
    }
    return ,($script:Utf8.GetBytes($text))
}
function Target-State([string]$Root,$Source) {
    $bytes=@{};$hashes=@{};$details=@();$missing=0
    foreach($name in $script:Names) {
        $file=Join-Path $Root $name
        if([IO.File]::Exists($file)){$raw=Read-Bytes $file;$bytes[$name]=$raw;$hashes[$name]=Sha $raw;$details += [ordered]@{file=$name;present=$true;canonical=($hashes[$name] -ceq $Source.Pins.target.$name.sha256)}}
        else {if([IO.Directory]::Exists($file)){Fail 'CODE_FILE_IS_DIRECTORY'};$bytes[$name]=$null;$hashes[$name]=$null;$missing++;$details += [ordered]@{file=$name;present=$false;canonical=$false}}
    }
    if($null -eq $bytes['manifest.json']){Fail 'MISSING_MANIFEST_IDENTITY'}
    $normalized=Normalize-ExactManifestText $bytes['manifest.json'] $Source.Manifest
    $manifest=Read-JsonBytes $normalized
    if($manifest.manifest_version -ne 3 -or $manifest.name -cne $Source.Manifest.name -or $manifest.key -cne $Source.Manifest.key){Fail 'FOREIGN_EXTENSION_IDENTITY'}
    if($manifest.version -notmatch '^1\.0\.\d+$'){Fail 'UNKNOWN_TARGET_VERSION'}
    if([version]$manifest.version -gt [version]'1.0.27'){Fail 'NEWER_EXTENSION_REFUSED'}
    $classification='UNKNOWN_CODE_VECTOR';$known=$null
    foreach($vector in $Source.Pins.accepted_vectors){$equal=$true;foreach($name in $script:Names){if($hashes[$name] -cne $vector.files.$name){$equal=$false;break}};if($equal){$known=$vector.label;break}}
    $allCanonical=$true;$presentCanonical=$true;$sevenCanonical=$true
    foreach($name in $script:Names){if($hashes[$name] -cne $Source.Pins.target.$name.sha256){$allCanonical=$false;if($null -ne $hashes[$name]){$presentCanonical=$false};if($name -ne 'manifest.json'){$sevenCanonical=$false}}}
    if($allCanonical){$classification='CURRENT_VALID'}
    elseif($known){$classification='KNOWN_OLD_VECTOR'}
    elseif($missing -gt 0 -and $presentCanonical){$classification='CANONICAL_MISSING_FILES'}
    elseif($missing -eq 0 -and $sevenCanonical -and $manifest.version -ceq '1.0.27' -and (Match-Patterns $manifest $Source.Manifest)){$classification='CANONICAL_MANIFEST_ENCODING'}
    return @{Bytes=$bytes;Hashes=$hashes;Details=$details;Classification=$classification;KnownLabel=$known;Version=$manifest.version;Repairable=($classification -in @('KNOWN_OLD_VECTOR','CANONICAL_MISSING_FILES','CANONICAL_MANIFEST_ENCODING'))}
}
function Assert-Unchanged([string]$Root,$Hashes) {
    [void](Target-Root $Root)
    foreach($name in $script:Names){if((File-Hash (Join-Path $Root $name)) -cne $Hashes[$name]){Fail 'DESTINATION_CHANGED'}}
}
function Write-NewFile([string]$Path,[byte[]]$Bytes) {
    [void](Safe-Path $Path -AllowMissing)
    $stream=New-Object IO.FileStream($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$stream.Write($Bytes,0,$Bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
}
function Write-CodeAtomic([string]$Path,[byte[]]$Bytes,$Expected) {
    if((File-Hash $Path) -cne $Expected){Fail 'DESTINATION_CHANGED'}
    $temporary=$Path+'.uoy-repair-'+[guid]::NewGuid().ToString('N')+'.tmp';$created=$false
    try {
        Write-NewFile $temporary $Bytes;$created=$true
        [void](Safe-Path ([IO.Path]::GetDirectoryName($Path)))
        if((File-Hash $Path) -cne $Expected -or (File-Hash $temporary) -cne (Sha $Bytes)){Fail 'DESTINATION_CHANGED'}
        if($null -eq $Expected){[IO.File]::Move($temporary,$Path)}else{[IO.File]::Replace($temporary,$Path,[NullString]::Value)}
    } finally {
        if($created -and [IO.File]::Exists($temporary) -and (File-Hash $temporary) -ceq (Sha $Bytes)){[IO.File]::Delete($temporary)}
    }
}
function Remove-OwnStage([string]$Stage,[string]$Backup,$Source) {
    if([IO.Path]::GetDirectoryName($Stage) -ine $Backup -or [IO.Path]::GetFileName($Stage) -cne 'staged'){Fail 'STAGE_OWNERSHIP'}
    [void](Safe-Path $Stage)
    foreach($name in $script:Names){$file=Join-Path $Stage $name;if([IO.File]::Exists($file)){if((File-Hash $file) -cne $Source.Pins.target.$name.sha256){Fail 'STAGE_CHANGED'};[IO.File]::Delete($file)}}
    [IO.Directory]::Delete($Stage,$false)
}
function Restore-Code([string]$Root,$State,$Source) {
    Assert-Unchanged $Root $State.Hashes
    $backupParent=Join-Path $Root '.uoy-companion-repair-backups';[void](Safe-Path $backupParent -AllowMissing)
    [IO.Directory]::CreateDirectory($backupParent)|Out-Null
    $backup=Join-Path $backupParent (([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ'))+'-'+[guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($backup)|Out-Null;[void](Safe-Path $backup)
    $stage=Join-Path $backup 'staged';[IO.Directory]::CreateDirectory($stage)|Out-Null
    $changed=New-Object 'System.Collections.Generic.List[string]';$attempted=New-Object 'System.Collections.Generic.List[string]';$pending=@();$failure=$null
    try {
        foreach($name in $script:Names){Write-NewFile (Join-Path $stage $name) $Source.Bytes[$name]}
        foreach($name in $script:Names){if((File-Hash (Join-Path $stage $name)) -cne $Source.Pins.target.$name.sha256){Fail 'STAGE_INTEGRITY'}}
        $inventory=@();foreach($name in $script:Names){$raw=$State.Bytes[$name];if($null -ne $raw){Write-NewFile (Join-Path $backup $name) $raw;if((File-Hash (Join-Path $backup $name)) -cne $State.Hashes[$name]){Fail 'BACKUP_INTEGRITY'}};$inventory += [ordered]@{file=$name;existed=($null -ne $raw);sha256=$State.Hashes[$name];size=$(if($null -ne $raw){$raw.Length}else{0})}}
        $record=[ordered]@{schema=1;tool='UOY Companion file checker';version='1.0.27';files=$inventory}
        Write-NewFile (Join-Path $backup 'inventory.json') $script:Utf8.GetBytes(($record|ConvertTo-Json -Depth 12))
        Assert-Unchanged $Root $State.Hashes
        foreach($name in $script:Names){if($State.Hashes[$name] -cne $Source.Pins.target.$name.sha256){$attempted.Add($name);Write-CodeAtomic (Join-Path $Root $name) $Source.Bytes[$name] $State.Hashes[$name];$changed.Add($name)}}
        foreach($name in $script:Names){if((File-Hash (Join-Path $Root $name)) -cne $Source.Pins.target.$name.sha256){Fail 'POSTWRITE_INTEGRITY'}}
    } catch {
        $failure=$_.Exception.Message
        for($i=$attempted.Count-1;$i -ge 0;$i--){$name=$attempted[$i];try{$file=Join-Path $Root $name;$current=File-Hash $file;if($current -ceq $State.Hashes[$name]){continue};if($current -cne $Source.Pins.target.$name.sha256){Fail 'LATER_EDIT_PRESERVED'};if($null -eq $State.Hashes[$name]){[IO.File]::Delete($file)}else{$old=Read-Bytes (Join-Path $backup $name);if((Sha $old) -cne $State.Hashes[$name]){Fail 'BACKUP_INTEGRITY'};Write-CodeAtomic $file $old $Source.Pins.target.$name.sha256}}catch{$pending+=$name}}
    } finally {try{if([IO.Directory]::Exists($stage)){Remove-OwnStage $stage $backup $Source}}catch{$pending+='staged'}}
    return @{Success=($null -eq $failure);Changed=$changed.Count;BackupRelative=('.uoy-companion-repair-backups/'+[IO.Path]::GetFileName($backup));Failure=$failure;RollbackPending=@($pending);RolledBack=($null -ne $failure -and $pending.Count -eq 0)}
}
function Invoke-CompanionCheck([string]$Path,[bool]$DoRepair=$false) {
    $report=[ordered]@{schema=1;tool='UOY Companion file checker';sourceVersion='1.0.27';ok=$false;status='refused';classification='';repairRequested=$DoRepair;repairable=$false;codeFilesChanged=0;chrome=(Chrome-Version);reloadRequired=$false;notes=@('No Chrome profile, pairing, cookies, API key or browser policy is read or changed.','A file restore does not prove the unknown Chrome load error is fixed. Reload the same extension; never Remove or Forget.')}
    try {
        $source=Source-Data;$root=Target-Root $Path;$state=Target-State $root $source
        $report.classification=$state.Classification;$report.targetVersion=$state.Version;$report.files=$state.Details;$report.repairable=$state.Repairable
        if($state.Classification -eq 'CURRENT_VALID'){$report.ok=$true;$report.status='current_valid';return $report}
        if(-not $state.Repairable){$report.errorCode='UNKNOWN_CODE_VECTOR';return $report}
        $report.status='repair_available'
        if(-not $DoRepair){return $report}
        $result=Restore-Code $root $state $source;$report.codeFilesChanged=$result.Changed;$report.backup=$result.BackupRelative;$report.rollbackPending=$result.RollbackPending
        if($result.Success){$report.ok=$true;$report.status='files_restored';$report.reloadRequired=$true}
        else{$report.status=$(if($result.RolledBack){'failed_rolled_back'}else{'failed_rollback_pending'});$report.errorCode=$(if($result.Failure -match '^[A-Z][A-Z0-9_]+$'){$result.Failure}else{'FILESYSTEM_ERROR'})}
    } catch {$report.errorCode=$(if($_.Exception.Message -match '^[A-Z][A-Z0-9_]+$'){$_.Exception.Message}else{'FILESYSTEM_ERROR'})}
    return $report
}
function Write-Report([string]$Path,$Report) {
    $full=Safe-Path $Path -AllowMissing
    if($full -match '(?i)\\(?:Google\\Chrome|Microsoft\\Edge|Chromium)\\User Data(?:\\|$)' -or [IO.Path]::GetExtension($full) -ine '.json' -or [IO.Path]::GetFileName($full) -in $script:Names){Fail 'UNSAFE_REPORT_PATH'}
    $json=$Report|ConvertTo-Json -Depth 16;Write-NewFile $full ($script:Utf8.GetBytes($json))
}
if($MyInvocation.InvocationName -eq '.'){return}
$cleanGuidanceOnly=$false
if($Interactive -and -not $TargetPath){
    try{[void](Source-Data)}catch{Write-Output '{"ok":false,"errorCode":"SOURCE_INTEGRITY"}';exit 1}
    Write-Host 'For a NEW install, choose the bundled Chrome-Base-Companion folder in Chrome Load unpacked.'
    Write-Host ('Clean bundled folder: '+(Join-Path $script:ToolRoot 'Chrome-Base-Companion'))
    Write-Host 'For an EXISTING extension, diagnose the exact source folder Chrome currently loads. Do not Remove or Forget.'
    $managed=$(if($env:LOCALAPPDATA){Join-Path $env:LOCALAPPDATA 'UOY\Companion'}else{''})
    if($managed -and [IO.Directory]::Exists($managed)){Write-Host ('Managed folder available: '+$managed);$choice=Read-Host 'Paste the exact existing folder, type MANAGED to inspect that displayed folder, or Enter for clean-bundle guidance only'}
    else{$choice=Read-Host 'Paste the exact existing folder, or Enter for clean-bundle guidance only'}
    if($choice -ceq 'MANAGED' -and $managed -and [IO.Directory]::Exists($managed)){$TargetPath=$managed}
    elseif(-not [string]::IsNullOrWhiteSpace($choice)){$TargetPath=$choice.Trim().Trim('"')}
    else{$cleanGuidanceOnly=$true}
}
if(-not $TargetPath -and -not $cleanGuidanceOnly){if(-not $env:LOCALAPPDATA){Write-Output '{"ok":false,"errorCode":"LOCALAPPDATA_REQUIRED"}';exit 1};$TargetPath=Join-Path $env:LOCALAPPDATA 'UOY\Companion'}
if($cleanGuidanceOnly){$result=[ordered]@{schema=1;tool='UOY Companion file checker';ok=$true;status='clean_bundle_ready';sourceVersion='1.0.27';bundledSourceFilesVerified=8;chromeLoadResult='unknown_not_tested';chrome=(Chrome-Version);codeFilesChanged=0;repairable=$false}}
else{$result=Invoke-CompanionCheck $TargetPath ([bool]$Repair)}
if($Interactive){
    if($TargetPath){Write-Host ('Folder: '+$TargetPath)};Write-Host ('Result: '+$result.status+' / '+$result.classification)
    if($result.chrome.found){Write-Host ('Detected Chrome: '+$result.chrome.version+'; required minimum: 120; compatible version: '+$result.chrome.meetsMinimum)}else{Write-Host 'Chrome was not found in standard installation locations; required minimum is120. No browser was launched.'}
    Write-Host 'Installed executable metadata only: the browser currently opened by you was NOT verified.'
    Write-Host 'CURRENT_VALID means FILES ONLY. The actual Chrome load result is UNKNOWN and was not tested.'
    if($result.repairable -and -not $Repair){Write-Host 'Only eight known extension code files can be restored. A backup will be retained.';$answer=Read-Host 'Type REPAIR to restore this exact folder, or press Enter to diagnose only';if($answer -ceq 'REPAIR'){$result=Invoke-CompanionCheck $TargetPath $true}}
    if(-not $ReportPath){$save=Read-Host 'Save a new local JSON report beside this tool so you can send it? Type YES to consent';if($save -ceq 'YES'){$ReportPath=Join-Path $script:ToolRoot ('Companion-check-report-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'-'+[guid]::NewGuid().ToString('N')+'.json')}}
}
if($ReportPath){try{Write-Report $ReportPath $result;if($Interactive){Write-Host ('Local report saved: '+$ReportPath)}}catch{$result.reportErrorCode='REPORT_NOT_WRITTEN'}}
Write-Output ($result|ConvertTo-Json -Depth 16)
if($Interactive){Write-Host 'Keep Chrome pairing. Reload the SAME extension and refresh Base once after a restore.';[void](Read-Host 'Press Enter to close')}
if($result.ok){exit 0};if($result.repairable -and -not $Repair){exit 2};exit 1
