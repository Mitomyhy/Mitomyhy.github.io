(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.UoyCompanion = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const EXTENSION_ID = 'nbmhofblkjlmlijiokgdeojjomjcphhj';
  const BUILD = '20261023-R55';
  // Companion-only content patch. Keep the authenticated host wire build
  // compatible with the existing R55 Photoshop/helper session.
  const CONTENT_REVISION = '20261027-R74';
  const CONTENT_PROTOCOL = 1;
  const ROLE = 'uoy-base-launcher';
  const ROUTES = new Set(['/launcher/v1/hello', '/launcher/v1/poll', '/launcher/v1/result', '/launcher/v1/state']);
  const STORAGE_KEY = 'uoy.launcher.config.v1';
  // R16's destructive Order X is intentionally not migrated. Going back to
  // the extension list and closing that list preserves the official reader.
  const STEPS = ['toolbar', 'order', 'back', 'listClose'];
  const OPEN_STEPS = ['toolbar', 'order'];
  // A Base can place Order directly in its list or inside Customize. Keep the
  // original four readiness keys; this extra route is only explicitly taught.
  const TEACH_STEPS = ['toolbar', 'customize', 'order', 'back', 'listClose'];
  const ORDER_TITLE_CLASS = 'extension-market-grid-list-flex-container-v4-item-content-title-recommend';
  const FORBIDDEN = /(?:log\s*in|sign\s*in|sign\s*up|password|cookie|captcha|verify|verification|permission|authorize|delete|remove|share|publish|invite|đăng\s*nhập|mật\s*khẩu|xác\s*minh|quyền|chia\s*sẻ|xóa|xoá|登录|验证|删除|共享|授权)/iu;
  const ERRORS = {
    READER_NOT_PAIRED:'Mở UOY Order Custom trong Base và ghép reader với Photoshop trước; Companion không thay thế quyền reader.',
    OTHER_LAUNCHER:'Một Companion khác đang dùng cầu nối. Chỉ giữ một tab Base/Companion rồi thử lại.',
    STALE_COMMAND:'Lệnh đã hết hạn. Không bấm lặp tự động; bấm Nạp lại trong Photoshop.',
    BASE_METADATA:'Chọn view có table/view trong URL Base rồi bấm Nạp lại.',
    BASE_IDENTITY:'Base hiện tại không khớp Base đã ghép Companion.',
    BASE_VIEW_CHANGED:'View đã đổi giữa lúc đọc. Chọn view đúng rồi bấm Nạp lại.',
    CLIENT:'Phiên Companion không hợp lệ; mở popup kiểm tra kết nối.',
    AUTH:'Mã Companion không còn được chấp nhận. Lấy mã Chrome Companion mới từ Photoshop.',
    REVOKED:'Ghép Companion đã bị quên ở Photoshop. Lấy mã Chrome Companion mới; ghép reader vẫn riêng biệt.',
    TRUST_LIMIT:'Cầu nối đã đủ số ghép được lưu. Quên một ghép Companion không dùng trước.',
    TRUST_STORE:'Photoshop không lưu được ghép Companion. Kết nối chỉ có hiệu lực phiên này.',
    BODY_LIMIT:'Metadata Companion vượt giới hạn; không gửi dữ liệu đơn qua Companion.',
    TYPE:'Cầu nối không nhận kiểu thông điệp Companion này.'
  };
  function fail(message, code) { const e = new Error(message); e.code = code || 'SAFE_STOP'; throw e; }
  function validateContentReadiness(reply) {
    if (reply && reply.contentBuild === BUILD && reply.contentRevision === CONTENT_REVISION && reply.contentProtocol === CONTENT_PROTOCOL && reply.readerBindingVersion === 1) return reply;
    const label=reply && (reply.contentRevision || reply.contentBuild);
    const actual = typeof label === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(label) ? label : 'chưa xác định';
    const e = new Error('Bộ kiểm tra trong tab Base: '+actual+'; Companion cần bản vá '+CONTENT_REVISION+' (tương thích host '+BUILD+'). Lưu công việc rồi tải lại riêng tab Base một lần để nạp đúng mã. Không tự tải lại tab, thay thế lệnh đang chạy hay đổi ghép nối.');
    e.code='CONTENT_VERSION';e.clientBuild=actual==='chưa xác định'?'':actual;e.requiredClientBuild=CONTENT_REVISION;throw e;
  }
  function text(value, max) { return typeof value === 'string' ? value.trim().slice(0, max || 160) : ''; }
  // Bounded public-control telemetry only; no DOM prose, source or selectors.
  function routeDiagnostic(value) {
    const keys=['contentRevision','documentVisible','hasHint','hasStrongHint','hintMatches','phase','semanticMatches','stateNormalizedMatches','step','strongMatches','version'];
    if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).sort().join(',')!==keys.join(','))return null;
    if(keys.some(key=>{const d=Object.getOwnPropertyDescriptor(value,key);return !d||!Object.prototype.hasOwnProperty.call(d,'value');}))return null;
    if(value.version!==1||value.contentRevision!==CONTENT_REVISION||!['toolbar','customize','order'].includes(value.step)||!['resolve','activate'].includes(value.phase)||typeof value.documentVisible!=='boolean'||typeof value.hasHint!=='boolean'||typeof value.hasStrongHint!=='boolean'||value.hasStrongHint&&!value.hasHint||['hintMatches','semanticMatches','strongMatches','stateNormalizedMatches'].some(key=>!Number.isInteger(value[key])||value[key]<0||value[key]>2))return null;
    return {version:1,contentRevision:CONTENT_REVISION,step:value.step,phase:value.phase,hintMatches:value.hintMatches,semanticMatches:value.semanticMatches,strongMatches:value.strongMatches,stateNormalizedMatches:value.stateNormalizedMatches,hasHint:value.hasHint,hasStrongHint:value.hasStrongHint,documentVisible:value.documentVisible};
  }
  function routeDiagnosticText(value) {const d=routeDiagnostic(value);return d?'[Route '+d.contentRevision+' '+d.step+'/'+d.phase+' hint='+d.hintMatches+' semantic='+d.semanticMatches+' strong='+d.strongMatches+' state='+d.stateNormalizedMatches+' saved='+(d.hasHint?1:0)+' identity='+(d.hasStrongHint?1:0)+' visible='+(d.documentVisible?1:0)+']':'';}
  function readerAvailability(value,expected) {
    validateContentReadiness(value);
    if(!value||Object.keys(value).sort().join(',')!=='contentBuild,contentProtocol,contentRevision,context,ok,readerBindingVersion,retainedReaderCount'||value.ok!==true||!Number.isInteger(value.retainedReaderCount)||value.retainedReaderCount<0||value.retainedReaderCount>2)fail('Trạng thái reader chưa hợp lệ.','CONTENT_UNAVAILABLE');
    const source=context(value.context&&value.context.url);
    if(!value.context||!validPageId(value.context.pageId)||typeof value.context.documentVisible!=='boolean'||!sameContext({...source,pageId:value.context.pageId},expected))fail('Phiên trang reader đã đổi.','VIEW_CHANGED');
    return {retainedReaderCount:value.retainedReaderCount,documentVisible:value.context.documentVisible};
  }
  function id(value) { return typeof value === 'string' && /^[A-Za-z0-9_-]{1,100}$/.test(value); }
  function endpoint(value) {
    let u; try { u = new URL(value); } catch (_) { fail('Mã kết nối không có địa chỉ local hợp lệ.'); }
    if (u.protocol !== 'http:' || u.hostname !== '127.0.0.1' || !/^\d+$/.test(u.port) || Number(u.port) < 1024 || Number(u.port) > 65535 || u.username || u.password || u.pathname !== '/' || u.search || u.hash) fail('Chỉ chấp nhận cầu nối 127.0.0.1 có cổng riêng.');
    return u.origin;
  }
  function context(value) {
    let u; try { u = new URL(value); } catch (_) { fail('Mở Base HTTPS trước.'); }
    if (u.protocol !== 'https:' || u.username || u.password || u.port || !/(?:^|\.)(?:larksuite\.com|feishu\.cn)$/.test(u.hostname) || !/^\/base\/[A-Za-z0-9_-]{1,100}\/?$/.test(u.pathname)) fail('Chỉ dùng trang Base HTTPS của Lark/Feishu.');
    if (u.searchParams.getAll('table').length !== 1 || u.searchParams.getAll('view').length !== 1 || !id(u.searchParams.get('table')) || !id(u.searchParams.get('view'))) fail('URL Base cần xác định duy nhất table và view. Chọn một view rồi mở popup lại.', 'VIEW_REQUIRED');
    const baseIdentity=u.origin+u.pathname.replace(/\/$/,'');const tableId=u.searchParams.get('table');const viewId=u.searchParams.get('view');
    return {baseIdentity,origin:u.origin,tableId,viewId,url:baseIdentity+'?table='+encodeURIComponent(tableId)+'&view='+encodeURIComponent(viewId)};
  }
  function pairing(value, expectedBase) {
    let p; try { p = typeof value === 'string' ? JSON.parse(value) : value; } catch (_) { fail('Mã Companion không phải JSON hợp lệ.'); }
    if (!p || p.version !== 1 || p.role !== ROLE || p.extensionId !== EXTENSION_ID || typeof p.token !== 'string' || !/^[a-f0-9]{64}$/i.test(p.token)) fail('Dùng mã Chrome Companion từ Photoshop, không dùng mã reader Order.');
    const out = {version:1, role:ROLE, endpoint:endpoint(p.endpoint), token:p.token.toLowerCase(), extensionId:EXTENSION_ID};
    if (p.baseIdentity !== undefined) {
      const c = context(p.baseIdentity + '?table=validation&view=validation');
      if (c.baseIdentity !== p.baseIdentity || (expectedBase && c.baseIdentity !== expectedBase)) fail('Ghép nối đã lưu thuộc Base khác.');
      out.baseIdentity = c.baseIdentity;
    }
    return out;
  }
  function validPageId(value) { return typeof value === 'string' && /^[a-f0-9]{32}$/.test(value); }
  function sameContext(a, b) { return !!a && !!b && a.baseIdentity === b.baseIdentity && a.tableId === b.tableId && a.viewId === b.viewId && (!(a.pageId !== undefined && b.pageId !== undefined) || validPageId(a.pageId) && a.pageId === b.pageId); }
  function validateReaderBinding(value, command, current, now) {
    const clock=now===undefined?Date.now():now;
    const keys=['baseIdentity','expiresAt','instance','nonce','pageId','requestId','tableId','version','viewId'];
    function bad(){fail('Phiếu xác nhận Reader không khớp lệnh, trang hoặc thời hạn. Chưa thao tác Order.','READER_OWNERSHIP');}
    if(!value || typeof value!=='object' || Array.isArray(value) || Object.keys(value).sort().join(',')!==keys.join(',') || value.version!==1 ||
      typeof value.nonce!=='string' || !/^[a-f0-9]{64}$/.test(value.nonce) ||
      typeof value.instance!=='string' || !/^[a-f0-9]{32}$/.test(value.instance) ||
      typeof value.requestId!=='string' || !/^[a-f0-9]{32}$/.test(value.requestId) ||
      !validPageId(value.pageId) || !id(value.tableId) || !id(value.viewId) ||
      !Number.isSafeInteger(value.expiresAt) || value.expiresAt<clock || value.expiresAt>clock+30000 ||
      !command || command.op!=='openOrder' || command.purpose!==undefined || !current ||
      value.instance!==command.instance || !validPageId(command.pageId) || !validPageId(current.pageId) ||
      value.pageId!==command.pageId || value.pageId!==current.pageId ||
      !sameContext(value,command) || !sameContext(value,current)) bad();
    let canonical;
    try {canonical=context(value.baseIdentity+'?table='+encodeURIComponent(value.tableId)+'&view='+encodeURIComponent(value.viewId));}
    catch(_){bad();}
    if(canonical.baseIdentity!==value.baseIdentity)bad();
    // Return the original object. This is a transient challenge; never strip
    // a field, rewrite it to match local selection, or persist it with trust.
    return value;
  }
  function validateCommand(cmd, current, now) {
    if (!cmd || !/^[a-f0-9]{32}$/i.test(cmd.commandId || '') || typeof cmd.instance !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(cmd.instance) || !['openOrder','closeOrder','verifySource'].includes(cmd.op) || !sameContext(cmd, current)) fail('Lệnh không khớp Base/view hiện tại.', 'VIEW_CHANGED');
    if (cmd.purpose !== undefined && (cmd.purpose !== 'standby' || cmd.op !== 'openOrder')) fail('Mục đích lệnh không được phép.', 'COMMAND_PURPOSE');
    if (cmd.pageId !== undefined && (!validPageId(cmd.pageId) || !current || cmd.pageId !== current.pageId)) fail('Trang Base đã được tải lại. Không thực hiện lệnh cũ.', 'PAGE_CHANGED');
    if (cmd.purpose === 'standby' && !validPageId(cmd.pageId)) fail('Lệnh khởi động reader không có phiên trang đã xác minh.', 'PAGE_CHANGED');
    const clock = now === undefined ? Date.now() : now;
    if (!Number.isSafeInteger(cmd.deadline) || cmd.deadline < clock || cmd.deadline > clock + 20000) fail('Lệnh đã quá hạn; bấm Nạp lại.', 'EXPIRED');
    if(cmd.readerBinding!==undefined) validateReaderBinding(cmd.readerBinding,cmd,current,clock);
    if(cmd.op==='verifySource' && (cmd.purpose!==undefined||cmd.readerBinding!==undefined||!validPageId(cmd.pageId)||typeof cmd.requestId!=='string'||!/^[a-f0-9]{32}$/.test(cmd.requestId)||typeof cmd.proofNonce!=='string'||!/^[a-f0-9]{64}$/.test(cmd.proofNonce)))fail('Phiếu xác minh trang nguồn chưa hợp lệ.','READER_OWNERSHIP');
    return cmd;
  }
  function validSender(sender, config, extensionId) {
    if (!sender || sender.id !== (extensionId || EXTENSION_ID) || sender.frameId !== 0 || !sender.tab || !Number.isInteger(sender.tab.id) || sender.tab.id !== config.tabId) return false;
    try { return context(sender.url || sender.tab.url).baseIdentity === config.baseIdentity; } catch (_) { return false; }
  }
  function fingerprint(value) {
    if (!value || !['BUTTON','DIV','SPAN','A'].includes(value.tag) || (value.role && !['button','menuitem'].includes(value.role))) fail('Chỉ dạy nút giao diện an toàn, không dạy tab/view.');
    const names=Array.isArray(value.classNames) ? value.classNames : [];
    if(names.length>6 || names.some(x=>typeof x!=='string'||!/^[A-Za-z_][A-Za-z0-9_-]{1,80}$/.test(x))) fail('Class công khai của nút không ổn định/không hợp lệ.');
    const out = {tag:value.tag, role:text(value.role,32), label:text(value.label,120), title:text(value.title,120), testId:text(value.testId,100), id:text(value.id,100), text:text(value.text,100),classNames:[...new Set(names)].sort()};
    // Only an explicitly supplied public SVG data-icon name, never SVG markup
    // or geometry. Keep old fingerprints byte-shape compatible when absent.
    if(value.icon!==undefined && value.icon!=='') {
      if(typeof value.icon!=='string'||!/^[A-Za-z][A-Za-z0-9_-]{0,79}$/.test(value.icon)) fail('Tên icon công khai của nút không hợp lệ.');
      out.icon=value.icon;
    }
    if(value.orderEntry!==undefined) {
      if(value.orderEntry!==true || out.tag!=='DIV' || out.role || typeof value.text!=='string' || value.text.length>100 || out.classNames.length!==1 || out.classNames[0]!==ORDER_TITLE_CLASS || !/^(?:Order|UOY Order Custom)$/i.test(out.text)) fail('Chỉ nhận tiêu đề Order công khai trong danh sách phần mở rộng đã xác minh.');
      out.orderEntry=true;
    }
    if (Object.values(out).some(x => typeof x === 'string' && FORBIDDEN.test(x)) || FORBIDDEN.test(out.classNames.join(' '))) fail('Không thể dạy nút đăng nhập, quyền, chia sẻ hoặc xóa.');
    if (!out.label && !out.title && !out.testId && !out.id && !out.text && !out.classNames.length && !out.icon) fail('Nút không có tên/định danh ổn định. Không đoán theo vị trí.');
    return out;
  }
  function cleanCalibration(value) {
    const out = {};
    for (const step of STEPS) if (value && value[step]) {
      const fp=fingerprint(value[step]);
      if(fp.orderEntry && step!=='order') fail('Tiêu đề Order chỉ được dạy cho bước mở Order.');
      out[step]=fp;
    }
    if (value && value.customize) out.customize = customizeFingerprint(value.customize);
    return out;
  }
  function customizeFingerprint(value) {
    const fp=fingerprint(value);
    if(fp.orderEntry) fail('Tiêu đề Order không phải nút Tùy chỉnh.');
    const names=[fp.label,fp.title,fp.text].map(name=>name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim());
    if (!names.some(name=>/^(?:customize|customise|tuy chinh|自定义|自訂)$/.test(name))) fail('Chỉ dạy nút Tùy chỉnh/Customize công khai để mở danh sách Order.');
    return fp;
  }
  function ownedFrame(src, localEndpoint) {
    try { const u = new URL(src); return u.origin === endpoint(localEndpoint) && u.pathname === '/extension/' && !u.username && !u.password && !u.search && !u.hash; } catch (_) { return false; }
  }
  async function limitedJson(response, limit) {
    const cap = limit || 32768;
    if (!response || !response.headers || !/application\/json/i.test(response.headers.get('content-type') || '')) fail('Cầu nối không trả JSON.');
    const stated = Number(response.headers.get('content-length') || 0);
    if (stated > cap) fail('Phản hồi cầu nối quá lớn.');
    let raw = '';
    if (response.body && response.body.getReader) {
      const reader = response.body.getReader(); const decoder = new TextDecoder(); let bytes = 0;
      try {
        while (true) {
          let part;
          try { part = await reader.read(); }
          catch (err) { bodyTransportFailure(err, response.ok === true); throw err; }
          if (part.done) break;
          bytes += part.value.byteLength;
          if (bytes > cap) { await reader.cancel(); fail('Phản hồi cầu nối quá lớn.'); }
          raw += decoder.decode(part.value, {stream:true});
        }
        raw += decoder.decode();
      } finally { reader.releaseLock(); }
    } else {
      try { raw = await response.text(); }
      catch (err) { bodyTransportFailure(err, response.ok === true); throw err; }
      if (new TextEncoder().encode(raw).byteLength > cap) fail('Phản hồi cầu nối quá lớn.');
    }
    // An accepted loopback request can lose its body while Photoshop exits.
    // Only successful empty EOF is transient; nonempty malformed JSON and
    // HTTP refusals remain fatal instead of becoming a reconnect hammer.
    if (response.ok === true && !raw.trim()) fail('Cầu nối Photoshop vừa ngắt phản hồi. Companion giữ ghép nối và sẽ xác nhận lại phiên.', 'LOCAL_TRANSPORT');
    let data; try { data = JSON.parse(raw); } catch (_) { fail('Cầu nối trả JSON không hoàn chỉnh.'); }
    if (!data || typeof data !== 'object' || Array.isArray(data)) fail('Cầu nối trả dữ liệu giao thức không hợp lệ.');
    if (!response.ok || data.ok === false) {
      const code=typeof data.error==='string' ? text(data.error,60) : text(data.error && data.error.code,60);
      const err=new Error(text(data.error && data.error.message || data.message || ERRORS[code] || 'Cầu nối từ chối kết nối.',700));err.code=code || 'BRIDGE';
      // Version labels are diagnostics, not credentials or source authority.
      for(const key of ['clientBuild','requiredClientBuild','launcherClientBuild','requiredLauncherBuild']) if(typeof data[key]==='string' && /^[A-Za-z0-9_-]{1,64}$/.test(data[key])) err[key]=data[key];
      throw err;
    }
    return data;
  }
  function bodyTransportFailure(err, successful) {
    // Classify only I/O boundaries, never arbitrary TypeErrors from parsing
    // protocol objects or inspecting the tab, controls and permissions.
    if (successful && err && (err.name === 'TypeError' || err.name === 'AbortError')) fail('Cầu nối Photoshop vừa ngắt phản hồi. Companion giữ ghép nối và sẽ xác nhận lại phiên.', 'LOCAL_TRANSPORT');
  }
  async function request(fetcher, config, route, body) {
    if (!ROUTES.has(route)) fail('Tuyến cầu nối không được phép.');
    const trust = pairing(config, config.baseIdentity);
    if (!/^[a-f0-9]{32}$/i.test(config.clientId || '')) fail('Client ID không hợp lệ.');
    const serialized = JSON.stringify(body || {}); if (serialized.length > 4096) fail('Metadata quá lớn.');
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 8000);
    try {
      let response;
      try { response=await fetcher(trust.endpoint + route, {method:'POST',credentials:'omit',redirect:'error',cache:'no-store',headers:{'Content-Type':'application/json','Authorization':'Bearer '+trust.token,'X-Uoy-Client':config.clientId},body:serialized,signal:controller.signal}); }
      catch(err) {
        // Only failures of the already validated loopback transport are
        // recoverable while Photoshop is closed/restarting. HTTP refusals,
        // revoked trust and malformed responses never acquire this code.
        if(err && (err.name==='TypeError' || err.name==='AbortError' || controller.signal.aborted)) fail('Photoshop chưa mở cầu nối Base. Companion giữ ghép nối và sẽ thử kết nối lại.','LOCAL_TRANSPORT');
        throw err;
      }
      return await limitedJson(response);
    } finally { clearTimeout(timer); }
  }
  return {EXTENSION_ID,BUILD,CONTENT_REVISION,CONTENT_PROTOCOL,ROLE,ROUTES,STORAGE_KEY,STEPS,OPEN_STEPS,TEACH_STEPS,ORDER_TITLE_CLASS,FORBIDDEN,ERRORS,fail,validateContentReadiness,routeDiagnostic,routeDiagnosticText,readerAvailability,text,id,endpoint,context,pairing,sameContext,validPageId,validateReaderBinding,validateCommand,validSender,fingerprint,customizeFingerprint,cleanCalibration,ownedFrame,limitedJson,request};
});
