'use strict';
const C=globalThis.UoyCompanion;
const byId=id=>document.getElementById(id);
let active=null;
let busy=false;
let currentStatus=null;
let refreshVersion=0;
let firstStatus=true;
function show(value){byId('status').textContent=C.text(value,700);}
byId('build').textContent='Base Companion · '+(C.CONTENT_REVISION||C.BUILD)+(typeof chrome.runtime.getManifest==='function'?' · v'+C.text(chrome.runtime.getManifest().version,20):'')+(C.CONTENT_REVISION&&C.CONTENT_REVISION!==C.BUILD?' · host '+C.BUILD:'');
async function send(message){const reply=await chrome.runtime.sendMessage(message);if(!reply||!reply.ok) C.fail(reply&&reply.error&&reply.error.message||'Companion không phản hồi.');return reply;}
function updateControls(){
  const s=currentStatus;const sameBase=!!active&&!!s&&s.baseIdentity===active.context.baseIdentity;
  byId('enabled').disabled=busy||!sameBase;byId('check').disabled=busy||!sameBase;byId('forget').disabled=busy||!s||!s.baseIdentity;
  document.querySelectorAll('[data-step]').forEach(button=>{button.disabled=busy||!sameBase;});byId('connect').disabled=busy||!active;
}
async function refresh(){
  const version=++refreshVersion;const s=await send({type:'status'});if(version!==refreshVersion)return;
  currentStatus=s;
  const diagnostic=C.routeDiagnostic(s.routeDiagnostic),code=['CALIBRATION','UI_AMBIGUOUS'].includes(s.routeDiagnosticCode)?s.routeDiagnosticCode:'';
  const verified=s.verifiedContentRevision===C.CONTENT_REVISION?s.verifiedContentRevision:'chưa xác minh — tải lại tab Base nếu vừa cập nhật';
  show(s.status+' · Mã tab: '+verified+(diagnostic?' · '+code+' '+C.routeDiagnosticText(diagnostic):''));
  byId('paired').textContent=s.baseIdentity||'chưa có';byId('learned').textContent=s.calibration.join(', ')||'chưa có';byId('enabled').checked=s.enabled;
  const sameBase=!!active&&s.baseIdentity===active.context.baseIdentity;
  byId('remembered').textContent=!s.baseIdentity?'Chrome Companion chưa có cấu hình ghép. Ghép Order trong Base là bước riêng; chỉ hiện đã ghi nhớ sau khi Chrome ghép thành công.':s.remembered===true?'Đã ghi nhớ trên máy này. Mở lại popup hoặc Chrome không cần dán mã.':'Ghép chỉ trong phiên Chrome này; Photoshop chưa xác nhận lưu lâu dài. Kiểm tra kết nối để thử lại, không cần dán mã trong phiên.';
  if(s.baseIdentity&&!sameBase&&active)byId('remembered').textContent+=' Tab này là Base khác: ghép riêng nếu muốn đổi Base.';
  if(firstStatus){byId('pairing-settings').open=!sameBase;firstStatus=false;}
  updateControls();
}
async function initialize(){
  let tabError=null;
  try{const tabs=await chrome.tabs.query({active:true,currentWindow:true});if(tabs.length!==1)C.fail('Chọn một tab Base.');active={id:tabs[0].id,context:C.context(tabs[0].url)};byId('base').textContent=active.context.baseIdentity;}
  catch(err){byId('base').textContent='không phải tab Base có table/view';tabError=err.message;}
  try{await refresh();if(tabError)show(tabError);}catch(err){show(err.message);updateControls();}
}
byId('connect').addEventListener('click',async()=>{
  if(busy)return;busy=true;++refreshVersion;updateControls();
  let connected=false;
  try{
    if(!active) C.fail('Mở Base có table/view trong URL trước.');const code=C.pairing(byId('code').value,active.context.baseIdentity);
    // Called directly from the human popup click; no automatic permission grants.
    if(!await chrome.permissions.request({origins:[active.context.origin+'/*']})) C.fail('Bạn chưa duyệt quyền Base. Chưa thay đổi ghép nối.');
    await send({type:'connect',tabId:active.id,context:active.context,code});byId('code').value='';byId('pairing-settings').open=false;connected=true;
  }catch(err){show(err.message);}finally{busy=false;updateControls();if(connected)await refresh().catch(err=>show(err.message));}
});
async function action(task){if(busy)return;busy=true;++refreshVersion;updateControls();try{await task();}catch(err){show(err.message);}finally{busy=false;updateControls();}}
document.querySelectorAll('[data-step]').forEach(button=>button.addEventListener('click',()=>action(async()=>{if(!active)C.fail('Mở Base đã ghép trước.');await send({type:'teach',step:button.dataset.step,context:active.context});window.close();})));
byId('check').addEventListener('click',()=>action(async()=>{if(!active)C.fail('Mở Base đã ghép trước.');await send({type:'check',context:active.context});await refresh();}));
byId('enabled').addEventListener('change',()=>action(async()=>{try{await send({type:'enabled',enabled:byId('enabled').checked});}finally{await refresh();}}));
byId('forget').addEventListener('click',()=>action(async()=>{await send({type:'forget'});byId('pairing-settings').open=true;await refresh();}));
initialize();
