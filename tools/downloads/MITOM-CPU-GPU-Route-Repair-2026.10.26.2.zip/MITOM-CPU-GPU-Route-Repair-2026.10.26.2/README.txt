MITOM CPU/GPU routing repair 2026.10.26.2

Save your work and close Photoshop and OrderStudio yourself before running Update CPU GPU Route.cmd.
Requires managed Panel2026.10.25.1 or2026.10.26.1 with exact known code. Changes at most two owned JS files.
No models, CPU/GPU runtimes, local settings, pairing or full-install receipt are changed.
No package download, CUDA setup, GPU probe or generation is started. GPU compatibility and VRAM remain separate checks.
A full backup is recorded under your own LOCALAPPDATA/UOY/Launcher/backups.
Use Launcher > Photoshop Panel > ... > Restore previous version if an update was interrupted.
Unknown/newer/custom files are preserved and require the cumulative release instead.
