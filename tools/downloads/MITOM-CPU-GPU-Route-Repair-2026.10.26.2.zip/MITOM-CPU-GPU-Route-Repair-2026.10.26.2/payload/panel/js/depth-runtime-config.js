/* Select the managed engine for v1 or exact known legacy input-slot protocols.
 * No configuration, model, output or user file is written by this module. */
"use strict";
var PIPELINE = "shared-acrylic-ai-v2";
var GPU_ENGINE_SHA256 = "6560582e3b0fd58da68ddf70348ec36956f83465211b19b53f81a72d3a4e2ec9";
var GPU_SETUP_SHA256 = "acaa260362a39f10bca704893864dfcb8aa22ccd4fe568db29b18a3f7343372a";
var CPU_HANDLER_SHA256 = "a9002ad845e9bb63801ba6ded518471da460572309ac4cb7cc652f61fb972308";
var LEGACY_INPUT_SLOT = [
  ["3.28.0", "ca18cb60f1d69d345a569f67766ec2da98361baffefdaec520198bfa405caadd", "e2ad0e166b9844e9a694dd90d5f5bfffae029b2618208f34b5cbd84b01930cd6"],
  ["3.29.0", "a88cac3311288e458c182dfe5f31c54b98866547f75100c580c5c0b6e2e6e735", "07af9030e493e6ec6822b43ec01d2de85156099cfb4451b2662a7277e2e213e1"],
  ["3.30.0", "2031d4f4e693e0243a72d4945f0ccebbc21a55fb24df0a19227b9a76d3b92342", "07af9030e493e6ec6822b43ec01d2de85156099cfb4451b2662a7277e2e213e1"]
];
function samePath(a, b, path) { return path.sep === "\\" ? a.toLowerCase() === b.toLowerCase() : a === b; }
function ownedPath(file, fs, path, allowMissing) {
  if (typeof file !== "string" || !path.isAbsolute(file) || /^\\\\/.test(file) || /[\x00-\x1f]/.test(file)) return false;
  var cursor = path.resolve(file), count = 0;
  try {
    while (++count <= 128) {
      try {
        var info = fs.lstatSync(cursor);
        if (info.isSymbolicLink() || !samePath(path.resolve(fs.realpathSync(cursor)), cursor, path)) return false;
      } catch (missing) { if (!allowMissing || missing.code !== "ENOENT") return false; }
      var parent = path.dirname(cursor);
      if (samePath(parent, cursor, path)) return true;
      cursor = parent;
    }
  } catch (_) {}
  return false;
}
function regularOwnedFile(file, fs, path, maximum) {
  try {
    if (!ownedPath(file, fs, path, false)) return false;
    var info = fs.lstatSync(file);
    return info.isFile() && info.size > 0 && info.size <= maximum;
  } catch (_) { return false; }
}
function managedGPU(options, fs, path, env) {
  // This is separate from the recipient's CPU selection. Never execute a
  // script found beside an arbitrary custom worker as an installer fallback.
  if (typeof env.LOCALAPPDATA !== "string" || !path.isAbsolute(env.LOCALAPPDATA) || /^\\\\/.test(env.LOCALAPPDATA)) return null;
  var root = path.join(env.LOCALAPPDATA, "UOY", "Launcher", "current"), engineRoot = path.join(root, "depth-engine");
  var worker = path.join(engineRoot, "engine.py"), setup = path.join(engineRoot, "setup_gpu.py"), python = path.join(root, "python", "python.exe");
  var gpuRoot = path.join(env.LOCALAPPDATA, "UOY", "DepthGPU"), gpuPython = path.join(gpuRoot, "Scripts", "python.exe");
  try {
    if (!regularOwnedFile(worker, fs, path, 262144) || !regularOwnedFile(setup, fs, path, 65536) ||
        !regularOwnedFile(python, fs, path, 32 * 1024 * 1024) ||
        !regularOwnedFile(path.join(engineRoot, "ceramic_product.py"), fs, path, 131072) || inspectWorker(worker, fs, path) !== PIPELINE ||
        !ownedPath(gpuRoot, fs, path, true) || !ownedPath(gpuPython, fs, path, true)) return null;
    var crypto = options.crypto || require("crypto"), engineBytes = fs.readFileSync(worker), setupBytes = fs.readFileSync(setup);
    if (crypto.createHash("sha256").update(engineBytes).digest("hex") !== GPU_ENGINE_SHA256 ||
        crypto.createHash("sha256").update(setupBytes).digest("hex") !== GPU_SETUP_SHA256 ||
        !/["']device_selection["']\s*:\s*["']explicit-cpu-cuda-v1["']/.test(String(engineBytes))) return null;
    return { worker: worker, setup: setup, setupPython: python, root: gpuRoot, python: gpuPython };
  } catch (_) { return null; }
}
function legacyInputSlot(worker, options, fs, path) {
  try {
    if (typeof worker !== "string" || path.basename(worker).toLowerCase() !== "engine.py" ||
        path.basename(path.dirname(worker)).toLowerCase() !== "depth-engine" || !regularOwnedFile(worker, fs, path, 262144)) return null;
    var handler = path.join(path.dirname(worker), "fullprint_commands.py");
    if (!regularOwnedFile(handler, fs, path, 65536)) return null;
    var crypto = options.crypto || require("crypto"), engineHash = crypto.createHash("sha256").update(fs.readFileSync(worker)).digest("hex");
    var handlerHash = crypto.createHash("sha256").update(fs.readFileSync(handler)).digest("hex");
    for (var i = 0; i < LEGACY_INPUT_SLOT.length; i++) if (engineHash === LEGACY_INPUT_SLOT[i][1] && handlerHash === LEGACY_INPUT_SLOT[i][2]) return LEGACY_INPUT_SLOT[i][0];
  } catch (_) {}
  return null;
}
function compatibleManagedCPU(options, fs, path, env) {
  var bases = [];
  if (typeof env.LOCALAPPDATA === "string" && path.isAbsolute(env.LOCALAPPDATA) && !/^\\\\/.test(env.LOCALAPPDATA)) bases.push(env.LOCALAPPDATA);
  if (typeof env.USERPROFILE === "string" && path.isAbsolute(env.USERPROFILE) && !/^\\\\/.test(env.USERPROFILE)) bases.push(path.join(env.USERPROFILE, "AppData", "Local"));
  for (var i = 0; i < bases.length; i++) {
    var root = path.join(bases[i], "UOY", "Launcher", "current"), engineRoot = path.join(root, "depth-engine");
    var worker = path.join(engineRoot, "engine.py"), python = path.join(root, "python", "python.exe"), handler = path.join(engineRoot, "fullprint_commands.py");
    try {
      if (!regularOwnedFile(worker, fs, path, 262144) || !regularOwnedFile(python, fs, path, 32 * 1024 * 1024) ||
          !regularOwnedFile(handler, fs, path, 65536) || !regularOwnedFile(path.join(engineRoot, "ceramic_product.py"), fs, path, 131072) || inspectWorker(worker, fs, path) !== PIPELINE) continue;
      var crypto = options.crypto || require("crypto");
      if (crypto.createHash("sha256").update(fs.readFileSync(worker)).digest("hex") !== GPU_ENGINE_SHA256 ||
          crypto.createHash("sha256").update(fs.readFileSync(handler)).digest("hex") !== CPU_HANDLER_SHA256) continue;
      return { worker: worker, python: python };
    } catch (_) {}
  }
  return null;
}
function inspectWorker(worker, fs, path) {
  try {
    if (typeof worker !== "string" || !path.isAbsolute(worker) || path.basename(worker).toLowerCase() !== "engine.py" || path.basename(path.dirname(worker)).toLowerCase() !== "depth-engine") return "unknown";
    var policy = path.join(path.dirname(worker), "ceramic_product.py");
    var stat = fs.lstatSync(policy), engineStat = fs.lstatSync(worker);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 131072 || !engineStat.isFile() || engineStat.isSymbolicLink()) return "unknown";
    var text = fs.readFileSync(policy, "utf8");
    if (/^ACRYLIC_COMPOSITION_PIPELINE\s*=\s*["']shared-acrylic-ai-v2["']\s*$/m.test(text)) return PIPELINE;
    if (/^SHARED_PIPELINE\s*=\s*["']shared-acrylic-ai-v1["']\s*$/m.test(text)) return "shared-acrylic-ai-v1";
  } catch (_) {}
  return "unknown";
}
function select(config, options) {
  options = options || {};
  var fs = options.fs || require("fs"), path = options.path || require("path"), env = options.env || require("process").env;
  var result = {}, key;
  for (key in config) if (Object.prototype.hasOwnProperty.call(config, key)) result[key] = config[key];
  var gpu = managedGPU(options, fs, path, env);
  var detected = inspectWorker(result.worker, fs, path);
  var legacy = legacyInputSlot(result.worker, options, fs, path);
  if (legacy) {
    var cpu = compatibleManagedCPU(options, fs, path, env);
    if (!cpu) {
      var error = new Error("CPU runtime cũ " + legacy + " không nhận product_type. Thiếu runtime CPU tương thích; hãy cập nhật đầy đủ MITOM Panel. Chưa nhận ảnh hay chạy Generate.");
      error.code = "DEPTH_CPU_INPUT_PROTOCOL_UPDATE_REQUIRED"; throw error;
    }
    result.worker = cpu.worker; result.python = cpu.python;
    return { config: result, migrated: true, pipeline: PIPELINE, gpu: gpu, cpuCompatibility: { reason: "known-legacy-input-slot", version: legacy } };
  }
  if (detected !== "shared-acrylic-ai-v1") return { config: result, migrated: false, pipeline: detected, gpu: gpu };
  var bases = [];
  if (typeof env.LOCALAPPDATA === "string" && path.isAbsolute(env.LOCALAPPDATA)) bases.push(env.LOCALAPPDATA);
  if (typeof env.USERPROFILE === "string" && path.isAbsolute(env.USERPROFILE)) bases.push(path.join(env.USERPROFILE, "AppData", "Local"));
  for (var i = 0; i < bases.length; i++) {
    var root = path.join(bases[i], "UOY", "Launcher", "current"), worker = path.join(root, "depth-engine", "engine.py"), python = path.join(root, "python", "python.exe");
    try {
      var pythonStat = fs.lstatSync(python);
      if (!pythonStat.isFile() || pythonStat.isSymbolicLink() || inspectWorker(worker, fs, path) !== PIPELINE) continue;
      // Data/model locations and every other machine-local option stay exact.
      result.worker = worker; result.python = python;
      return { config: result, migrated: true, pipeline: PIPELINE, gpu: gpu };
    } catch (_) {}
  }
  return { config: result, migrated: false, pipeline: detected, gpu: gpu };
}
module.exports = { select: select, inspectWorker: inspectWorker, pipeline: PIPELINE };
