/* Ceramic source-eye transaction 20261009-R2; restored only after depth commit.
 * Read-only template -> 3D composite export. No capture/AI/session dependency.
 * Open native role contents only to establish their real parent linkage. Never
 * save/close an existing child; only export from disposable owned duplicates.
 */
(function () {
function _uoyDTImportPaths(request) {
    var product=_uoyDTSpec(request.product_type).product_type,slot=String(request.slot_id||'');
    if(!/^[a-f0-9]{32}$/.test(slot))throw new Error('Slot import template khong hop le.');
    function output(value,name) {
        if(typeof value!=='string')throw new Error('Thieu duong dan import template.');
        var normalized=value.replace(/\\/g,'/'),file=new File(value);
        if(normalized.toLowerCase()!==_uoyDTPath(file)||normalized.toLowerCase().slice(-(slot.length+name.length+7))!=='/jobs/'+slot+'/'+name)throw new Error('Sai slot/ten tep import template.');
        _uoyDTPlain(file,false);_uoyDTMarkedJob(file.parent);
        if(file.exists)throw new Error('Slot import da ton tai. Khong ghi de.');
        return file;
    }
    var depth=output(request.depth_path,'template-depth.png'),color=output(request.color_path,'template-color.png'),shape=null,cut=null,guide=null;
    if(_uoyDTPath(depth.parent)!==_uoyDTPath(color.parent))throw new Error('Depth/color phai cung slot.');
    if(product!=='acrylic') {
        shape=output(request.shape_path,'ceramic-shape.png');
        if(_uoyDTPath(depth.parent)!==_uoyDTPath(shape.parent))throw new Error('Shape phai cung slot.');
        guide=output(request.ceramic_guide_path,'ceramic-guide.png');
        if(_uoyDTPath(depth.parent)!==_uoyDTPath(guide.parent))throw new Error('Guide phai cung slot.');
    }else{
        if(request.shape_path)throw new Error('Acrylic khong nhan fixed shape ceramic.');
        if(request.ceramic_guide_path)throw new Error('Acrylic khong nhan guide ceramic.');
        if(request.cut_shape_path){cut=output(request.cut_shape_path,'cut-shape.png');if(_uoyDTPath(depth.parent)!==_uoyDTPath(cut.parent))throw new Error('Cut phai cung slot.');}
    }
    return {slot:slot,product:product,depth:depth,color:color,shape:shape,cut:cut,guide:guide};
}
function _uoyDTImportOpenRole(parent,role,owned) {
    app.activeDocument=parent;var layer=_uoyDTLayer(parent,role.layer);
    return _uoyDTNativeEditContents(parent,layer,owned,String(layer.name||'template role'),role);
}
function _uoyDTImportCandidate(doc,product) {
    try {return {parent:doc,roles:_uoyDTRoles(doc,product)};}catch(notTemplate){return null;}
}
function _uoyDTImportSelect(request,owned,previous) {
    var product=_uoyDTSpec(request.product_type).product_type,active=previous?_uoyDTImportCandidate(previous,product):null;
    if(active)return active;
    var candidates=[],initial=[],i;
    if(app.documents.length>128)throw new Error('Qua nhieu tab Photoshop. Chon tab template can xem 3D truoc.');
    for(i=0;i<app.documents.length;i++)initial.push(app.documents[i]);
    for(i=0;i<initial.length;i++){var candidate=_uoyDTImportCandidate(initial[i],product);if(candidate)candidates.push(candidate);}
    if(candidates.length>16)throw new Error('Qua nhieu template. Chon dung tab template truoc.');
    if(!candidates.length&&previous)return {standalone:previous};
    if(!candidates.length)throw _uoyDTError('UOY_TEMPLATE_NOT_FOUND','Mo tai lieu depth/fullprint can nap trong Photoshop.');
    // A currently edited unsaved In/Depth tab outranks a stale panel hint only
    // when Photoshop itself resolves it from the candidate's actual SO role.
    var related=[],possibleChild=false;
    if(previous)try{_uoyDTImportCanvas(previous,product,'depth');possibleChild=true;}catch(unrelatedCanvas){}
    if(possibleChild)for(i=0;i<candidates.length;i++) {
        var match=false,roles=product==='acrylic'?['depth','input','cut']:['depth','input'];
        for(var r=0;r<roles.length;r++) {
            var child=_uoyDTImportOpenRole(candidates[i].parent,candidates[i].roles[roles[r]],owned);
            if(_uoyDTId(child)===_uoyDTId(previous)){match=true;break;}
        }
        if(match)related.push(candidates[i]);
    }
    if(related.length===1)return related[0];
    if(related.length>1)throw _uoyDTError('UOY_TEMPLATE_AMBIGUOUS','Tab con dang duoc nhieu template dung chung. Chon dung tab template cha.');
    // A standalone document explicitly selected by the user wins over an old
    // panel hint. Never import a different open PSD just because it is cached.
    if(previous)return {standalone:previous};
    var hint=String(request.parent_document_id||'');
    if(hint&&!/^\d+$/.test(hint))throw new Error('Parent document ID khong hop le.');
    for(i=0;i<candidates.length;i++)if(_uoyDTId(candidates[i].parent)===hint)return candidates[i];
    if(candidates.length===1)return candidates[0];
    throw _uoyDTError('UOY_TEMPLATE_AMBIGUOUS','Dang mo nhieu template cung loai. Chon dung tab template can xem 3D roi bam lai.');
}
function _uoyDTImportCanvas(doc,product,role) {
    var size=_uoyDTSize(doc),spec;
    if(product==='acrylic'){
        if(size.width<1||size.height<1||size.width*size.height>40000000||!isFinite(size.dpi)||size.dpi<=0)throw new Error('Canvas depth qua lon/khong hop le (toi da 40 MP).');
        spec={product_type:product,width:size.width,height:size.height,dpi:size.dpi};
    }else{spec=_uoyDTSpec(product,size.width,size.height);spec.dpi=size.dpi;if(Math.abs(size.dpi-300)>.02)throw new Error('Ceramic can dung canvas template va 300 DPI.');}
    if(doc.bitsPerChannel!==BitsPerChannelType.EIGHT&&doc.bitsPerChannel!==BitsPerChannelType.SIXTEEN)throw new Error('In/Depth chi ho tro 8-bit hoac 16-bit. Khong tu ha bit.');
    if(role==='input') {
        if(doc.mode!==DocumentMode.RGB)throw new Error('Fullprint In phai la RGB.');
        _uoyDTRequireSRGB(doc);
    }else if(doc.mode!==DocumentMode.RGB&&doc.mode!==DocumentMode.GRAYSCALE)throw new Error('Depth phai la RGB xam hoac Grayscale. Khong tu chuyen mau.');
    return spec;
}
function _uoyDTImportComposite(doc,role,product,file,owned,written) {
    if(doc.layers.length>4000)throw new Error('Qua nhieu layer trong role template.');
    var spec=_uoyDTImportCanvas(doc,product,role);
    // Current visibility is authoritative for manual readback. A user may
    // repaint Layer 1, paste depth into it, or rename art to a helper's name.
    // Names/kinds/bounds cannot attest helper pixel identity after editing.
    // Hide no layer here: the user can hide guides in the template explicitly.
    // Only one merged duplicate: avoid a full layered duplicate on weak PCs.
    app.activeDocument=doc;var merged=doc.duplicate('_UOY template preview PNG '+role,true);owned.push(_uoyDTId(merged));
    if(role==='input'&&merged.mode===DocumentMode.GRAYSCALE)merged.changeMode(ChangeMode.RGB);
    _uoyDTMatchCanvas(merged,spec);_uoyDTImportCanvas(merged,product,role);
    if((role==='depth'&&merged.mode!==doc.mode)||merged.bitsPerChannel!==doc.bitsPerChannel)throw new Error('Composite da doi mode/bit. Khong xuat depth sai gia tri.');
    var hasPixels=false;
    for(var i=0;i<merged.layers.length;i++){var bounds=_uoyDTBounds(merged.layers[i]);if(merged.layers[i].visible&&bounds[2]>bounds[0]&&bounds[3]>bounds[1])hasPixels=true;}
    if(!hasPixels)throw new Error(role==='depth'?'Layer depth map chua co noi dung.':'Layer In chua co fullprint.');
    _uoyDTPlain(file,false);_uoyDTMarkedJob(file.parent);if(file.exists)throw new Error('Slot PNG da ton tai. Khong ghi de.');
    var png=new PNGSaveOptions();png.interlaced=false;written.push(file);
    // No changeMode / convertProfile / flatten / bit-depth assignment here.
    // The worker reads scalar PNG sample codes, not display gamma/luminance.
    merged.saveAs(file,png,true,Extension.LOWERCASE);_uoyDTWaitPNG(file);
    if(!file.exists)throw new Error('Photoshop chua xuat xong PNG template.');
    _uoyDTCloseOwned(merged,owned);
}
function _uoyDTExportTemplatePreview(request) {
    var files=_uoyDTImportPaths(request),owned=[],written=[],previous=app.documents.length?app.activeDocument:null;
    try {
        var explicit=request.document_id?_uoyDTFindDoc(String(request.document_id)):previous;
        var selected=_uoyDTImportSelect(request,owned,explicit),parent=selected.parent,roles=selected.roles;
        if(selected.standalone){
            var standalone=selected.standalone,standaloneSpec=_uoyDTImportCanvas(standalone,files.product,'depth'),originalHistory=_uoyDTHistory(standalone);
            _uoyDTImportComposite(standalone,'depth',files.product,files.depth,owned,written);
            // Without an explicitly paired In role, use depth as the neutral
            // texture. Never attach an unrelated cached print by dimensions.
            app.activeDocument=standalone;var neutral=standalone.duplicate('_UOY neutral preview',true);owned.push(_uoyDTId(neutral));
            if(neutral.mode===DocumentMode.GRAYSCALE)neutral.changeMode(ChangeMode.RGB);
            if(String(neutral.colorProfileName)!=='sRGB IEC61966-2.1')neutral.convertProfile('sRGB IEC61966-2.1',Intent.RELATIVECOLORIMETRIC,true,false);
            _uoyDTImportComposite(neutral,'input',files.product,files.color,owned,written);_uoyDTCloseOwned(neutral,owned);
            if(files.shape){written.push(files.shape);_uoyDTExportCeramicShape(files.product,files.shape,owned,standaloneSpec,standalone,true);}
            if(files.guide){written.push(files.guide);_uoyDTExportCeramicGuide(files.product,files.guide,owned,standaloneSpec,standalone);}
            if(!_uoyDTSameHistory(standalone,originalHistory))throw new Error('Depth da thay doi trong luc nap; bam lai.');
            return {ok:true,product_type:files.product,slot_id:files.slot,width:standaloneSpec.width,height:standaloneSpec.height,dpi:standaloneSpec.dpi,parent_document_id:_uoyDTId(standalone),source_name:String(standalone.name),depth_path:_uoyDTPath(files.depth),color_path:_uoyDTPath(files.color),shape_path:files.shape?_uoyDTPath(files.shape):'',ceramic_guide_path:files.guide?_uoyDTPath(files.guide):'',cut_shape_path:'',standalone:true,neutral_texture:true};
        }
        var parentHistory=_uoyDTHistory(parent),depth=_uoyDTImportOpenRole(parent,roles.depth,owned),input=_uoyDTImportOpenRole(parent,roles.input,owned);
        if(_uoyDTId(depth)===_uoyDTId(input))throw new Error('Depth va In cung mot noi dung. Khong nhap nham fullprint thanh depth.');
        var spec=_uoyDTImportCanvas(depth,files.product,'depth');_uoyDTImportCanvas(input,files.product,'input');_uoyDTMatchCanvas(input,spec);
        if(files.shape&&(spec.width!==_uoyDTSpec(files.product).width||spec.height!==_uoyDTSpec(files.product).height))throw new Error('Template ceramic cu khong cung canvas shape hien tai. Khong resize; dung template ceramic moi.');
        var depthHistory=_uoyDTHistory(depth),inputHistory=_uoyDTHistory(input),cut=null,cutHistory=null,depthBits=depth.bitsPerChannel===BitsPerChannelType.SIXTEEN?16:8,colorBits=input.bitsPerChannel===BitsPerChannelType.SIXTEEN?16:8,depthMode=depth.mode===DocumentMode.GRAYSCALE?'grayscale':'rgb';
        if(files.cut){
            cut=_uoyDTImportOpenRole(parent,roles.cut,owned);_uoyDTMatchCanvas(cut,spec);_uoyDTImportCanvas(cut,files.product,'cut');cutHistory=_uoyDTHistory(cut);
            if(_uoyDTId(cut)===_uoyDTId(input)||_uoyDTId(cut)===_uoyDTId(depth))throw new Error('Cut phai la noi dung rieng voi In/Depth.');
        }
        _uoyDTImportComposite(depth,'depth',files.product,files.depth,owned,written);
        _uoyDTImportComposite(input,'input',files.product,files.color,owned,written);
        if(files.shape){written.push(files.shape);_uoyDTExportCeramicShape(files.product,files.shape,owned,spec,input,true);}
        if(files.guide){written.push(files.guide);_uoyDTExportCeramicGuide(files.product,files.guide,owned,spec,input);}
        // All three child canvases share their native origin. The parent's
        // side-by-side presentation is not a print placement transform.
        if(cut)_uoyDTImportComposite(cut,'cut',files.product,files.cut,owned,written);
        if(!_uoyDTSameHistory(parent,parentHistory)||!_uoyDTSameHistory(depth,depthHistory)||!_uoyDTSameHistory(input,inputHistory)||(cut&&!_uoyDTSameHistory(cut,cutHistory)))throw new Error('Template dang thay doi trong luc doc. Chinh xong roi bam Xem 3D lai; ban cu van duoc giu.');
        var fresh=_uoyDTRoles(parent,files.product);
        for(var role in roles)if(roles.hasOwnProperty(role)&&(roles[role].layer!==fresh[role].layer||roles[role].content!==fresh[role].content||roles[role].transform!==fresh[role].transform))throw new Error('Role template da thay doi trong luc xuat.');
        return {ok:true,product_type:files.product,slot_id:files.slot,width:spec.width,height:spec.height,dpi:300,parent_document_id:_uoyDTId(parent),source_name:String(parent.name).slice(0,500),depth_path:_uoyDTPath(files.depth),color_path:_uoyDTPath(files.color),shape_path:files.shape?_uoyDTPath(files.shape):'',ceramic_guide_path:files.guide?_uoyDTPath(files.guide):'',cut_shape_path:cut?_uoyDTPath(files.cut):'',depth_bit_depth:depthBits,color_bit_depth:colorBits,depth_mode:depthMode};
    }catch(error) {
        for(var i=0;i<written.length;i++)try{if(written[i].exists)written[i].remove();}catch(cleanFile){}
        throw error;
    }finally {
        _uoyDTCleanup(owned);if(previous)try{app.activeDocument=previous;}catch(restoreTab){}
    }
}
function _uoyDTCaptureContext(request){
    var owned=[],previous=app.documents.length?app.activeDocument:null,product=_uoyDTSpec(request.product_type).product_type;
    if(!previous)throw new Error('Mo fullprint/PSD can lay trong Photoshop.');
    try{
        var selected=_uoyDTImportSelect(request,owned,previous),parent,input,roles,spec=_uoyDTSpec(product);
        if(selected.standalone){
            var source=selected.standalone;_uoyDTMatchCanvas(source,spec);
            var opened=_uoyDTOpenTemplate({product_type:product}),created=_uoyDTLoadSession(opened.template_token);
            parent=_uoyDTFindDoc(created.parent);input=_uoyDTFindDoc(created.input);roles=created.roles;
            owned.push(created.parent);owned.push(created.input);
            var sourceHelpers=_uoyDTSourceHelpers(source,product,true);
            _uoyDTCopyLayers(source,input,sourceHelpers);_uoyDTCopyCeramicCaptureShape(source,input,sourceHelpers,created);
        }else{
            parent=selected.parent;roles=selected.roles;input=_uoyDTImportOpenRole(parent,roles.input,owned);app.activeDocument=input;_uoyDTMatchCanvas(input,spec);
            roles.input.helpers=_uoyDTHelpers(input,'input',false,product);
            for(var h=0;h<roles.input.helpers.length;h++)_uoyDTLayer(input,roles.input.helpers[h]).visible=false;
            for(var rn=0;rn<spec.roles.length;rn++){
                var roleName=spec.roles[rn];if(roleName==='input')continue;
                var roleDoc=_uoyDTImportOpenRole(parent,roles[roleName],owned);
                roles[roleName].helpers=_uoyDTHelpers(roleDoc,roleName,false,product);
            }
        }
        // Explicit Add fullprint starts a new snapshot, even after edits or a
        // previous completed apply. Old captures and AI results stay intact.
        var session={product_type:product,width:spec.width,height:spec.height,token:_uoyDTToken('template'),parent:_uoyDTId(parent),input:_uoyDTId(input),roles:roles,captures:{},done:false,broken:false};
        _uoyDTSaveSession(session);var keep={};keep['d'+session.parent]=true;keep['d'+session.input]=true;
        _uoyDTCleanup(owned,keep);owned=[];app.activeDocument=input;return _uoyDTInfo(session);
    }finally{_uoyDTCleanup(owned);}
}
function _uoyDTCeramicToolbarShape(record,spec,source){
    if(spec.product_type==='acrylic'||!record||!record.ceramic_shape)return null;
    var receipt=record.ceramic_shape;
    if(!receipt||typeof receipt!=='object'||typeof receipt.visible!=='boolean'||!receipt.history||!/^\d+$/.test(String(receipt.history.id))||!/^\d+$/.test(String(receipt.document))||!/^\d+$/.test(String(receipt.layer)))throw new Error('Receipt shape Ceramic nguon khong hop le; khong bat mat layer khac.');
    if(!source)source=_uoyDTFindDoc(record.source);
    if(_uoyDTId(source)!==String(receipt.document)||String(record.source)!==String(receipt.document))throw new Error('Shape Ceramic khong thuoc PSD nguon da chup.');
    if(record.target&&(String(record.target.source)!==String(receipt.document)||!record.target.sourceHistory||String(record.target.sourceHistory.id)!==String(receipt.history.id)))throw new Error('Receipt shape Ceramic khong khop dich Generate.');
    _uoyDTMatchCanvas(source,spec);
    if(!_uoyDTSameHistory(source,receipt.history))throw new Error('Shape/PSD Ceramic nguon da thay doi trong khi Generate. Giu nguyen mat layer.');
    var helpers=_uoyDTSourceHelpers(source,spec.product_type,true),shape=_uoyDTCeramicShape(source,spec,receipt.layer);
    if(String(helpers[1])!==String(receipt.layer)||shape.parent!==source||shape.visible!==receipt.visible)throw new Error('Shape Ceramic nguon da doi ID/role/mat layer; khong tu doan.');
    return {doc:source,spec:spec,layer:String(receipt.layer),previousVisible:receipt.visible,attempted:false,saveAttempted:false};
}
function _uoyDTCeramicRollbackToolbarShape(state){
    if(!state||!state.attempted)return;
    var source=_uoyDTFindDoc(_uoyDTId(state.doc));
    if(source!==state.doc)throw new Error('Mat PSD shape Ceramic nguon khi phuc hoi mat layer.');
    app.activeDocument=source;
    _uoyDTCeramicRestoreShape(source,state.spec,state.layer,state.previousVisible);
    if(state.saveAttempted)source.save();
    state.attempted=false;
}
function _uoyDTCeramicFinishStandalone(record,spec,state){
    if(spec.product_type==='acrylic'||!record||record.target)return null;
    state=state||_uoyDTCeramicToolbarShape(record,spec,null);
    if(!state)return null;
    // This is the original standalone PSD. Reveal only its exact source shape;
    // do not save that PSD or replace its artwork with the temporary template.
    state.attempted=true;
    _uoyDTCeramicShowShape(state.doc,spec,state.layer);
    return state;
}
function _uoyDTRebuildCache(request){
    var spec=_uoyDTSpec(request.product_type),owned=[],created=null,success=false,stage='open template',previous=app.documents.length?app.activeDocument:null,record=null,reuse=false,standaloneShape=null,boundShape=null;
    function cached(value,pattern){var file=new File(String(value||''));_uoyDTPlain(file,true);_uoyDTMarkedJob(file.parent);if(!pattern.test(String(file.name)))throw new Error('Sai file cache.');return file;}
    var colorFile=cached(request.color_path,/^(?:source|fullprint-color|text-color|texture)(?:-[0-9]+)?\.png$/i);
    var depthFile=cached(request.path,/^depth-[0-9]{4,}\.png$/i),alphaFile=cached(request.alpha_path,/^(?:alpha|text-color-alpha|ceramic-shape)\.png$/i);
    if(_uoyDTPath(depthFile.parent)!==_uoyDTPath(alphaFile.parent)||Number(request.width)!==spec.width||Number(request.height)!==spec.height)throw new Error('Cache khong cung canvas template. Khong resize du lieu.');
    try{
        if(request.toolbar==='true'&&request.toolbar_capture_token){
            created=_uoyDTLoadSession(request.toolbar_capture_token);
            record=created.toolbar_capture||($.global._uoyToolbarCaptures||{})[request.toolbar_capture_token];
            if(!record)throw new Error('Mat ban chup Generate. Khong tu mo them template.');
            var captureInput=_uoyDTFindDoc(record.input),captureParent=_uoyDTFindDoc(record.parent),validCapture=false;
            for(var ck in created.captures)if(created.captures.hasOwnProperty(ck)&&_uoyDTSameHistory(captureInput,created.captures[ck].history))validCapture=true;
            if(created.parent!==record.parent||created.input!==record.input||created.product_type!==spec.product_type||!validCapture||!_uoyDTSameHistory(captureParent,record.history))throw new Error('Template chup da thay doi trong khi Generate. Giu nguyen, khong ghi de.');
            reuse=true;
        }else{var opened=_uoyDTOpenTemplate({product_type:spec.product_type});created=_uoyDTLoadSession(opened.template_token);}
        owned.push(created.parent);owned.push(created.input);
        var parent=_uoyDTFindDoc(created.parent);
        function compose(){
        var input=_uoyDTFindDoc(created.input),depth=_uoyDTOpenRole(parent,created.roles.depth,owned),cut=spec.product_type==='acrylic'?_uoyDTOpenRole(parent,created.roles.cut,owned):null;
        var source=null,skip=[],layered=false,textTree=null;stage='restore In';
        if(request.snapshot_path){
            var snapshot=cached(request.snapshot_path,/^text-preview-[a-z0-9_-]+\.psd$/i);
            if(_uoyDTFileSHA256(snapshot)!==request.snapshot_sha256)throw new Error('Checkpoint da thay doi.');
            source=_uoyDTOpenFile(snapshot,owned);_uoyDTMatchCanvas(source,spec);
            skip=_uoyDTHelpers(source,'input',false,spec.product_type);layered=true;
        }else{source=_uoyDTOpenFile(colorFile,owned);_uoyDTMatchCanvas(source,spec);}
        if(!reuse&&spec.product_type!=='acrylic'&&request.generation_pipeline==='shared-acrylic-ai-v2'&&!layered)throw new Error('Cache Ceramic thieu snapshot shape goc. Add fullprint va Generate lai; khong thay bang shape mac dinh.');
        if(!reuse){
            _uoyDTCopyLayers(source,input,skip);
            if(layered&&spec.product_type!=='acrylic')_uoyDTCopyCeramicCaptureShape(source,input,skip,created);
        }
        if(layered&&request.text_manifest&&request.plain_path){
            var textManifest=_uoyDTDataParse(request.text_manifest);
            _uoyDTPreviewMatch(source,textManifest);
            if(textManifest.layers.length){
                var modes=_uoyDTModes(request.text_modes,textManifest),plain=request.toolbar==='true';
                textTree=plain?_uoyDTPreservedTextTree(source,textManifest,owned):_uoyDTTextTree(source,textManifest,modes,_uoyDTReadPresets(owned),owned);
                depthFile=cached(request.plain_path,/^depth-[0-9]{4,}\.png$/i);
                if(_uoyDTPath(depthFile.parent)!==_uoyDTPath(alphaFile.parent))throw new Error('Plain depth khong cung cache.');
            }
        }
        _uoyDTCloseOwned(source,owned);
        stage='embed Gray16';var raw=_uoyDTOpenFile(depthFile,owned);_uoyDTMatchCanvas(raw,spec);
        if(raw.mode!==DocumentMode.GRAYSCALE||raw.bitsPerChannel!==BitsPerChannelType.SIXTEEN)throw new Error('Cache depth phai Gray16.');
        app.activeDocument=raw;if(raw.activeLayer.isBackgroundLayer)raw.activeLayer.isBackgroundLayer=false;
        executeAction(stringIDToTypeID('newPlacedLayer'),undefined,DialogModes.NO);_uoyDTScalarProfile(raw,owned);
        stage='restore Depth';var alpha=_uoyDTOpenFile(alphaFile,owned);_uoyDTMatchCanvas(alpha,spec);
        app.activeDocument=raw;var map=raw.activeLayer.duplicate(depth,ElementPlacement.PLACEATBEGINNING);
        app.activeDocument=depth;map.name='UOY Plain Depth - Gray16';
        var wrapper=depth.layerSets.add();wrapper.name='UOY Depth + Text';wrapper.blendMode=BlendMode.NORMAL;map.move(wrapper,ElementPlacement.INSIDE);
        if(textTree){var letters=wrapper.layerSets.add();letters.name='UOY Editable Text';letters.blendMode=BlendMode.NORMAL;var anchor=letters.artLayers.add();anchor.name='_UOY insertion anchor';letters=_uoyDTCopyTextTree(textTree,depth,letters);anchor.remove();letters.move(map,ElementPlacement.PLACEBEFORE);_uoyDTCloseOwned(textTree,owned);}
        _uoyDTAlpha(depth,wrapper,alpha);
        app.activeDocument=raw;var hidden=raw.activeLayer.duplicate(input,ElementPlacement.PLACEATEND);
        app.activeDocument=input;hidden.name='UOY Depth Map - Gray16';_uoyDTAlpha(input,hidden,alpha);hidden.visible=false;
        stage='hide helpers and restore Cut';app.activeDocument=depth;var depthHelpers=_uoyDTHelpers(depth,'depth',false,spec.product_type);
        for(var d=0;d<depthHelpers.length;d++)_uoyDTLayer(depth,depthHelpers[d]).visible=false;
        if(spec.product_type!=='acrylic'&&request.generation_pipeline==='shared-acrylic-ai-v2'){stage='add black Ceramic substrate';_uoyDTCeramicBlackBase(input,depth,spec);}
        if(cut){_uoyDTCopyLayers(depth,cut,depthHelpers);var cutHelpers=_uoyDTHelpers(cut,'cut',false,spec.product_type);for(var c=0;c<cutHelpers.length;c++)_uoyDTLayer(cut,cutHelpers[c]).visible=false;_uoyDTBlackOverlay(parent,_uoyDTLayer(parent,created.roles.cut.layer));}
        app.activeDocument=parent;for(var p=0;p<parent.layers.length;p++)if(String(parent.layers[p].name).toLowerCase().replace(/\s+/g,'')==='safezone')parent.layers[p].visible=false;
        if(spec.product_type!=='acrylic'){stage='show completed Ceramic input shape';_uoyDTCeramicShowShape(input,spec,created.roles.input.helpers[1]);}
        stage='save template contents';app.activeDocument=input;input.save();app.activeDocument=depth;depth.save();if(cut){app.activeDocument=cut;cut.save();}
        created.done=true;_uoyDTSaveSession(created);
        _uoyDTCloseOwned(input,owned);_uoyDTCloseOwned(depth,owned);if(cut)_uoyDTCloseOwned(cut,owned);
        app.activeDocument=parent;parent.activeLayer=_uoyDTLayer(parent,created.roles[cut?'cut':'depth'].layer);
        return {ok:true,complete:true,parent_document_id:created.parent,document_id:created.parent,product_type:spec.product_type,parent_unsaved:true,layered_input:layered,depth_composite:!textTree,reused_template:reuse};
        }
        var result=_uoyDTOwnedQuiet(parent,compose);
        if(record&&record.target){
            stage='commit to original template';boundShape=_uoyDTCeramicToolbarShape(record,spec,_uoyDTFindDoc(record.target.source));
            var destination=_uoyDTCommitToolbarTarget(record,parent,spec,owned);
            // Commit itself owns its early rollback. After it succeeds, retain
            // only the original eye transaction across late close/focus checks.
            if(boundShape){boundShape.attempted=true;boundShape.saveAttempted=true;}
            _uoyDTCloseOwned(parent,owned);if($.global._uoyToolbarCaptures)delete $.global._uoyToolbarCaptures[request.toolbar_capture_token];
            result.parent_document_id=result.document_id=destination;result.reused_template=true;app.activeDocument=_uoyDTFindDoc(destination);
        }else if(record&&record.ceramic_shape&&spec.product_type!=='acrylic'){
            stage='show original standalone Ceramic shape';standaloneShape=_uoyDTCeramicToolbarShape(record,spec,null);
            if(standaloneShape){_uoyDTCeramicFinishStandalone(record,spec,standaloneShape);app.activeDocument=_uoyDTFindDoc(created.parent);result.ceramic_shape_visible=true;}
        }
        success=true;return result;
    }catch(error){
        try{_uoyDTCeramicRollbackToolbarShape(standaloneShape);_uoyDTCeramicRollbackToolbarShape(boundShape);}catch(shapeRollback){throw new Error('Dựng template ['+stage+']: '+String(error.message||error)+' Khong phuc hoi duoc mat shape Ceramic nguon; giu PSD de kiem tra. '+String(shapeRollback.message||shapeRollback));}
        throw new Error('Dựng template ['+stage+']: '+String(error.message||error)+(boundShape&&boundShape.saveAttempted?' Depth co the da nhap; giu template de kiem tra, mat shape nguon da phuc hoi.':''));
    }finally{var keep={};if(success&&created)keep['d'+created.parent]=true;_uoyDTCleanup(owned,keep);if(!success&&previous)try{app.activeDocument=previous;}catch(restore){} }
}
function _uoyDTCutHasArtwork(doc,helpers){
    function populated(layer){if(layer.typename!=='LayerSet')return true;for(var n=0;n<layer.layers.length;n++)if(populated(layer.layers[n]))return true;return false;}
    for(var i=0;i<doc.layers.length;i++){var layer=doc.layers[i],id=_uoyDTId(layer);if(id!==helpers[0]&&id!==helpers[1]&&populated(layer))return true;}
    return false;
}
function _uoyDTCutMatchesBundledBlank(cut){
    // Reopened PSDs lose the app-only pristine receipt. Never infer a blank
    // manufacturing cut from helper names, gray pixels, or a content UUID:
    // prove its entire saved native PSB equals the bundled original instead.
    // This includes every hidden layer, mask, vector path, alpha and setting.
    if(cut.saved!==true||cut.layers.length!==2)return false;
    var previous=app.activeDocument,owned=[],copy=null,copied=false,left=null,right=null;
    var history=_uoyDTHistory(cut),result=false,leftStamp='',rightStamp='';
    try{
        left=new File(cut.fullName.fsName);_uoyDTPlain(left,true);
        if(left.length<26||left.length>16777216)return false;
        leftStamp=_uoyDTSignature(left);
        _uoyDTPlain(_uoyDTAsset,true);
        copy=new File(Folder.temp.fsName+'/_UOY-cut-proof-'+_uoyDTToken('copy')+'.psd');
        _uoyDTPlain(copy,false);if(copy.exists||!_uoyDTAsset.copy(copy.fsName))return false;copied=true;
        var baseline=_uoyDTOpenFile(copy,owned),roles=_uoyDTRoles(baseline,'acrylic');
        var blank=_uoyDTOpenRole(baseline,roles.cut,owned);
        _uoyDTHelpers(blank,'cut',true,'acrylic');
        if(blank.saved!==true)return false;
        right=new File(blank.fullName.fsName);_uoyDTPlain(right,true);
        if(_uoyDTPath(left)===_uoyDTPath(right)||left.length!==right.length)return false;
        rightStamp=_uoyDTSignature(right);left.encoding=right.encoding='BINARY';
        if(!left.open('r')||!right.open('r'))return false;
        var remaining=Number(left.length);
        while(remaining>0){var count=Math.min(65536,remaining),a=left.read(count),b=right.read(count);if(a.length!==count||b.length!==count||a!==b)return false;remaining-=count;}
        result=cut.saved===true&&_uoyDTSameHistory(cut,history)&&_uoyDTSignature(left)===leftStamp&&_uoyDTSignature(right)===rightStamp;
    }catch(unproven){result=false;}
    finally{
        if(left)try{left.close();}catch(closeLeft){}
        if(right)try{right.close();}catch(closeRight){}
        _uoyDTCleanup(owned);
        if(copied)try{copy.remove();}catch(removeCopy){}
        try{app.activeDocument=previous;}catch(restore){}
    }
    return result;
}
function _uoyDTCommitToolbarTarget(record,built,spec,owned){
    var target=record.target,parent=_uoyDTFindDoc(target.parent),source=_uoyDTFindDoc(target.source),roles=_uoyDTRoles(parent,spec.product_type),builtRoles=_uoyDTRoles(built,spec.product_type),rows=[],mutated=false,cutStyleHistory=null,sourceShape=null;
    if(!_uoyDTSameHistory(source,target.sourceHistory))throw new Error('In dang thay doi trong khi Generate. Khong ghi de; giu ban Generate de phuc hoi.');
    // Parent layout/view history and an independently edited Cut are not AI
    // source changes. Resolve the current native links; preserve presentation
    // transforms. Still refuse a replaced In or a newly edited Depth target.
    var protectedRoles=['input','depth'];
    for(var pr=0;pr<protectedRoles.length;pr++){
        var role=protectedRoles[pr];
        if(roles[role].layer!==target.roles[role].layer||(role==='depth'&&roles[role].content!==target.roles[role].content))throw new Error('In/Depth dich bi thay the trong khi Generate. Khong ghi de chinh sua moi.');
    }
    if(_uoyDTId(_uoyDTImportOpenRole(parent,roles.input,owned))!==_uoyDTId(source))throw new Error('In khong con lien ket voi ban chup Generate.');
    sourceShape=_uoyDTCeramicToolbarShape(record,spec,source);
    try{
        // Regenerating relief must never replace an authored manufacturing
        // cutline. Initialize Cut only when it still contains no user artwork.
        var names=['depth'],preserveCut=false;
        if(spec.product_type==='acrylic'){
            var currentCut=_uoyDTImportOpenRole(parent,roles.cut,owned),cutHelpers=_uoyDTHelpers(currentCut,'cut',false,spec.product_type);
            preserveCut=_uoyDTCutHasArtwork(currentCut,cutHelpers)||!(_uoyDTIsPristineCut(parent,roles.cut,currentCut)||_uoyDTCutMatchesBundledBlank(currentCut));
            if(!preserveCut)names.push('cut');
        }
        for(var i=0;i<names.length;i++){
            var name=names[i],to=_uoyDTImportOpenRole(parent,roles[name],owned),from=_uoyDTImportOpenRole(built,builtRoles[name],owned),helpers=_uoyDTHelpers(to,name,false,spec.product_type),fromHelpers=_uoyDTHelpers(from,name,false,spec.product_type);
            app.activeDocument=to;var backup=to.duplicate('UOY RECOVERY '+name,false);owned.push(_uoyDTId(backup));rows.push({role:name,to:to,from:from,backup:backup,history:_uoyDTHistory(to),helpers:helpers,fromHelpers:fromHelpers});
        }
        for(i=0;i<rows.length;i++){
            var row=rows[i];app.activeDocument=row.to;mutated=true;
            for(var n=row.to.layers.length-1;n>=0;n--){var layer=row.to.layers[n],id=_uoyDTId(layer);if(id!==row.helpers[0]&&id!==row.helpers[1]){if(layer.allLocked)layer.allLocked=false;layer.remove();}}
            _uoyDTCopyLayers(row.from,row.to,row.fromHelpers);app.activeDocument=row.to;
            // Old Cut PSBs can still show their bundled rectangle/safe-zone
            // helpers. Black Overlay would turn that backdrop into a solid
            // rectangle rather than the product silhouette. Retain the helper
            // layers/IDs, but hide them exactly as in the fresh Cut build.
            for(var h=0;h<row.helpers.length;h++)_uoyDTLayer(row.to,row.helpers[h]).visible=false;
            if(spec.product_type!=='acrylic')for(var bi=0;bi<row.to.layers.length;bi++)if(String(row.to.layers[bi].name)==='UOY Ceramic Black Base'){var blackBase=row.to.layers[bi],last=row.to.layers[row.to.layers.length-1];if(_uoyDTId(last)!==_uoyDTId(blackBase))blackBase.move(last,ElementPlacement.PLACEAFTER);break;}
            row.to.save();
        }
        // All depth destination commits succeeded. Reveal only the original
        // Ceramic shape recorded before AI; never unhide safezone or artwork.
        if(sourceShape){sourceShape.attempted=true;_uoyDTCeramicShowShape(source,spec,sourceShape.layer);sourceShape.saveAttempted=true;}
        // Saving the native In refreshes the original parent's color preview.
        app.activeDocument=source;source.save();app.activeDocument=parent;
        // Cut contents are copied into the ORIGINAL template's Smart Object.
        // Its style does not come along from the temporary build's parent layer.
        // Reassert the black silhouette on this real destination, never on In.
        cutStyleHistory=_uoyDTHistory(parent);
        for(var p=0;p<parent.layers.length;p++)if(String(parent.layers[p].name).toLowerCase().replace(/\s+/g,'')==='safezone')parent.layers[p].visible=false;
        var depthRole=_uoyDTLayer(parent,roles.depth.layer);depthRole.visible=true;depthRole.opacity=100;depthRole.fillOpacity=100;
        if(spec.product_type==='acrylic'&&!preserveCut){var cutRole=_uoyDTLayer(parent,roles.cut.layer);cutRole.visible=true;cutRole.opacity=100;cutRole.fillOpacity=100;_uoyDTBlackOverlay(parent,cutRole);}
        return _uoyDTId(parent);
    }catch(error){
        var recovered=true;
        if(cutStyleHistory&&!_uoyDTRestore(parent,cutStyleHistory))recovered=false;
        if(mutated)for(var r=rows.length-1;r>=0;r--)try{_uoyDTRestore(rows[r].to,rows[r].history);app.activeDocument=rows[r].to;rows[r].to.save();}catch(rollback){recovered=false;}
        try{_uoyDTCeramicRollbackToolbarShape(sourceShape);}catch(shapeRollback){recovered=false;}
        if(!recovered){for(r=0;r<rows.length;r++)for(var o=owned.length-1;o>=0;o--)if(owned[o]===_uoyDTId(rows[r].backup))owned.splice(o,1);throw new Error(String(error)+' Recovery tabs retained; khong dong khi chua luu phuc hoi.');}
        throw error;
    }
}
return {module:'import',schema:1,version:'20260918-scope1',api:{exportTemplatePreview:_uoyDTExportTemplatePreview,captureContext:_uoyDTCaptureContext,rebuildCache:_uoyDTRebuildCache,selectContext:_uoyDTImportSelect,openRole:_uoyDTImportOpenRole}};
})();
