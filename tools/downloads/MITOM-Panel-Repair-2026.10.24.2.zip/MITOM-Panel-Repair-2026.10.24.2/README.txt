MITOM CUT repair 2026.10.24.2

Fixes the missing CUT output for both Generate CPU and Generate GPU.
An untouched template CUT placeholder is replaced by the generated silhouette.
A manually authored CUT is preserved. This repair does not alter the AI models.

1. Save your documents and close Photoshop yourself.
2. Extract the ZIP fully. Run Update MITOM Panel.cmd.
3. Open Photoshop again.
The updater stops before changes if Photoshop is running; it never closes any application.
For verification only, run Update MITOM Panel.cmd --preflight. No files are written.

Supports the complete Launcher installation 2026.10.23.2, including the reviewed
2026.10.23.3, 2026.10.23.4 and 2026.10.24.1 incremental repairs.
Exactly one source file is changed: panel/jsx/depth-template-import.jsx.
Unknown edited files are preserved and the updater stops.
The original source is backed up. Failed writes restore only this repair's own output.
Other panel repairs, model files, account/session data, Base Companion pairing,
configuration and the complete-install receipt remain unchanged.
A separate repair journal records 2026.10.24.2.

HUONG DAN
Luu cong viec va dong Photoshop. Giai nen ZIP, chay Update MITOM Panel.cmd.
Mo lai Photoshop. Sua CUT cho ca CPU va GPU; giu nguyen CUT do ban tu thiet ke.
Giu nguyen cac ban sua khac, model, tai khoan, cau hinh va ghep noi Base.
