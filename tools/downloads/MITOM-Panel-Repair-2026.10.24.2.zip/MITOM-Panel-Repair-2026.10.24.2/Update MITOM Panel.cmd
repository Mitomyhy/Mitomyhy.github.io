@echo off
setlocal
set "MITOM_CUT_PYTHON=%LOCALAPPDATA%\UOY\Launcher\current\python\python.exe"
if not exist "%MITOM_CUT_PYTHON%" (
  echo Install the current MITOM Launcher panel before running this repair.
  pause
  exit /b 1
)
"%MITOM_CUT_PYTHON%" -B "%~dp0apply_patch_update.py" %*
set "MITOM_CUT_RESULT=%ERRORLEVEL%"
pause
exit /b %MITOM_CUT_RESULT%
