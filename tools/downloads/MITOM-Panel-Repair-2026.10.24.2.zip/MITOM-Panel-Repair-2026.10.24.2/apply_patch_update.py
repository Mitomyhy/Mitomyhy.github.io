"""Apply the single reviewed CUT placeholder repair to a managed MITOM panel.

The full-install receipt is read, never changed. No download, process termination,
model, authentication, configuration or Companion changes are performed.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import uuid

BASE = "2026.10.23.2"
VERSION = "2026.10.24.2"
NAME = "panel/jsx/depth-template-import.jsx"
ALLOWED = frozenset((NAME,))
BASE_FILE_SHA256 = "56a1afef402a01976bb581c8df1bd6ea0a23398edc47cc6bec57f74bad87db31"
BASE_FILE_SIZE = 33595
REVIEWED_OUTPUT_SHA256 = "54994fa4d328794c5a77ab41c3a5f0d3c456441c609fbf035a9982585117ccc2"
RECEIPT_VERSIONS = frozenset((BASE, "2026.10.23.3", "2026.10.23.4", "2026.10.24.1", VERSION))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked(path):
    path = Path(path).absolute()
    if str(path).startswith("\\\\") or any(part == ".." for part in path.parts):
        raise ValueError("Use the local managed installation without parent traversal.")
    for item in (path, *path.parents):
        if item.exists() or item.is_symlink():
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("A junction/link was found. Existing files were preserved.")
            if stat.S_ISREG(info.st_mode) and info.st_nlink != 1:
                raise ValueError("A linked file was found. Existing files were preserved.")
    return path


def existing(path):
    path = checked(path)
    if path.exists() and not path.is_file():
        raise ValueError("A repair target is not a file.")
    return path.read_bytes() if path.exists() else None


def target_path(roots, name):
    if name not in ALLOWED:
        raise ValueError("Unreviewed repair target was refused.")
    root, relative = name.split("/", 1)
    base = checked(roots[root])
    target = checked(base / relative)
    if not target.is_relative_to(base):
        raise ValueError("Repair target escaped the managed installation.")
    return target


def atomic(path, data, expected):
    previous = existing(path)
    if (digest(previous) if previous is not None else None) != expected:
        raise ValueError("A file changed during the repair. No replacement was made.")
    checked(path.parent)
    handle, temporary_name = tempfile.mkstemp(prefix=".mitom-cut-", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        current = existing(path)
        if (digest(current) if current is not None else None) != expected:
            raise ValueError("A file changed before replacement. Existing files were preserved.")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def photoshop_closed():
    if os.name != "nt":
        return
    tasklist = Path(os.environ["SystemRoot"]) / "System32/tasklist.exe"
    process = subprocess.run([str(tasklist), "/FO", "CSV", "/NH"], shell=False,
        check=True, capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
    if any(row and row[0].casefold() == "photoshop.exe"
           for row in csv.reader(io.StringIO(process.stdout))):
        raise RuntimeError("Save your documents and close Photoshop, then run this repair again. No process was closed.")


def verify_receipt(receipt):
    raw = existing(receipt)
    baseline = json.loads(raw.decode("utf-8-sig")) if raw is not None else None
    if not isinstance(baseline, dict) or baseline.get("schema") != 1 or baseline.get("version") not in RECEIPT_VERSIONS:
        raise ValueError("Install the complete supported panel through MITOM Launcher before this repair.")
    identity = baseline.get("identity")
    inventory = baseline.get("files")
    if not isinstance(identity, str) or len(identity) != 64 or any(c not in "0123456789abcdef" for c in identity):
        raise ValueError("The complete-install receipt identity is invalid; it was preserved.")
    if not isinstance(inventory, list) or any(not isinstance(row, dict) or not isinstance(row.get("path"), str) for row in inventory):
        raise ValueError("The complete-install receipt inventory is invalid; it was preserved.")
    if len({row["path"] for row in inventory}) != len(inventory):
        raise ValueError("The complete-install receipt has duplicate paths; it was preserved.")
    rows = [row for row in inventory if row["path"] == NAME]
    if len(rows) != 1 or rows[0].get("sha256") != BASE_FILE_SHA256 or rows[0].get("size") != BASE_FILE_SIZE:
        raise ValueError("The complete-install receipt is not the reviewed CUT baseline; it was preserved.")
    return digest(raw)


def preflight(package, roots, receipt):
    package = checked(package)
    raw = existing(package / "patch-manifest.json")
    manifest = json.loads(raw.decode("utf-8")) if raw is not None else None
    if not isinstance(manifest, dict) or manifest.get("schema") != 2 or manifest.get("base_version") != BASE or manifest.get("version") != VERSION:
        raise ValueError("This package is not the reviewed CUT repair.")
    rows = manifest.get("files")
    if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict) or rows[0].get("path") != NAME:
        raise ValueError("The repair inventory must contain exactly the reviewed CUT source file.")
    row = rows[0]
    if row.get("accepted_before_sha256") != [BASE_FILE_SHA256] or row.get("baseline_size") != BASE_FILE_SIZE:
        raise ValueError("The repair preimage inventory is not the authenticated baseline.")
    if row.get("sha256") != REVIEWED_OUTPUT_SHA256 or not isinstance(row.get("size"), int) or not 0 < row["size"] <= 4_000_000:
        raise ValueError("The repair output inventory is not the reviewed source.")
    receipt_sha = verify_receipt(checked(receipt))
    data = existing(package / "payload" / NAME)
    if data is None or len(data) != row["size"] or digest(data) != row["sha256"]:
        raise ValueError("Package verification failed for " + NAME)
    target = target_path(roots, NAME)
    before = existing(target)
    current = digest(before) if before is not None else None
    if current not in (BASE_FILE_SHA256, REVIEWED_OUTPUT_SHA256):
        raise ValueError("The installed file differs from the reviewed production version. It was preserved; use a reviewed cumulative Launcher update.")
    return dict(path=NAME, target=target, before=before, after=data, before_sha256=current,
        sha256=row["sha256"], already_current=current == row["sha256"], receipt_sha256=receipt_sha)


def apply(package, roots, receipt, backups, closed=photoshop_closed, dry_run=False):
    plan = preflight(package, roots, receipt)
    if dry_run:
        return dict(preflight=True, version=VERSION, files=0 if plan["already_current"] else 1,
            already_current=plan["already_current"], full_install_receipt_preserved=True)
    closed()
    if plan["already_current"]:
        return dict(updated=False, already_current=True, version=VERSION)
    if digest(existing(receipt)) != plan["receipt_sha256"]:
        raise ValueError("The complete-install receipt changed during preflight. No replacement was made.")
    backup = checked(backups) / ("mitom-cut-" + VERSION + "-" + uuid.uuid4().hex)
    backup.mkdir(parents=True)
    saved = checked(backup / NAME)
    saved.parent.mkdir(parents=True)
    atomic(saved, plan["before"], None)
    journal_path = checked(backup / "repair-journal.json")
    journal = dict(schema=1, patch_version=VERSION, created_utc=datetime.now(timezone.utc).isoformat(),
        files=[{key: plan[key] for key in ("path", "before_sha256", "sha256")}], completed=False)
    initial_journal = (json.dumps(journal, indent=2) + "\n").encode()
    atomic(journal_path, initial_journal, None)
    try:
        atomic(plan["target"], plan["after"], plan["before_sha256"])
        if digest(existing(plan["target"])) != plan["sha256"]:
            raise ValueError("A concurrent edit followed replacement; it was preserved.")
        journal["completed"] = True
        atomic(journal_path, (json.dumps(journal, indent=2) + "\n").encode(), digest(initial_journal))
    except BaseException:
        # Restore only our own output. Never overwrite a newer unrelated edit.
        current = existing(plan["target"])
        if current is not None and digest(current) == plan["sha256"]:
            atomic(plan["target"], plan["before"], plan["sha256"])
        raise
    return dict(updated=True, version=VERSION, files=1, backup=str(backup),
        full_install_receipt_preserved=True, models_unchanged=True,
        machine_configuration_unchanged=True, companion_unchanged=True,
        authentication_unchanged=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preflight", action="store_true", help="Verify only; write no files. Photoshop may stay open.")
    args = parser.parse_args()
    local, roaming = Path(os.environ["LOCALAPPDATA"]), Path(os.environ["APPDATA"])
    roots = dict(panel=roaming / "Adobe/CEP/extensions/com.uoy.orderpanel")
    report = apply(Path(__file__).resolve().parent, roots,
        local / "UOY/Launcher/install-receipt.json", local / "UOY/UpdateBackups", dry_run=args.preflight)
    print("Verification only; no files changed." if args.preflight else "MITOM CUT repair installed. Open Photoshop again.")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Repair stopped: " + str(error), file=sys.stderr)
        raise SystemExit(1)
