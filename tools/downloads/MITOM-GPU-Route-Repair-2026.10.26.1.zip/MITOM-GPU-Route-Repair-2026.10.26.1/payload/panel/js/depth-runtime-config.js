/* Select the installed managed engine when an old local setup still emits v1.
 * No configuration, model, output or user file is written by this module. */
"use strict";
var PIPELINE = "shared-acrylic-ai-v2";
var GPU_ENGINE_SHA256 = "6560582e3b0fd58da68ddf70348ec36956f83465211b19b53f81a72d3a4e2ec9";
var GPU_SETUP_SHA256 = "acaa260362a39f10bca704893864dfcb8aa22ccd4fe568db29b18a3f7343372a";
function samePath(a, b, path) { return path.sep === "\\" ? a.toLowerCase() === b.toLowerCase() : a === b; }
function ownedPath(file, fs, path, allowMissing) {
  if (typeof file !== "string" || !path.isAbsolute(file) || /^\\\\/.test(file) || /[\x00-\x1f]/.test(file)) return false;
  var cursor = path.resolve(file), count = 0;
  try {
    while (++count <= 128) {
      try {
        var info = fs.lstatSync(cursor);
        if (info.isSymbolicLink() || !samePath(path.resolve(fs.realpathSync(cursor)), cursor, path)) return false;
      } catch (missing) { if (!allowMissing || missing.code !== "ENOENT") return false; }
      var parent = path.dirname(cursor);
      if (samePath(parent, cursor, path)) return true;
      cursor = parent;
    }
  } catch (_) {}
  return false;
}
function regularOwnedFile(file, fs, path, maximum) {
  try {
    if (!ownedPath(file, fs, path, false)) return false;
    var info = fs.lstatSync(file);
    return info.isFile() && info.size > 0 && info.size <= maximum;
  } catch (_) { return false; }
}
function managedGPU(options, fs, path, env) {
  // This is separate from the recipient's CPU selection. Never execute a
  // script found beside an arbitrary custom worker as an installer fallback.
  if (typeof env.LOCALAPPDATA !== "string" || !path.isAbsolute(env.LOCALAPPDATA) || /^\\\\/.test(env.LOCALAPPDATA)) return null;
  var root = path.join(env.LOCALAPPDATA, "UOY", "Launcher", "current"), engineRoot = path.join(root, "depth-engine");
  var worker = path.join(engineRoot, "engine.py"), setup = path.join(engineRoot, "setup_gpu.py"), python = path.join(root, "python", "python.exe");
  var gpuRoot = path.join(env.LOCALAPPDATA, "UOY", "DepthGPU"), gpuPython = path.join(gpuRoot, "Scripts", "python.exe");
  try {
    if (!regularOwnedFile(worker, fs, path, 262144) || !regularOwnedFile(setup, fs, path, 65536) ||
        !regularOwnedFile(python, fs, path, 32 * 1024 * 1024) ||
        !regularOwnedFile(path.join(engineRoot, "ceramic_product.py"), fs, path, 131072) || inspectWorker(worker, fs, path) !== PIPELINE ||
        !ownedPath(gpuRoot, fs, path, true) || !ownedPath(gpuPython, fs, path, true)) return null;
    var crypto = options.crypto || require("crypto"), engineBytes = fs.readFileSync(worker), setupBytes = fs.readFileSync(setup);
    if (crypto.createHash("sha256").update(engineBytes).digest("hex") !== GPU_ENGINE_SHA256 ||
        crypto.createHash("sha256").update(setupBytes).digest("hex") !== GPU_SETUP_SHA256 ||
        !/["']device_selection["']\s*:\s*["']explicit-cpu-cuda-v1["']/.test(String(engineBytes))) return null;
    return { worker: worker, setup: setup, setupPython: python, root: gpuRoot, python: gpuPython };
  } catch (_) { return null; }
}
function inspectWorker(worker, fs, path) {
  try {
    if (typeof worker !== "string" || !path.isAbsolute(worker) || path.basename(worker).toLowerCase() !== "engine.py" || path.basename(path.dirname(worker)).toLowerCase() !== "depth-engine") return "unknown";
    var policy = path.join(path.dirname(worker), "ceramic_product.py");
    var stat = fs.lstatSync(policy), engineStat = fs.lstatSync(worker);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 131072 || !engineStat.isFile() || engineStat.isSymbolicLink()) return "unknown";
    var text = fs.readFileSync(policy, "utf8");
    if (/^ACRYLIC_COMPOSITION_PIPELINE\s*=\s*["']shared-acrylic-ai-v2["']\s*$/m.test(text)) return PIPELINE;
    if (/^SHARED_PIPELINE\s*=\s*["']shared-acrylic-ai-v1["']\s*$/m.test(text)) return "shared-acrylic-ai-v1";
  } catch (_) {}
  return "unknown";
}
function select(config, options) {
  options = options || {};
  var fs = options.fs || require("fs"), path = options.path || require("path"), env = options.env || require("process").env;
  var result = {}, key;
  for (key in config) if (Object.prototype.hasOwnProperty.call(config, key)) result[key] = config[key];
  var gpu = managedGPU(options, fs, path, env);
  var detected = inspectWorker(result.worker, fs, path);
  if (detected !== "shared-acrylic-ai-v1") return { config: result, migrated: false, pipeline: detected, gpu: gpu };
  var bases = [];
  if (typeof env.LOCALAPPDATA === "string" && path.isAbsolute(env.LOCALAPPDATA)) bases.push(env.LOCALAPPDATA);
  if (typeof env.USERPROFILE === "string" && path.isAbsolute(env.USERPROFILE)) bases.push(path.join(env.USERPROFILE, "AppData", "Local"));
  for (var i = 0; i < bases.length; i++) {
    var root = path.join(bases[i], "UOY", "Launcher", "current"), worker = path.join(root, "depth-engine", "engine.py"), python = path.join(root, "python", "python.exe");
    try {
      var pythonStat = fs.lstatSync(python);
      if (!pythonStat.isFile() || pythonStat.isSymbolicLink() || inspectWorker(worker, fs, path) !== PIPELINE) continue;
      // Data/model locations and every other machine-local option stay exact.
      result.worker = worker; result.python = python;
      return { config: result, migrated: true, pipeline: PIPELINE, gpu: gpu };
    } catch (_) {}
  }
  return { config: result, migrated: false, pipeline: detected, gpu: gpu };
}
module.exports = { select: select, inspectWorker: inspectWorker, pipeline: PIPELINE };
