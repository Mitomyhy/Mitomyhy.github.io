@echo off
setlocal
set "MITOM_REPAIR_PYTHON=%LOCALAPPDATA%\UOY\Launcher\current\python\python.exe"
if not exist "%MITOM_REPAIR_PYTHON%" (
  echo Install the current managed MITOM Panel before this repair.
  pause
  exit /b 1
)
"%MITOM_REPAIR_PYTHON%" -B "%~dp0apply_gpu_route_repair.py"
set "MITOM_REPAIR_RESULT=%ERRORLEVEL%"
pause
exit /b %MITOM_REPAIR_RESULT%
