"""Two-target managed-panel repair; no downloads or runtime/configuration writes.

The builder embeds exact approved output pins below. installer_guard.py is the
unchanged audited Launcher installer, reused only for its canonical ownership,
process, mutex, path, transaction and rollback guards. No install() is called.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import time
import uuid
import installer_guard as guard

VERSION = '2026.10.26.1'
BASE_VERSION = '2026.10.25.1'
BEFORE = {
    'panel/js/depth-map.js': '9da76ce9477018396ce59280a27ae5fb29ccb87e6631099d47aa6233deecb1da',
    'panel/js/depth-runtime-config.js': '2d1e1376f2cf9a0eddadab3444504cca31a274043f59e168c81f5389e313b1ed',
}
# Replaced only by the release builder after both source approval gates pass.
APPROVED_OUTPUT = {'panel/js/depth-map.js': {'size': 239306, 'sha256': 'b08954f02da3716c0afc0c9482066d7d806afe0d64e4812a95c0d0d8f091a1e9'}, 'panel/js/depth-runtime-config.js': {'size': 5566, 'sha256': '7019b35ce6606f4accfb0782a3f2800da48295a170421a42e0d230cdba119f6f'}}

def _digest(data):
    return hashlib.sha256(data).hexdigest()

def _package(package):
    package = guard._plain(package)
    if not isinstance(APPROVED_OUTPUT, dict) or set(APPROVED_OUTPUT) != set(BEFORE):
        raise guard.InstallError('This is an unsealed repair source, not an installable package.')
    manifest = guard._read_json(package / 'patch-manifest.json')
    if (manifest.get('schema') != 2 or manifest.get('version') != VERSION or
            manifest.get('base_version') != BASE_VERSION or manifest.get('files') != APPROVED_OUTPUT):
        raise guard.InstallError('Repair manifest differs from the approved two-file package.')
    payload = {}
    for name, expected in APPROVED_OUTPUT.items():
        if (not isinstance(expected, dict) or set(expected) != {'size', 'sha256'} or
                type(expected['size']) is not int or not 0 < expected['size'] <= 1024 * 1024):
            raise guard.InstallError('Invalid approved repair pin.')
        source = guard._child(package / 'payload', name)
        if guard._hash(source) is None:
            raise guard.InstallError('Repair payload integrity failed: ' + name)
        data = source.read_bytes()
        if len(data) != expected['size'] or _digest(data) != expected['sha256']:
            raise guard.InstallError('Repair payload integrity failed: ' + name)
        payload[name] = data
    return payload

def apply(package, base_root=None):
    payload = _package(Path(package))
    roots, local, sandbox = guard._roots(base_root)
    guard._closed(sandbox)
    with guard._lock(roots, sandbox):
        pending = roots['launcher'] / 'pending-transaction.json'
        if guard._hash(pending) is not None:
            raise guard.InstallError('An unfinished Launcher update was preserved. Use Restore previous version first; no repair files changed.')
        guard._closed(sandbox)
        receipt_path = roots['launcher'] / 'install-receipt.json'
        receipt_hash = guard._hash(receipt_path)
        receipt = guard._read_json(receipt_path)
        identity = guard._identity(roots)
        if (receipt.get('schema') != 1 or receipt.get('version') != BASE_VERSION or
                receipt.get('identity') != identity):
            raise guard.InstallError('This repair requires the current user\'s exact Panel 2026.10.25.1 installation. Existing files were preserved.')
        recorded = receipt.get('files')
        if not isinstance(recorded, list):
            raise guard.InstallError('The existing full-install receipt was preserved: invalid inventory.')
        owned = {}
        for row in recorded:
            if not isinstance(row, dict) or not isinstance(row.get('path'), str) or row['path'] in owned:
                raise guard.InstallError('The existing receipt has invalid or duplicate paths.')
            owned[row['path']] = row
        changes = []
        for name in sorted(BEFORE):
            if owned.get(name, {}).get('sha256') != BEFORE[name]:
                raise guard.InstallError('The full-install receipt does not own the supported preimage: ' + name)
            target = guard._child(roots['panel'], name.split('/', 1)[1])
            before = guard._hash(target)
            if before == APPROVED_OUTPUT[name]['sha256']:
                continue
            if before != BEFORE[name]:
                raise guard.InstallError('A newer or custom panel file was preserved: ' + name)
            changes.append({'entry': {'path': name, **APPROVED_OUTPUT[name]}, 'target': target,
                            'before': before, 'data': payload[name]})
        if not changes:
            return {'updated': False, 'already_current': True, 'patch_version': VERSION,
                    'full_install_receipt_preserved': True}
        guard._space_preflight(changes, roots)
        backup = guard._child(roots['launcher'], 'backups/' + time.strftime('%Y%m%d-%H%M%S') + '-gpu-route-' + uuid.uuid4().hex)
        backup.mkdir(parents=True, exist_ok=False)
        journal = {'schema': 1, 'identity': identity, 'version': VERSION, 'status': 'preparing',
                   'files': [], 'registry': []}
        for index, change in enumerate(changes):
            if guard._hash(change['target']) != change['before']:
                raise guard.InstallError('A target changed during repair preflight; no panel file changed.')
            stored = 'files/' + str(index) + '.bin'
            guard._atomic(guard._child(backup, stored), guard._FileSource(change['target'], change['before']), None)
            journal['files'].append({'path': change['entry']['path'], 'before': change['before'],
                                     'after': change['entry']['sha256'], 'backup': stored, 'applied': True})
        guard._write_journal(backup / 'transaction.json', journal)
        guard._atomic(pending, guard._json_bytes({'schema': 1, 'identity': identity,
                                                'backup': backup.relative_to(roots['launcher']).as_posix()}), None)
        try:
            for change in changes:
                guard._closed(sandbox)
                if guard._hash(receipt_path) != receipt_hash:
                    raise guard.InstallError('The full-install receipt changed during repair.')
                guard._atomic(change['target'], change['data'], change['before'])
            if guard._hash(receipt_path) != receipt_hash:
                raise guard.InstallError('The full-install receipt changed during repair.')
            journal['status'] = 'installed'
            guard._write_journal(backup / 'transaction.json', journal)
            guard._plain(pending).unlink()
        except BaseException as error:
            retained = guard._restore(journal, backup, roots, sandbox)
            journal['status'] = 'recovery_required' if retained else 'rolled_back'
            journal['retained'] = retained
            guard._write_journal(backup / 'transaction.json', journal)
            if not retained:
                guard._plain(pending).unlink(missing_ok=True)
            raise guard.InstallError('Repair stopped. ' + ('Later edits retained; use Restore previous version.' if retained else 'Previous panel files restored.') + ' Backup: ' + str(backup)) from error
        return {'updated': True, 'patch_version': VERSION, 'files': len(changes), 'backup': str(backup),
                'full_install_receipt_preserved': guard._hash(receipt_path) == receipt_hash,
                'settings_models_runtimes_unchanged': True, 'gpu_setup_or_inference_started': False}

def main():
    result = apply(Path(__file__).resolve().parent)
    print('GPU routing repair complete. Reopen Photoshop when convenient. No CUDA installation or generation was started.')
    print(json.dumps(result, ensure_ascii=False))

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('Repair stopped: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
