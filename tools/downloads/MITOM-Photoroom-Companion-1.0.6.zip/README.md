# UOY Photoroom Companion — 1.0.6

Extension Chrome riêng cho tab **Photoroom** của panel UOY. Không thay extension GPT/Gemini, không cần API key Photoroom, không chạy BiRefNet.

## Cài một lần trên mỗi máy

1. Lưu công việc và đóng Photoshop trước khi chạy bản cập nhật panel đi kèm.
2. Giải nén bộ cập nhật vào một folder cố định. Không xóa hay chuyển folder extension sau khi đã nạp.
3. Trong **Google Chrome**, mở `chrome://extensions`, bật **Developer mode**, chọn **Load unpacked**, chọn folder `photoroom-extension` (folder chứa `manifest.json`).
4. Mở Photoshop → panel UOY → **Photoroom**. Mã được lưu bền trong file `%LOCALAPPDATA%\UOY\Photoroom\settings\photoroom_pairing_token.txt`. Dán đường dẫn này vào thanh địa chỉ File Explorer, mở TXT và copy toàn bộ mã. Không cần ô mã trong panel.
5. Bấm biểu tượng **UOY Photoroom Companion** trong Chrome, dán mã, bấm **Ghép kết nối**. Đây là mã kết nối nội bộ máy, không phải API key hay mật khẩu Photoroom. Không gửi mã cho người khác.
6. Bấm **Chọn & tách ảnh** và chọn file. Ngay sau khi nhận ảnh hợp lệ, panel **tự gửi ảnh tới Photoroom, tách nền rồi thêm kết quả vào Photoshop**, không cần nút Tách nền nữa. Kéo-thả, **Từ Photoshop** và **Dán Clipboard** cũng bắt đầu cùng luồng tự động. Chrome phải đang chạy và companion đã ghép. Tab xử lý mở ở nền và tự đóng sau phiên.

Máy đã ghép giữ nguyên mã và kết nối sau cập nhật. Nếu folder extension đang nạp đã được cập nhật, chỉ bấm **Reload** tại `chrome://extensions`; không gỡ/cài lại hoặc chọn folder mới. Mã chỉ được tạo lần đầu rồi lưu lại; không đổi mỗi lần mở Photoshop, không phải API key. Mỗi máy dùng mã riêng trong TXT trên máy đó; không nhúng chung khóa thật vào code hay ZIP.

## Thay đổi 1.0.6 — chọn ảnh là tự chạy

- Bỏ nút **Tách nền bằng Photoroom**. Chọn một ảnh hợp lệ, kéo ảnh vào panel hoặc chủ động lấy từ Photoshop/Clipboard sẽ tự thực hiện đúng một lượt gửi → tách → thêm layer. Các định dạng PNG/JPEG/WebP/BMP hiện có vẫn được hỗ trợ.
- Đổi tên tab **Remove BG** thành **Photoroom**, dùng logo PNG nguyên bản do người dùng cung cấp. Logo được cài cùng panel, không phụ thuộc đường dẫn Downloads của máy này.
- **Hủy** và **Xóa ảnh** dừng phiên chờ; kết nối đến muộn không được tự gửi ảnh đã hủy. Lỗi không tạo vòng lặp gửi lại: chọn lại ảnh khi muốn thử lại. Lỗi nhập Photoshop vẫn giữ PNG hiện tại để bấm **Thêm vào Photoshop**, không phải tách lần nữa.
- Chuẩn bị trang trống ngay lúc mở hộp chọn ảnh/lấy ảnh Photoshop hoặc Clipboard nếu bridge đã sẵn sàng. Không chèn thời gian chờ 4 giây; ảnh hợp lệ bắt đầu xử lý ngay. Đóng hộp chọn mà không chọn ảnh không tải ảnh nào lên web.
- Mã điều khiển Chrome giữ nguyên bản 1.0.5; thay đổi tự chạy nằm trong panel. Máy đang chạy companion 1.0.5 đã ghép không cần ghép lại hoặc Reload để dùng luồng này. Bộ 1.0.6 có manifest/tài liệu cập nhật cho lần nạp tiếp theo.
- Không tự lấy ảnh khi mở panel, không khôi phục/gửi lại ảnh cũ. Vẫn giữ ảnh hiện tại trong RAM và dọn PNG chuyển tạm sau khi Photoshop nhận xong; không thêm lịch sử ảnh.

## Thay đổi 1.0.5 — chuẩn bị trang sớm và truyền ảnh lớn nhanh hơn

Ghi chú phiên bản cũ dưới đây dùng thao tác bấm Tách nền; ở 1.0.6, lựa chọn ảnh đã thay cho thao tác đó.

- Khi đã kết nối và chọn ảnh hợp lệ, chuẩn bị tối đa một tab Photoroom mới, trống ở nền trong tối đa 60 giây. Chỉ có mã phiên ngẫu nhiên nội bộ, không gửi ảnh/tên file tới web trước lúc bấm **Tách nền**. Không yêu cầu bạn chờ hoặc bấm thêm nút.
- Khi chạy, dùng tab trống đó đúng một lần rồi đóng. Không giữ lại trang đã xử lý ảnh để dùng cho lần sau. Xóa ảnh, đổi ảnh, đóng panel hoặc hết hạn sẽ thu hồi tab chuẩn bị; nếu kết nối bị mất, dọn sau kiểm tra tiếp theo/hết hạn. Nếu Chrome tạm ngưng worker, việc đóng tab trống có thể chậm đến khi worker chạy lại; không cam kết dọn đúng giây khi trình duyệt bị treo. Không giành focus, không dùng tab riêng người dùng đang mở.
- Đọc ảnh từ panel vào RAM song song lúc tải trang; vẫn đợi trang tải hoàn tất, kiểm tra hủy/đổi trang trước khi gửi. Khối truyền tăng từ 384 KiB lên 1.5 MiB (2 MiB base64), giảm số lượt truyền với ảnh lớn. PNG giữ nguyên kích thước và chất lượng, không nén lại.
- Dòng thời gian kết quả tính đến khi Photoshop xác nhận đã thêm layer; thời gian chờ web, kiểm tra PNG và nhập Photoshop được đo riêng trong RAM, không lưu log ảnh/lịch sử.
- Không thay mô hình tách nền, không rút ngắn bảo vệ decode 750 ms và không thay quyền extension. Mức nhanh hơn phụ thuộc trang đã kịp tải trong lúc chọn ảnh, kích thước ảnh và tốc độ dịch vụ. Không bảo đảm mọi ảnh đạt 3–5 giây.
- Cần cập nhật cả panel và **Reload extension** để có chuẩn bị trang sớm. Nếu chưa cập nhật cả hai, luồng cũ vẫn chạy nhưng không có lợi ích chuẩn bị trang.

## Thay đổi 1.0.4 — giảm thời gian chờ nội bộ

- PNG đã được broker kiểm tra đầy đủ sẽ được đưa thẳng vào Photoshop; không chờ thêm một lượt giải mã ảnh xem trước. Preview và nhập layer dùng cùng nguyên bản PNG, không nén lại hoặc giảm kích thước.
- Tối ưu vòng lặp kiểm tra PNG, giữ kiểm tra checksum, mọi scanline, kích thước và nền trong suốt. Các chỉ số bảng màu vẫn được kiểm tra đầy đủ, kể cả sau khi đã tìm thấy vùng trong suốt.
- Extension kiểm tra trạng thái phiên và tab song song, dùng lại kết quả kiểm tra tab khi đợi trang tải. Vẫn kiểm tra hủy phiên/đổi trang trước khi gửi ảnh và nhận PNG.
- Giảm khoảng nghỉ bình thường giữa hai lượt nhận việc từ 500 xuống 50 ms; giữ nguyên thời gian chờ lại khi có lỗi. Không giữ tab cũ hay ảnh cũ để tăng tốc, không đổi cơ chế chạy nền hoặc thời gian bảo vệ decode.
- Đây là giảm chi phí nội bộ, **không phải cam kết Photoroom xử lý mọi ảnh trong 3–5 giây**. Ở bản 1.0.4, thời gian panel hiển thị được tính đến khi broker nhận PNG, chưa gồm thời gian Photoshop thêm layer; bản 1.0.5 đã đo đến khi Photoshop xác nhận.

## Thay đổi 1.0.3 — tự thêm ảnh vào Photoshop

- Khi nhận PNG thành công, panel tự thêm một layer ảnh mới vào tài liệu Photoshop đang active tại thời điểm nhập kết quả. Ảnh được căn giữa canvas, không tự đổi kích thước ảnh hay ghi đè layer cũ.
- Nếu không có tài liệu nào mở, tạo một tài liệu Photoshop mới chưa lưu từ PNG. Panel này chạy bên trong Photoshop; đây là trường hợp không có **tài liệu** mở, không phải khởi chạy một Photoshop đang tắt.
- Không tự lưu PSD, không ghi đè ảnh nguồn, không dùng Clipboard để nhập layer và không liên kết layer với file tạm. File PNG chuyển tạm được dọn sau khi Photoshop xác nhận đã nhận ảnh.
- Nếu nhập layer thất bại, PNG vẫn còn ở panel: bấm **Thêm vào Photoshop** để thử lại, không cần gửi ảnh lên Photoroom lần nữa. Nút này cũng cho phép chủ động thêm kết quả lần nữa vào tài liệu bạn chọn.
- Chrome giữ cơ chế chạy nền của 1.0.2; không đổi mã ghép hay tăng quyền extension. Đóng Photoshop trước khi cài bản cập nhật panel.

## Thay đổi 1.0.2

- Thêm lớp tương thích tạm thời cho `HTMLImageElement.decode()` trong tab Photoroom ẩn do chính companion tạo. Khi native decode chưa hoàn tất, chỉ ảnh raster cục bộ đã tải đủ, chưa gắn vào trang mới có thể được kiểm tra bằng canvas 1 pixel để tiếp tục. Không giả trạng thái visibility, không chọn tab hay đưa Chrome lên trước.
- Lớp tương thích chỉ áp dụng ở trang remover công khai, không áp dụng iframe/CAPTCHA hoặc tab có sẵn của người dùng. Nó được hoàn tác khi kết thúc, hủy hoặc hết hạn; không tải ảnh lên một API khác.
- Ngày 2026-09-09 đã kiểm tra Chrome/Photoshop thật với ảnh cốc mẫu 512 × 512: hai lần panel báo 8 giây và 5 giây. Lần thứ hai do agent bấm chạy, Photoshop ở phía trước và không chọn tab Chrome; PNG trong suốt tự trở về. Đây không phải bảo đảm mọi ảnh/máy đều mất 5 giây.
- Không đổi 6 file CEP so với bản 1.0.1 đã cài. Chỉ extension có thay đổi chức năng; mã ghép và các tính năng khác được giữ nguyên.

## Thay đổi 1.0.1

- Thu gọn panel: chỉ giữ trạng thái kết nối và các nút xử lý ảnh, bỏ ghi chú dài/ô mã/checkbox.
- Nhận PNG từ đúng ảnh kết quả được gắn nhãn, không chờ `img.complete`/`naturalWidth` của ảnh chưa hiển thị trong tab ẩn. Broker vẫn giải mã và kiểm tra PNG/alpha trước khi trả ảnh về Photoshop.
- Tắt tự động discard chỉ cho tab tạm của phiên. Không chọn tab, đưa cửa sổ Chrome lên trước, đổi browser flags hoặc giả trạng thái visibility. Vì vậy không giành focus khi bạn làm Photoshop.
- Đã có kiểm thử mô phỏng tab ẩn với ảnh chưa decode. Cần kiểm thử lại trên Chrome thật; nếu chính website ngừng xử lý khi bị ẩn (khác việc nhận ảnh), báo lại để xác định, không coi bản này là cam kết mọi phiên Chrome đều chạy nền.

## Cơ chế và giới hạn

- Extension thao tác ô tải ảnh của `https://www.photoroom.com/tools/background-remover` và lấy PNG kết quả mà trang đã hiển thị. Không gọi API riêng, không đọc cookie/token Photoroom, không dùng API key, không vượt CAPTCHA, đăng nhập, giới hạn tải hay paywall.
- PNG/JPG/WebP; tối đa 60 MB và 40 megapixel ở panel. Kết quả là độ phân giải web thực sự trả về, không tự phóng lớn hay hứa luôn bằng ảnh gốc.
- Không tự bấm lưu design vào tài khoản, mua gói hoặc xuất độ phân giải bị khóa. Nếu web yêu cầu thao tác thủ công, panel báo lỗi có hướng dẫn. Tài khoản/gói sử dụng phải phù hợp mục đích thương mại của bạn; xem điều khoản Photoroom.
- 3–5 giây **không được bảo đảm**: tổng thời gian gồm mở trang, tải ảnh, Photoroom xử lý và chuyển PNG về máy. Mạng, kích thước ảnh, Chrome và giới hạn dịch vụ ảnh hưởng tốc độ. Web đổi giao diện có thể cần cập nhật adapter.
- Bộ điều khiển được kiểm thử tự động bằng mô phỏng Chrome và DOM tương ứng giao diện hiện tại; 1.0.2 cũng đã có phép thử nền thực tế nêu trên. Flow tự thêm layer mới của 1.0.3 cần kiểm tra sau khi cài trên máy sử dụng; đừng coi unit test là benchmark Photoroom.

## Không lưu lịch sử ảnh của flow mới

- Ảnh nguồn người dùng chọn không bị sửa/xóa. Ảnh đang chọn, ảnh kết quả và hàng đợi chỉ nằm trong RAM. Đổi ảnh, Clear hoặc đóng panel sẽ bỏ chúng; không khôi phục phiên ảnh cũ.
- Clipboard/Photoshop có thể cần PNG tạm để chuyển dữ liệu. Panel chỉ xóa file tạm của chính flow sau khi đọc hoặc Photoshop xác nhận nhận xong. File **Save PNG** bạn chủ động chọn lưu là kết quả được giữ lại.
- Nếu Photoshop/Windows bị tắt đột ngột, PNG chuyển tạm có thể còn sót. Lần mở panel sau chỉ dọn folder có đúng dấu sở hữu của flow và xác nhận tiến trình cũ đã thoát; không xóa file của một phiên còn chạy hoặc không rõ chủ. Đây không phải cam kết xóa an toàn tức thì khi máy bị crash.
- Extension không dùng Downloads, IndexedDB, localStorage hoặc `chrome.storage` để lưu ảnh. Chỉ mã ghép được giữ trong `chrome.storage.local`; `storage.session` chỉ ghi ID tab/phiên để dọn tab khi service worker khởi động lại.
- Photoroom và Chrome có cơ chế lưu dữ liệu/cache riêng. Companion không thể bảo đảm xóa dữ liệu phía Photoroom hoặc mọi cache trình duyệt; cũng không xóa cookie, lịch sử web hay dữ liệu site của người dùng.
- Các ảnh/cache BiRefNet cũ không thuộc flow này và không tự bị xóa. Model BiRefNet còn trên ổ nhưng không được nạp/chạy bởi tab mới.

## Khắc phục

- Chưa kết nối: mở tab Photoroom trong Photoshop, bật extension đúng profile Chrome, kiểm tra lại mã ghép. Chỉ ghép một profile trên một máy để tránh tranh phiên ảnh.
- Cổng 8766 bận: đóng bản panel UOY trùng đang chạy; không tắt firewall hay thay DNS chỉ để ghép.
- CAPTCHA/đăng nhập/giới hạn: mở Photoroom thủ công và xử lý bằng tài khoản của bạn, sau đó chạy lại từ panel. Không tự gửi lại ảnh lỗi nhiều lần.
- Không tìm thấy PNG/giao diện thay đổi: lưu ảnh gốc, báo lỗi để cập nhật adapter; không sử dụng ảnh nguồn làm kết quả giả.
- Không Reload/tắt extension trong lúc xử lý. Nếu lỡ làm, hãy đóng thủ công tab Photoroom do phiên vừa tạo và chạy lại; Chrome xóa dữ liệu `storage.session` khi reload extension nên companion không còn ID tab cũ để tự dọn. Không tự quét và đóng các tab Photoroom khác của bạn.

Nguồn: [Photoroom Background Remover](https://www.photoroom.com/tools/background-remover), [Terms](https://www.photoroom.com/legal/terms-and-conditions), [Privacy](https://www.photoroom.com/legal/privacy).
