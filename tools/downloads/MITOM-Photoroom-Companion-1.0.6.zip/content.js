/* DOM-only adapter for the public background-remover tool. No private APIs,
 * cookies, page application internals, synthetic downloads or old-image cache. */
(function () {
  "use strict";
  if (globalThis.__uoyPhotoroomContent) return;
  globalThis.__uoyPhotoroomContent = true;
  const C = UOYPhotoroomCore;
  let state = null;
  const visible = e => !!e && e.getClientRects().length > 0;
  const name = e => String(e.getAttribute("aria-label") || e.textContent || "").trim();
  function clean() {
    if (state) { state.cancelled = true; for (const part of state.parts) part.fill(0); state.parts.length = 0; state.result = ""; }
    state = null;
    const input = document.querySelector('input[type="file"]'); if (input) input.value = "";
  }
  function ensure(id) {
    if (!C.validPage(location.href) || !state || state.id !== id || state.cancelled) throw new Error("Phiên Photoroom đã hủy hoặc trang đã thay đổi.");
    return state;
  }
  function blocker() {
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"],dialog,[role="alert"]')).filter(visible).map(name).join(" ");
    if (/captcha|verify.*human|xác minh|verification|security check/i.test(dialogs) || Array.from(document.querySelectorAll('iframe[src*="captcha"],iframe[title*="challenge"]')).some(visible)) return "Photoroom yêu cầu xác minh. Mở web và xử lý thủ công rồi thử lại; companion không vượt CAPTCHA.";
    if (/sign in|log in|sign up|đăng nhập|đăng ký|upgrade|subscribe|payment|nâng cấp|limit reached|too many|daily limit/i.test(dialogs)) return "Photoroom yêu cầu đăng nhập hoặc kiểm tra giới hạn/gói. Mở web xử lý thủ công rồi thử lại.";
    const alerts = Array.from(document.querySelectorAll('[role="alert"]')).filter(visible).map(name).join(" ");
    if (/error|failed|try again|lỗi|không thể/i.test(alerts)) return "Photoroom báo xử lý thất bại. Hãy kiểm tra ảnh hoặc mở web thử lại.";
    return "";
  }
  function displayedResult() {
    // These exact image labels and PNG data URLs were observed on the public
    // tool on 2026-09-09. Any incompatible redesign fails instead of guessing.
    const ready = Array.from(document.querySelectorAll("button")).some(e => visible(e) && !e.disabled && /^(Download|Tải xuống)$/i.test(name(e)));
    if (!ready) return null;
    // Hidden tabs can defer image decoding/painting. The result's PNG bytes
    // can already exist in src while complete=false and naturalWidth=0. Never
    // wait for a foreground paint: the local broker validates decoded PNG/alpha.
    const images = Array.from(document.querySelectorAll('img[alt="Image with background removed"]'));
    if (!images.length) return null;
    const urls = [...new Set(images.map(e => (typeof e.getAttribute === "function" && e.getAttribute("src")) || e.src || e.currentSrc).filter(Boolean))];
    if (!urls.length) return null;
    if (urls.length !== 1) throw new Error("Web có nhiều ảnh kết quả khác nhau; dừng để tránh nhận nhầm ảnh.");
    return C.pngData(urls[0]);
  }
  async function processImage(id) {
    const s = ensure(id);
    if (s.processing || s.received !== s.size) throw new Error("Ảnh truyền chưa đủ hoặc phiên đang xử lý.");
    s.processing = true;
    const inputs = Array.from(document.querySelectorAll('input[type="file"]')).filter(e => /image\//.test(e.accept));
    if (inputs.length !== 1 || document.querySelector('img[alt="Image with background removed"]')) throw new Error("Giao diện Photoroom không khớp hoặc còn ảnh cũ. Không gửi ảnh vào trang này.");
    const blocked = blocker(); if (blocked) throw new Error(blocked);
    const file = new File(s.parts, "uoy-input." + (s.mime === "image/jpeg" ? "jpg" : s.mime === "image/webp" ? "webp" : "png"), {type:s.mime});
    for (const part of s.parts) part.fill(0); s.parts.length = 0;
    const transfer = new DataTransfer(); transfer.items.add(file);
    ensure(id); inputs[0].files = transfer.files;
    inputs[0].dispatchEvent(new Event("change", {bubbles:true}));
    const deadline = Date.now() + 105000;
    while (Date.now() < deadline) {
      ensure(id);
      const problem = blocker(); if (problem) throw new Error(problem);
      const result = displayedResult();
      if (result) { s.result = result; inputs[0].value = ""; return {ready:true, length:result.length}; }
      await new Promise(resolve => { const observer = new MutationObserver(done); const timer = setTimeout(done, 500); function done() { clearTimeout(timer); observer.disconnect(); resolve(); } observer.observe(document.documentElement, {childList:true, subtree:true, attributes:true, attributeFilter:["src","disabled"]}); });
    }
    throw new Error("Photoroom chưa trả kết quả sau 105 giây. Kiểm tra mạng, đăng nhập hoặc giới hạn của web.");
  }
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (sender.id !== chrome.runtime.id || !C.validPage(location.href)) return false;
    (async () => {
      if (msg.type === "prepare") {
        if (state) throw new Error("Trang đang có một phiên xử lý.");
        if (!C.validJob(msg) || !Number.isInteger(msg.size) || msg.size < 1 || msg.size > C.LIMIT) throw new Error("Thông tin ảnh không hợp lệ.");
        state = {id:msg.id, mime:msg.mime, size:msg.size, parts:[], received:0, result:"", processing:false}; return {ok:true};
      }
      const s = ensure(msg.id);
      if (msg.type === "stage") {
        // Read-only progress must not clear a completed result if a late page
        // alert appears. processImage owns all blocker/error enforcement.
        return {stage:s.result || document.querySelector('img[alt="Image with background removed"]') ? "result" : document.querySelector('img[alt="Original image"]') ? "processing" : "reading-input"};
      }
      if (msg.type === "chunk") {
        if (s.processing || msg.index !== s.parts.length || typeof msg.data !== "string" || msg.data.length > C.CHUNK * 4 / 3) throw new Error("Khối ảnh không đúng phiên/thứ tự.");
        const bytes = C.unbase64(msg.data); if (!bytes.length || s.received + bytes.length > s.size) { bytes.fill(0); throw new Error("Khối ảnh vượt kích thước."); }
        s.parts.push(bytes); s.received += bytes.length; return {ok:true};
      }
      if (msg.type === "process") return await processImage(msg.id);
      if (msg.type === "result-chunk") {
        if (!s.result || !Number.isInteger(msg.offset) || msg.offset < 0 || msg.offset % (C.CHUNK * 4 / 3)) throw new Error("Khối kết quả không hợp lệ.");
        return {data:s.result.slice(msg.offset, msg.offset + C.CHUNK * 4 / 3)};
      }
      if (msg.type === "clear") { clean(); return {ok:true}; }
      throw new Error("Lệnh không hỗ trợ.");
    })().then(reply, error => { if (msg.type !== "stage") clean(); reply({error:String(error.message || error).slice(0,400)}); });
    return true;
  });
  addEventListener("pagehide", clean, {once:true});
})();
