/* Temporary MAIN-world compatibility for native image.decode() in a never-shown
 * Chrome tab. The public Photoroom upload code awaits detached image decodes;
 * some Chromium compositor paths leave those promises queued until first paint.
 * No visibility spoofing, frame/CAPTCHA changes, endpoint calls or focus changes.
 * Native decode wins normally. The fallback checks only a loaded local raster
 * through a 1px software canvas. A blob: header read stays inside browser RAM;
 * its response body is immediately cancelled, never consumed or retained.
 */
(function (root) {
  "use strict";
  const KEY = "__uoyPhotoroomDecodeCompat";
  const ORIGIN = "https://www.photoroom.com";
  const MAX_PIXELS = 40000000, MAX_DATA_URL = 83886120;
  const FALLBACK_AFTER = 750, POLL_MS = 250, DECODE_LIMIT = 12000, LIFETIME = 120000;
  const raster = /^image\/(png|jpeg|webp|avif)$/i;
  function validPage() {
    try {
      const url = new URL(root.location.href);
      return root === root.top && root === root.self && root === root.window &&
        url.origin === ORIGIN && !url.username && !url.password &&
        url.pathname.replace(/\/$/, "") === "/tools/background-remover";
    } catch (_) { return false; }
  }
  if (!validPage() || Object.prototype.hasOwnProperty.call(root, KEY)) return;
  const prototype = root.HTMLImageElement && root.HTMLImageElement.prototype;
  const original = prototype && Object.getOwnPropertyDescriptor(prototype, "decode");
  if (!original || typeof original.value !== "function" || !original.configurable) return;
  const nativeDecode = original.value;
  const pending = new Set();
  const totals = {calls:0, eligible:0, nativeResolved:0, nativeRejected:0, fallbacks:0,
    fallbackErrors:0, cancelled:0, timedOut:0};
  let active = true, expiry = null;
  function encodingError() { return new DOMException("The source image cannot be decoded.", "EncodingError"); }
  function abortError() { return new DOMException("Image decode compatibility session ended.", "AbortError"); }
  function localSource(image) {
    if (!(image instanceof root.HTMLImageElement) || image.ownerDocument !== root.document || image.isConnected) return null;
    const src = image.src;
    if (typeof src !== "string" || !src || (image.currentSrc && image.currentSrc !== src)) return null;
    if (/^data:/i.test(src)) {
      if (src.length > MAX_DATA_URL || !/^data:image\/(png|jpeg|webp|avif);base64,[a-z0-9+/]+={0,2}$/i.test(src)) return null;
      return {src, kind:"data"};
    }
    if (!src.startsWith("blob:" + ORIGIN + "/")) return null;
    try { if (new URL(src).origin !== ORIGIN) return null; } catch (_) { return null; }
    return {src, kind:"blob"};
  }
  function unchanged(record) {
    const image = record.image;
    return active && validPage() && image && image.ownerDocument === root.document &&
      !image.isConnected && image.src === record.src && (!image.currentSrc || image.currentSrc === record.src);
  }
  function release(record) {
    clearTimeout(record.timer);
    clearTimeout(record.expiryTimer);
    if (record.control) record.control.abort();
    record.control = null; record.image = null; record.src = "";
    pending.delete(record);
  }
  function settle(record, error, kind) {
    if (record.done) return;
    record.done = true;
    if (kind) totals[kind]++;
    release(record);
    if (error) record.reject(error); else record.resolve();
  }
  async function allowedBlob(record) {
    // Never follow a URL supplied by page data onto the network. The URL was
    // checked twice before this call and must remain an origin-local blob URL.
    if (record.kind !== "blob") return true;
    const control = new AbortController(); record.control = control;
    let response = null;
    try {
      response = await root.fetch(record.src, {signal:control.signal, credentials:"omit", cache:"no-store", redirect:"error"});
      return response.ok && raster.test(String(response.headers.get("Content-Type") || "").split(";",1)[0].trim());
    } finally {
      if (response && response.body) await response.body.cancel().catch(() => {});
      control.abort();
      if (record.control === control) record.control = null;
    }
  }
  function verifyPixels(image) {
    const canvas = root.document.createElement("canvas");
    canvas.width = canvas.height = 1;
    let pixels = null;
    try {
      const context = canvas.getContext("2d", {willReadFrequently:true});
      if (!context) throw encodingError();
      context.drawImage(image, 0, 0, 1, 1);
      pixels = context.getImageData(0, 0, 1, 1).data;
      if (!pixels || pixels.length !== 4) throw encodingError();
    } finally {
      if (pixels && typeof pixels.fill === "function") pixels.fill(0);
      canvas.width = canvas.height = 0;
    }
  }
  async function fallback(record) {
    if (record.done) return;
    if (!unchanged(record)) return settle(record, encodingError(), "fallbackErrors");
    if (Date.now() >= record.deadline) return settle(record, encodingError(), "timedOut");
    const image = record.image;
    if (!root.document.hidden || !image.complete) {
      record.timer = setTimeout(() => fallback(record), POLL_MS); return;
    }
    const width = image.naturalWidth, height = image.naturalHeight;
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width * height > MAX_PIXELS)
      return settle(record, encodingError(), "fallbackErrors");
    try {
      if (!await allowedBlob(record)) return settle(record, encodingError(), "fallbackErrors");
      if (record.done) return;
      if (!unchanged(record)) return settle(record, encodingError(), "fallbackErrors");
      // Visibility can change while reading local blob metadata. In that case
      // leave the native decoder alone, rather than force a canvas fallback.
      if (!root.document.hidden) { record.timer = setTimeout(() => fallback(record), POLL_MS); return; }
      verifyPixels(image);
      settle(record, null, "fallbacks");
    } catch (_) {
      // No URL or raw browser exception is reported to the panel or diagnostic.
      if (!record.done) settle(record, encodingError(), "fallbackErrors");
    }
  }
  function decode() {
    totals.calls++;
    // Invoke the native method first, including its receiver validation and
    // exact error behavior. Ineligible/visible calls retain the native promise.
    const result = Reflect.apply(nativeDecode, this, arguments);
    if (!active || !validPage() || !root.document.hidden) return result;
    let source;
    try { source = localSource(this); } catch (_) { return result; }
    if (!source || !result || typeof result.then !== "function") return result;
    totals.eligible++;
    return new Promise((resolve, reject) => {
      const record = {image:this, src:source.src, kind:source.kind, resolve, reject,
        done:false, control:null, timer:null, expiryTimer:null, deadline:Date.now() + DECODE_LIMIT};
      pending.add(record);
      result.then(() => settle(record, null, "nativeResolved"), error => settle(record, error, "nativeRejected"));
      record.timer = setTimeout(() => fallback(record), FALLBACK_AFTER);
      record.expiryTimer = setTimeout(() => settle(record, encodingError(), "timedOut"), DECODE_LIMIT);
    });
  }
  function restore() {
    if (!active) return;
    active = false; clearTimeout(expiry);
    root.removeEventListener("pagehide", restore);
    for (const record of Array.from(pending)) settle(record, abortError(), "cancelled");
    // Preserve another script's later patch; never blindly overwrite it.
    const current = Object.getOwnPropertyDescriptor(prototype, "decode");
    if (current && current.value === decode) Object.defineProperty(prototype, "decode", original);
  }
  const api = Object.freeze({version:1, restore, stats:() => Object.freeze({...totals, active, pending:pending.size})});
  Object.defineProperty(prototype, "decode", {...original, value:decode});
  Object.defineProperty(root, KEY, {value:api, configurable:true, enumerable:false, writable:false});
  root.addEventListener("pagehide", restore, {once:true});
  expiry = setTimeout(restore, LIFETIME);
})(globalThis);
