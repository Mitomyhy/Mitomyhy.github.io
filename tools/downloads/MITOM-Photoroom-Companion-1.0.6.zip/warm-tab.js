(function (root) {
  "use strict";
  const URL = "https://www.photoroom.com/tools/background-remover";
  const validId = value => typeof value === "string" && /^[A-Za-z0-9_-]{16,128}$/.test(value);
  function createWarmTabs(options) {
    const chrome = options && options.chrome;
    if (!chrome || typeof options.isLive !== "function") throw new TypeError("Warm tabs require Chrome and an authenticated liveness check.");
    const now = options.now || Date.now;
    const later = options.setTimeout || setTimeout, cancelTimer = options.clearTimeout || clearTimeout;
    const maxAge = Math.min(60000, Math.max(1, Number(options.maxAge) || 60000));
    const validPage = options.validPage || (value => {
      try { const u = new root.URL(value); return u.origin === "https://www.photoroom.com" && u.pathname.replace(/\/$/, "") === "/tools/background-remover"; } catch (_) { return false; }
    });
    const scoped = options.scopedTab || (tab => !!tab && (!tab.pendingUrl || validPage(tab.pendingUrl)) && (validPage(tab.url) || ((!tab.url || tab.url === "about:blank") && validPage(tab.pendingUrl))));
    let current = null, disposed = false, recovery = null, cleanupBlocked = false, storageQueue = Promise.resolve();
    function storageTask(task) {
      const result = storageQueue.then(task);
      storageQueue = result.catch(() => {});
      return result;
    }
    function usable(record) { return current === record && !record.retired && !record.taken && !disposed && now() < record.expires; }
    function stopTimers(record) { cancelTimer(record.ttl); cancelTimer(record.monitor); record.ttl = record.monitor = null; }
    async function forget(record) {
      if (!Number.isInteger(record.tabId)) return true;
      return storageTask(async () => {
        const value = (await chrome.storage.session.get("warmTab")).warmTab;
        if (value && value.id === record.id && value.tabId === record.tabId) await chrome.storage.session.remove("warmTab");
        return true;
      }).catch(() => false);
    }
    async function closeScoped(record) {
      if (!Number.isInteger(record.tabId) || record.tabId < 0 || record.taken) return true;
      try {
        const tab = await chrome.tabs.get(record.tabId);
        // The controller only closes its created/recovered exact id, and only
        // while both the committed and pending navigation remain in scope.
        if (tab && tab.id === record.tabId && scoped(tab) && !record.taken) await chrome.tabs.remove(record.tabId);
        return true;
      } catch (error) { return /No tab with id|Invalid tab ID|Tab not found/i.test(String(error && error.message || error)); }
    }
    function retire(record) {
      if (!record || record.taken) return Promise.resolve(true);
      record.retired = true; stopTimers(record);
      if (current === record) current = null;
      if (!record.cleanup) record.cleanup = (async () => {
        if (record.previousCleanup && !(await record.previousCleanup)) return false;
        // A create already issued can resolve after cancellation. Await that
        // specific promise, never scan or remove other Photoroom/user tabs.
        if (record.creation) {
          try { const tab = await record.creation; if (tab && Number.isInteger(tab.id)) record.tabId = tab.id; } catch (_) {}
        }
        if (!(await closeScoped(record))) {
          cleanupBlocked = true;
          // A Chrome API failure must not erase the only restart-cleanup hint.
          if (Number.isInteger(record.tabId)) await storageTask(() => chrome.storage.session.set({warmTab:{id:record.id,tabId:record.tabId}})).catch(() => {});
          return false;
        }
        await forget(record);
        return true;
      })();
      return record.cleanup;
    }
    function recover() {
      if (!recovery) recovery = (async () => {
        let stored;
        try { stored = (await chrome.storage.session.get("warmTab")).warmTab; } catch (_) { cleanupBlocked = true; return false; }
        if (!stored) return true;
        if (validId(stored.id) && Number.isInteger(stored.tabId) && stored.tabId >= 0) {
          const record = {id:stored.id,tabId:stored.tabId};
          if (!(await closeScoped(record))) { cleanupBlocked = true; return false; }
          await forget(record);
        } else {
          // Invalid metadata is not authority to close any browser tab.
          await storageTask(() => chrome.storage.session.remove("warmTab")).catch(() => {});
        }
        return true;
      })();
      return recovery;
    }
    async function live(record) {
      try { return !!(await options.isLive(record.id)); } catch (_) { return false; }
    }
    function monitor(record) {
      record.monitor = later(() => {
        if (!usable(record)) { retire(record); return; }
        monitor(record);
        if (record.checking) return;
        record.checking = true;
        (async () => {
          try {
            const values = await Promise.all([live(record), Number.isInteger(record.tabId) ? chrome.tabs.get(record.tabId).catch(() => null) : Promise.resolve(null)]);
            if (!usable(record) || !values[0] || (Number.isInteger(record.tabId) && (!values[1] || values[1].id !== record.tabId || !scoped(values[1])))) await retire(record);
          } finally { record.checking = false; }
        })().catch(() => { retire(record); });
      }, 2000);
    }
    async function prepare(spec) {
      if (disposed || cleanupBlocked) return null;
      if (!spec || !validId(spec.id)) { await clear(); return null; }
      if (current && current.id === spec.id && usable(current)) return current.work;
      const previous = current;
      const record = {id:spec.id,tabId:null,expires:now()+maxAge,retired:false,taken:false,claiming:false,creation:null,cleanup:null,ttl:null,monitor:null,checking:false};
      current = record;
      const previousCleanup = retire(previous);
      record.previousCleanup = previousCleanup;
      record.ttl = later(() => { retire(record); }, maxAge);
      monitor(record);
      record.work = (async () => {
        try {
          if (!(await recover()) || !(await previousCleanup) || cleanupBlocked) { await retire(record); return null; }
          if (!usable(record) || !(await live(record)) || !usable(record)) { await retire(record); return null; }
          record.creation = Promise.resolve(chrome.tabs.create({url:URL,active:false}));
          const tab = await record.creation;
          if (!tab || !Number.isInteger(tab.id) || tab.id < 0) throw new Error("No owned warm tab.");
          record.tabId = tab.id;
          if (!usable(record) || !scoped(tab) || !(await live(record)) || !usable(record)) { await retire(record); return null; }
          const saved = await storageTask(async () => {
            if (!usable(record)) return false;
            await chrome.storage.session.set({warmTab:{id:record.id,tabId:record.tabId}});
            return true;
          });
          if (!saved || !usable(record)) { await retire(record); return null; }
          return tab;
        } catch (_) { await retire(record); return null; }
      })();
      return record.work;
    }
    async function take(id, adopt) {
      const record = current;
      if (!record || record.id !== id || !validId(id)) { await clear(); return null; }
      if (record.claiming) return null;
      record.claiming = true;
      try {
        const created = await record.work;
        if (!created || !usable(record)) { await retire(record); return null; }
        const values = await Promise.all([live(record),chrome.tabs.get(record.tabId).catch(() => null)]);
        if (!usable(record) || !values[0] || !values[1] || values[1].id !== record.tabId || !scoped(values[1])) { await retire(record); return null; }
        // Persist the next owner's metadata before forgetting warm ownership,
        // so a worker restart cannot strand a tab in a handoff crash gap.
        if (adopt) {
          await adopt(values[1]);
          const adopted = await Promise.all([live(record),chrome.tabs.get(record.tabId).catch(() => null)]);
          if (!usable(record) || !adopted[0] || !adopted[1] || adopted[1].id !== record.tabId || !scoped(adopted[1])) { await retire(record); return null; }
          values[1] = adopted[1];
        }
        if (!usable(record)) { await retire(record); return null; }
        if (!(await forget(record)) || !usable(record)) { await retire(record); return null; }
        record.taken = true; current = null; stopTimers(record);
        return values[1];
      } catch (_) { await retire(record); return null; }
    }
    async function clear() {
      const previous = current;
      current = null;
      await Promise.all([recover(),retire(previous)]);
    }
    async function dispose() { disposed = true; await clear(); }
    return {prepare,take,clear,recover,dispose};
  }
  const api = {createWarmTabs};
  if (typeof module === "object" && module.exports) module.exports = api;
  root.UOYPhotoroomWarm = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
