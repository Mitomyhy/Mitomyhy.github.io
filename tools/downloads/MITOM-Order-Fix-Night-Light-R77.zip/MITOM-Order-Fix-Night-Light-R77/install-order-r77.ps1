#requires -Version 5.1
[CmdletBinding()]
param([string]$PanelRoot='', [switch]$CheckOnly, [string]$Rollback='', [switch]$CompleteKnownMixed, [switch]$LibraryOnly)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$script:R77Revision='20261029-R77'
$script:R77Activation='20261029-R77-known-mixed-v1'
# Sealed by the builder after the two candidates are explicitly approved.
$script:R77ManifestSha='9ae831b16333ca1c32214da8ca1fdcff11b620e2964d06b652895b3698b9a08c'
$script:R77Utf8=New-Object Text.UTF8Encoding($false,$true)
function Get-R77Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Get-R77BytesHash([byte[]]$Bytes){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Assert-R77Plain([string]$Path,[string]$Kind='Any'){
    if(-not [IO.Path]::IsPathRooted($Path) -or $Path.StartsWith('\\')){throw 'A local absolute path is required.'}
    $full=[IO.Path]::GetFullPath($Path);$cursor=$full
    while($cursor){
        if(Test-Path -LiteralPath $cursor){if((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw ('Linked path refused: '+$cursor)}}
        $parent=[IO.Path]::GetDirectoryName($cursor);if($parent -eq $cursor){break};$cursor=$parent
    }
    if($Kind -eq 'File' -and -not(Test-Path -LiteralPath $full -PathType Leaf)){throw ('Missing file: '+$full)}
    if($Kind -eq 'Directory' -and -not(Test-Path -LiteralPath $full -PathType Container)){throw ('Missing directory: '+$full)}
    return $full
}
function Assert-R77AppsClosed {
    $busy=@(Get-Process -ErrorAction Stop|Where-Object {$_.ProcessName -match '^(Photoshop|OrderStudio|UOY[-_ ]?OrderStudio|MITOM[-_ ]?OrderStudio)$'})
    if($busy.Count){throw 'Save work and close Photoshop and OrderStudio yourself before Update or Rollback. No application was stopped.'}
}
function New-R77PrivateDirectory([string]$Path){
    [void](Assert-R77Plain $Path)
    $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
    if(Test-Path -LiteralPath $Path){
        [void](Assert-R77Plain $Path 'Directory');$acl=Get-Acl -LiteralPath $Path
        if(-not $acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin @($sid.Value,'S-1-5-32-544')){throw 'Backup directory ownership/protection differs.'}
        foreach($r in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])){if($r.AccessControlType -eq 'Allow' -and $r.IdentityReference.Value -notin @($sid.Value,'S-1-5-18')){throw 'Backup directory grants another principal access.'}}
        return
    }
    [void][IO.Directory]::CreateDirectory($Path)
    $acl=New-Object Security.AccessControl.DirectorySecurity;$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
    foreach($id in @($sid,(New-Object Security.Principal.SecurityIdentifier('S-1-5-18')))){$acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($id,'FullControl','ContainerInherit,ObjectInherit','None','Allow')))}
    Set-Acl -LiteralPath $Path -AclObject $acl
}
function Read-R77Json([string]$Path){$text=$script:R77Utf8.GetString([IO.File]::ReadAllBytes((Assert-R77Plain $Path 'File'))).TrimStart([char]0xFEFF);return ($text|ConvertFrom-Json)}
function Write-R77Json([string]$Path,$Value){[IO.File]::WriteAllText($Path,($Value|ConvertTo-Json -Depth 15),$script:R77Utf8)}
function Get-R77Manifest([string]$PackageRoot){
    if($script:R77ManifestSha -cnotmatch '^[0-9a-f]{64}$'){throw 'Unsealed R77 installer.'}
    $file=Assert-R77Plain (Join-Path (Assert-R77Plain $PackageRoot 'Directory') 'patch-manifest.json') 'File'
    if((Get-R77Hash $file) -cne $script:R77ManifestSha){throw 'Sealed manifest hash differs.'}
    $m=Read-R77Json $file
    if($m.schema -ne 1 -or $m.revision -cne $script:R77Revision -or @($m.files).Count -ne 2){throw 'R77 package identity differs.'}
    if((@($m.files.id|Sort-Object)-join ',') -cne 'panel-main,uploader'){throw 'Only the two reviewed code roles are allowed.'}
    foreach($row in $m.files){
        if(@($row.variants).Count -lt 1 -or @($row.variants).Count -gt 2){throw 'Invalid code variant count.'}
        foreach($v in $row.variants){
            if($v.before_sha256 -cnotmatch '^[0-9a-f]{64}$' -or $v.sha256 -cnotmatch '^[0-9a-f]{64}$' -or $v.before_size -lt 1 -or $v.before_size -gt 2097152 -or $v.size -lt 1 -or $v.size -gt 2097152 -or @($v.hunks).Count -gt 200){throw 'Invalid pinned patch variant.'}
        }
    }
    return $m
}
function Get-R77Targets([string]$RequestedRoot){
    if(-not $RequestedRoot){if(-not $env:APPDATA){throw 'APPDATA is unavailable.'};$RequestedRoot=Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.uoy.orderpanel'}
    $panel=Assert-R77Plain $RequestedRoot 'Directory'
    if([IO.Path]::GetFileName($panel.TrimEnd('\')) -cne 'com.uoy.orderpanel'){throw 'Target must be the existing com.uoy.orderpanel directory.'}
    $cfgPath=Assert-R77Plain (Join-Path $panel 'local-config.json') 'File';$cfgHash=Get-R77Hash $cfgPath
    $cfg=Read-R77Json $cfgPath
    if((Get-R77Hash $cfgPath) -cne $cfgHash){throw 'Configuration changed while resolving upload paths.'}
    $tool='';if($cfg.PSObject.Properties.Name -contains 'uploadToolDir'){$tool=[string]$cfg.uploadToolDir}
    if(-not $tool){if(-not $env:LOCALAPPDATA){throw 'LOCALAPPDATA is unavailable.'};$tool=Join-Path $env:LOCALAPPDATA 'UOY\Upload He Thong'}
    $targets=@([pscustomobject]@{id='panel-main';role='panel-main';path=(Assert-R77Plain (Join-Path $panel 'js\main.js') 'File')},[pscustomobject]@{id='configured-uploader';role='uploader';path=(Assert-R77Plain (Join-Path (Assert-R77Plain $tool 'Directory') 'upload_he_thong.py') 'File')})
    if($env:LOCALAPPDATA){
        $managed=Join-Path $env:LOCALAPPDATA 'UOY\Launcher\current\upload-tool\upload_he_thong.py'
        if((Test-Path -LiteralPath $managed) -and $managed -ine $targets[1].path){$targets+=[pscustomobject]@{id='managed-uploader';role='uploader';path=(Assert-R77Plain $managed 'File')}}
    }
    return [pscustomobject]@{Panel=$panel;Targets=$targets;ConfigPath=$cfgPath;ConfigHash=$cfgHash}
}
function Get-R77Plan($Mapping,$Manifest,[switch]$AllowKnownMixed){
    $rows=@()
    foreach($target in $Mapping.Targets){
        $policy=@($Manifest.files|Where-Object id -ceq $target.role)[0];$hash=Get-R77Hash $target.path
        $variants=@($policy.variants|Where-Object {$_.before_sha256 -ceq $hash -or $_.sha256 -ceq $hash})
        if($variants.Count -ne 1){throw ('Unknown or locally modified code preserved: '+$target.id)}
        $v=$variants[0];$state=if($hash -ceq $v.before_sha256){'before'}else{'after'}
        $rows+=[pscustomobject]@{id=$target.id;path=$target.path;state=$state;variant=$v}
    }
    if(-not $AllowKnownMixed -and @($rows.state|Select-Object -Unique).Count -ne 1){throw 'Mixed R77/original code preserved; rerun with explicit -CompleteKnownMixed only for the exact known bytes.'}
    return $rows
}
function Assert-R77Mapping($Expected){
    $actual=Get-R77Targets $Expected.Panel
    if($actual.Panel -ine $Expected.Panel -or $actual.ConfigPath -ine $Expected.ConfigPath -or $actual.ConfigHash -cne $Expected.ConfigHash -or @($actual.Targets).Count -ne @($Expected.Targets).Count){throw 'Configuration or target mapping changed; no guessed path is used.'}
    foreach($t in $Expected.Targets){$match=@($actual.Targets|Where-Object id -ceq $t.id);if($match.Count -ne 1 -or $match[0].path -ine $t.path -or $match[0].role -cne $t.role){throw 'Resolved upload path changed; preserved.'}}
}
function Assert-R77Vector($Mapping,$Manifest,$Expected){
    Assert-R77Mapping $Mapping
    $fresh=@(Get-R77Plan $Mapping $Manifest -AllowKnownMixed)
    if($fresh.Count -ne @($Expected).Count){throw 'Target vector changed.'}
    foreach($e in $Expected){$row=@($fresh|Where-Object id -ceq $e.id);if($row.Count -ne 1 -or $row[0].path -ine $e.path -or $row[0].state -cne $e.state -or $row[0].variant.before_sha256 -cne $e.variant.before_sha256 -or $row[0].variant.sha256 -cne $e.variant.sha256){throw 'Known target vector changed before commit.'}}
}
function Get-R77PatchedBytes([byte[]]$Original,$Variant){
    if((Get-R77BytesHash $Original) -cne $Variant.before_sha256 -or $Original.Length -ne $Variant.before_size){throw 'Patch preimage differs.'}
    $text=$script:R77Utf8.GetString($Original);$end=0
    foreach($h in @($Variant.hunks)){
        if($h.start -isnot [ValueType] -or $h.remove -isnot [ValueType] -or $h.start -lt $end -or $h.remove -lt 0 -or $h.start+$h.remove -gt $text.Length -or $h.insert -isnot [string]){throw 'Invalid or overlapping text hunk.'}
        $end=$h.start+$h.remove
    }
    $hunks=@($Variant.hunks)
    for($i=$hunks.Count-1;$i -ge 0;$i--){$h=$hunks[$i];$text=$text.Substring(0,[int]$h.start)+$h.insert+$text.Substring([int]($h.start+$h.remove))}
    $bytes=$script:R77Utf8.GetBytes($text)
    if($bytes.Length -ne $Variant.size -or (Get-R77BytesHash $bytes) -cne $Variant.sha256){throw 'Patch output hash differs.'}
    return ,$bytes
}
function Copy-R77Verified([string]$Source,[string]$Destination,[string]$Hash){
    [void](Assert-R77Plain $Source 'File');[void](Assert-R77Plain ([IO.Path]::GetDirectoryName($Destination)) 'Directory')
    if(Test-Path -LiteralPath $Destination){throw 'New-only backup/stage file already exists.'}
    [IO.File]::Copy($Source,$Destination,$false)
    if((Get-R77Hash $Source) -cne $Hash -or (Get-R77Hash $Destination) -cne $Hash){throw 'Source changed during verified backup.'}
}
function Set-R77Atomic([string]$Stage,[string]$Destination){[IO.File]::Replace($Stage,$Destination,[System.Management.Automation.Language.NullString]::Value,$true)}
function Enter-R77Locks($Rows){
    $locks=@()
    try{foreach($dir in @($Rows|ForEach-Object {[IO.Path]::GetDirectoryName($_.path)}|Sort-Object -Unique)){$file=Assert-R77Plain (Join-Path $dir '.mitom-order-R77.lock');$locks+=,[IO.File]::Open($file,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)};return $locks}
    catch{foreach($lock in $locks){$lock.Dispose()};throw}
}
function Assert-R77Preserved($Rows){foreach($r in @($Rows)){if((Get-R77Hash (Assert-R77Plain $r.path 'File')) -cne $r.sha256){throw 'Already-current code changed; preserved.'}}}
function Restore-R77Rows($Rows,$MappingProof=$null,$Preserved=@(),[switch]$BestEffort){
    $failed=@()
    if($MappingProof){Assert-R77Mapping $MappingProof};Assert-R77Preserved $Preserved
    foreach($r in $Rows){
        [void](Assert-R77Plain $r.path 'File');[void](Assert-R77Plain $r.original 'File')
        if((Get-R77Hash $r.original) -cne $r.before_sha256){throw 'Original backup hash differs.'}
        $actual=Get-R77Hash $r.path
        if($actual -cne $r.before_sha256 -and $actual -cne $r.sha256){if(-not $BestEffort){throw 'Rollback preserves unknown/concurrent code.'};$failed+=$r.id}
    }
    for($i=@($Rows).Count-1;$i -ge 0;$i--){
        $r=$Rows[$i];if($failed -contains $r.id){continue}
        try{
            Assert-R77AppsClosed
            if($MappingProof){Assert-R77Mapping $MappingProof};Assert-R77Preserved $Preserved
            $actual=Get-R77Hash $r.path;if($actual -ceq $r.before_sha256){continue};if($actual -cne $r.sha256){throw 'Rollback CAS changed.'}
            $stage=Join-Path ([IO.Path]::GetDirectoryName($r.original)) ('restore-'+[Guid]::NewGuid().ToString('N'))
            Copy-R77Verified $r.original $stage $r.before_sha256
            if($MappingProof){Assert-R77Mapping $MappingProof};Assert-R77Preserved $Preserved
            if((Get-R77Hash $r.path) -cne $r.sha256){throw 'Rollback CAS changed.'}
            Set-R77Atomic $stage $r.path
            if((Get-R77Hash $r.path) -cne $r.before_sha256){throw 'Rollback output differs.'}
        }catch{if(-not $BestEffort){throw};$failed+=$r.id}
    }
    if($failed.Count){throw ('Rollback retained unknown/busy code: '+($failed -join ', '))}
}
function Invoke-R77Update([string]$PackageRoot,[string]$RequestedRoot='',[switch]$OnlyCheck,[switch]$CompleteKnownMixed){
    $manifest=Get-R77Manifest $PackageRoot;$map=Get-R77Targets $RequestedRoot;$plan=@(Get-R77Plan $map $manifest -AllowKnownMixed:$CompleteKnownMixed)
    $changes=@($plan|Where-Object state -ceq 'before')
    if(-not $changes.Count){return @{status='already_installed';changed=0;panel_root=$map.Panel}}
    if($OnlyCheck){return @{status='ready';changed=0;would_change=$changes.Count;already_current=($plan.Count-$changes.Count);panel_root=$map.Panel;requires_apps_closed=$true;activation=$script:R77Activation}}
    Assert-R77AppsClosed
    $locks=@(Enter-R77Locks $plan);$transaction=[Guid]::NewGuid().ToString('N');$rows=@();$journal=$null;$master=''
    try{
        Assert-R77AppsClosed;Assert-R77Vector $map $manifest $plan
        $masterParent=Join-Path ([IO.Path]::GetDirectoryName($map.Targets[0].path)) '.mitom-order-R77-backups';New-R77PrivateDirectory $masterParent
        $masterDir=Join-Path $masterParent $transaction;New-R77PrivateDirectory $masterDir
        foreach($p in $changes){
            $parent=Join-Path ([IO.Path]::GetDirectoryName($p.path)) '.mitom-order-R77-backups';New-R77PrivateDirectory $parent
            $backup=Join-Path $parent $transaction;New-R77PrivateDirectory $backup
            $original=Join-Path $backup ($p.id+'.original');$staged=Join-Path $backup ($p.id+'.staged')
            Copy-R77Verified $p.path $original $p.variant.before_sha256
            [IO.File]::WriteAllBytes($staged,(Get-R77PatchedBytes ([IO.File]::ReadAllBytes($original)) $p.variant))
            if((Get-R77Hash $staged) -cne $p.variant.sha256){throw 'Staged code hash differs.'}
            $rows+=[pscustomobject]@{id=$p.id;path=$p.path;original=$original;staged=$staged;before_sha256=$p.variant.before_sha256;sha256=$p.variant.sha256}
        }
        $master=Join-Path $masterDir 'transaction.json'
        $vector=@($plan|ForEach-Object {[pscustomobject]@{id=$_.id;path=$_.path;state=$_.state;before_sha256=$_.variant.before_sha256;sha256=$_.variant.sha256}})
        $journal=@{schema=2;revision=$script:R77Revision;activation=$script:R77Activation;manifest_sha256=$script:R77ManifestSha;panel_root=$map.Panel;config_path=$map.ConfigPath;config_sha256=$map.ConfigHash;transaction=$transaction;state='prepared';files=$rows;initial_vector=$vector}
        Write-R77Json $master $journal
        foreach($r in $rows){
            Assert-R77AppsClosed;Assert-R77Vector $map $manifest $plan;[void](Assert-R77Plain $r.path 'File');[void](Assert-R77Plain $r.staged 'File')
            if((Get-R77Hash $r.path) -cne $r.before_sha256 -or (Get-R77Hash $r.staged) -cne $r.sha256){throw 'Commit compare-and-swap precondition changed.'}
            Set-R77Atomic $r.staged $r.path
            if((Get-R77Hash $r.path) -cne $r.sha256){throw 'Committed code hash differs.'}
            @($plan|Where-Object id -ceq $r.id)[0].state='after'
        }
        Assert-R77Vector $map $manifest $plan
        $journal.state='complete';Write-R77Json $master $journal
        return @{status='updated';changed=$rows.Count;backup=$master;panel_root=$map.Panel}
    }catch{
        $errorText=$_.Exception.Message
        if($journal){try{Assert-R77AppsClosed;Restore-R77Rows $rows -MappingProof $map -Preserved @($journal.initial_vector|Where-Object state -ceq 'after') -BestEffort;$journal.state='rolled_back';Write-R77Json $master $journal}catch{$journal.state='recovery_required';try{Write-R77Json $master $journal}catch{};throw ($errorText+' / '+$_.Exception.Message+' Keep backup: '+$master)}}
        throw ($errorText+$(if($master){' Backup retained: '+$master}else{''}))
    }finally{foreach($lock in $locks){$lock.Dispose()}}
}
function Invoke-R77Rollback([string]$PackageRoot,[string]$RequestedRoot,[string]$JournalPath,[switch]$OnlyCheck){
    $m=Get-R77Manifest $PackageRoot;$map=Get-R77Targets $RequestedRoot;$journalFile=Assert-R77Plain $JournalPath 'File';$j=Read-R77Json $journalFile
    if($j.schema -ne 2 -or $j.activation -cne $script:R77Activation -or $j.revision -cne $script:R77Revision -or $j.manifest_sha256 -cne $script:R77ManifestSha -or $j.panel_root -ine $map.Panel -or $j.config_path -ine $map.ConfigPath -or $j.config_sha256 -cne $map.ConfigHash -or $j.transaction -cnotmatch '^[0-9a-f]{32}$' -or @($j.files).Count -lt 1 -or @($j.files).Count -gt @($map.Targets).Count -or @($j.initial_vector).Count -ne @($map.Targets).Count){throw 'Rollback journal/configuration identity differs.'}
    $expected=Join-Path ([IO.Path]::GetDirectoryName($map.Targets[0].path)) ('.mitom-order-R77-backups\'+$j.transaction+'\transaction.json')
    if($journalFile -ine $expected){throw 'Use the exact journal created inside this panel.'}
    $changedIds=@();$preserved=@()
    foreach($t in $map.Targets){
        $v=@($j.initial_vector|Where-Object id -ceq $t.id);if($v.Count -ne 1 -or $v[0].path -ine $t.path -or $v[0].state -notin @('before','after')){throw 'Rollback target vector differs.'};$v=$v[0]
        $variants=@(@($m.files|Where-Object id -ceq $t.role)[0].variants|Where-Object {$_.before_sha256 -ceq $v.before_sha256 -and $_.sha256 -ceq $v.sha256});if($variants.Count -ne 1){throw 'Rollback code policy differs.'}
        $r=@($j.files|Where-Object id -ceq $t.id)
        if($v.state -ceq 'after'){if($r.Count){throw 'Rollback must not contain an already-current target.'};$preserved+=$v;continue}
        if($r.Count -ne 1 -or $r[0].path -ine $t.path -or $r[0].before_sha256 -cne $v.before_sha256 -or $r[0].sha256 -cne $v.sha256){throw 'Rollback changed-target mapping differs.'};$r=$r[0];$changedIds+=$r.id
        $original=Join-Path ([IO.Path]::GetDirectoryName($t.path)) ('.mitom-order-R77-backups\'+$j.transaction+'\'+$t.id+'.original')
        if($r.original -ine $original -or (Get-R77Hash (Assert-R77Plain $original 'File')) -cne $r.before_sha256){throw 'Rollback backup ownership differs.'}
        $actual=Get-R77Hash (Assert-R77Plain $t.path 'File');if($actual -cne $r.before_sha256 -and $actual -cne $r.sha256){throw 'Rollback preserves unknown current code.'}
    }
    if($changedIds.Count -ne @($j.files).Count -or @($changedIds|Select-Object -Unique).Count -ne $changedIds.Count){throw 'Rollback has extra or duplicate changed targets.'}
    Assert-R77Preserved $preserved;Assert-R77Mapping $map
    if($OnlyCheck){return @{status='rollback_ready';changed=0;backup=$journalFile}}
    Assert-R77AppsClosed;$locks=@(Enter-R77Locks @($map.Targets))
    try{Restore-R77Rows @($j.files) -MappingProof $map -Preserved $preserved;$j.state='rolled_back';Write-R77Json $journalFile $j;return @{status='rolled_back';changed=@($j.files).Count;backup=$journalFile}}
    finally{foreach($lock in $locks){$lock.Dispose()}}
}
if(-not $LibraryOnly){try{if($Rollback){$r=Invoke-R77Rollback $PSScriptRoot $PanelRoot $Rollback -OnlyCheck:$CheckOnly}else{$r=Invoke-R77Update $PSScriptRoot $PanelRoot -OnlyCheck:$CheckOnly -CompleteKnownMixed:$CompleteKnownMixed};$r|ConvertTo-Json -Depth 5;exit 0}catch{[Console]::Error.WriteLine($_.Exception.Message);exit 1}}
