@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-order-r77.ps1" -CompleteKnownMixed
pause
