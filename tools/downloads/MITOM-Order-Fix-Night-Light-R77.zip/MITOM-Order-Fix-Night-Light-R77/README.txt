MITOM Order Save Fix + Night Light R77 - activation compatibility

HƯỚNG DẪN
1. Giải nén toàn bộ ZIP vào thư mục bình thường.
2. Check Order R77.cmd chỉ kiểm tra; có thể chạy khi Photoshop đang mở.
3. Khi tiện, lưu PSD rồi tự đóng Photoshop và OrderStudio. Chạy Update
   Order R77.cmd, sau đó mở lại Photoshop/panel khi báo updated.
4. Bản cài này hoàn thiện các tệp R77 còn thiếu sau khi cập nhật bằng Launcher.
   Tệp đã đúng R77 được giữ nguyên, không ghi lại hay hạ phiên bản.
   Không cần gỡ/ghép lại Companion hoặc cài lại GPU.

Nội dung R77 không đổi: Save Fix giữ -fix, -fix1, -fix2. Night light
4-inch Warm Light lưu Ball trước rồi Base; 3.2/2.4 chỉ một fullprint.
Đây là ZIP để tự cài sau, không tự chạy Photoshop hay upload đơn.

SAFETY / ACTIVATION COMPATIBILITY
The code hunk manifest is exactly the previously reviewed R77 manifest.
No runtime feature/code, DEFAULT_CFG, deployment endpoint or credential changes
are added by this compatibility installer.

The supplied Check/Update commands explicitly use -CompleteKnownMixed.
Every resolved target must match one exact reviewed before OR after hash.
Already-after files remain unchanged. Only before files are backed up and
patched with the original R77 hunks. Unknown bytes/layouts are preserved and
refused. Without -CompleteKnownMixed the original mixed-vector guard remains.

Paths are resolved from this PC's APPDATA/local-config.json uploadToolDir and
the existing managed Launcher uploader. The raw configuration hash and full
resolved target vector are rechecked before each replacement; no fixed ADMIN
or drive path is used. Concurrent configuration/path/code changes are refused.
Private DEFAULT_CFG remains in place; only verified code hunks are applied.

Only files actually changed by this transaction are retained in private
.mitom-order-R77-backups folders beside each target. Already-current targets
are recorded as guarded, not backed up or changed. The printed transaction.json
path is the only rollback journal for this compatibility installer:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-order-r77.ps1 -Rollback "exact printed transaction.json path" -CheckOnly
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-order-r77.ps1 -Rollback "exact printed transaction.json path"
Rollback restores only this transaction's changed files and never downgrades
targets that were already R77. Old original-installer schema1 journals require
their original installer; do not mix rollback tools or edit a journal.

No process is stopped. No upload/Lark request, automatic Base scan, source
configuration rewrite, full-install receipt rewrite or backup cleanup occurs.
Save Task R78, GPU/runtime, pairing, PSDs, exports and login state are untouched.
Synthetic checks do not confirm actual save/upload behavior on every machine.
