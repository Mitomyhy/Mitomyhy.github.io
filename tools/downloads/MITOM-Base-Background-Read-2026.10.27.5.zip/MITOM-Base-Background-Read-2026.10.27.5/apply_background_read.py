"""Fourteen-target R74-to-R75 repair; no downloads or runtime/configuration writes.

The builder embeds exact approved output pins below. installer_guard.py is the
unchanged audited Launcher installer, reused only for its canonical ownership,
process, mutex, path, transaction and rollback guards. No install() is called.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import uuid
import installer_guard as guard

VERSION = '2026.10.27.5'
# Filled only by the gated builder from independently pinned sealed manifests.
BEFORE = {'companion/README.txt': {'size': 25929, 'sha256': '3d055b1652284e177678c6a85321e17f14ada8b8b1b8c2a720f8cba33a9a8317'}, 'companion/background.js': {'size': 63796, 'sha256': '2043026219cf425fe22fed56d5b201ba7e6f8910e1e76d07a655e88bd50ecf21'}, 'companion/content.js': {'size': 68028, 'sha256': '789d3ce96598650e16b96f3c6ecedecb3e82ada7ac201dfd8daefee87b5c1fdb'}, 'companion/core.js': {'size': 21049, 'sha256': 'ad7d9d06782f5a023879b20d65a49f48f6fa5eb9b805573ac2b2b0b5295b3d95'}, 'companion/manifest.json': {'size': 1104, 'sha256': 'f22b6e6d5a0412d222f55ad8d5450d80ec973bbe041a1ee80768a6f62ede26f7'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 9021, 'sha256': 'd47e67e00ad82aec251304967861e58bdccbb0c76ea9d36001ccbde99a399f66'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '658f407e42fb5447f7d5932b5afd0c12f5140eef2167b240f7894a8f09d3ee78'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '97f4850eea7f8df880f011a74d1f9b367ff59aa86b30f6a0ba2fc123e8c79a03'}, 'panel/js/lark-base-bridge.js': {'size': 110388, 'sha256': '6c787fcd4f04af78954d40a487fafd0fbba297470989666087d676daff0c5d74'}, 'panel/lark-base-extension/extension.js': {'size': 1044144, 'sha256': '3825078ba5053c2ad451f4e540b8dca37b7a419e55412a1c64d640c6ad90779c'}, 'panel/lark-base-extension/index.html': {'size': 3645, 'sha256': 'ccb398fb4332506df71652f2ab9f86968b49e28811571337b24507b85a5c9481'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 67991, 'sha256': '06b2807a9c63e1ebee2f5a388ea7213b4e92dc55a2138a83e6ea50cfd88528be'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 45086, 'sha256': 'a9a501db75aaee3752df903b619b8d791eb85b4219e2df0dc47c48989331b807'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 13769, 'sha256': '850caccf16ab957bd51aebcbe31564d6c2144665c9926ded1294ac6112ce51d8'}}
PREREQUISITES = {'coexist/coexist-client.js': {'size': 16904, 'sha256': '26a2053ad63dedafa57d9a2ce9c10383a599f08dfa881bf30103aef0d7af332e'}, 'coexist/coexist-host.js': {'size': 32318, 'sha256': '2df221a867f6676b2261c5faa64ec85eed123859154eb99e080f40d35785a0cc'}, 'panel/js/lark-base-watch.js': {'size': 29489, 'sha256': 'a82505f1d46268b8d8ac39a7896ea3c85383cb208fde167b92a9aa1bb4ae3b4a'}, 'panel/js/lark-live-status.js': {'size': 44333, 'sha256': '04f31f6fc63c4e87a50103293f3da491783407d09ad350b1dac060c59e2aae9b'}, 'panel/js/main.js': {'size': 540471, 'sha256': 'a343d532edc52f857723b6d784c8295f3278ad0c0a0c55451e077b78122264a9'}}
SUPPORTED_BEFORE = {'2026.10.25.1': {'coexist/coexist-client.js': {'size': 12669, 'sha256': '7968190a2f849ef3678e48a7cd493945bdb19c36356c86e94910db33eafc5253'}, 'coexist/coexist-host.js': {'size': 30288, 'sha256': '86034515f5cda3367fb3e6dac629867e8812c105e7c4cec1da94bd5a16c5f296'}, 'companion/README.txt': {'size': 24328, 'sha256': 'a634c70a5d1e90e800d9bbb558eb417d799b98aa3d557006f97683a1da537e14'}, 'companion/background.js': {'size': 51664, 'sha256': '5b312d2b8f4dbcaae48b4088cc07ba67d374b9553b2e4490aa97a61b3f30fd00'}, 'companion/content.js': {'size': 65759, 'sha256': '2fc6b4e4d07bfe4c034b6b7b7aa2c70f51f633f7d628f862534573d2a0a1d57a'}, 'companion/core.js': {'size': 20693, 'sha256': 'dad35a2dab3455883f9483487a155751f6d335888996ed0a12f5ab238a3759e7'}, 'companion/manifest.json': {'size': 1104, 'sha256': '862089f33dc5478648bc00de283d420813ef4a982333d073861351b5d04bc76e'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 6675, 'sha256': '487684c5bb7cfea04b73dae17e59e413121747e1869cf7750ea5bab7c69280c1'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '6671767bace45abff3ee915f5c1b34ef499f5dc2178edb97756f54d68e34f549'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '4bb009a92532b086aeed36c8ccff56835018e837083be235660d1463ae1e6d75'}, 'panel/js/lark-base-bridge.js': {'size': 105846, 'sha256': 'a871152461c3074250e926f65661d2fdf77a08ce83318e357635c21c874bf4d9'}, 'panel/js/lark-base-watch.js': {'size': 30923, 'sha256': '4e317422e0ef86026431736ff7a092b0bd4baefcad6a8c1712fd54d550d3b3f6'}, 'panel/js/lark-live-status.js': {'size': 38126, 'sha256': 'bdc7e5fc562b6456e574a98c811422f22cbf13be16791d24f442e513b561afb4'}, 'panel/js/main.js': {'size': 548743, 'sha256': 'f9c4e9b0b75a15a2f3c00051bd007d4101dc59114cab019fe6633c853cc823b9'}, 'panel/lark-base-extension/extension.js': {'size': 1043085, 'sha256': '35d961fd4146afbcbc6e4083da512ab72181e4a71d18078fce22778a3266c645'}, 'panel/lark-base-extension/index.html': {'size': 3645, 'sha256': '2b8a3c5c69c34264325a65eaf12cd9f9fecbfc11c99ceda4e3fdb7a15577e9f3'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 61367, 'sha256': 'fdce149907bbe04fb5984c2abb63859693f3dc59aaf26a848a4e04d6aed13fa5'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 44187, 'sha256': '7ec0e86d2c2bfe7bbd1c48ccca765604ec79c3ce71f2b68c51c071f22da3b451'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 11340, 'sha256': '15d2c9bea65448a50d6a50329dcc3d440a09c0884ccfe0bb6e9766d2f7a77f13'}}, '2026.10.26.1': {'coexist/coexist-client.js': {'size': 12669, 'sha256': '7968190a2f849ef3678e48a7cd493945bdb19c36356c86e94910db33eafc5253'}, 'coexist/coexist-host.js': {'size': 30288, 'sha256': '86034515f5cda3367fb3e6dac629867e8812c105e7c4cec1da94bd5a16c5f296'}, 'companion/README.txt': {'size': 24328, 'sha256': 'a634c70a5d1e90e800d9bbb558eb417d799b98aa3d557006f97683a1da537e14'}, 'companion/background.js': {'size': 51664, 'sha256': '5b312d2b8f4dbcaae48b4088cc07ba67d374b9553b2e4490aa97a61b3f30fd00'}, 'companion/content.js': {'size': 65759, 'sha256': '2fc6b4e4d07bfe4c034b6b7b7aa2c70f51f633f7d628f862534573d2a0a1d57a'}, 'companion/core.js': {'size': 20693, 'sha256': 'dad35a2dab3455883f9483487a155751f6d335888996ed0a12f5ab238a3759e7'}, 'companion/manifest.json': {'size': 1104, 'sha256': '862089f33dc5478648bc00de283d420813ef4a982333d073861351b5d04bc76e'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 6675, 'sha256': '487684c5bb7cfea04b73dae17e59e413121747e1869cf7750ea5bab7c69280c1'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '6671767bace45abff3ee915f5c1b34ef499f5dc2178edb97756f54d68e34f549'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '4bb009a92532b086aeed36c8ccff56835018e837083be235660d1463ae1e6d75'}, 'panel/js/lark-base-bridge.js': {'size': 105846, 'sha256': 'a871152461c3074250e926f65661d2fdf77a08ce83318e357635c21c874bf4d9'}, 'panel/js/lark-base-watch.js': {'size': 30923, 'sha256': '4e317422e0ef86026431736ff7a092b0bd4baefcad6a8c1712fd54d550d3b3f6'}, 'panel/js/lark-live-status.js': {'size': 38126, 'sha256': 'bdc7e5fc562b6456e574a98c811422f22cbf13be16791d24f442e513b561afb4'}, 'panel/js/main.js': {'size': 548743, 'sha256': 'f9c4e9b0b75a15a2f3c00051bd007d4101dc59114cab019fe6633c853cc823b9'}, 'panel/lark-base-extension/extension.js': {'size': 1043085, 'sha256': '35d961fd4146afbcbc6e4083da512ab72181e4a71d18078fce22778a3266c645'}, 'panel/lark-base-extension/index.html': {'size': 3645, 'sha256': '2b8a3c5c69c34264325a65eaf12cd9f9fecbfc11c99ceda4e3fdb7a15577e9f3'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 61367, 'sha256': 'fdce149907bbe04fb5984c2abb63859693f3dc59aaf26a848a4e04d6aed13fa5'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 44187, 'sha256': '7ec0e86d2c2bfe7bbd1c48ccca765604ec79c3ce71f2b68c51c071f22da3b451'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 11340, 'sha256': '15d2c9bea65448a50d6a50329dcc3d440a09c0884ccfe0bb6e9766d2f7a77f13'}}, '2026.10.26.2': {'coexist/coexist-client.js': {'size': 12669, 'sha256': '7968190a2f849ef3678e48a7cd493945bdb19c36356c86e94910db33eafc5253'}, 'coexist/coexist-host.js': {'size': 30288, 'sha256': '86034515f5cda3367fb3e6dac629867e8812c105e7c4cec1da94bd5a16c5f296'}, 'companion/README.txt': {'size': 24328, 'sha256': 'a634c70a5d1e90e800d9bbb558eb417d799b98aa3d557006f97683a1da537e14'}, 'companion/background.js': {'size': 51664, 'sha256': '5b312d2b8f4dbcaae48b4088cc07ba67d374b9553b2e4490aa97a61b3f30fd00'}, 'companion/content.js': {'size': 65759, 'sha256': '2fc6b4e4d07bfe4c034b6b7b7aa2c70f51f633f7d628f862534573d2a0a1d57a'}, 'companion/core.js': {'size': 20693, 'sha256': 'dad35a2dab3455883f9483487a155751f6d335888996ed0a12f5ab238a3759e7'}, 'companion/manifest.json': {'size': 1104, 'sha256': '862089f33dc5478648bc00de283d420813ef4a982333d073861351b5d04bc76e'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 6675, 'sha256': '487684c5bb7cfea04b73dae17e59e413121747e1869cf7750ea5bab7c69280c1'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '6671767bace45abff3ee915f5c1b34ef499f5dc2178edb97756f54d68e34f549'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '4bb009a92532b086aeed36c8ccff56835018e837083be235660d1463ae1e6d75'}, 'panel/js/lark-base-bridge.js': {'size': 105846, 'sha256': 'a871152461c3074250e926f65661d2fdf77a08ce83318e357635c21c874bf4d9'}, 'panel/js/lark-base-watch.js': {'size': 30923, 'sha256': '4e317422e0ef86026431736ff7a092b0bd4baefcad6a8c1712fd54d550d3b3f6'}, 'panel/js/lark-live-status.js': {'size': 38126, 'sha256': 'bdc7e5fc562b6456e574a98c811422f22cbf13be16791d24f442e513b561afb4'}, 'panel/js/main.js': {'size': 548743, 'sha256': 'f9c4e9b0b75a15a2f3c00051bd007d4101dc59114cab019fe6633c853cc823b9'}, 'panel/lark-base-extension/extension.js': {'size': 1043085, 'sha256': '35d961fd4146afbcbc6e4083da512ab72181e4a71d18078fce22778a3266c645'}, 'panel/lark-base-extension/index.html': {'size': 3645, 'sha256': '2b8a3c5c69c34264325a65eaf12cd9f9fecbfc11c99ceda4e3fdb7a15577e9f3'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 61367, 'sha256': 'fdce149907bbe04fb5984c2abb63859693f3dc59aaf26a848a4e04d6aed13fa5'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 44187, 'sha256': '7ec0e86d2c2bfe7bbd1c48ccca765604ec79c3ce71f2b68c51c071f22da3b451'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 11340, 'sha256': '15d2c9bea65448a50d6a50329dcc3d440a09c0884ccfe0bb6e9766d2f7a77f13'}}, '2026.10.26.3': {'coexist/coexist-client.js': {'size': 12669, 'sha256': '7968190a2f849ef3678e48a7cd493945bdb19c36356c86e94910db33eafc5253'}, 'coexist/coexist-host.js': {'size': 30288, 'sha256': '86034515f5cda3367fb3e6dac629867e8812c105e7c4cec1da94bd5a16c5f296'}, 'companion/README.txt': {'size': 24328, 'sha256': 'a634c70a5d1e90e800d9bbb558eb417d799b98aa3d557006f97683a1da537e14'}, 'companion/background.js': {'size': 51664, 'sha256': '5b312d2b8f4dbcaae48b4088cc07ba67d374b9553b2e4490aa97a61b3f30fd00'}, 'companion/content.js': {'size': 65759, 'sha256': '2fc6b4e4d07bfe4c034b6b7b7aa2c70f51f633f7d628f862534573d2a0a1d57a'}, 'companion/core.js': {'size': 20693, 'sha256': 'dad35a2dab3455883f9483487a155751f6d335888996ed0a12f5ab238a3759e7'}, 'companion/manifest.json': {'size': 1104, 'sha256': '862089f33dc5478648bc00de283d420813ef4a982333d073861351b5d04bc76e'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 6675, 'sha256': '487684c5bb7cfea04b73dae17e59e413121747e1869cf7750ea5bab7c69280c1'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '6671767bace45abff3ee915f5c1b34ef499f5dc2178edb97756f54d68e34f549'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '4bb009a92532b086aeed36c8ccff56835018e837083be235660d1463ae1e6d75'}, 'panel/js/lark-base-bridge.js': {'size': 105846, 'sha256': 'a871152461c3074250e926f65661d2fdf77a08ce83318e357635c21c874bf4d9'}, 'panel/js/lark-base-watch.js': {'size': 31862, 'sha256': 'a042643962d37b4db2d54f31578dbef13cf1422f3006769d5ffe855e60404bbd'}, 'panel/js/lark-live-status.js': {'size': 40503, 'sha256': 'cd79f4904c40b4ec6934e49f9891b8c524160d561549312c87722d1390bf297f'}, 'panel/js/main.js': {'size': 556978, 'sha256': '89592a0b46508cf292fe948a9b39e9076544b5fcd7d82c69b112c75883a8b3f5'}, 'panel/lark-base-extension/extension.js': {'size': 1043085, 'sha256': '35d961fd4146afbcbc6e4083da512ab72181e4a71d18078fce22778a3266c645'}, 'panel/lark-base-extension/index.html': {'size': 3645, 'sha256': '2b8a3c5c69c34264325a65eaf12cd9f9fecbfc11c99ceda4e3fdb7a15577e9f3'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 61367, 'sha256': 'fdce149907bbe04fb5984c2abb63859693f3dc59aaf26a848a4e04d6aed13fa5'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 44187, 'sha256': '7ec0e86d2c2bfe7bbd1c48ccca765604ec79c3ce71f2b68c51c071f22da3b451'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 11340, 'sha256': '15d2c9bea65448a50d6a50329dcc3d440a09c0884ccfe0bb6e9766d2f7a77f13'}}, '2026.10.27.1': {'coexist/coexist-client.js': {'size': 16904, 'sha256': '26a2053ad63dedafa57d9a2ce9c10383a599f08dfa881bf30103aef0d7af332e'}, 'coexist/coexist-host.js': {'size': 32318, 'sha256': '2df221a867f6676b2261c5faa64ec85eed123859154eb99e080f40d35785a0cc'}, 'companion/README.txt': {'size': 24328, 'sha256': 'a634c70a5d1e90e800d9bbb558eb417d799b98aa3d557006f97683a1da537e14'}, 'companion/background.js': {'size': 51664, 'sha256': '5b312d2b8f4dbcaae48b4088cc07ba67d374b9553b2e4490aa97a61b3f30fd00'}, 'companion/content.js': {'size': 65759, 'sha256': '2fc6b4e4d07bfe4c034b6b7b7aa2c70f51f633f7d628f862534573d2a0a1d57a'}, 'companion/core.js': {'size': 20693, 'sha256': 'dad35a2dab3455883f9483487a155751f6d335888996ed0a12f5ab238a3759e7'}, 'companion/manifest.json': {'size': 1104, 'sha256': '862089f33dc5478648bc00de283d420813ef4a982333d073861351b5d04bc76e'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 6675, 'sha256': '487684c5bb7cfea04b73dae17e59e413121747e1869cf7750ea5bab7c69280c1'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '6671767bace45abff3ee915f5c1b34ef499f5dc2178edb97756f54d68e34f549'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '4bb009a92532b086aeed36c8ccff56835018e837083be235660d1463ae1e6d75'}, 'panel/js/lark-base-bridge.js': {'size': 104812, 'sha256': 'bae74c22ac29bbe1c3d0139af571712fd4cfede68d59159067cbe90058f058d7'}, 'panel/js/lark-base-watch.js': {'size': 29489, 'sha256': 'a82505f1d46268b8d8ac39a7896ea3c85383cb208fde167b92a9aa1bb4ae3b4a'}, 'panel/js/lark-live-status.js': {'size': 44333, 'sha256': '04f31f6fc63c4e87a50103293f3da491783407d09ad350b1dac060c59e2aae9b'}, 'panel/js/main.js': {'size': 540471, 'sha256': 'a343d532edc52f857723b6d784c8295f3278ad0c0a0c55451e077b78122264a9'}, 'panel/lark-base-extension/extension.js': {'size': 1043085, 'sha256': '35d961fd4146afbcbc6e4083da512ab72181e4a71d18078fce22778a3266c645'}, 'panel/lark-base-extension/index.html': {'size': 3645, 'sha256': '2b8a3c5c69c34264325a65eaf12cd9f9fecbfc11c99ceda4e3fdb7a15577e9f3'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 61367, 'sha256': 'fdce149907bbe04fb5984c2abb63859693f3dc59aaf26a848a4e04d6aed13fa5'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 44187, 'sha256': '7ec0e86d2c2bfe7bbd1c48ccca765604ec79c3ce71f2b68c51c071f22da3b451'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 11340, 'sha256': '15d2c9bea65448a50d6a50329dcc3d440a09c0884ccfe0bb6e9766d2f7a77f13'}}}
# Replaced only by the release builder after both source approval gates pass.
APPROVED_OUTPUT = {'companion/README.txt': {'size': 25929, 'sha256': '3d055b1652284e177678c6a85321e17f14ada8b8b1b8c2a720f8cba33a9a8317'}, 'companion/background.js': {'size': 63796, 'sha256': '2043026219cf425fe22fed56d5b201ba7e6f8910e1e76d07a655e88bd50ecf21'}, 'companion/content.js': {'size': 68028, 'sha256': '789d3ce96598650e16b96f3c6ecedecb3e82ada7ac201dfd8daefee87b5c1fdb'}, 'companion/core.js': {'size': 21049, 'sha256': 'ad7d9d06782f5a023879b20d65a49f48f6fa5eb9b805573ac2b2b0b5295b3d95'}, 'companion/manifest.json': {'size': 1104, 'sha256': 'f22b6e6d5a0412d222f55ad8d5450d80ec973bbe041a1ee80768a6f62ede26f7'}, 'core/companion-handoff/companion-handoff-manifest.json': {'size': 9021, 'sha256': 'd47e67e00ad82aec251304967861e58bdccbb0c76ea9d36001ccbde99a399f66'}, 'core/companion-handoff/companion_handoff.py': {'size': 14385, 'sha256': '658f407e42fb5447f7d5932b5afd0c12f5140eef2167b240f7894a8f09d3ee78'}, 'panel/js/companion-update-handoff.js': {'size': 6139, 'sha256': '97f4850eea7f8df880f011a74d1f9b367ff59aa86b30f6a0ba2fc123e8c79a03'}, 'panel/js/lark-base-bridge.js': {'size': 110388, 'sha256': '6c787fcd4f04af78954d40a487fafd0fbba297470989666087d676daff0c5d74'}, 'panel/lark-base-extension/extension.js': {'size': 1045170, 'sha256': 'f533f2197df17a6d509ca818d0dd3a0f99f5fc96af9bf9fbb8ddbec6d7bf9e56'}, 'panel/lark-base-extension/index.html': {'size': 3659, 'sha256': '7db527d8f05fb7008d25892d460e26846bda6bda7d62b66d1ffe7da087f368b6'}, 'panel/lark-base-extension/reader-adapter.js': {'size': 67991, 'sha256': '06b2807a9c63e1ebee2f5a388ea7213b4e92dc55a2138a83e6ea50cfd88528be'}, 'panel/lark-base-extension/reader-live-status.js': {'size': 45086, 'sha256': 'a9a501db75aaee3752df903b619b8d791eb85b4219e2df0dc47c48989331b807'}, 'panel/lark-base-extension/reader-ownership.js': {'size': 13769, 'sha256': '850caccf16ab957bd51aebcbe31564d6c2144665c9926ded1294ac6112ce51d8'}}

def _digest(data):
    return hashlib.sha256(data).hexdigest()

def _package(package):
    package = guard._plain(package)
    if (not isinstance(BEFORE, dict) or len(BEFORE) != 14 or not isinstance(PREREQUISITES, dict) or len(PREREQUISITES) != 5 or
            not isinstance(SUPPORTED_BEFORE, dict) or not isinstance(APPROVED_OUTPUT, dict) or set(APPROVED_OUTPUT) != set(BEFORE)):
        raise guard.InstallError('This is an unsealed repair source, not an installable package.')
    manifest = guard._read_json(package / 'patch-manifest.json')
    if (manifest.get('schema') != 5 or manifest.get('version') != VERSION or
            manifest.get('base_versions') != SUPPORTED_BEFORE or manifest.get('disk_preimage') != BEFORE or
            manifest.get('prerequisites') != PREREQUISITES or manifest.get('files') != APPROVED_OUTPUT):
        raise guard.InstallError('Repair manifest differs from the approved fourteen-file package.')
    payload = {}
    for name, expected in APPROVED_OUTPUT.items():
        if (not isinstance(expected, dict) or set(expected) != {'size', 'sha256'} or
                type(expected['size']) is not int or not 0 < expected['size'] <= 1024 * 1024):
            raise guard.InstallError('Invalid approved repair pin.')
        source = guard._child(package / 'payload', name)
        if guard._hash(source) is None:
            raise guard.InstallError('Repair payload integrity failed: ' + name)
        data = source.read_bytes()
        if len(data) != expected['size'] or _digest(data) != expected['sha256']:
            raise guard.InstallError('Repair payload integrity failed: ' + name)
        payload[name] = data
    return payload

def _target(roots, name):
    if name not in BEFORE:
        raise guard.InstallError('Target is not in the exact reviewed fourteen-file repair allowlist.')
    component, relative = name.split('/', 1)
    if component not in ('panel', 'companion', 'core'):
        raise guard.InstallError('Unapproved repair component root.')
    return guard._child(roots[component], relative)

def _prerequisites(roots):
    for name, pin in PREREQUISITES.items():
        component, relative = name.split('/', 1)
        if component not in ('panel', 'coexist') or guard._hash(guard._child(roots[component], relative)) != pin['sha256']:
            raise guard.InstallError('Exact R71 manual-only prerequisite missing or changed; use the cumulative Launcher update: ' + name)

def _inspect(roots, payload):
    pending = roots['launcher'] / 'pending-transaction.json'
    if guard._hash(pending) is not None:
        raise guard.InstallError('An unfinished Launcher update was preserved. Use Restore previous version first; no repair files changed.')
    receipt_path = roots['launcher'] / 'install-receipt.json'
    receipt_hash = guard._hash(receipt_path)
    receipt = guard._read_json(receipt_path)
    identity = guard._identity(roots)
    receipt_version = receipt.get('version')
    if (receipt.get('schema') != 1 or not isinstance(receipt_version, str) or receipt_version not in SUPPORTED_BEFORE or receipt.get('identity') != identity):
        raise guard.InstallError('This repair requires a known managed receipt carrying the exact R74 repair and R71 manual-only prerequisites. Existing files were preserved.')
    recorded = receipt.get('files')
    if not isinstance(recorded, list):
        raise guard.InstallError('The existing full-install receipt was preserved: invalid inventory.')
    owned = {}
    for row in recorded:
        if not isinstance(row, dict) or not isinstance(row.get('path'), str) or row['path'] in owned:
            raise guard.InstallError('The existing receipt has invalid or duplicate paths.')
        owned[row['path']] = row
    for name, pin in SUPPORTED_BEFORE[receipt_version].items():
        row = owned.get(name, {})
        if row.get('sha256') != pin['sha256'] or row.get('size') != pin['size']:
            raise guard.InstallError('The full-install receipt does not own the supported preimage: ' + name)
    _prerequisites(roots)
    changes = []
    for name in sorted(BEFORE):
        target = _target(roots, name)
        before = guard._hash(target)
        if before == APPROVED_OUTPUT[name]['sha256']:
            continue
        if before != BEFORE[name]['sha256']:
            raise guard.InstallError('An old unpatched, missing, newer or custom file was preserved; use the cumulative Launcher update: ' + name)
        changes.append({'entry': {'path': name, **APPROVED_OUTPUT[name]}, 'target': target, 'before': before, 'data': payload[name]})
    return changes, receipt_path, receipt_hash, identity

def apply(package, base_root=None, *, check_only=False):
    payload = _package(Path(package))
    roots, local, sandbox = guard._roots(base_root)
    guard._closed(sandbox)
    if check_only:
        changes, receipt_path, receipt_hash, identity = _inspect(roots, payload)
        return {'preflight': True, 'patch_version': VERSION, 'would_change': [change['entry']['path'] for change in changes],
                'already_current': not changes, 'files_changed': 0, 'full_install_receipt_preserved': True}
    with guard._lock(roots, sandbox):
        guard._closed(sandbox)
        changes, receipt_path, receipt_hash, identity = _inspect(roots, payload)
        pending = roots['launcher'] / 'pending-transaction.json'
        if not changes:
            return {'updated': False, 'already_current': True, 'patch_version': VERSION,
                    'full_install_receipt_preserved': True}
        guard._space_preflight(changes, roots)
        backup = guard._child(roots['launcher'], 'backups/' + time.strftime('%Y%m%d-%H%M%S') + '-base-background-read-' + uuid.uuid4().hex)
        backup.mkdir(parents=True, exist_ok=False)
        journal = {'schema': 1, 'identity': identity, 'version': VERSION, 'status': 'preparing',
                   'files': [], 'registry': []}
        for index, change in enumerate(changes):
            if guard._hash(change['target']) != change['before']:
                raise guard.InstallError('A target changed during repair preflight; no panel file changed.')
            stored = 'files/' + str(index) + '.bin'
            guard._atomic(guard._child(backup, stored), guard._FileSource(change['target'], change['before']), None)
            journal['files'].append({'path': change['entry']['path'], 'before': change['before'],
                                     'after': change['entry']['sha256'], 'backup': stored, 'applied': True})
        guard._write_journal(backup / 'transaction.json', journal)
        guard._atomic(pending, guard._json_bytes({'schema': 1, 'identity': identity,
                                                'backup': backup.relative_to(roots['launcher']).as_posix()}), None)
        try:
            for change in changes:
                guard._closed(sandbox)
                if guard._hash(receipt_path) != receipt_hash:
                    raise guard.InstallError('The full-install receipt changed during repair.')
                _prerequisites(roots)
                guard._atomic(change['target'], change['data'], change['before'])
            if guard._hash(receipt_path) != receipt_hash:
                raise guard.InstallError('The full-install receipt changed during repair.')
            _prerequisites(roots)
            journal['status'] = 'installed'
            guard._write_journal(backup / 'transaction.json', journal)
            guard._plain(pending).unlink()
        except BaseException as error:
            retained = guard._restore(journal, backup, roots, sandbox)
            journal['status'] = 'recovery_required' if retained else 'rolled_back'
            journal['retained'] = retained
            guard._write_journal(backup / 'transaction.json', journal)
            if not retained:
                guard._plain(pending).unlink(missing_ok=True)
            raise guard.InstallError('Repair stopped. ' + ('Later edits retained; use Restore previous version.' if retained else 'Previous panel files restored.') + ' Backup: ' + str(backup)) from error
        return {'updated': True, 'patch_version': VERSION, 'files': len(changes), 'backup': str(backup),
                'full_install_receipt_preserved': guard._hash(receipt_path) == receipt_hash,
                'settings_models_runtimes_unchanged': True, 'gpu_setup_or_inference_started': False,
                'chrome_profiles_or_pairing_changed': False, 'chrome_reload_or_tab_activation_started': False}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true', help='Read-only package/receipt/prerequisite preflight; no repair files or backups created.')
    args = parser.parse_args()
    result = apply(Path(__file__).resolve().parent, check_only=args.check)
    print('Base background-read preflight complete; no files changed.' if args.check else 'Base background-read code repair complete. No Chrome reload, tab activation, CUDA setup or generation was started.')
    print(json.dumps(result, ensure_ascii=False))

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('Repair stopped: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
