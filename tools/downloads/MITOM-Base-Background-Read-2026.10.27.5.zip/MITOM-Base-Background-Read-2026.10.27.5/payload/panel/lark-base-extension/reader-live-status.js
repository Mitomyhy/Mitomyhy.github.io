/* Read-only status checks by exact record ID, independent of view filters. */
(function(root,factory){var reader=typeof module==='object'&&module.exports&&typeof require==='function'?require('./reader-adapter.js'):root&&root.UOYLarkFreshViewReader;var api=factory(reader);if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.UOYReaderLiveStatus=api;})(typeof window==='undefined'?null:window,function(reader){
  'use strict';
  var TABLE_EVENTS=['onRecordModify','onRecordAdd','onRecordDelete','onFieldModify','onFieldDelete'],membershipPending=new WeakMap(),observerRawPending=new WeakMap();
  function sdkCall(operation,start){return reader&&typeof reader.safeSDKCall==='function'?reader.safeSDKCall(operation,start):Promise.resolve().then(start);}
  function sdkError(operation,error){return reader&&typeof reader.safeSDKError==='function'?reader.safeSDKError(operation,error):error;}
  function trackMembership(sdk,promise){
    var pending=membershipPending.get(sdk);if(!pending){pending=new Set();membershipPending.set(sdk,pending);}
    var token={};pending.add(token);
    function settled(){pending.delete(token);if(!pending.size&&membershipPending.get(sdk)===pending)membershipPending.delete(sdk);}
    Promise.resolve(promise).then(settled,settled);return promise;
  }
  function fail(code,message){var e=new Error(message);e.code=code;throw e;}
  function id(value){return typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(value);}
  function canonical(value){try{var u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||!/(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(u.hostname)||u.pathname==='/')return '';return u.origin+u.pathname.replace(/\/$/,'');}catch(_){return '';}}
  function cleanSource(value){if(!value||typeof value!=='object'||Array.isArray(value)||!canonical(value.url)||!id(value.tableId)||!id(value.viewId))fail('STATUS_REQUEST','Nguồn kiểm tra Working Status chưa hợp lệ.');return{url:value.url,tableId:value.tableId,viewId:value.viewId};}
  function sameSource(a,b){return !!a&&!!b&&canonical(a.url)===canonical(b.url)&&a.tableId===b.tableId&&a.viewId===b.viewId;}
  function selected(value){if(!value||!id(value.tableId)||!id(value.viewId))fail('VIEW_CHANGED','Base chưa xác nhận bảng/view hiện tại.');return{tableId:value.tableId,viewId:value.viewId,baseId:typeof value.baseId==='string'?value.baseId:''};}
  function sameSelection(a,b){return a.tableId===b.tableId&&a.viewId===b.viewId&&a.baseId===b.baseId;}
  function request(value){
    if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).sort().join(',')!=='recordIds,source'||!Array.isArray(value.recordIds)||value.recordIds.length<1||value.recordIds.length>5000)fail('STATUS_REQUEST','Lượt kiểm tra Working Status cần 1–5000 Record ID.');
    if(!value.source||Object.keys(value.source).sort().join(',')!=='tableId,url,viewId')fail('STATUS_REQUEST','Nguồn kiểm tra Working Status chưa hợp lệ.');
    var source=cleanSource(value.source),seen=Object.create(null),ids=value.recordIds.slice();
    ids.forEach(function(value){if(!id(value)||seen[value])fail('STATUS_REQUEST','Record ID trống, trùng hoặc chưa hợp lệ.');seen[value]=true;});
    return{source:source,recordIds:ids};
  }
  function schemaSignature(fields){
    if(!Array.isArray(fields)||fields.length>1000)fail('FIELD_SCHEMA','Danh sách cột Base chưa hợp lệ.');
    function own(value,key){var descriptor=value&&typeof value==='object'&&Object.getOwnPropertyDescriptor(value,key);return descriptor&&Object.prototype.hasOwnProperty.call(descriptor,'value')?descriptor.value:undefined;}
    var checked=[],seen=Object.create(null);
    for(var index=0;index<fields.length;index++){var field=own(fields,String(index)),fieldId=own(field,'id'),fieldName=own(field,'name'),fieldType=own(field,'type');if(!field||typeof field!=='object'||Array.isArray(field)||!id(fieldId)||seen[fieldId]||typeof fieldName!=='string'||fieldName.length>100000||fieldType!==undefined&&(!Number.isInteger(fieldType)||fieldType<0||fieldType>100000))fail('FIELD_SCHEMA','Cấu trúc cột Base chưa hợp lệ; chưa xác nhận Working Status.');seen[fieldId]=true;checked.push({id:fieldId,name:fieldName,type:fieldType});}
    return JSON.stringify(checked.sort(function(a,b){return a.id.localeCompare(b.id);}));
  }
  function canonicalData(value){
    var nodes=0;
    function data(item,depth){
      if(++nodes>10000||depth>20)fail('MEMBERSHIP_UNAVAILABLE','Cấu hình view vượt giới hạn xác minh.');
      if(item===null||typeof item==='string'||typeof item==='boolean'||typeof item==='number'&&isFinite(item))return item;
      if(!item||typeof item!=='object'||Object.prototype.toString.call(item)!=='[object Object]'&&!Array.isArray(item))fail('MEMBERSHIP_UNAVAILABLE','Cấu hình view chưa có dữ liệu tường minh.');
      var array=Array.isArray(item),result=array?[]:{},keys=array?Array.from({length:item.length},function(_,index){return String(index);}):Object.getOwnPropertyNames(item).sort();
      if(keys.length>5000)fail('MEMBERSHIP_UNAVAILABLE','Cấu hình view vượt giới hạn xác minh.');
      keys.forEach(function(key){var descriptor=Object.getOwnPropertyDescriptor(item,key);if(!descriptor||!Object.prototype.hasOwnProperty.call(descriptor,'value'))fail('MEMBERSHIP_UNAVAILABLE','Cấu hình view chưa trả dữ liệu đầy đủ.');if(!array&&descriptor.value===undefined)return;Object.defineProperty(result,key,{value:data(descriptor.value,depth+1),enumerable:true});});return result;
    }
    var result=data(value,0);if(JSON.stringify(result).length>100000)fail('MEMBERSHIP_UNAVAILABLE','Cấu hình view vượt giới hạn xác minh.');return result;
  }
  function explicitFilterSignature(filter){
    if(filter===null)return 'null';
    if(!filter||typeof filter!=='object'||Array.isArray(filter))fail('MEMBERSHIP_UNAVAILABLE','SDK chưa xác nhận bộ lọc hiện tại của view.');
    var conjunction=Object.getOwnPropertyDescriptor(filter,'conjunction'),conditions=Object.getOwnPropertyDescriptor(filter,'conditions');
    if(!conjunction||!Object.prototype.hasOwnProperty.call(conjunction,'value')||!['and','or'].includes(conjunction.value)||!conditions||!Object.prototype.hasOwnProperty.call(conditions,'value')||!Array.isArray(conditions.value))fail('MEMBERSHIP_UNAVAILABLE','Bộ lọc view chưa có dữ liệu tường minh.');
    return JSON.stringify(canonicalData(filter));
  }
  function designUrl(value){
    if(typeof value!=='string'||!value||value.length>8192||/[\x00-\x20\x7f\s]/.test(value))fail('STATUS_LINK','Design Link chưa có một URL rõ ràng; không dùng lại folder cũ.');
    var url;try{url=new URL(value);}catch(_){fail('STATUS_LINK','Design Link không phải URL hợp lệ; chưa dùng folder cũ.');}
    if(!/^https?:$/.test(url.protocol)||!url.hostname||url.username||url.password)fail('STATUS_LINK','Design Link phải là URL HTTP(S) không kèm tài khoản.');
    return value;
  }
  function designLink(text,raw){
    if(text==null)text='';
    if(typeof text!=='string'||text.length>8192||/[\x00-\x1f\x7f]/.test(text))fail('STATUS_LINK','Design Link chưa trả chuỗi hợp lệ.');
    // URL and text fields both use SDK segments. Never mistake an editable
    // hyperlink label (even one that looks like another URL) for its href.
    // Official IOpenUrlSegment: {type:'url',text:string,link:string}.
    if(raw==null||raw===''||Array.isArray(raw)&&raw.length===0){if(text!=='')fail('STATUS_LINK','Design Link chưa được SDK xác nhận; không dùng folder cũ.');return '';}
    if(typeof raw==='string'){var literal=designUrl(raw);if(text!==literal)fail('STATUS_LINK','Chuỗi Design Link không khớp giá trị SDK hiện tại; chưa dùng folder cũ.');return literal;}
    var segments=Array.isArray(raw)?raw:[raw];
    if(segments.length>100)fail('STATUS_LINK','Design Link có quá nhiều thành phần; chưa xác định được một folder.');
    var meaningful=[];
    segments.forEach(function(segment){
      if(!segment||typeof segment!=='object'||Array.isArray(segment)||typeof segment.text!=='string'||segment.text.length>8192||/[\x00-\x1f\x7f]/.test(segment.text))fail('STATUS_LINK','Định dạng Design Link chưa được xác nhận.');
      if(segment.type==='text'&&Object.keys(segment).sort().join(',')==='text,type'&&!segment.text.trim())return;
      meaningful.push(segment);
    });
    if(!meaningful.length&&text==='')return '';
    if(meaningful.length!==1)fail('STATUS_LINK','Design Link trống mơ hồ hoặc có nhiều liên kết; không chọn một link bất kỳ.');
    var segment=meaningful[0],keys=Object.keys(segment).sort().join(',');
    if(segment.type==='url'&&keys==='link,text,type')return designUrl(segment.link);
    if(segment.type==='text'&&keys==='text,type'){var plain=designUrl(segment.text);if(text!==plain)fail('STATUS_LINK','Văn bản Design Link không khớp giá trị SDK hiện tại.');return plain;}
    fail('STATUS_LINK','Design Link chưa có dạng URL/text được hỗ trợ; không dùng folder đã lưu từ trước.');
  }
  function createReader(adapter){
    if(!adapter||!Array.isArray(adapter.FIELDS)||!['workingStatus','designLink'].every(function(key){return adapter.FIELDS.some(function(f){return f[1]===key;});})||typeof adapter.mapFields!=='function')fail('SDK_VERSION','Thiếu ánh xạ Working Status/Design Link của bộ đọc Base.');
    function normalizeName(value){var text=String(value||'').trim();if(text.normalize)text=text.normalize('NFKC').normalize('NFD').replace(/[\u0300-\u036f]/g,'');return text.toLowerCase().replace(/đ/g,'d').replace(/[\u200b-\u200d\u2060\ufeff]/g,'').replace(/[_-]+/g,' ').replace(/\s*\/\s*/g,'/').replace(/^[\s*:]+|[\s*:]+$/g,'').replace(/\s+/g,' ');}
    // Reuse the adapter's declared labels/aliases and exact explicit-ID
    // preference, but resolve only these two cells. An unrelated SKU/Name
    // mapping error or unreadable Design Link cannot freeze Working Status.
    function mapCurrent(fields,mapping){
      function resolve(key){
        var definition=adapter.FIELDS.filter(function(f){return f[1]===key;})[0],manual=mapping&&mapping[key],matches;
        if(manual){if(!id(manual))fail('FIELD_MAPPING','ID cột đã chọn chưa hợp lệ.');matches=fields.filter(function(f){return f.id===manual;});}
        else{
          var aliases=Array.isArray(definition[2])?definition[2]:[definition[0]];
          matches=fields.filter(function(f){return aliases.some(function(alias){return normalizeName(alias)===normalizeName(f.name);});});
          var exact=matches.filter(function(f){return normalizeName(f.name)===normalizeName(definition[0]);});if(exact.length)matches=exact;
          if(!matches.length&&Array.isArray(definition[3]))matches=fields.filter(function(f){return definition[3].some(function(alias){return normalizeName(alias)===normalizeName(f.name);});});
        }
        if(matches.length!==1||!id(matches[0].id))fail(matches.length>1?'FIELD_AMBIGUOUS':'FIELD_MISSING','Chưa xác định được một cột '+definition[0]+'.');return matches[0].id;
      }
      var working=resolve('workingStatus'),link='';try{link=resolve('designLink');}catch(error){if(!/^FIELD_/.test(error.code||''))throw error;}
      return{workingStatus:working,designLink:link===working?'':link};
    }
    function mappingIdentity(value){return JSON.stringify({workingStatus:value&&value.workingStatus,designLink:value&&value.designLink});}
    function unavailableCell(error){
      // Exact bundled SDK ErrorCode values; never infer from exception text.
      var codes=[10214997,10214998,10214999,10216997,10216999],names=['RecordPermissionDeniedError','RecordNotFoundError','RecordUnknownError','CellPermissionDeniedError','CellUnknownError'];
      return !!error&&(codes.indexOf(error.code)>=0||names.indexOf(error.code)>=0);
    }
    return async function readRecordStatuses(sdk,options){
      options=options||{};var job=request(options.statusRequest),off=[],dirty=false,closed=false,timer,rejectTimeout,readError=null,count=0,phase='initializing',membershipIds=null,membershipView=null,membershipStamp='';
      var membershipNow=typeof options.now==='function'?options.now:Date.now,membershipStarted=0,membershipDeadline=0,membershipExpired=false;
      var membershipBudget=typeof options.membershipTimeoutMs==='number'&&isFinite(options.membershipTimeoutMs)&&options.membershipTimeoutMs>0?Math.min(5000,options.membershipTimeoutMs):1500;
      var timeout=typeof options.timeoutMs==='number'&&isFinite(options.timeoutMs)&&options.timeoutMs>0?options.timeoutMs:110000;
      var timedOut=new Promise(function(_,reject){rejectTimeout=reject;});timedOut.catch(function(){});
      timer=setTimeout(function(){var e=new Error('Base chưa trả Working Status đúng hạn. Chưa xác nhận đơn để tránh làm trùng.');e.code='READ_TIMEOUT';readError=readError||e;rejectTimeout(readError);},timeout);
      function check(){if(readError)throw readError;if(typeof options.checkCurrent==='function')try{options.checkCurrent();}catch(error){readError=error;throw error;}}
      function guard(work){check();var operation=Promise.resolve().then(function(){check();return typeof work==='function'?work():work;}),awaited=typeof options.parentAwait==='function'?options.parentAwait(operation):operation;return Promise.race([timedOut,awaited]).then(function(value){check();return value;},function(error){check();throw error;});}
      function currentSelection(optional){
        var operation;
        if(typeof options.sourceGuard==='function'){
          if(!reader||typeof reader.checkedScopedResult!=='function')fail('SDK_VERSION','Thiếu bộ xác minh nguồn đọc được chỉ định.');
          operation=Promise.resolve().then(function(){check();return options.sourceGuard();}).then(function(value){
            check();var actual=reader.checkedScopedResult(value),source=cleanSource({url:actual.url,tableId:actual.selected.tableId,viewId:actual.selected.viewId});
            if(!sameSource(source,job.source))changed();return actual.selected;
          });
        }else operation=sdkCall('selection',function(){return sdk.base.getSelection();});
        if(optional)trackMembership(sdk,operation);return optional?operation:guard(operation);
      }
      function changed(){fail('VIEW_CHANGED','Base, view, ánh xạ hoặc Working Status đã thay đổi trong lúc kiểm tra. Chưa dùng dữ liệu cũ.');}
      function mark(){dirty=true;}
      function mapping(){return typeof options.getMapping==='function'?options.getMapping():options.mapping;}
      async function actual(sel,optional){check();var promise=sdkCall('source-url',function(){return sdk.bridge.getBitableUrl({tableId:sel.tableId,viewId:sel.viewId});});if(optional)trackMembership(sdk,promise);var url=optional?await promise:await guard(promise);check();return cleanSource({url:url,tableId:sel.tableId,viewId:sel.viewId});}
      function watch(target,name,fn){if(target&&typeof target[name]==='function')try{off.push(target[name](fn));}catch(error){throw sdkError('event-subscription',error);}}
      async function progress(nextPhase){phase=nextPhase;check();if(typeof options.onProgress==='function')try{await guard(function(){return options.onProgress({phase:phase,readRecords:count});});}catch(error){readError=readError||error;throw readError;}}
      function membershipRemaining(){
        var stamp=membershipNow(),remaining=membershipDeadline-stamp;
        if(membershipExpired||!membershipDeadline||stamp<membershipStarted||remaining<=0){
          membershipExpired=true;membershipIds=null;membershipView=null;membershipStamp='';
          fail('MEMBERSHIP_UNAVAILABLE','Chưa đọc đủ danh sách của view trong lượt kiểm tra; không suy đoán đơn đã rời view.');
        }
        return remaining;
      }
      async function membershipAwait(action){
        // One aggregate optional budget, including the source/schema checks
        // around pages. A slow optional call must not postpone status cells
        // by another fresh timeout at every page or final view validation.
        check();var timeoutTimer,remaining=membershipRemaining();
        if(membershipPending.has(sdk)){membershipExpired=true;membershipIds=null;membershipView=null;membershipStamp='';fail('MEMBERSHIP_UNAVAILABLE','Lượt đọc danh sách view trước chưa kết thúc; không dùng lại membership cũ.');}
        var expired=new Promise(function(_,reject){timeoutTimer=setTimeout(function(){membershipExpired=true;membershipIds=null;membershipView=null;membershipStamp='';var e=new Error('Chưa đọc đủ danh sách của view trong lượt kiểm tra; không suy đoán đơn đã rời view.');e.code='MEMBERSHIP_UNAVAILABLE';reject(e);},remaining);});
        // SDK calls cannot be aborted by Promise.race. Keep only a bare token
        // until the original optional operation settles, across per-job readers.
        // Later jobs skip membership, never reuse its old data or add hung RPCs.
        var operation=trackMembership(sdk,Promise.resolve().then(function(){check();membershipRemaining();return action();}));
        try{var result=await guard(Promise.race([operation,expired]));membershipRemaining();return result;}finally{clearTimeout(timeoutTimer);}
      }
      async function globalBoundary(optional){
        try{
          check();if(closed||dirty)changed();
          // Promise.all is fail-fast: a rejected sibling must not release the
          // fence while another raw SDK RPC is still unanswered.
          var selectionPromise=currentSelection(optional);
          var fieldsPromise=sdkCall('field-meta',function(){return table.getFieldMetaList();});if(optional)trackMembership(sdk,fieldsPromise);
          var promise=Promise.all([selectionPromise,fieldsPromise]),current=optional?await promise:await guard(promise),selection=selected(current[0]);
          if(closed||dirty||!sameSelection(initial,selection)||schemaSignature(current[1])!==signature||!sameSource(await actual(selection,optional),job.source))changed();
        }catch(error){if(error&&(/^(?:READ_TIMEOUT|READ_CANCELLED)$/.test(error.code||'')||typeof error.operation==='string'))throw error;changed();}
      }
      async function viewStamp(view){
        var meta=await membershipAwait(function(){return sdkCall('view-meta',function(){return typeof view.getMeta==='function'?view.getMeta():table.getViewMetaById(initial.viewId);});});
        if(!meta||typeof meta!=='object'||Array.isArray(meta)||meta.id!==initial.viewId)fail('MEMBERSHIP_UNAVAILABLE','SDK chưa xác nhận metadata của đúng view.');
        function metadataFilter(){
          var property=Object.getOwnPropertyDescriptor(meta,'property'),value=property&&Object.prototype.hasOwnProperty.call(property,'value')&&property.value;
          var defined=value&&typeof value==='object'&&!Array.isArray(value)&&Object.getOwnPropertyDescriptor(value,'filterInfo');
          if(!defined||!Object.prototype.hasOwnProperty.call(defined,'value'))fail('MEMBERSHIP_UNAVAILABLE','SDK chưa trả bộ lọc tường minh; không suy đoán đơn đã rời view.');
          return defined.value;
        }
        var filter;
        if(typeof view.getFilterInfo==='function')try{filter=await membershipAwait(function(){return sdkCall('view-filter',function(){return view.getFilterInfo();});});}
        catch(error){
          // Only the SDK's explicit unsupported-view-filter result permits
          // this equivalent fresh metadata path. Permission, unknown errors,
          // timeouts and incomplete metadata never certify absence.
          if(!reader||typeof reader.isSDKUnsupported!=='function'||!reader.isSDKUnsupported(error,10215996))throw error;
          filter=metadataFilter();
        }
        else filter=metadataFilter();
        var signed=canonicalData(meta),proofMeta={};Object.keys(signed).forEach(function(key){if(key!=='name')Object.defineProperty(proofMeta,key,{value:signed[key],enumerable:true});});
        return JSON.stringify({meta:proofMeta,filter:explicitFilterSignature(filter)});
      }
      function membershipFailure(error){if(error&&/^(?:VIEW_CHANGED|READ_TIMEOUT|READ_CANCELLED)$/.test(error.code||''))throw error;membershipIds=null;}
      async function viewBoundary(){
        if(!membershipView)return;
        try{if(await viewStamp(membershipView)!==membershipStamp)changed();}catch(error){membershipFailure(error);}
      }
      async function readMembership(){
        // Only complete exact-view pagination can certify absence. The legacy
        // getVisibleRecordIdList API is capped at 200 and is never a fallback.
        if(typeof table.getViewById!=='function'||membershipPending.has(sdk))return;
        membershipStarted=membershipNow();membershipDeadline=membershipStarted+membershipBudget;
        try{
          await membershipAwait(function(){return globalBoundary(true);});
          var view=await membershipAwait(function(){return sdkCall('view',function(){return table.getViewById(initial.viewId);});});
          if(!view||typeof view.getVisibleRecordIdListByPage!=='function'||typeof view.getMeta!=='function'&&typeof table.getViewMetaById!=='function')return;
          if(view.id!==undefined&&view.id!==initial.viewId||view.tableId!==undefined&&view.tableId!==initial.tableId)changed();
          membershipStamp=await viewStamp(view);membershipView=view;
          var ids=Object.create(null),tokens=Object.create(null),pageToken,total=null,seen=0;
          for(var pages=0;pages<26;pages++){
            await membershipAwait(function(){return globalBoundary(true);});if(await viewStamp(view)!==membershipStamp)changed();
            var params={pageSize:200};if(pageToken!==undefined)params.pageToken=pageToken;
            var page=await membershipAwait(function(){return sdkCall('visible-records',function(){return view.getVisibleRecordIdListByPage(params);});});
            await membershipAwait(function(){return globalBoundary(true);});if(await viewStamp(view)!==membershipStamp)changed();
            if(!page||!Array.isArray(page.recordIds)||page.recordIds.length>200||typeof page.hasMore!=='boolean'||!Number.isSafeInteger(page.total)||page.total<0||page.total>5000)fail('MEMBERSHIP_UNAVAILABLE','Danh sách view chưa đầy đủ hoặc vượt giới hạn.');
            if(total===null)total=page.total;else if(total!==page.total)changed();
            for(var recordIndex=0;recordIndex<page.recordIds.length;recordIndex++){
              var record=Object.getOwnPropertyDescriptor(page.recordIds,String(recordIndex)),recordId=record&&record.value;
              if(!record||!Object.prototype.hasOwnProperty.call(record,'value')||!id(recordId)||ids[recordId])fail('MEMBERSHIP_UNAVAILABLE','ID của view trống, trùng hoặc chưa hợp lệ.');ids[recordId]=true;seen++;
            }
            if(seen>total||seen>5000)fail('MEMBERSHIP_UNAVAILABLE','Số dòng của view chưa khớp.');
            if(!page.hasMore){if(seen!==total)fail('MEMBERSHIP_UNAVAILABLE','Chưa nhận đủ view; không xác nhận đơn vắng mặt.');membershipIds=ids;return;}
            if(!page.recordIds.length||!Number.isSafeInteger(page.pageToken)||page.pageToken<0||tokens[page.pageToken])fail('MEMBERSHIP_UNAVAILABLE','Mã phân trang của view trống, lặp hoặc chưa hợp lệ.');
            tokens[page.pageToken]=true;pageToken=page.pageToken;
          }
          fail('MEMBERSHIP_UNAVAILABLE','Danh sách view vượt số trang cho phép.');
        }catch(error){membershipFailure(error);}
        if(!membershipExpired){try{await membershipAwait(function(){return globalBoundary(true);});}catch(error){membershipFailure(error);}}
      }
      try{
        var initial=selected(await currentSelection()),before=await actual(initial);
        if(!sameSource(before,job.source))changed();
        var table=await guard(function(){return sdkCall('table',function(){return sdk.base.getTableById(initial.tableId);});});
        if(!table||typeof table.getCellString!=='function'||typeof table.getFieldMetaList!=='function')fail('SDK_VERSION','Base SDK chưa hỗ trợ đọc Working Status theo Record ID.');
        TABLE_EVENTS.forEach(function(name){watch(table,name,mark);});watch(sdk.base,'onPermissionChange',mark);
        watch(sdk.base,'onSelectionChange',function(){
          // Scoped requests prove their explicit source at normal boundaries
          // and final validation. Foreground-selection noise must not launch
          // overlapping sourceGuard RPCs or exhaust pinned-source slots.
          if(typeof options.sourceGuard==='function')return;
          Promise.resolve().then(function(){if(closed)return null;check();return currentSelection();}).then(function(value){if(!closed&&!sameSelection(initial,selected(value)))mark();}).catch(mark);
        });
        await progress('metadata');var fields=await guard(function(){return sdkCall('field-meta',function(){return table.getFieldMetaList();});}),signature=schemaSignature(fields),initialMapping=mapping(),mapped=mapCurrent(fields,initialMapping),field=mapped.workingStatus,linkField=mapped.designLink;
        var mapSignature=JSON.stringify(mapped),mappingStamp=mappingIdentity(initialMapping),records=[];await progress('reading');await readMembership();
        for(var start=0;start<job.recordIds.length;start+=20){
          if(dirty)changed();
          var ids=job.recordIds.slice(start,start+20),values=await guard(function(){return Promise.all(ids.map(async function(recordId){
            try{
            // Each of the <=20 workers has only ONE SDK cell call in flight.
            // Event/source/schema guards make the two mapped cells one proof.
            var status=await guard(function(){return sdkCall('cell-string',function(){return table.getCellString(field,recordId);});});
            if(closed||dirty)changed();
            if(!linkField||typeof table.getCellValue!=='function')return {workingStatus:status,designLink:''};
            var text=await guard(function(){return sdkCall('cell-string',function(){return table.getCellString(linkField,recordId);});});
            if(closed||dirty)changed();
            var raw=await guard(function(){return sdkCall('cell-value',function(){return table.getCellValue(linkField,recordId);});});
            if(closed||dirty)changed();
            var link='';try{link=designLink(text,raw);}catch(error){if(error.code!=='STATUS_LINK')throw error;}
            return {workingStatus:status,designLink:link};
            }catch(error){if(closed||dirty)changed();if(unavailableCell(error))return{workingStatus:'',designLink:''};throw error;}
          }));});
          if(dirty)changed();
          for(var i=0;i<ids.length;i++){
            var value=values[i].workingStatus;if(value==null)value='';
            if(typeof value!=='string'||value.length>256||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(value))fail('STATUS_CELL','Working Status chưa trả chuỗi hợp lệ; không tự coi đơn đã hoàn tất.');
            records.push({recordId:ids[i],workingStatus:value,designLink:values[i].designLink,viewMembership:'unknown'});
          }
          count=records.length;await progress('reading');
        }
        await progress('validating');var final=await guard(function(){return Promise.all([currentSelection(),sdkCall('field-meta',function(){return table.getFieldMetaList();})]);}),finalSelection=selected(final[0]),after=await actual(finalSelection);
        var finalMapping=mapping();
        if(dirty||!sameSelection(initial,finalSelection)||!sameSource(after,job.source)||schemaSignature(final[1])!==signature||mappingIdentity(finalMapping)!==mappingStamp||JSON.stringify(mapCurrent(final[1],finalMapping))!==mapSignature)changed();
        await viewBoundary();await globalBoundary();if(closed||dirty||mappingIdentity(mapping())!==mappingStamp)changed();
        records.forEach(function(record){record.viewMembership=membershipIds?(membershipIds[record.recordId]?'in':'out'):'unknown';});
        await progress('sending');check();if(dirty)changed();
        return{version:3,kind:'record-statuses',source:{url:after.url,tableId:after.tableId,viewId:after.viewId},records:records};
      }catch(error){var wrapped=sdkError('',error);wrapped.phase=phase;wrapped.readRecords=count;throw wrapped;}finally{closed=true;clearTimeout(timer);off.forEach(function(stop){try{if(typeof stop==='function')stop();}catch(_){}});}
    };
  }
  function createObserver(options){
    options=options||{};var state=null,generation=0,timer=null,configTimer=null,off=[],initialAttempt=0,set=options.setTimeout||setTimeout,clear=options.clearTimeout||clearTimeout;
    function stop(){var owner=state;generation++;state=null;if(timer!==null)clear(timer);if(configTimer!==null)clear(configTimer);timer=null;configTimer=null;var previous=off;off=[];previous.forEach(function(fn){try{if(typeof fn==='function')fn();}catch(_){}});if(typeof options.onStop==='function')options.onStop(owner);}
    function live(owner){var current=typeof options.getState==='function'?options.getState():null;return !!owner&&state===owner&&current&&current.connected===true&&!current.paused&&!current.forgetting&&current.connection===owner.connection&&current.generation===owner.generation&&current.instance===owner.instance;}
    function terminal(error){return !!error&&['AUTH','REVOKED','CLIENT_VERSION'].indexOf(error.code)>=0;}
    function metadataWork(sdk,phase,start){
      var phases=observerRawPending.get(sdk);if(!phases){phases={source:new Set(),table:new Set(),configuration:new Set()};observerRawPending.set(sdk,phases);}var bucket=phases[phase];
      if(bucket.size>=2){var error=new Error('SDK chưa kết thúc hai lượt metadata cũ; đang chờ Base phục hồi.');error.code=phase==='source'?'SDK_OBSERVER_SOURCE_TIMEOUT':phase==='table'?'SDK_OBSERVER_TABLE_TIMEOUT':'SDK_OBSERVER_CONFIG_TIMEOUT';error.phase='initializing';error.readRecords=0;return Promise.reject(error);}
      var operation=Promise.resolve().then(start);bucket.add(operation);function settled(){bucket.delete(operation);}operation.then(settled,settled);return operation;
    }
    function own(value,key){var descriptor=value&&typeof value==='object'&&Object.getOwnPropertyDescriptor(value,key);return descriptor&&Object.prototype.hasOwnProperty.call(descriptor,'value')?descriptor.value:undefined;}
    function hint(name,event){
      if(typeof options.eventHint==='function')return options.eventHint(name,event);
      var kind={onRecordModify:'record-modify',onRecordAdd:'record-add',onRecordDelete:'record-delete',onFieldAdd:'field',onFieldModify:'field',onFieldDelete:'field',onSelectionChange:'selection',onPermissionChange:'permission'}[name]||'unknown',result={recordIds:[],fieldIds:[],kinds:[kind],full:!/^record-/.test(kind)};
      function ids(data,keys,target,limit){keys.forEach(function(key){var value=own(data,key);if(value===undefined)return;var list=Array.isArray(value)?value:[value];if(list.length>limit){result.full=true;return;}for(var i=0;i<list.length;i++){var item=own(list,String(i));if(!id(item)){result.full=true;continue;}if(target.indexOf(item)<0){if(target.length>=limit)result.full=true;else target.push(item);}}});}
      [event,own(event,'data')].forEach(function(data){if(!data||typeof data!=='object'||Array.isArray(data))return;ids(data,['recordId','recordIds','recordIdList'],result.recordIds,5000);ids(data,['fieldId','fieldIds','fieldIdList'],result.fieldIds,1000);});
      if(/^record-/.test(kind)&&!result.recordIds.length)result.full=true;return result;
    }
    function empty(){return{recordIds:[],fieldIds:[],kinds:[],full:false};}
    function merge(target,change){['recordIds','fieldIds','kinds'].forEach(function(key){var limit=key==='recordIds'?5000:key==='fieldIds'?1000:10;(change[key]||[]).forEach(function(value){if(target[key].indexOf(value)<0){if(target[key].length>=limit)target.full=true;else target[key].push(value);}});});target.full=target.full||change.full;return target;}
    function schedule(owner,delay){if(!live(owner)||timer!==null||owner.sending||!owner.pending)return;timer=set(function(){timer=null;if(!live(owner)||owner.sending)return;var batch=owner.pending,currentSource=owner.currentSource;owner.pending=null;owner.currentSource=null;owner.sending=true;var body={instance:owner.instance,source:{url:owner.source.url,tableId:owner.source.tableId,viewId:owner.source.viewId},dirty:batch};if(currentSource)body.currentSource=currentSource;owner.sendPromise=Promise.resolve().then(function(){if(live(owner))return options.send(body);}).catch(function(error){if(live(owner)){owner.pending=merge(owner.pending||empty(),batch);if(currentSource&&!owner.currentSource)owner.currentSource=currentSource;if(typeof options.onError==='function')options.onError(error);}}).then(function(){owner.sending=false;if(live(owner))schedule(owner,250);});},delay===undefined?250:delay);}
    async function readiness(owner,ready){
      if(!live(owner))return false;if(!ready){owner.ready=false;if(owner.unavailableSent)return true;}
      var change={recordIds:[],fieldIds:[],kinds:[ready?'ready':'unavailable'],full:!ready};
      if(!ready&&typeof options.onDirty==='function')options.onDirty(change);
      if(owner.sendPromise)try{await owner.sendPromise;}catch(_){}
      if(!live(owner))return false;owner.sending=true;
      var body={instance:owner.instance,source:{url:owner.source.url,tableId:owner.source.tableId,viewId:owner.source.viewId},dirty:change,eventReady:ready};
      if(!ready&&owner.currentSource)body.currentSource=owner.currentSource;
      owner.sendPromise=Promise.resolve().then(function(){if(live(owner))return options.send(body);});
      try{await owner.sendPromise;if(!live(owner))return false;owner.ready=ready;owner.unavailableSent=!ready;return true;}finally{owner.sending=false;if(live(owner))schedule(owner,250);}
    }
    function invalidate(change,currentSource){var owner=state;if(!live(owner)){stop();return;}change=change||{recordIds:[],fieldIds:[],kinds:['unknown'],full:true};if(typeof options.onDirty==='function')options.onDirty(change);owner.pending=merge(owner.pending||empty(),change);if(currentSource)owner.currentSource=currentSource;schedule(owner);}
    function sourceHint(owner){
      if(!live(owner))return Promise.resolve();if(owner.sourceBusy)return owner.sourcePromise;owner.sourceBusy=true;var job=++owner.sourceJob;
      var raw=metadataWork(owner.sdk,'source',function(){return options.getSource();});raw.then(function(){if(job===owner.sourceJob)owner.sourceBusy=false;},function(){if(job===owner.sourceJob)owner.sourceBusy=false;});
      var wait=typeof options.awaitMetadata==='function'?options.awaitMetadata:function(value){return value;};
      owner.sourcePromise=Promise.resolve(wait(raw)).then(function(value){if(!live(owner))return;value=value&&value.selected?{url:value.url,tableId:value.selected.tableId,viewId:value.selected.viewId}:value;try{value=cleanSource(value);}catch(_){invalidate({recordIds:[],fieldIds:[],kinds:['selection'],full:true});return;}if(!sameSource(owner.source,value))invalidate({recordIds:[],fieldIds:[],kinds:['selection'],full:true},value);}).catch(function(error){if(live(owner)){owner.sourceBusy=false;if(typeof options.onMetadataFailure==='function')options.onMetadataFailure(error);invalidate({recordIds:[],fieldIds:[],kinds:['selection'],full:true});}});return owner.sourcePromise;
    }
    function scheduleConfiguration(owner,delay){if(!live(owner))return;if(configTimer!==null)clear(configTimer);configTimer=set(function(){configTimer=null;if(live(owner))reconcile(owner);},delay);}
    function reconcile(owner,initial){
      if(!live(owner)||typeof options.configurationSignature!=='function')return;
      if(owner.configBusy)return owner.configPromise;owner.configBusy=true;var job=++owner.configJob,deadline=Date.now()+5000,initialWait=initial&&owner.initialWait;
      var context={owner:owner,table:owner.table,isCurrent:function(){return live(owner)&&job===owner.configJob&&!owner.configExpired;}};
      owner.configExpired=false;
      function wait(value){if(initialWait)return initialWait(value,'observer_configuration');var remaining=deadline-Date.now();if(remaining<=0){var error=new Error('Base chưa xác nhận cấu hình view đúng hạn.');error.code='SDK_OBSERVER_CONFIG_TIMEOUT';return Promise.reject(error);}return typeof options.awaitMetadata==='function'?options.awaitMetadata(value,remaining,'observer_configuration'):value;}
      var raw=metadataWork(owner.sdk,'configuration',function(){return options.configurationSignature(owner.sdk,owner.source,wait,context);});
      owner.configPromise=Promise.resolve(wait(raw)).then(async function(signature){if(!live(owner)||job!==owner.configJob)return false;if(typeof signature!=='string')throw Object.assign(new Error('SDK chưa xác nhận cấu hình view.'),{code:'VIEW_CONFIG'});if(owner.configuration!==null&&(signature!==owner.configuration||owner.configUnavailable)||owner.configUnavailable)invalidate({recordIds:[],fieldIds:[],kinds:['view'],full:true});owner.configuration=signature;owner.configError=null;var recovered=owner.configUnavailable;owner.configUnavailable=false;owner.configAttempt=0;if(options.requireEvents&&recovered&&!owner.ready&&!await readiness(owner,true))return false;return true;}).catch(async function(error){if(!live(owner)||job!==owner.configJob)return false;owner.configExpired=true;owner.configError=error;if(terminal(error)){stop();if(typeof options.onError==='function')options.onError(error);if(initial)throw error;return false;}owner.ready=false;if(!owner.configUnavailable)invalidate({recordIds:[],fieldIds:[],kinds:['view'],full:true});owner.configUnavailable=true;owner.configAttempt++;if(typeof options.onMetadataFailure==='function')options.onMetadataFailure(error,context);if(options.requireEvents){try{await readiness(owner,false);}catch(sendError){if(terminal(sendError)){stop();if(typeof options.onError==='function')options.onError(sendError);if(initial)throw sendError;return false;}}}await sourceHint(owner);if(initial)throw error;return false;}).finally(function(){if(live(owner)&&job===owner.configJob){owner.configBusy=false;owner.configPromise=null;scheduleConfiguration(owner,owner.configUnavailable?[1000,2000,4000,5000][Math.min(Math.max(owner.configAttempt-1,0),3)]:5000);}});
      return owner.configPromise;
    }
    async function observe(sdk,source,instance,initialOptions){
      source=cleanSource(source);if(typeof instance!=='string'||!/^[a-f0-9]{32}$/.test(instance))fail('STATUS_INSTANCE','Thiếu phiên xác nhận Working Status.');
      var current=options.getState();
      if(state&&live(state)&&state.instance===instance&&sameSource(state.source,source)){if(state.initialization)return state.initialization;if(!options.requireEvents||state.ready===true)return true;if(state.listenersReady){var existing=state,recovered=await reconcile(existing,false);if(!recovered&&existing.configError)throw existing.configError;return recovered;}}
      stop();var mine=generation;
      if(!current||current.connected!==true||current.paused||current.forgetting||!current.connection||current.instance!==instance)return false;
      var timeout=initialOptions&&initialOptions.timeoutMs!==undefined?initialOptions.timeoutMs:20000;
      if(!Number.isFinite(timeout)||timeout<=0||timeout>30000)fail('SDK_EVENTS','Thời gian khởi tạo theo dõi Base chưa hợp lệ.');
      var deadline=Date.now()+timeout;
      var owner={source:source,instance:instance,connection:current.connection,generation:current.generation,sdk:sdk,table:null,pending:null,sending:false,sendPromise:null,currentSource:null,sourceBusy:false,sourceJob:0,sourcePromise:null,configBusy:false,configJob:0,configAttempt:0,configPromise:null,configExpired:false,configError:null,configuration:null,configUnavailable:false,ready:false,unavailableSent:false,listenersReady:false};state=owner;
      var wait=typeof options.awaitMetadata==='function'?options.awaitMetadata:function(value){return value;};
      owner.initialWait=function(work,context){
        var remaining=deadline-Date.now();
        function expired(){var error=new Error('Base chưa khởi tạo theo dõi view đầy đủ đúng hạn.');error.code=context==='observer_source'?'SDK_OBSERVER_SOURCE_TIMEOUT':context==='observer_table'?'SDK_OBSERVER_TABLE_TIMEOUT':'SDK_OBSERVER_CONFIG_TIMEOUT';error.phase='initializing';error.readRecords=0;return error;}
        if(remaining<=0)return Promise.reject(expired());
        var deadlineTimer,operation;
        try{operation=wait(typeof work==='function'?work():work,remaining,context);}catch(error){return Promise.reject(error);}
        var timeoutPromise=new Promise(function(_,reject){deadlineTimer=setTimeout(function(){reject(expired());},remaining);});
        return Promise.race([operation,timeoutPromise]).finally(function(){clearTimeout(deadlineTimer);});
      };
      owner.initialization=(async function(){
        try{
          var actualSource=await owner.initialWait(function(){return metadataWork(sdk,'source',function(){return options.getSource();});},'observer_source');
          var value=actualSource&&actualSource.selected?{url:actualSource.url,tableId:actualSource.selected.tableId,viewId:actualSource.selected.viewId}:actualSource;
          if(mine!==generation||!live(owner))return false;if(!sameSource(source,value)){invalidate({recordIds:[],fieldIds:[],kinds:['selection'],full:true},cleanSource(value));fail('VIEW_CHANGED','SDK chưa xác nhận đúng view khi khởi tạo theo dõi; đang chờ nguồn view ổn định.');}
          var table=await owner.initialWait(function(){return metadataWork(sdk,'table',function(){return sdkCall('table',function(){return sdk.base.getTableById(source.tableId);});});},'observer_table');if(mine!==generation||!live(owner))return false;
          owner.table=table;
          if(options.requireEvents&&(!TABLE_EVENTS.concat(['onFieldAdd']).every(function(name){return table&&typeof table[name]==='function';})||!['onSelectionChange','onPermissionChange'].every(function(name){return sdk.base&&typeof sdk.base[name]==='function';})||typeof options.configurationSignature!=='function'))fail('SDK_EVENTS','SDK chưa hỗ trợ đủ sự kiện record/cột/quyền và cấu hình view.');
          function attach(target,name,callback){var unsubscribe;try{unsubscribe=target[name](callback);}catch(error){throw sdkError('event-subscription',error);}if(typeof unsubscribe==='function')off.push(unsubscribe);else if(options.requireEvents)fail('SDK_EVENTS','SDK chưa xác nhận đăng ký sự kiện có thể hủy.');}
          TABLE_EVENTS.concat(['onFieldAdd']).forEach(function(name){if(table&&typeof table[name]==='function')attach(table,name,function(event){if(live(owner))invalidate(hint(name,event));});});
          ['onSelectionChange','onPermissionChange'].forEach(function(name){if(sdk.base&&typeof sdk.base[name]==='function')attach(sdk.base,name,function(event){if(!live(owner))return;if(name==='onSelectionChange')sourceHint(owner);else invalidate(hint(name,event));});});
          owner.listenersReady=true;
          if(options.requireEvents){if(!await reconcile(owner,true)||mine!==generation||!live(owner))return false;if(!await owner.initialWait(function(){return readiness(owner,true);},'observer_configuration'))return false;}
          else reconcile(owner);
          initialAttempt=0;return true;
        }catch(error){if(mine===generation){if(terminal(error)){stop();if(typeof options.onError==='function')options.onError(error);throw error;}owner.ready=false;if(typeof options.onMetadataFailure==='function')options.onMetadataFailure(error);if(options.requireEvents&&Date.now()<deadline)try{await owner.initialWait(function(){return readiness(owner,false);},'observer_configuration');}catch(sendError){if(terminal(sendError)){stop();if(typeof options.onError==='function')options.onError(sendError);}}if(mine===generation){if(owner.listenersReady){if(!owner.configUnavailable){owner.configUnavailable=true;owner.configAttempt++;scheduleConfiguration(owner,[1000,2000,4000,5000][Math.min(owner.configAttempt-1,3)]);}}else if(error&&error.code==='SDK_EVENTS')stop();else{owner.configUnavailable=true;initialAttempt++;if(configTimer!==null)clear(configTimer);configTimer=set(function(){configTimer=null;if(!live(owner))return;stop();observe(sdk,source,instance,initialOptions).catch(function(){});},[1000,2000,4000,5000][Math.min(initialAttempt-1,3)]);}}}throw error;}
        finally{owner.initialWait=null;owner.initialization=null;}
      })();
      return owner.initialization;
    }
    return{observe:observe,stop:stop,invalidate:invalidate};
  }
  return{createReader:createReader,createObserver:createObserver,validateRequest:request,designLink:designLink,sameSource:sameSource};
});
