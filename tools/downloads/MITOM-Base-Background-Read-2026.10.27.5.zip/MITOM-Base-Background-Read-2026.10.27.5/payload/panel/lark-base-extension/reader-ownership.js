/* R33: an iframe proves its own live SDK source; a parent can request a proof,
 * never supply credentials, rows, SDK selection or permission to reconnect. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.UOYReaderOwnership = api;
})(typeof window === 'undefined' ? null : window, function () {
  'use strict';
  var HEX32 = /^[a-f0-9]{32}$/, HEX64 = /^[a-f0-9]{64}$/;
  var ID = /^[A-Za-z0-9_-]{1,160}$/;
  var SPECTATOR = ['READER_BINDING_REQUIRED','READER_NOT_SELECTED','READER_BINDING_INVALID','READER_BINDING_EXPIRED'];
  var CODES = ['READER_BINDING_INVALID','READER_BINDING_EXPIRED','READER_SOURCE_CHANGED','READER_NOT_TRUSTED','READER_PAUSED','READER_BINDING_REJECTED','READER_BUSY','READER_UNAVAILABLE','READER_CANCELLED'];
  function fail(code) { var error = new Error(code); error.code = code; throw error; }
  function exact(value, keys) {
    return !!value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).sort().join(',') === keys.slice().sort().join(',');
  }
  function ticket(value, now) {
    if (!exact(value,['version','nonce','instance','requestId','expiresAt','baseIdentity','tableId','viewId','pageId']) || value.version !== 1 ||
        !HEX64.test(value.nonce || '') || !HEX32.test(value.instance || '') || !HEX32.test(value.requestId || '') || !HEX32.test(value.pageId || '') ||
        typeof value.tableId !== 'string' || !ID.test(value.tableId) || typeof value.viewId !== 'string' || !ID.test(value.viewId) ||
        typeof value.baseIdentity !== 'string' || !Number.isSafeInteger(value.expiresAt)) fail('READER_BINDING_INVALID');
    var url;
    try { url = new URL(value.baseIdentity); } catch (_) { fail('READER_BINDING_INVALID'); }
    if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash ||
        !/(?:^|\.)(?:larksuite\.com|feishu\.cn)$/.test(url.hostname) || !/^\/base\/[A-Za-z0-9_-]{1,100}$/.test(url.pathname) || url.origin + url.pathname !== value.baseIdentity) fail('READER_BINDING_INVALID');
    if (value.expiresAt <= now || value.expiresAt > now + 30000) fail('READER_BINDING_EXPIRED');
    return {version:1,nonce:value.nonce,instance:value.instance,requestId:value.requestId,expiresAt:value.expiresAt,baseIdentity:value.baseIdentity,tableId:value.tableId,viewId:value.viewId,pageId:value.pageId};
  }
  function create(options) {
    options = options || {};
    var win = options.window, random = options.crypto, now = options.now || Date.now;
    if (!win || !random || typeof random.getRandomValues !== 'function' || typeof options.getSource !== 'function' || typeof options.getTrust !== 'function' || typeof options.reconnect !== 'function' || typeof options.getState !== 'function' || typeof options.canonicalBase !== 'function') fail('READER_UNAVAILABLE');
    var bytes = random.getRandomValues(new Uint8Array(16)), documentNonce = Array.prototype.map.call(bytes,function (n) { return n.toString(16).padStart(2,'0'); }).join('');
    var generation = 0, disposed = false, spectator = false, active = null, commands = new Map();
    function allowed() { var state = options.getState(); return !disposed && state && state.paused !== true && state.forgetting !== true; }
    function check(mine) { if (disposed || mine !== generation) fail('READER_CANCELLED'); if (!allowed()) fail('READER_PAUSED'); }
    function parent(event) { return !disposed && win.parent && win.parent !== win && event.source === win.parent && typeof event.origin === 'string' && event.origin !== 'null'; }
    async function source(event, mine, binding) {
      // R72: the authenticated one-use ticket chooses a query scope, never a
      // fabricated SDK selection. getScopedSource independently verifies the
      // table/view through SDK; reconnect still proves this exact server nonce.
      var actual = binding && typeof options.getScopedSource === 'function' ? await options.getScopedSource(binding) : await options.getSource();
      check(mine);
      var base, origin;
      try { base = options.canonicalBase(actual.url); origin = new URL(actual.url).origin; } catch (_) { fail('READER_SOURCE_CHANGED'); }
      if (!base || !actual.selected || !ID.test(actual.selected.tableId || '') || !ID.test(actual.selected.viewId || '') || event.origin !== origin) fail('READER_SOURCE_CHANGED');
      var trust = options.getTrust(base), frameOrigin;
      try { frameOrigin = new URL(win.location.href).origin; } catch (_) { fail('READER_NOT_TRUSTED'); }
      if (!trust || trust.baseIdentity !== base || trust.version !== 2 || new URL(trust.endpoint).origin !== frameOrigin) fail('READER_NOT_TRUSTED');
      return {actual:actual,baseIdentity:base,tableId:actual.selected.tableId,viewId:actual.selected.viewId,origin:origin};
    }
    function post(event, value) { if (!disposed && parent(event)) event.source.postMessage(value,event.origin); }
    function result(event, commandId, value) { post(event,Object.assign({type:'uoy-reader-bind-result',version:1,commandId:commandId},value)); }
    function safe(error) { return CODES.indexOf(error && error.code) >= 0 ? error.code : 'READER_BINDING_REJECTED'; }
    function rejected(error, phase) { var code = safe(error); return {ok:false,code:code,readerDiagnostic:{version:1,phase:phase,code:code}}; }
    async function handle(event) {
      if (!parent(event)) return;
      var message = event.data;
      if (!message || (message.type !== 'uoy-reader-bind-probe' && message.type !== 'uoy-reader-bind')) return;
      var probe = message.type === 'uoy-reader-bind-probe';
      if (!exact(message,probe ? ['type','version','commandId'] : ['type','version','commandId','readerBinding']) || message.version !== 1 || !HEX32.test(message.commandId || '')) return;
      var mine = generation, verified;
      if (probe) {
        if (typeof options.getScopedSource === 'function') {
          // A readiness echo grants no source, credentials or read authority.
          // Do not await the foreground-selection RPC before accepting a
          // scoped ticket. The bind below independently checks SDK scope,
          // stored trust and the server's one-use nonce before reconnecting.
          try {
            check(mine);
            var origin = new URL(event.origin);
            if (origin.protocol !== 'https:' || origin.port || origin.origin !== event.origin || !/(?:^|\.)(?:larksuite\.com|feishu\.cn)$/.test(origin.hostname)) return;
          } catch (_) { return; }
          post(event,{type:'uoy-reader-bind-ready',version:1,commandId:message.commandId}); return;
        }
        try { verified = await source(event,mine); } catch (_) { return; }
        post(event,{type:'uoy-reader-bind-ready',version:1,commandId:message.commandId}); return;
      }
      var binding;
      try {
        check(mine); binding = ticket(message.readerBinding,now());
        // A valid-looking ticket from another embedding origin must not hold
        // the early reservation or start SDK work. SDK origin/trust checks
        // below still independently verify this exact source after the await.
        if (event.origin !== new URL(binding.baseIdentity).origin) fail('READER_SOURCE_CHANGED');
      } catch (error) { result(event,message.commandId,rejected(error,'ticket')); return; }
      var serialized = JSON.stringify(binding), existing = commands.get(message.commandId);
      if (existing) {
        if (existing.ticket !== serialized || existing.generation !== generation) { result(event,message.commandId,rejected({code:'READER_BINDING_INVALID'},'ticket')); return; }
        var repeated = await existing.promise;
        if (existing.generation === generation && !disposed && (repeated.ok === false || allowed())) result(event,message.commandId,repeated);
        return;
      }
      commands.forEach(function (entry, key) { if (entry.finished && entry.expiresAt <= now()) commands.delete(key); });
      if (active || commands.size >= 32) { result(event,message.commandId,rejected({code:'READER_BUSY'},'ticket')); return; }
      // Reserve before the first SDK await. Startup sm()/selection callbacks
      // must see this explicit bind while its scoped metadata is still pending;
      // otherwise an automatic ow() can advance Qn and cancel the valid proof.
      mine = ++generation; spectator = false;
      var operation = {ticket:binding,generation:mine,clientId:null,proof:null}; active = operation;
      var entry = {ticket:serialized,generation:mine,promise:null,expiresAt:binding.expiresAt,finished:false};
      entry.promise = (async function () {
        var phase = 'scope-before';
        try {
          check(mine);
          verified = await source(event,mine,binding);
          if (binding.baseIdentity !== verified.baseIdentity || binding.tableId !== verified.tableId || binding.viewId !== verified.viewId) fail('READER_SOURCE_CHANGED');
          ticket(binding,now());
          // Selection or explicit table/view metadata was obtained directly
          // from SDK. The entry uses this independently verified scope only
          // for reconnect; the parent cannot manufacture a selection proof.
          phase = 'reconnect';
          await options.reconnect(binding,verified.actual,{
            isCurrent:function () { return active === operation && mine === generation && allowed(); },
            prepare:function (connection) {
              check(mine);
              if (active !== operation || !connection || !HEX32.test(connection.clientId || '') ||
                  (operation.clientId && operation.clientId !== connection.clientId)) fail('READER_CANCELLED');
              operation.clientId = connection.clientId;
            }
          });
          check(mine);
          phase = 'scope-after';
          var finalSource = await source(event,mine,binding);
          if (finalSource.baseIdentity !== binding.baseIdentity || finalSource.tableId !== binding.tableId || finalSource.viewId !== binding.viewId) fail('READER_SOURCE_CHANGED');
          ticket(binding,now());
          phase = 'server-proof';
          var state = options.getState(), proof = operation.proof;
          if (!proof || !state.connection || state.connection.clientId !== proof.clientId || state.baseIdentity !== binding.baseIdentity || state.connected !== true) fail('READER_BINDING_REJECTED');
          spectator = false;
          return {ok:true};
        } catch (error) { return rejected(error,phase); }
        finally { entry.finished = true; if (active === operation) active = null; }
      })();
      commands.set(message.commandId,entry);
      var answer = await entry.promise;
      // A paused owner may still report a bounded refusal, never success.
      // Disposed or superseded documents cannot publish either outcome.
      if (mine === generation && !disposed && (answer.ok === false || allowed())) result(event,message.commandId,answer);
    }
    function headers(value) { return Object.assign({},value,{'X-Uoy-Reader-Document':documentNonce}); }
    async function readResponse(response, decode) {
      if (response.ok) return decode(response);
      // R20's decoder deliberately maps unknown errors to HTTP. Recognize only
      // the new ownership refusals here, without modifying its vendor bundle
      // or changing AUTH/REVOKED/EOF behavior and remembered trust handling.
      var text = Promise.resolve().then(function () { return response.text(); });
      var buffered = {ok:response.ok,status:response.status,text:function () { return text; }};
      try {
        var raw = await text, value = raw.length <= 65536 ? JSON.parse(raw) : null;
        if ((response.status === 403 || response.status === 409) && value && !Array.isArray(value) &&
            SPECTATOR.indexOf(value.error) >= 0) fail(value.error);
      } catch (error) {
        if (SPECTATOR.indexOf(error && error.code) >= 0) throw error;
      }
      return decode(buffered);
    }
    function hello(value, connection) {
      var body = Object.assign({},value,{readerDocument:documentNonce});
      if (active) {
        check(active.generation);
        var binding = ticket(active.ticket,now());
        // Only the staged reconnect can nominate its candidate. An old SDK
        // selection callback or in-flight bootstrap must never borrow proof.
        if (!connection || connection.clientId !== active.clientId || value.baseIdentity !== binding.baseIdentity) fail('READER_BUSY');
        body.readerBinding = binding;
      }
      return body;
    }
    function response(route, value, connection) {
      if (route !== '/v1/hello' || !active || !connection || connection.clientId !== active.clientId) return value;
      check(active.generation);
      var binding = active.ticket;
      if (!value || value.ok !== true || value.readerBindingAccepted !== true || value.readerDocument !== documentNonce || value.bindingRequestId !== binding.requestId || value.instance !== binding.instance) fail('READER_BINDING_REJECTED');
      active.proof = {clientId:connection.clientId}; return value;
    }
    function connectionError(error) { if (SPECTATOR.indexOf(error && error.code) >= 0) spectator = true; }
    function dispose() { if (disposed) return; disposed = true; generation++; active = null; win.removeEventListener('message',listener); }
    function listener(event) { void handle(event).catch(function () {}); }
    win.addEventListener('message',listener);
    return {headers:headers,readResponse:readResponse,hello:hello,response:response,connectionError:connectionError,isSpectator:function () { return spectator; },isBinding:function () { return !!active; },dispose:dispose};
  }
  return {create:create,validateTicket:ticket};
});
