/* Fresh, complete view reader. The bundled SDK remains the data authority. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.UOYLarkFreshViewReader = api;
})(typeof window === 'undefined' ? null : window, function () {
  'use strict';
  var MAX_RECORDS = 5000, MAX_BYTES = 8 * 1024 * 1024, MAX_CELL = 100000, viewCaches = new WeakMap(), configurationPending = new WeakMap(), sourceSlots = new WeakMap(), pinnedSourceSlots = new WeakMap(), configurationSlots = new WeakMap(), configurationHandles = new WeakMap();

  // Pairing is remembered. Incremental rows exist only in this iframe's memory,
  // scoped to the live connection/generation; never in browser storage.
  function isTransientConnectionError(error) {
    return !!error && ['NETWORK', 'EOF', 'SESSION_RESTARTED', 'CONNECT_BUSY'].indexOf(error.code) >= 0;
  }
  function isMetadataTimeout(error) {
    return !!error && ['SDK_TIMEOUT', 'SDK_SELECTION_TIMEOUT', 'SDK_SOURCE_URL_TIMEOUT', 'SDK_SELECTION_VERIFY_TIMEOUT'].indexOf(error.code) >= 0;
  }
  var METADATA_TIMEOUTS = {
    selection: ['SDK_SELECTION_TIMEOUT', 'Base chưa trả bảng/view đang chọn đúng hạn.'],
    source_url: ['SDK_SOURCE_URL_TIMEOUT', 'Base chưa trả URL của view đang chọn đúng hạn.'],
    selection_verify: ['SDK_SELECTION_VERIFY_TIMEOUT', 'Base chưa xác nhận lại view sau khi đọc URL đúng hạn.'],
    observer_source: ['SDK_OBSERVER_SOURCE_TIMEOUT', 'Base chưa xác nhận nguồn khi khởi tạo theo dõi view đúng hạn.'],
    observer_table: ['SDK_OBSERVER_TABLE_TIMEOUT', 'Base chưa trả bảng để theo dõi view đúng hạn.'],
    observer_configuration: ['SDK_OBSERVER_CONFIG_TIMEOUT', 'Base chưa xác nhận cấu hình và bộ lọc của view đúng hạn.']
  };
  function metadataTimeout(context) {
    var definition = METADATA_TIMEOUTS[context], error = new Error(definition ? definition[1] : 'Base chưa trả thông tin view kịp. Đang chờ Base sẵn sàng để nối lại Photoshop.');
    error.code = definition ? definition[0] : 'SDK_TIMEOUT';
    error.phase = 'initializing'; error.readRecords = 0; return error;
  }
  function awaitMetadata(promise, timeoutMs, signal, context) {
    var timer, abort;
    var timeout = new Promise(function (_, reject) {
      timer = setTimeout(function () {
        reject(metadataTimeout(context));
      }, timeoutMs || 5000);
    });
    var aborted = new Promise(function (_, reject) {
      abort = function () { var error = new Error('Đã hủy chờ thông tin Base.'); error.name = 'AbortError'; reject(error); };
      if (signal) { if (signal.aborted) abort(); else signal.addEventListener('abort', abort, { once: true }); }
    });
    return Promise.race([promise, timeout, aborted]).finally(function () { clearTimeout(timer); if (signal) signal.removeEventListener('abort', abort); });
  }
  function createMetadataGate() {
    var pending = [], generation = 0;
    return {
      wait: function (promise, timeoutMs, context, externalSignal) {
        var controller = new AbortController(); pending.push(controller);
        var abort = function () { controller.abort(); };
        if (externalSignal) { if (externalSignal.aborted) abort(); else externalSignal.addEventListener('abort', abort, { once: true }); }
        return awaitMetadata(promise, timeoutMs, controller.signal, context).finally(function () {
          if (externalSignal) externalSignal.removeEventListener('abort', abort);
          var index = pending.indexOf(controller); if (index >= 0) pending.splice(index, 1);
        });
      },
      generation: function () { return generation; },
      cancelAll: function () { generation++; var copy = pending.slice(); pending = []; copy.forEach(function (controller) { controller.abort(); }); }
    };
  }
  function createReconnectPolicy(options) {
    options = options || {};
    var timer = null, attempt = 0, set = options.setTimeout || setTimeout, clear = options.clearTimeout || clearTimeout;
    var delays = [1000, 2000, 4000, 5000];
    function allowed() { return typeof options.allowed !== 'function' || options.allowed(); }
    function cancel() { if (timer !== null) clear(timer); timer = null; }
    return {
      clear: cancel,
      reset: function () { cancel(); attempt = 0; },
      schedule: function (callback) {
        cancel();
        if (!allowed()) return false;
        var delay = delays[Math.min(attempt++, delays.length - 1)];
        timer = set(function () { timer = null; if (allowed()) callback(); }, delay);
        return true;
      }
    };
  }

  function fail(code, message) { var error = new Error(message); error.code = code; throw error; }
  var READ_ERROR_CODES = ['NO_VIEW', 'SDK_VERSION', 'CELL_FORMAT', 'CELL_LIMIT', 'FIELD_SCHEMA',
    'FIELD_MAPPING', 'FIELD_AMBIGUOUS', 'FIELD_REQUIRED', 'BASE_IDENTITY', 'VIEW_CHANGED',
    'VIEW_CONFIG', 'VIEW_CONFIG_BUSY', 'DIRTY_REQUEST', 'STATUS_REQUEST', 'FIELD_MISSING', 'STATUS_CELL', 'MEMBERSHIP_UNAVAILABLE', 'STATUS_INSTANCE', 'SDK_EVENTS', 'STATUS_LINK', 'PAGE_SCHEMA', 'RECORD_SCHEMA', 'READ_LIMIT', 'PAGE_INCOMPLETE', 'READ_TIMEOUT', 'SDK_TIMEOUT',
    'SDK_SELECTION_TIMEOUT', 'SDK_SOURCE_URL_TIMEOUT', 'SDK_SELECTION_VERIFY_TIMEOUT',
    'SDK_OBSERVER_SOURCE_TIMEOUT', 'SDK_OBSERVER_TABLE_TIMEOUT', 'SDK_OBSERVER_CONFIG_TIMEOUT', 'SDK_METADATA_STALLED', 'READ_CANCELLED', 'READ_CONTROL_STALE', 'READ_CONTROL_UNAVAILABLE'];
  var CONTROL_MESSAGES = {
    READ_CONTROL_STALE: 'Cầu nối local từ chối lượt đọc vì phiên hoặc nguồn view không còn khớp. Chưa nhận dữ liệu mới; bấm Nạp để xác nhận lại đúng view.',
    READ_CONTROL_UNAVAILABLE: 'Cầu nối local chưa xác nhận thao tác điều khiển lượt đọc. Chưa nhận dữ liệu mới; kiểm tra Panel và kết nối Chrome.'
  };
  function controlCategory(code) {
    if (['READ_CONTROL_STALE', 'STALE_REQUEST', 'READER_BINDING_REQUIRED', 'READER_NOT_SELECTED', 'READER_BINDING_INVALID', 'READER_BINDING_EXPIRED', 'READER_SOURCE_CHANGED', 'READER_BINDING_REJECTED'].indexOf(code) >= 0) return 'READ_CONTROL_STALE';
    if (['READ_CONTROL_UNAVAILABLE', 'HTTP', 'NETWORK', 'EOF', 'AUTH', 'REVOKED', 'CLIENT', 'CLIENT_VERSION', 'ORIGIN', 'SESSION_RESTARTED', 'CONNECT_BUSY', 'READER_PAUSED', 'READER_BUSY', 'READER_UNAVAILABLE'].indexOf(code) >= 0) return 'READ_CONTROL_UNAVAILABLE';
    return '';
  }
  var READ_PHASES = ['initializing', 'metadata', 'reading', 'validating', 'sending'];
  var SDK_OPERATIONS = ['selection', 'source-url', 'table', 'field-meta', 'view', 'view-meta', 'view-filter', 'visible-records', 'bulk-records', 'cell-string', 'cell-value', 'event-subscription'];
  var SDK_CATEGORY_MESSAGES = {
    SDK_NOT_LOADED: 'Base chưa tải xong bảng đang chọn. Đợi bảng tải xong rồi bấm Nạp lại.',
    SDK_PERMISSION: 'Base SDK từ chối quyền đọc bảng, view hoặc cột. Kiểm tra quyền của phần mở rộng Order trên Base này.',
    SDK_NOT_FOUND: 'Base SDK không còn tìm thấy bảng, view hoặc cột. Chọn lại view và kiểm tra ánh xạ cột.',
    SDK_UNSUPPORTED: 'Base SDK chưa hỗ trợ thao tác đọc này trên view hiện tại.',
    SDK_PARAMETER: 'Base SDK chưa chấp nhận tham số của thao tác đọc view.',
    SDK_HOST_NOT_READY: 'Cầu nối SDK của Base chưa đăng ký hoặc chưa sẵn sàng. Chưa xác nhận dữ liệu view.',
    SDK_UNKNOWN: 'Base SDK trả lỗi nội bộ khi đọc view. Chưa xác nhận dữ liệu.',
    SDK_LIMIT: 'Base SDK từ chối lượt đọc vì vượt giới hạn. Chưa xác nhận dữ liệu.',
    SDK_FAILURE: 'Base SDK chưa đọc được view. Chưa xác định nguyên nhân; không tự coi đây là lỗi quyền đọc.'
  };
  function sdkNumericCode(error) {
    var code = own(error, 'code');
    return Number.isInteger(code) && code >= 10200000 && code <= 10299999 ? code : null;
  }
  function sdkCategory(error) {
    var code = sdkNumericCode(error);
    if (code === 10212001) return 'SDK_NOT_LOADED';
    if (code === 10212003) return 'SDK_PERMISSION';
    if (code === 10214001) return 'SDK_LIMIT';
    // These are the bundled SDK's resource and host entity IDs. A host's
    // HostNotRegistered(997) is not a data-resource PermissionDenied(997).
    var data = [11, 12, 13, 14, 15, 16, 17], hosts = [89, 96, 97, 98, 99];
    for (var i = 0; i < data.length; i++) {
      var base = 10200000 + data[i] * 1000;
      if (code === base + 997) return 'SDK_PERMISSION';
      if (code === base + 998) return 'SDK_NOT_FOUND';
      if (code === base + 991 || code === base + 996) return 'SDK_UNSUPPORTED';
      if (code === base + 992) return 'SDK_PARAMETER';
      if (code === base + 993 || code === base + 994) return 'SDK_LIMIT';
      if (code === base + 999) return 'SDK_UNKNOWN';
    }
    for (var j = 0; j < hosts.length; j++) {
      var host = 10200000 + hosts[j] * 1000;
      if (code === host + 997) return 'SDK_HOST_NOT_READY';
      if (code === host + 998) return 'SDK_NOT_FOUND';
      if (code === host + 999) return 'SDK_UNKNOWN';
    }
    return 'SDK_FAILURE';
  }
  function isSDKUnsupported(error, numericCode) {
    var descriptor = error && typeof error === 'object' && Object.getOwnPropertyDescriptor(error, 'code'), code = own(error, 'code');
    if (descriptor) return Number.isInteger(numericCode) && code === numericCode || code === 'NOT_SUPPORTED' || code === 'NotSupportedError';
    return own(error, 'name') === 'NotSupportedError';
  }
  function tagSDKError(operation, error) {
    var code = own(error, 'code'), typed = READ_ERROR_CODES.indexOf(code) >= 0;
    var wrapped = new Error(typed && typeof own(error, 'message') === 'string' ? own(error, 'message') : SDK_CATEGORY_MESSAGES.SDK_FAILURE);
    if (typeof code === 'string' || typeof code === 'number') wrapped.code = code;
    else if (error && typeof error === 'object' && Object.getOwnPropertyDescriptor(error, 'code')) wrapped.code = undefined;
    if (own(error, 'name') === 'AbortError') wrapped.name = 'AbortError';
    else if (own(error, 'name') === 'NotSupportedError') wrapped.name = 'NotSupportedError';
    var previous = own(error, 'operation');
    if (SDK_OPERATIONS.indexOf(previous) >= 0) wrapped.operation = previous;
    else if (SDK_OPERATIONS.indexOf(operation) >= 0) wrapped.operation = operation;
    if (READ_PHASES.indexOf(own(error, 'phase')) >= 0) wrapped.phase = own(error, 'phase');
    if (Number.isInteger(own(error, 'readRecords')) && own(error, 'readRecords') >= 0 && own(error, 'readRecords') <= MAX_RECORDS) wrapped.readRecords = own(error, 'readRecords');
    return wrapped;
  }
  function safeSDKCall(operation, start) {
    return Promise.resolve().then(function () { return typeof start === 'function' ? start() : start; }).catch(function (error) { throw tagSDKError(operation, error); });
  }
  // Unknown SDK messages can include request arguments. Send only known reader
  // diagnostics and fixed SDK categories across the loopback boundary.
  function serializeReadError(error) {
    error = error || {};
    var rawCode = own(error, 'code'), typed = READ_ERROR_CODES.indexOf(rawCode) >= 0, control = controlCategory(rawCode);
    var code = control || (typed ? rawCode : sdkCategory(error));
    var message = control ? CONTROL_MESSAGES[control] : typed ? String(own(error, 'message') || 'Không đọc được view Base.') : SDK_CATEGORY_MESSAGES[code];
    var sdkCode = sdkNumericCode(error), operation = own(error, 'operation'), diagnostic = [];
    if (!control && sdkCode !== null) diagnostic.push(String(sdkCode));
    if (!control && SDK_OPERATIONS.indexOf(operation) >= 0) diagnostic.push(operation);
    if (diagnostic.length) message += ' [SDK ' + diagnostic.join('; ') + ']';
    var result = { code: code, message: message.replace(/[\x00-\x1f\x7f]/g, ' ').slice(0, 700) };
    if (READ_PHASES.indexOf(own(error, 'phase')) >= 0) result.phase = own(error, 'phase');
    if (Number.isInteger(own(error, 'readRecords')) && own(error, 'readRecords') >= 0 && own(error, 'readRecords') <= MAX_RECORDS) result.readRecords = own(error, 'readRecords');
    return result;
  }
  function validId(value) { return typeof value === 'string' && /^[A-Za-z0-9_-]{1,160}$/.test(value); }
  function selection(value) {
    if (!value || !validId(value.tableId) || !validId(value.viewId)) fail('NO_VIEW', 'Chọn một view trong Base trước khi bấm Nạp ở Photoshop.');
    return { tableId: value.tableId, viewId: value.viewId, baseId: typeof value.baseId === 'string' ? value.baseId : '' };
  }
  function sameSelection(a, b) { return a.tableId === b.tableId && a.viewId === b.viewId && a.baseId === b.baseId; }
  function createSourceReader(sdk, gate) {
    if (!sdk || !sdk.base || !sdk.bridge || !gate || typeof gate.wait !== 'function') fail('SDK_VERSION', 'Thiếu bộ xác minh nguồn Base.');
    var pending = new Map(), controllers = new Set(), generation = 0, gateGeneration = typeof gate.generation === 'function' ? gate.generation() : 0;
    // SDK RPCs cannot be cancelled. A timed-out operation is quarantined, not
    // reused as the next attempt's answer and not forgotten by the raw cap.
    var slots = sourceSlots.get(sdk); if (!slots) { slots = { selection: new Set(), source_url: new Set() }; sourceSlots.set(sdk, slots); }
    function reset() { generation++; pending.clear(); controllers.forEach(function (controller) { controller.abort(); }); controllers.clear(); }
    function raw(key, start) {
      if (pending.has(key)) return pending.get(key);
      var phase = key === 'selection' ? 'selection' : 'source_url', bucket = slots[phase];
      if (bucket.size >= 2) { var capped = Promise.reject(metadataTimeout(phase)); capped.catch(function () {}); return { promise: capped, capped: true }; }
      var entry = { promise: Promise.resolve().then(start) }; bucket.add(entry); pending.set(key, entry);
      function settled() { bucket.delete(entry); if (pending.get(key) === entry) pending.delete(key); }
      entry.promise.then(settled, settled); return entry;
    }
    async function readSource(options) {
      options = options || {};
      var timeoutMs = options.timeoutMs === undefined ? 20000 : options.timeoutMs;
      if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 30000) fail('SDK_VERSION', 'Thời gian xác minh nguồn Base chưa hợp lệ.');
      var currentGate = typeof gate.generation === 'function' ? gate.generation() : 0;
      if (currentGate !== gateGeneration) { reset(); gateGeneration = currentGate; }
      var deadline = Date.now() + timeoutMs, mine = generation, controller = new AbortController(); controllers.add(controller);
      function check() { if (mine !== generation || controller.signal.aborted || typeof gate.generation === 'function' && gateGeneration !== gate.generation()) { var error = new Error('Đã hủy xác minh nguồn Base.'); error.name = 'AbortError'; throw error; } if (typeof options.checkCurrent === 'function') options.checkCurrent(); }
      async function wait(entry, context) {
        check(); var remaining = deadline - Date.now(); if (remaining <= 0) { if (!entry.capped && mine === generation) reset(); throw metadataTimeout(context); }
        try { var value = await gate.wait(entry.promise, remaining, context, controller.signal); check(); return value; }
        catch (error) { if (isMetadataTimeout(error) && !entry.capped && mine === generation) reset(); throw error; }
      }
      try {
      var selected = selection(await wait(raw('selection', function () { check(); return safeSDKCall('selection', function () { return sdk.base.getSelection(); }); }), 'selection'));
      var url = await wait(raw('url|' + selected.tableId + '|' + selected.viewId, function () { check(); return safeSDKCall('source-url', function () { return sdk.bridge.getBitableUrl({ tableId: selected.tableId, viewId: selected.viewId }); }); }), 'source_url');
      // A timed-out RPC cannot be aborted. Drain pending selection work before
      // requesting a new post-URL proof; never reuse its earlier answer.
      if (pending.has('selection')) await wait(pending.get('selection'), 'selection_verify');
      var verified = selection(await wait(raw('selection', function () { check(); return safeSDKCall('selection', function () { return sdk.base.getSelection(); }); }), 'selection_verify'));
      if (!sameSelection(selected, verified)) changed();
      return { selected: selected, url: url };
      } finally { controllers.delete(controller); }
    }
    readSource.reset = reset; return readSource;
  }
  function checkedPinnedSource(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).sort().join(',') !== 'baseIdentity,tableId,viewId' ||
      canonicalSource(value.baseIdentity) !== value.baseIdentity || !validId(value.tableId) || !validId(value.viewId)) fail('BASE_IDENTITY', 'Nguồn đọc được chỉ định chưa hợp lệ.');
    return { baseIdentity: value.baseIdentity, tableId: value.tableId, viewId: value.viewId };
  }
  function checkedScopedResult(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) fail('BASE_IDENTITY', 'SDK chưa xác nhận nguồn đọc được chỉ định.');
    var selected = selection(value.selected), url;
    try { url = new URL(value.url); } catch (_) { fail('BASE_IDENTITY', 'SDK chưa trả liên kết của nguồn được chỉ định.'); }
    if (!canonicalSource(value.url) || url.searchParams.getAll('table').length !== 1 || url.searchParams.getAll('view').length !== 1 ||
      url.searchParams.get('table') !== selected.tableId || url.searchParams.get('view') !== selected.viewId) fail('BASE_IDENTITY', 'Liên kết SDK chưa khớp nguồn đọc được chỉ định.');
    return { selected: selected, url: value.url, table: value.table, view: value.view };
  }
  // A broker-selected source is a read capability, not a claim about the SDK's
  // foreground selection. Prove its table/view through real SDK existence and
  // metadata calls. The entry point separately verifies the parent page proof.
  function createPinnedSourceReader(sdk, gate) {
    if (!sdk || !sdk.base || !sdk.bridge || !gate || typeof gate.wait !== 'function' || typeof sdk.base.getTableById !== 'function' || typeof sdk.bridge.getBitableUrl !== 'function') fail('SDK_VERSION', 'Thiếu bộ đọc nguồn Base được chỉ định.');
    var generation = 0, controllers = new Set(), slots = pinnedSourceSlots.get(sdk);
    if (!slots) { slots = new Set(); pinnedSourceSlots.set(sdk, slots); }
    function reset() { generation++; controllers.forEach(function (controller) { controller.abort(); }); controllers.clear(); }
    async function readPinnedSource(expected, options) {
      expected = checkedPinnedSource(expected); options = options || {};
      var timeoutMs = options.timeoutMs === undefined ? 20000 : options.timeoutMs;
      if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 30000) fail('SDK_VERSION', 'Thời gian xác minh nguồn Base chưa hợp lệ.');
      if (slots.size >= 2) fail('SDK_METADATA_STALLED', 'SDK chưa kết thúc hai lượt xác minh nguồn cũ. Chưa bắt đầu lượt đọc mới.');
      var mine = generation, gateGeneration = typeof gate.generation === 'function' ? gate.generation() : 0, controller = new AbortController(), deadline = Date.now() + timeoutMs, expired = false;
      controllers.add(controller);
      function check() {
        if (mine !== generation || controller.signal.aborted || typeof gate.generation === 'function' && gateGeneration !== gate.generation()) { var error = new Error('Đã hủy xác minh nguồn Base.'); error.name = 'AbortError'; throw error; }
        if (expired || Date.now() >= deadline) throw metadataTimeout('source_url');
        if (typeof options.checkCurrent === 'function') options.checkCurrent();
      }
      function call(operation, start) { check(); return safeSDKCall(operation, function () { check(); return start(); }).then(function (value) { check(); return value; }); }
      var raw = Promise.resolve().then(async function () {
        var table = await call('table', function () { return sdk.base.getTableById(expected.tableId); });
        if (!table || table.id !== expected.tableId || typeof table.getViewById !== 'function') fail('BASE_IDENTITY', 'SDK chưa xác nhận đúng bảng được chỉ định.');
        var view = await call('view', function () { return table.getViewById(expected.viewId); });
        if (!view || view.id !== expected.viewId || view.tableId !== expected.tableId || typeof view.getMeta !== 'function' && typeof table.getViewMetaById !== 'function') fail('BASE_IDENTITY', 'SDK chưa xác nhận đúng view của bảng được chỉ định.');
        var metadata = await call('view-meta', function () { return typeof view.getMeta === 'function' ? view.getMeta() : table.getViewMetaById(expected.viewId); });
        if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata) || metadata.id !== expected.viewId) fail('BASE_IDENTITY', 'Metadata SDK chưa khớp view được chỉ định.');
        var url = await call('source-url', function () { return sdk.bridge.getBitableUrl({ tableId: table.id, viewId: metadata.id }); });
        var value = checkedScopedResult({ selected: { tableId: table.id, viewId: metadata.id, baseId: '' }, url: url, table: table, view: view });
        if (canonicalSource(value.url) !== expected.baseIdentity) fail('BASE_IDENTITY', 'SDK đang thuộc Base khác nguồn đọc được chỉ định.');
        check(); return value;
      });
      slots.add(raw); raw.then(function () { slots.delete(raw); }, function () { slots.delete(raw); });
      try { var result = await gate.wait(raw, timeoutMs, 'source_url', controller.signal); check(); return result; }
      finally { expired = true; controllers.delete(controller); }
    }
    readPinnedSource.reset = reset; return readPinnedSource;
  }
  function cell(value) {
    if (value == null) return '';
    if (typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') fail('CELL_FORMAT', 'SDK chưa trả giá trị ô dạng chuỗi. Chưa nạp dữ liệu để tránh sai nội dung.');
    value = String(value);
    if (value.length > MAX_CELL || /[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(value)) fail('CELL_LIMIT', 'Một ô dữ liệu vượt giới hạn hoặc chứa ký tự không hợp lệ.');
    return value;
  }
  function fieldSignature(fields) {
    if (!Array.isArray(fields) || fields.length > 1000) fail('FIELD_SCHEMA', 'SDK chưa trả danh sách cột hợp lệ; chưa xác nhận dữ liệu view.');
    var checked = [], seen = Object.create(null);
    for (var index = 0; index < fields.length; index++) {
      var field = own(fields, String(index)), id = own(field, 'id'), name = own(field, 'name'), type = own(field, 'type');
      if (!field || typeof field !== 'object' || Array.isArray(field) || !validId(id) || seen[id] || typeof name !== 'string' || name.length > MAX_CELL || type !== undefined && (!Number.isInteger(type) || type < 0 || type > 100000)) fail('FIELD_SCHEMA', 'SDK chưa trả cấu trúc cột hợp lệ; chưa xác nhận dữ liệu view.');
      seen[id] = true; checked.push({ id: id, name: name, type: type });
    }
    return JSON.stringify(checked.sort(function (a, b) { return a.id.localeCompare(b.id); }));
  }
  function changed() { fail('VIEW_CHANGED', 'View, cột hoặc dữ liệu thay đổi trong lúc nạp. Bấm Nạp lại; chưa nạp bản thiếu.'); }
  function messageFor(progress) {
    if (progress.phase === 'initializing') return 'Đang xác định view Base…';
    if (progress.phase === 'metadata') return 'Đang đọc cột và cấu hình view…';
    if (progress.phase === 'reading') return 'Đang đọc view Base: ' + progress.readRecords + ' dòng…';
    if (progress.phase === 'validating') return 'Đang kiểm tra đầy đủ view: ' + progress.readRecords + ' dòng…';
    return 'Đã đọc ' + progress.readRecords + ' dòng; đang gửi Photoshop…';
  }

  // Covers the bundle's source checks as well as the adapter itself. A single
  // job budget begins when the delivered request is received in this frame.
  function createReadJob(options) {
    options = options || {};
    var timeoutMs = typeof options.timeoutMs === 'number' && isFinite(options.timeoutMs) && options.timeoutMs > 0 ? options.timeoutMs : 120000;
    var everyMs = typeof options.progressEveryMs === 'number' && isFinite(options.progressEveryMs) && options.progressEveryMs > 0 ? options.progressEveryMs : 5000;
    var deadline = Date.now() + timeoutMs, closed = false, progress = { phase: 'initializing', readRecords: 0 };
    var busy = null, again = false, rejectFailure, heartbeat, firstFailure = null;
    var failure = new Promise(function (_, reject) { rejectFailure = reject; });
    failure.catch(function () {});
    function timeoutError() {
      var error = new Error('Base chưa trả view đầy đủ đúng hạn. Bấm Nạp lại; chưa đưa bản thiếu vào Photoshop.');
      error.code = 'READ_TIMEOUT'; return error;
    }
    function failed(error) { if (!firstFailure) firstFailure = tagSDKError('', error); rejectFailure(firstFailure); }
    function checkpoint() {
      if (firstFailure) throw firstFailure;
      if (closed) { var error = new Error('Lượt đọc Base cũ đã kết thúc.'); error.code = 'READ_CANCELLED'; throw error; }
      if (Date.now() >= deadline) { failed(timeoutError()); throw firstFailure; }
    }
    var timer = setTimeout(function () { failed(timeoutError()); }, timeoutMs);
    function remaining() { return Math.max(0, deadline - Date.now()); }
    function send() {
      if (closed || firstFailure || typeof options.onProgress !== 'function') return Promise.resolve();
      if (busy) { again = true; return busy; }
      var value = { phase: progress.phase, readRecords: progress.readRecords };
      busy = Promise.resolve().then(function () { checkpoint(); return options.onProgress(value); }).catch(failed).then(function () {
        busy = null;
        if (again && !closed && !firstFailure) { again = false; return send(); }
      });
      return busy;
    }
    heartbeat = setInterval(send, everyMs);
    send();
    return {
      remaining: remaining,
      checkpoint: checkpoint,
      report: function (value) { checkpoint(); progress = { phase: value.phase, readRecords: value.readRecords }; return Promise.race([failure, send()]).then(function (result) { checkpoint(); return result; }); },
      readerTimeoutMs: function (reserveMs) {
        checkpoint();
        var budget = remaining() - reserveMs;
        if (budget <= 0) { failed(timeoutError()); throw firstFailure; }
        return budget;
      },
      awaitSDK: async function (work, maxWaitMs) {
        checkpoint();
        var budget = Math.min(remaining(), maxWaitMs), waitTimer;
        if (budget <= 0) { failed(timeoutError()); throw firstFailure; }
        var expired = new Promise(function (_, reject) { waitTimer = setTimeout(function () { failed(timeoutError()); reject(firstFailure); }, budget); });
        try { var value = await Promise.race([failure, expired, typeof work === 'function' ? work() : work]); checkpoint(); return value; }
        finally { clearTimeout(waitTimer); }
      },
      finish: function () { closed = true; clearTimeout(timer); clearInterval(heartbeat); }
    };
  }

  function canonicalSource(value) {
    try { var url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password && !url.port && /(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(url.hostname) && url.pathname !== '/' ? url.origin + url.pathname.replace(/\/$/, '') : ''; } catch (_) { return ''; }
  }
  // Chrome's exact page/view request remains the authority boundary. During
  // Base UI navigation the SDK can lag briefly; wait for that exact source,
  // never authorize the old SDK view or extend the original read deadline.
  async function waitForExpectedSource(readSource, expected, options) {
    options = options || {}; var now = options.now || Date.now, pause = options.pause || function (ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); };
    var budget = Math.min(5000, options.timeoutMs === undefined ? 5000 : options.timeoutMs), start = now(), current = options.initial;
    function cancelled() { if (typeof options.isCurrent === 'function' && !options.isCurrent()) { var error = new Error('Đã hủy lượt xác minh view.'); error.name = 'AbortError'; throw error; } }
    function remaining() { var elapsed = now() - start; return elapsed < 0 ? 0 : Math.min(budget - elapsed, typeof options.remaining === 'function' ? options.remaining() : budget); }
    function matches(value) { return value && value.selected && canonicalSource(value.url) === expected.baseIdentity && value.selected.tableId === expected.tableId && value.selected.viewId === expected.viewId; }
    for (;;) {
      cancelled();
      if (current) {
        if (canonicalSource(current.url) !== expected.baseIdentity) fail('BASE_IDENTITY', 'Base đã đổi; chưa đọc dữ liệu từ Base khác.');
        if (matches(current)) return current;
      }
      var left = remaining(); if (left <= 0) changed();
      await pause(Math.min(250, left)); cancelled(); left = remaining(); if (left <= 0) changed();
      try { current = await readSource({ timeoutMs: Math.min(1500, left) }); }
      catch (error) { cancelled(); if (!isMetadataTimeout(error)) throw error; current = null; }
      cancelled();
    }
  }
  function sourceIdentity(value) {
    if (!value || !canonicalSource(value.url) || !validId(value.tableId) || !validId(value.viewId)) fail('BASE_IDENTITY', 'Nguồn view Base chưa được xác nhận.');
    return canonicalSource(value.url) + '|' + value.tableId + '|' + value.viewId;
  }
  function own(value, key) { var descriptor = value && typeof value === 'object' && Object.getOwnPropertyDescriptor(value, key); return descriptor && Object.prototype.hasOwnProperty.call(descriptor, 'value') ? descriptor.value : undefined; }
  function boundedData(value) {
    var nodes = 0;
    function copy(item, depth) {
      if (++nodes > 10000 || depth > 20) fail('VIEW_CONFIG', 'Cấu hình view vượt giới hạn xác minh.');
      if (item === null || typeof item === 'string' || typeof item === 'boolean' || typeof item === 'number' && isFinite(item)) return item;
      if (!item || typeof item !== 'object' || !Array.isArray(item) && Object.prototype.toString.call(item) !== '[object Object]') fail('VIEW_CONFIG', 'Cấu hình view chưa trả dữ liệu tường minh.');
      var result = Array.isArray(item) ? [] : {}, keys = Array.isArray(item) ? Array.from({ length: item.length }, function (_, index) { return String(index); }) : Object.getOwnPropertyNames(item).sort();
      if (keys.length > 5000) fail('VIEW_CONFIG', 'Cấu hình view vượt giới hạn xác minh.');
      keys.forEach(function (key) {
        var descriptor = Object.getOwnPropertyDescriptor(item, key);
        if (!descriptor || !Object.prototype.hasOwnProperty.call(descriptor, 'value')) fail('VIEW_CONFIG', 'Cấu hình view chưa đầy đủ.');
        // GridView metadata contains optional object properties such as
        // hierarchyConfig.fieldId: undefined. Match JSON object semantics;
        // array holes/undefined and accessors still fail closed.
        if (!Array.isArray(item) && descriptor.value === undefined) return;
        Object.defineProperty(result, key, { value: copy(descriptor.value, depth + 1), enumerable: true });
      });
      return result;
    }
    var data = copy(value, 0); if (JSON.stringify(data).length > 100000) fail('VIEW_CONFIG', 'Cấu hình view vượt giới hạn xác minh.'); return data;
  }
  async function viewConfiguration(table, view, viewId, wait, start) {
    // Metadata and the explicit filter are independent SDK reads. Both still
    // belong to the caller's one deadline and are signed together below.
    start = start || function (work) { return wait(work()); };
    var values = await Promise.all([
      start(function () { return safeSDKCall('view-meta', function () { return typeof view.getMeta === 'function' ? view.getMeta() : table.getViewMetaById(viewId); }); }),
      typeof view.getFilterInfo === 'function' ? start(function () { return safeSDKCall('view-filter', function () { return view.getFilterInfo(); }); }).then(function (value) { return { value: value }; }, function (error) {
        // The method may exist in this SDK while the Base host does not
        // implement it. Only its exact NotSupported code permits the same
        // fresh metadata's explicit filter to stand in for that API.
        if (isSDKUnsupported(error, 10215996)) return { unsupported: true };
        throw error;
      }) : Promise.resolve({ unsupported: true })
    ]);
    var meta = boundedData(values[0]);
    if (!meta || Array.isArray(meta) || meta.id !== viewId) fail('VIEW_CONFIG', 'SDK chưa xác nhận metadata của đúng view.');
    var filter = values[1].unsupported ? own(own(meta, 'property'), 'filterInfo') : values[1].value;
    if (filter !== null && (!filter || !['and', 'or'].includes(own(filter, 'conjunction')) || !Array.isArray(own(filter, 'conditions')))) fail('VIEW_CONFIG', 'SDK chưa xác nhận bộ lọc tường minh của view.');
    filter = boundedData(filter);
    var dependencies = Object.create(null);
    function collect(value) { if (!value || typeof value !== 'object') return; Object.keys(value).forEach(function (key) { var item = value[key]; if (key === 'fieldId' && validId(item)) dependencies[item] = true; if (key === 'fieldIds' && Array.isArray(item)) item.forEach(function (id) { if (validId(id)) dependencies[id] = true; }); if (item && typeof item === 'object') collect(item); }); }
    collect(meta); collect(filter);
    function knownCondition(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
      var conditions = own(value, 'conditions');
      if (conditions !== undefined) return ['and', 'or'].includes(own(value, 'conjunction')) && Array.isArray(conditions) && conditions.every(knownCondition);
      return validId(own(value, 'fieldId'));
    }
    var sort = own(own(meta, 'property'), 'sortInfo');
    var dependenciesKnown = (filter === null || knownCondition(filter)) && (sort === null || Array.isArray(sort) && sort.every(function (rule) { return rule && typeof rule === 'object' && !Array.isArray(rule) && validId(own(rule, 'fieldId')); }));
    // A view label does not change membership, order, cells or permissions.
    // Every unknown metadata property remains signed conservatively. Object
    // key order is canonical; array order (notably sort rules) is semantic.
    var proofMeta = {}; Object.keys(meta).forEach(function (key) { if (key !== 'name') Object.defineProperty(proofMeta, key, { value: meta[key], enumerable: true }); });
    return { meta: meta, dependencies: dependencies, dependenciesKnown: dependenciesKnown, signature: JSON.stringify({ meta: proofMeta, filter: filter }) };
  }
  function eventHint(name, event) {
    var kind = { onRecordModify: 'record-modify', onRecordAdd: 'record-add', onRecordDelete: 'record-delete', onFieldAdd: 'field', onFieldModify: 'field', onFieldDelete: 'field', onSelectionChange: 'selection', onPermissionChange: 'permission' }[name] || 'unknown';
    var hint = { recordIds: [], fieldIds: [], kinds: [kind], full: !/^record-/.test(kind) }, recordSeen = Object.create(null), fieldSeen = Object.create(null);
    function ids(value, target, seen, limit) { if (value === undefined) return; var list = Array.isArray(value) ? value : [value]; if (list.length > limit) { hint.full = true; return; } for (var i = 0; i < list.length; i++) { var item = own(list, String(i)); if (!validId(item)) { hint.full = true; continue; } if (!seen[item]) { if (target.length >= limit) { hint.full = true; continue; } seen[item] = true; target.push(item); } } }
    [event, own(event, 'data')].forEach(function (data) { if (!data || typeof data !== 'object' || Array.isArray(data)) return; ['recordId', 'recordIds', 'recordIdList'].forEach(function (key) { ids(own(data, key), hint.recordIds, recordSeen, MAX_RECORDS); }); ['fieldId', 'fieldIds', 'fieldIdList'].forEach(function (key) { ids(own(data, key), hint.fieldIds, fieldSeen, 1000); }); });
    if (/^record-/.test(kind) && !hint.recordIds.length) hint.full = true;
    return hint;
  }
  function invalidateCache(sdk, hint) {
    var cache = viewCaches.get(sdk); if (!cache) return;
    cache.revision++;
    if (!hint || hint.full) { cache.rows = Object.create(null); cache.full = true; }
    else hint.recordIds.forEach(function (id) { delete cache.rows[id]; });
  }
  function clearCache(sdk) { viewCaches.delete(sdk); }
  function configurationOwner(sdk, context) { return context && context.owner && typeof context.owner === 'object' ? context.owner : context && typeof context === 'object' ? context : sdk; }
  function retireConfiguration(sdk, context) {
    var pending = configurationPending.get(sdk), owner = context === undefined ? null : configurationOwner(sdk, context);
    if (owner) configurationHandles.delete(owner);
    if (!pending) return;
    pending.forEach(function (entry) { if (!owner || entry.owner === owner) { entry.retired = true; pending.delete(entry); configurationHandles.delete(entry.owner); } });
    if (!pending.size) configurationPending.delete(sdk);
  }
  function configurationSignature(sdk, source, wait, context) {
    var sourceKey = sourceIdentity(source), owner = configurationOwner(sdk, context), pending = configurationPending.get(sdk);
    function cancelled() { var error = new Error('Đã hủy lượt xác minh cấu hình Base cũ.'); error.name = 'AbortError'; return error; }
    function current(entry) { if (entry && entry.retired || context && typeof context.isCurrent === 'function' && !context.isCurrent()) throw cancelled(); }
    current();
    // One exact-source owner shares its still-running proof. A second caller
    // is not evidence that the Base view changed and must not fail BUSY.
    if (pending) for (var entry of pending) { if (!entry.retired && entry.owner === owner && entry.source === sourceKey) return entry.promise; }
    var slots = configurationSlots.get(sdk); if (!slots) { slots = new Set(); configurationSlots.set(sdk, slots); }
    if (slots.size >= 2) { var stalled = new Error('SDK chưa kết thúc hai lượt cấu hình cũ. Reader cần phục hồi; chưa xác nhận view.'); stalled.code = 'SDK_METADATA_STALLED'; stalled.recoveryRequired = true; throw stalled; }
    if (!pending) { pending = new Set(); configurationPending.set(sdk, pending); }
    wait = wait || function (value) { return value; };
    var job = { owner: owner, source: sourceKey, retired: false, settled: false, raw: new Set(), promise: null }; pending.add(job); slots.add(job);
    function cleanup() { if (!job.settled || job.raw.size) return; slots.delete(job); }
    function tracked(promise) {
      var raw = Promise.resolve(promise); job.raw.add(raw);
      function settled() { job.raw.delete(raw); cleanup(); }
      raw.then(settled, settled);
      return Promise.resolve(wait(raw)).then(function (value) { current(job); return value; });
    }
    function read(start) { current(job); return tracked(Promise.resolve().then(function () { current(job); return start(); })); }
    function validView(table, view) {
      if (!table || typeof table.getFieldMetaList !== 'function' || !view || view.id !== undefined && view.id !== source.viewId || view.tableId !== undefined && view.tableId !== source.tableId) fail('VIEW_CONFIG', 'SDK chưa xác nhận metadata của đúng view.');
    }
    job.promise = (async function () {
      var scoped = context && typeof context.sourceGuard === 'function' ? checkedScopedResult(await read(context.sourceGuard)) : null;
      var selected = scoped ? scoped.selected : selection(await read(function () { return safeSDKCall('selection', function () { return sdk.base.getSelection(); }); }));
      if (selected.tableId !== source.tableId || selected.viewId !== source.viewId) changed();
      if (scoped && sourceIdentity({ url: scoped.url, tableId: selected.tableId, viewId: selected.viewId }) !== sourceKey) changed();
      var handles = context && configurationHandles.get(owner);
      if (!handles || handles.sdk !== sdk || handles.source !== sourceKey || context && context.table && handles.table !== context.table) handles = null;
      var urlPromise = read(function () { return safeSDKCall('source-url', function () { return sdk.bridge.getBitableUrl({ tableId: selected.tableId, viewId: selected.viewId }); }); });
      var tablePromise = scoped && scoped.table ? Promise.resolve(scoped.table) : handles ? Promise.resolve(handles.table) : context && context.table ? Promise.resolve(context.table) : read(function () { return safeSDKCall('table', function () { return sdk.base.getTableById(selected.tableId); }); });
      var tables = await Promise.all([urlPromise, tablePromise]); current(job);
      if (sourceIdentity({ url: tables[0], tableId: selected.tableId, viewId: selected.viewId }) !== sourceKey) changed();
      var table = tables[1];
      if (!table || table.id !== undefined && table.id !== source.tableId || typeof table.getViewById !== 'function') fail('VIEW_CONFIG', 'SDK chưa xác nhận metadata của đúng view.');
      var viewPromise = scoped && scoped.view ? Promise.resolve(scoped.view) : handles ? Promise.resolve(handles.view) : read(function () { return safeSDKCall('view', function () { return table.getViewById(selected.viewId); }); });
      var schemaPromise = read(function () { return safeSDKCall('field-meta', function () { return table.getFieldMetaList(); }); });
      var configPromise = viewPromise.then(async function (view) { current(job); validView(table, view); return { view: view, config: await viewConfiguration(table, view, selected.viewId, tracked, read) }; });
      var values = await Promise.all([configPromise, schemaPromise]); current(job);
      // The owner already proved this table's source before creating context.
      // Reusing only these handles avoids repeated SDK existence RPCs; URL,
      // selection, schema, metadata and explicit filter are still read fresh.
      if (context) configurationHandles.set(owner, { sdk: sdk, source: sourceKey, table: table, view: values[0].view });
      return values[0].config.signature + '|' + fieldSignature(values[1]);
    })();
    function settled() { job.settled = true; pending.delete(job); if (!pending.size && configurationPending.get(sdk) === pending) configurationPending.delete(sdk); cleanup(); }
    job.promise.then(settled, function () { job.retired = true; settled(); }); return job.promise;
  }
  function createReader(adapter, document) {
    if (!adapter || !Array.isArray(adapter.FIELDS) || typeof adapter.mapFields !== 'function') fail('SDK_VERSION', 'Chưa có bộ đọc Base hợp lệ.');
    var fields = adapter.FIELDS;
    return async function readCurrentView(sdk, options) {
      options = options || {};
      var timeoutMs = typeof options.timeoutMs === 'number' && isFinite(options.timeoutMs) && options.timeoutMs > 0 ? options.timeoutMs : 110000;
      var everyMs = typeof options.progressEveryMs === 'number' && isFinite(options.progressEveryMs) && options.progressEveryMs > 0 ? options.progressEveryMs : 5000;
      var phase = 'initializing', count = 0, dirty = false, closed = false, off = [], progressBusy = null, progressAgain = false, scopedSourceKey = '';
      var rejectProgress, rejectDeadline, deadlineTimer, heartbeatTimer, firstFailure = null, deadline = Date.now() + timeoutMs;
      var progressFailure = new Promise(function (_, reject) { rejectProgress = reject; });
      var deadlineFailure = new Promise(function (_, reject) { rejectDeadline = reject; });
      // Attach immediately; an event can reject while no SDK await is active.
      progressFailure.catch(function () {}); deadlineFailure.catch(function () {});
      function timeoutError() {
        var error = new Error('Base chưa đọc xong ở bước ' + messageFor({ phase: phase, readRecords: count }).replace(/…$/, '') + '. Bấm Nạp lại; chưa đưa bản thiếu vào Photoshop.');
        error.code = 'READ_TIMEOUT'; error.phase = phase; error.readRecords = count; return error;
      }
      function failed(error, reject) { if (!firstFailure) firstFailure = tagSDKError('', error); reject(firstFailure); }
      function checkpoint() {
        if (firstFailure) throw firstFailure;
        if (closed) { var error = new Error('Lượt đọc Base cũ đã kết thúc.'); error.code = 'READ_CANCELLED'; throw error; }
        if (Date.now() >= deadline) { failed(timeoutError(), rejectDeadline); throw firstFailure; }
        if (typeof options.checkCurrent === 'function') { try { options.checkCurrent(); } catch (error) { failed(error, rejectProgress); throw firstFailure; } }
      }
      deadlineTimer = setTimeout(function () { failed(timeoutError(), rejectDeadline); }, timeoutMs);
      function guarded(work) {
        checkpoint();
        var operation = typeof options.parentAwait === 'function' ? options.parentAwait(work) : typeof work === 'function' ? work() : work;
        return Promise.race([progressFailure, deadlineFailure, operation]).then(function (value) { checkpoint(); return value; });
      }
      function report() {
        if (closed || firstFailure) return Promise.resolve();
        if (progressBusy) { progressAgain = true; return progressBusy; }
        var progress = { phase: phase, readRecords: count };
        if (document && typeof document.getElementById === 'function') {
          var status = document.getElementById('status');
          if (status) { status.textContent = messageFor(progress); if (status.dataset) status.dataset.error = 'false'; }
        }
        if (typeof options.onProgress !== 'function') return Promise.resolve();
        progressBusy = Promise.resolve().then(function () { checkpoint(); return options.onProgress(progress); }).catch(function (error) {
          failed(error, rejectProgress);
        }).then(function () {
          progressBusy = null;
          if (progressAgain && !closed && !firstFailure) { progressAgain = false; return report(); }
        });
        return progressBusy;
      }
      function setPhase(value) { phase = value; report(); }
      function currentSelection() {
        return typeof options.sourceGuard === 'function' ? guarded(options.sourceGuard).then(function (value) {
          var actual = checkedScopedResult(value), key = sourceIdentity({ url: actual.url, tableId: actual.selected.tableId, viewId: actual.selected.viewId });
          if (scopedSourceKey && scopedSourceKey !== key) changed(); scopedSourceKey = key; return actual.selected;
        }) : guarded(function () { return safeSDKCall('selection', function () { return sdk.base.getSelection(); }); });
      }
      if (options.progressEveryMs !== 0) heartbeatTimer = setInterval(report, everyMs);
      report();
      try {
        var initial = selection(await currentSelection());
        var table = await guarded(function () { return safeSDKCall('table', function () { return sdk.base.getTableById(initial.tableId); }); });
        if (!table || typeof table.getViewById !== 'function' || typeof table.getCellString !== 'function') fail('SDK_VERSION', 'Cần SDK đọc đúng danh sách view và các ô theo Record ID.');
        var visible = null, configuration = null, mapping = null, pendingEvents = [], boundaryEpoch = 0, adjacentBoundary = null;
        function revokeAdjacentBoundary(){boundaryEpoch++;adjacentBoundary=null;}
        function relevant(hint) {
          if (hint.full || hint.kinds.some(function (kind) { return !/^record-/.test(kind); }) || hint.kinds.includes('record-add')) return true;
          if (!visible || !configuration || !mapping) return null;
          var affectsMembership = !configuration.dependenciesKnown || !hint.fieldIds.length || hint.fieldIds.some(function (id) { return configuration.dependencies[id]; });
          if (hint.kinds.includes('record-modify') && affectsMembership) return true;
          return hint.recordIds.some(function (id) { return visible[id]; }) && (hint.kinds.includes('record-delete') || !hint.fieldIds.length || hint.fieldIds.some(function (id) { return Object.keys(mapping).some(function (key) { return mapping[key] === id; }); }));
        }
        function markDirty(hint) { invalidateCache(sdk, hint); var affects = relevant(hint); if(affects!==false)revokeAdjacentBoundary();if (affects === null) pendingEvents.push(hint); else if (affects) dirty = true; }
        ['onRecordModify', 'onRecordAdd', 'onRecordDelete', 'onFieldAdd', 'onFieldModify', 'onFieldDelete'].forEach(function (name) {
          if (typeof table[name] === 'function') try { off.push(table[name](function (event) { markDirty(eventHint(name, event)); })); } catch (error) { throw tagSDKError('event-subscription', error); }
        });
        if (typeof sdk.base.onSelectionChange === 'function') try { off.push(sdk.base.onSelectionChange(function () {
          // Any selection event revokes an adjacent fence synchronously.
          // A scoped read proves its own table/view at each normal boundary;
          // unrelated foreground-selection bursts must not start overlapping
          // sourceGuard RPCs or exhaust the pinned-source quarantine slots.
          revokeAdjacentBoundary();
          if (typeof options.sourceGuard === 'function') return;
          // Legacy unscoped reads still verify the actual foreground selection.
          try {
            currentSelection().then(function (value) {
              if (!sameSelection(initial, selection(value))) markDirty(eventHint('onSelectionChange'));
            }).catch(function () { markDirty(eventHint('onSelectionChange')); });
          } catch (_) { markDirty(eventHint('onSelectionChange')); }
        })); } catch (error) { throw tagSDKError('event-subscription', error); }
        if (typeof sdk.base.onPermissionChange === 'function') try { off.push(sdk.base.onPermissionChange(function () { markDirty(eventHint('onPermissionChange')); })); } catch (error) { throw tagSDKError('event-subscription', error); }
        setPhase('metadata');
        var metadata = await guarded(function () { return Promise.all([
          safeSDKCall('field-meta', function () { return table.getFieldMetaList(); }), safeSDKCall('view', function () { return table.getViewById(initial.viewId); }),
          safeSDKCall('source-url', function () { return sdk.bridge.getBitableUrl({ tableId: initial.tableId, viewId: initial.viewId }); })
        ]); });
        var schema = metadata[0], view = metadata[1], url = metadata[2], initialMapping = typeof options.getMapping === 'function' ? options.getMapping() : options.mapping;
        mapping = adapter.mapFields(schema, initialMapping);
        var signature = fieldSignature(schema), mappingSignature = JSON.stringify(mapping), explicitMappingSignature = JSON.stringify(initialMapping || {}), source = { url: url, tableId: initial.tableId, viewId: initial.viewId };
        var sourceKey = sourceIdentity(source);
        if (scopedSourceKey) { checkedScopedResult({ selected: initial, url: url }); if (scopedSourceKey !== sourceKey) changed(); }
        if (!view || typeof view.getVisibleRecordIdListByPage !== 'function' || view.id !== undefined && view.id !== initial.viewId || view.tableId !== undefined && view.tableId !== initial.tableId) fail('SDK_VERSION', 'SDK chưa hỗ trợ phân trang danh sách ID của đúng view.');
        configuration = await viewConfiguration(table, view, initial.viewId, guarded, guarded);
        var dirtyRequest = options.dirtyRequest;
        if (dirtyRequest !== undefined) {
          if (!dirtyRequest || typeof dirtyRequest !== 'object' || Array.isArray(dirtyRequest) || Object.keys(dirtyRequest).sort().join(',') !== 'full,recordIds,source' || typeof dirtyRequest.full !== 'boolean' || !Array.isArray(dirtyRequest.recordIds) || dirtyRequest.recordIds.length > MAX_RECORDS || !dirtyRequest.source || Object.keys(dirtyRequest.source).sort().join(',') !== 'tableId,url,viewId' || sourceIdentity(dirtyRequest.source) !== sourceKey) fail('DIRTY_REQUEST', 'Yêu cầu đọc thay đổi không thuộc đúng view.');
          var requested = Object.create(null); dirtyRequest.recordIds.forEach(function (id) { if (!validId(id) || requested[id]) fail('DIRTY_REQUEST', 'Record ID thay đổi trống, trùng hoặc không hợp lệ.'); requested[id] = true; });
          invalidateCache(sdk, dirtyRequest);
        }
        var cache = viewCaches.get(sdk), cacheAllowed = !!options.cacheOwner && cache && cache.owner === options.cacheOwner && cache.generation === options.cacheGeneration && cache.source === sourceKey && cache.schema === signature && cache.mapping === mappingSignature && cache.explicitMapping === explicitMappingSignature;
        var cachedRows = cacheAllowed && dirtyRequest && !dirtyRequest.full && !cache.full ? cache.rows : Object.create(null);
        var rows = [fields.map(function (field) { return field[0]; })], recordsSeen = Object.create(null), tokensSeen = Object.create(null), orderedIds = [];
        var pageToken, total = null, bulkWanted = !dirtyRequest || dirtyRequest.full || !cacheAllowed || cache.full, joinedBulk = null;
        setPhase('reading');
        async function boundary() {
          checkpoint();
          if (dirty) changed();
          var proofEpoch=boundaryEpoch;
          // The same complete proof still brackets every membership/bulk page.
          // These independent read-only facts need one round trip group, not
          // four serial waits, and events invalidate the whole group.
          var proof = await guarded(function () { return Promise.all([
            currentSelection(),
            safeSDKCall('source-url', function () { return sdk.bridge.getBitableUrl({ tableId: initial.tableId, viewId: initial.viewId }); }),
            viewConfiguration(table, view, initial.viewId, guarded, guarded)
          ]); });
          if (dirty || !sameSelection(initial, selection(proof[0])) || sourceIdentity({ url: proof[1], tableId: initial.tableId, viewId: initial.viewId }) !== sourceKey || proof[2].signature !== configuration.signature) changed();
          adjacentBoundary=proofEpoch===boundaryEpoch?{epoch:proofEpoch}:null;
        }
        function consumeAdjacentBoundary() {
          checkpoint();if(dirty)changed();
          // An after-page fence is also the next before-page fence when only
          // synchronous bounded validation separated them. Consume once;
          // never reuse a value across another SDK operation or final check.
          if(adjacentBoundary&&adjacentBoundary.epoch===boundaryEpoch){adjacentBoundary=null;return true;}
          return false;
        }
        for (var pageIndex = 0; ; pageIndex++) {
          if (pageIndex > 25) fail('PAGE_INCOMPLETE', 'View vượt số trang cho phép.');
          if(!consumeAdjacentBoundary())await boundary();adjacentBoundary=null;
          var params = { pageSize: 200 };
          if (pageToken !== undefined) params.pageToken = pageToken;
          var page = await guarded(function () { return safeSDKCall('visible-records', function () { return view.getVisibleRecordIdListByPage(params); }); });
          if (dirty) changed();
          // Only an already structurally complete first membership response
          // may share its before/after fence with the first bulk seed RPC.
          // Do not speculate on unknown membership or change multipage IO.
          if(pageIndex===0&&bulkWanted&&typeof table.getRecordsByPage==='function'&&page&&Array.isArray(page.recordIds)&&page.recordIds.length>0&&page.recordIds.length<=200&&page.hasMore===false&&Number.isSafeInteger(page.total)&&page.total===page.recordIds.length&&page.total<=MAX_RECORDS){
            var provisional=Object.create(null);
            for(var provisionalIndex=0;provisionalIndex<page.recordIds.length;provisionalIndex++){var provisionalId=own(page.recordIds,String(provisionalIndex));if(!validId(provisionalId)||provisional[provisionalId])fail('RECORD_SCHEMA','ID của view trống, trùng hoặc chưa đầy đủ.');provisional[provisionalId]=true;}
            // Local relevance may abort before bulk; membership is not
            // published or committed until the fresh shared after-fence.
            visible=provisional;pendingEvents.forEach(function(hint){if(relevant(hint))dirty=true;});pendingEvents=[];if(dirty)changed();
            try{joinedBulk={page:await guarded(function(){return safeSDKCall('bulk-records',function(){return table.getRecordsByPage({pageSize:200,viewId:initial.viewId,stringValue:true});});})};}
            catch(error){if(isSDKUnsupported(error,10212996))joinedBulk={unsupported:true};else throw error;}
            if(dirty)changed();
          }
          await boundary();
          if (!page || !Array.isArray(page.recordIds) || page.recordIds.length > 200 || typeof page.hasMore !== 'boolean' || !Number.isSafeInteger(page.total) || page.total < 0 || page.total > MAX_RECORDS) fail('PAGE_SCHEMA', 'Danh sách ID của view không hợp lệ hoặc vượt 5000 dòng.');
          if (total === null) total = page.total; else if (total !== page.total) changed();
          for (var recordIndex = 0; recordIndex < page.recordIds.length; recordIndex++) {
            var recordId = own(page.recordIds, String(recordIndex));
            if (!validId(recordId) || recordsSeen[recordId]) fail('RECORD_SCHEMA', 'ID của view trống, trùng hoặc chưa đầy đủ.');
            recordsSeen[recordId] = true; orderedIds.push(recordId);
          }
          if (orderedIds.length > total) fail('PAGE_INCOMPLETE', 'Số dòng của view chưa khớp.');
          if (!page.hasMore) break;
          if (!page.recordIds.length || !Number.isSafeInteger(page.pageToken) || page.pageToken < 0 || tokensSeen[String(page.pageToken)]) fail('PAGE_INCOMPLETE', 'Thiếu hoặc lặp mã phân trang; chưa nạp view không đầy đủ.');
          tokensSeen[String(page.pageToken)] = true; pageToken = page.pageToken;
        }
        if (orderedIds.length !== total) fail('PAGE_INCOMPLETE', 'Chưa nhận đủ số dòng của view. Không nạp một phần.');
        visible = recordsSeen; pendingEvents.forEach(function (hint) { if (relevant(hint)) dirty = true; }); pendingEvents = [];
        if (dirty) changed();
        // The existing production bulk API is only a cell-value seed, never
        // membership authority: SDK viewId pages can disagree with visible IDs.
        // A bounded missing/partial prefix falls back to exact-ID cells; it
        // cannot remove an actual visible record or add a table-only record.
        var seedRows = Object.create(null);
        if (bulkWanted && orderedIds.length && typeof table.getRecordsByPage === 'function' && !(joinedBulk&&joinedBulk.unsupported)) {
          var bulkToken, bulkTotal = null, bulkSeen = Object.create(null), bulkTokens = Object.create(null), bulkCount = 0, seeded = 0;
          for (var bulkPageIndex = 0; bulkPageIndex < 26 && bulkCount < MAX_RECORDS && seeded < orderedIds.length; bulkPageIndex++) {
            var bulkParams = { pageSize: Math.min(200, MAX_RECORDS - bulkCount), viewId: initial.viewId, stringValue: true };
            if (bulkToken !== undefined) bulkParams.pageToken = bulkToken;
            var bulkPage;
            if(bulkPageIndex===0&&joinedBulk){bulkPage=joinedBulk.page;}
            else{
            if(!consumeAdjacentBoundary())await boundary();adjacentBoundary=null;
            try { bulkPage = await guarded(function () { return safeSDKCall('bulk-records', function () { return table.getRecordsByPage(bulkParams); }); }); }
            catch (error) { if (isSDKUnsupported(error, 10212996)) break; throw error; }
            if (dirty) changed();
            await boundary();
            }
            if (!bulkPage || !Array.isArray(bulkPage.records) || bulkPage.records.length > bulkParams.pageSize || typeof bulkPage.hasMore !== 'boolean' || !Number.isSafeInteger(bulkPage.total) || bulkPage.total < 0) fail('PAGE_SCHEMA', 'Trang seed ô Base không hợp lệ.');
            if (bulkTotal === null) bulkTotal = bulkPage.total; else if (bulkTotal !== bulkPage.total) changed();
            for (var bulkIndex = 0; bulkIndex < bulkPage.records.length; bulkIndex++) {
              var record = own(bulkPage.records, String(bulkIndex)), recordId = own(record, 'recordId'), values = own(record, 'fields');
              if (!validId(recordId) || bulkSeen[recordId] || !values || typeof values !== 'object' || Array.isArray(values)) fail('RECORD_SCHEMA', 'Record của trang seed trống, trùng hoặc chưa hợp lệ.');
              bulkSeen[recordId] = true; bulkCount++;
              if (!visible[recordId]) continue;
              var seed = fields.map(function (definition) {
                var fieldId = mapping[definition[1]], descriptor = fieldId && Object.getOwnPropertyDescriptor(values, fieldId);
                if (descriptor && !Object.prototype.hasOwnProperty.call(descriptor, 'value')) fail('RECORD_SCHEMA', 'Ô seed chưa trả dữ liệu tường minh.');
                var value = fieldId ? cell(descriptor && descriptor.value) : '';
                if (definition[1] === 'recordId') { if (fieldId && value !== recordId) fail('RECORD_SCHEMA', 'Cột Record ID không khớp ID thật của SDK.'); return recordId; }
                return value;
              });
              seedRows[recordId] = seed; seeded++;
            }
            if (bulkCount > bulkTotal) fail('PAGE_SCHEMA', 'Số record seed vượt tổng SDK xác nhận.');
            if (!bulkPage.hasMore) break;
            if (!bulkPage.records.length || typeof bulkPage.pageToken !== 'string' && typeof bulkPage.pageToken !== 'number' || typeof bulkPage.pageToken === 'string' && !bulkPage.pageToken || String(bulkPage.pageToken).length > 1000 || typeof bulkPage.pageToken === 'number' && (!Number.isSafeInteger(bulkPage.pageToken) || bulkPage.pageToken < 0) || bulkTokens[String(bulkPage.pageToken)]) fail('PAGE_INCOMPLETE', 'Mã phân trang seed trống, lặp hoặc chưa hợp lệ.');
            bulkTokens[String(bulkPage.pageToken)] = true; bulkToken = bulkPage.pageToken;
          }
        }
        adjacentBoundary=null;
        var nextRows = Object.create(null);
        for (var start = 0; start < orderedIds.length; start += 20) {
          var batch = orderedIds.slice(start, start + 20);
          var readRows = await guarded(function () { return Promise.all(batch.map(async function (recordId) {
            checkpoint();
            if (dirty) changed();
            if (cachedRows[recordId] && !(requested && requested[recordId])) return cachedRows[recordId].slice();
            var row = [];
            for (var index = 0; index < fields.length; index++) {
              checkpoint();
              var definition = fields[index], fieldId = mapping[definition[1]], value = fieldId ? seedRows[recordId] ? seedRows[recordId][index] : cell(await guarded(function () { return safeSDKCall('cell-string', function () { return table.getCellString(fieldId, recordId); }); })) : '';
              if (dirty) changed();
              if (definition[1] === 'recordId') { if (fieldId && value !== recordId) fail('RECORD_SCHEMA', 'Cột Record ID không khớp ID thật của SDK; chưa nạp đơn để tránh nhầm record.'); value = recordId; }
              if (definition[1] === 'designLink' && fieldId && typeof options.linkParser === 'function') {
                if (typeof table.getCellValue !== 'function') value = '';
                else { var raw = await guarded(function () { return safeSDKCall('cell-value', function () { return table.getCellValue(fieldId, recordId); }); }); if (dirty) changed(); try { value = options.linkParser(value, raw); } catch (error) { if (error.code !== 'STATUS_LINK') throw error; value = ''; } }
              }
              row.push(value);
            }
            return row;
          })); });
          if (dirty) changed();
          batch.forEach(function (recordId, index) { nextRows[recordId] = readRows[index].slice(); rows.push(readRows[index]); });
          count = rows.length - 1; report();
        }
        setPhase('validating');
        var final = await guarded(function () { return Promise.all([safeSDKCall('field-meta', function () { return table.getFieldMetaList(); }), currentSelection()]); }), finalMapping = typeof options.getMapping === 'function' ? options.getMapping() : options.mapping;
        if (dirty || !sameSelection(initial, selection(final[1])) || signature !== fieldSignature(final[0]) || explicitMappingSignature !== JSON.stringify(finalMapping || {}) || mappingSignature !== JSON.stringify(adapter.mapFields(final[0], finalMapping))) changed();
        await boundary();
        var snapshot = { version: 1, source: { url: url, tableId: initial.tableId, viewId: initial.viewId, viewName: cell(configuration.meta.name || initial.viewId) }, count: total, rows: rows };
        if (new TextEncoder().encode(JSON.stringify(snapshot)).length > MAX_BYTES) fail('READ_LIMIT', 'JSON của view vượt 8 MB. Giảm số dòng của view.');
        setPhase('sending');
        await guarded(report);
        checkpoint();
        if (dirty) changed();
        if (options.cacheOwner) viewCaches.set(sdk, { owner: options.cacheOwner, generation: options.cacheGeneration, source: sourceKey, schema: signature, mapping: mappingSignature, explicitMapping: explicitMappingSignature, rows: nextRows, full: false, revision: cache ? cache.revision : 0 });
        return snapshot;
      } catch (error) {
        var wrapped = new Error(error && error.message || 'Không đọc được view Base.');
        wrapped.code = error && error.code;
        if (own(error, 'name') === 'AbortError') wrapped.name = 'AbortError';
        if (SDK_OPERATIONS.indexOf(own(error, 'operation')) >= 0) wrapped.operation = own(error, 'operation');
        wrapped.phase = phase; wrapped.readRecords = count;
        throw wrapped;
      } finally {
        closed = true; clearTimeout(deadlineTimer); clearInterval(heartbeatTimer);
        off.forEach(function (unsubscribe) { try { if (typeof unsubscribe === 'function') unsubscribe(); } catch (_) {} });
      }
    };
  }
  function install(adapter, document) {
    if (!adapter) return false;
    adapter.readCurrentView = createReader(adapter, document);
    return true;
  }
  return { createSourceReader: createSourceReader, createPinnedSourceReader: createPinnedSourceReader, checkedScopedResult: checkedScopedResult, waitForExpectedSource: waitForExpectedSource, serializeReadError: serializeReadError, createReader: createReader, createReadJob: createReadJob, install: install, eventHint: eventHint,
    safeSDKCall: safeSDKCall, safeSDKError: tagSDKError, isSDKUnsupported: isSDKUnsupported, readViewConfiguration: viewConfiguration,
    invalidateCache: invalidateCache, clearCache: clearCache, configurationSignature: configurationSignature, retireConfiguration: retireConfiguration,
    isMetadataTimeout: isMetadataTimeout, isTransientConnectionError: isTransientConnectionError, awaitMetadata: awaitMetadata, createMetadataGate: createMetadataGate, createReconnectPolicy: createReconnectPolicy };
});
