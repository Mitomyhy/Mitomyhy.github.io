MITOM R75 explicit-read latency repair 2026.10.27.5

Save your work and close Photoshop and OrderStudio yourself before Update Base Background Read.cmd.
Check Base Background Read.cmd is a read-only package/ownership/precondition check; it also requires closed applications.
Requires the exact managed R74 cold-source repair with the R71 manual-only prerequisites. Unknown, older unpatched or custom files are preserved and refused.
Verifies fourteen allowlisted code/documentation files; only the two differing SDK entry/index files are written. Five exact R71 prerequisites and all historical receipt ownership pins are verified.
No models, CPU/GPU engines, pairing, configuration, receipts, Chrome profile files or preferences are changed.
Companion stays at 1.0.30 and all Companion/handoff bytes are unchanged from R74; no Companion reload, removal or re-pairing is needed.
After installation, reopen Photoshop/OrderStudio as needed and hard-reload only the Base tab once (Ctrl+Shift+R) to load the R75 Reader entry.
Applications need to be closed for installation/precondition checks only, not for normal background reads afterward.
This installer never reloads Chrome, activates tabs, opens Base, reads orders or starts Generate.
Rollback uses the existing Launcher Restore previous version; separate Companion handoff backups are not rolled back by it.
This local candidate is not a statement that native Chrome background reading or public deployment has passed.
