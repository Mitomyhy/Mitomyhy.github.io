UOY Base Companion — Chrome v1.0.25 / content 20261024-R62 / host 20261023-R55
Stable Chrome extension ID: nbmhofblkjlmlijiokgdeojjomjcphhj

R62 — one compact Order button with the table width restored
Collapse retains the same authenticated SDK iframe. The exact verified Base
table/hidden switcher reservation is released using reversible presentation
markers; unrelated Comments controls and document contents are not changed.
Only one root-level Companion control survives an extension-world reload.
Update the same unpacked folder, reload the extension, then refresh the Base
tab once to replace its previous isolated script. Keep pairing and storage.
Host wire R55, permissions and stable identity remain unchanged.

R55 — automatic opener and event-reader recovery
Use the matching bridge whose requiredLauncherBuild is 20261023-R55.
No hardcoded machine or Companion installation path is used at runtime.
Existing saved controls are optional exact-match hints. A unique public
Extensions / Customize / Order route is resolved and checked again before
each click. Missing teaching no longer blocks this route. Ambiguous controls,
unrelated frames, login and permission dialogs are never guessed or clicked.
The broker retries only certified zero-action standby refusals, at most three
attempts per exact source/page, with 2s and 5s backoff. Unknown or partially
clicked outcomes are never replayed. SDK event/source proof remains required.
Save and close Photoshop/OrderStudio before installing the shared bridge.
Reload this SAME unpacked Companion once, refresh only the Base tab once,
then reopen Photoshop. Keep extension identity, trust, pairing and storage.
The R51 notes below are historical; mandatory opener teaching is superseded.

R51 — reader recovery and independent opening/collapse readiness
Install with the matching R51 Photoshop bridge. Reload this SAME unpacked
extension at chrome://extensions once, then refresh only the Base tab once.
Do not Remove, Forget, clear browser storage, or copy another PC's pairing.
The extension ID, public key, permissions, remembered pairing and learned
controls remain unchanged. No browser profile or account data is packaged.

A single exact retained reader is challenged and rebound before any UI control
is required. If no reader exists, toolbar and Order must be taught before UI
opening; Customize remains optional. Back and list-X are needed only for safe
collapse. If either is missing, Order is kept open and reads are not blocked.
The popup reports this explicitly; it never guesses a replacement close button.

Only a definitive no-action failure releases a standby reservation. A dispatched
command with unknown outcome stays fenced, including after worker restart.
Source metadata comes from the exact selected tab/page; rows are accepted only
after the matching SDK reader independently confirms the requested source.
After the first import, the matching Panel can follow view events without a
new manual import. Closing/discarding the Base tab or stopping its iframe can
interrupt this runtime; fresh source confirmation is required after reconnect.

The notes below describe previous releases. The R51 behavior above supersedes
their four-control prerequisite and explicit-import-only wording.

20261013 R29 — start the reader automatically, preserve the existing hidden flow
Install together with the matching R29 Photoshop bridge. Reload this SAME
unpacked Chrome extension once, then refresh the Base tab once. Do not Remove,
Forget, clear storage, copy another machine's pairing, or paste a new code.
Existing identity, permissions, remembered pairing and taught controls remain.
All four existing controls are still required for automatic open and safe
collapse: toolbar, Order, Back to the extensions list and X of that LIST.
The optional Customize route remains available. Never use the X of Order.

With Photoshop's Order panel running and the paired, logged-in Base tab ready,
the broker may issue one bounded standby open for the exact freshly verified
Base/table/view and top-document identity. The official SDK reader then returns
to its retained hidden state using the existing Back + list-X flow. It does not
remain floating over the Base and does not read rows until explicit Photoshop
Nap. Companion still does not read orders or grant Base/Chrome permissions.
Chrome startup and restored tab events reconnect remembered setup without
manually opening Order every day. Closed applications or a missing/logged-out
Base cannot be made resident by this update; no OS startup settings are changed.
Standby waits until the Base document is visible before claiming or opening it;
an inactive/minimized tab is not consumed as a failed startup attempt. A healthy
already retained hidden SDK reader still serves explicit reads as before. The
Base may remain visible while Photoshop has keyboard focus; no focus stealing.

Each top document has a random, noncredential page ID. Before any standby DOM
command is sent, a bounded Chrome-session ledger records only its public source
metadata and page ID. Worker/broker restart cannot automatically replay that
page/view's unknown standby action. A full ledger stops standby rather than
evicting an alive page; explicit Nap remains available. A real Chrome restart
creates new documents and a new session. Pause/Forget and changed tab/view/page
always defeat an in-flight action; no private Lark API, iframe injection, account
access, cookie, token or order snapshot is added to this ledger or package.

R28 current-tab selection and bounded cold-recovery protections are retained.
Fixture checks are not a signed-in Base/reboot test; verify the real retained
reader after installation. Previous release history below is historical.

20261008 R28 — resolve duplicate Base tabs by the current Chrome tab
Already-R27 Photoshop bridge files remain byte-identical; update only this
Companion and Photoshop may stay open. Older Panels can use the full updater.
Reload this SAME unpacked Chrome extension once, then refresh the Base tab
once. Keep saved pairing, controls,
permissions, storage and extension identity; do not Remove or Forget.
When the same paired Base is open in several tabs, select the exact Base tab
that is active in Chrome's last-focused window. Other inactive tabs do not
force a blanket multiple-tab failure. When only one matching Base tab exists,
the established unique-tab fallback is retained.
The tab list/current selection is checked afresh for metadata polling and
before dispatch. A changed target or view cannot retarget or replay a command.
The content helper refuses a DOM command in an inactive/hidden document.
Cleanup closes only the exact reader tab that acknowledged its preceding open;
a worker restart loses that memory-only ownership and declines guessed cleanup.
No permanent active-tab selection, previous view, order snapshot, cookies or
account data is stored to decide the target. Unresolvable conflicts still
fail closed. Existing R27 deadlines/recovery and SDK R20 read checks remain.
Protocol core BUILD stays R22; no additional Chrome permissions are needed.
Automated fixtures do not confirm a real signed-in Base import on this machine.

Previous release history follows; use the R28 instructions above for this update.

20261008 R27 — bounded Chrome recovery and exact local diagnostics
Install with the R27 Photoshop bridge. Reload this SAME unpacked Chrome
extension once after updating, then refresh the Base tab once to replace its
old isolated helper. Do not Remove, Forget, clear storage or paste a new code.
This one-time update step is not required after every Photoshop/computer restart.
Chrome storage, permission, tab inspection, injection and context RPC have an
eight-second deadline. Timed-out sessions cannot resume a stale follow-on chain.
A remembered enabled pairing authenticates locally before tab inspection, so
the Panel receives named errors for a missing tab, multiple Base tabs, a missing
table/view URL, denied permission or unavailable tab helper instead of masking
them behind a generic 45-second wait. No URLs, Chrome exception text, rows,
cookies or account data are added to that diagnostic channel.
Temporary tab/context failures retry at bounded intervals, preserving Pause,
Forget, saved authorization and exact Base/table/view checks. Denied permission,
auth/version errors and multiple tabs never trigger a fast retry hammer.
A dispatched DOM command is not replayed just because its acknowledgement was
lost. Public-URL wake hints retry rejected acknowledgements, never old view rows.
Tests use synthetic Chrome/DOM and local HTTP fixtures. They do not confirm a
successful live signed-in Base read on this machine.

Previous release history continues below.

20261007 — automatically recover remembered connections after a reboot
Install with the R26 Photoshop Base bridge and Reload this SAME unpacked Chrome
folder once after updating. Existing Base permission, pairing, calibration and
extension identity are retained. Do not Remove, Forget or clear browser storage.
After that update, Chrome startup, extension reload, the fallback alarm and a
restored/updated Base tab all resume the stored connection without opening the
popup or manually opening/closing the Base Order extension each day.
Awake local outages use the bounded 1/2/4/5-second retry. Body I/O interruption
or empty successful JSON EOF while Photoshop closes also resumes safely; invalid
JSON, HTTP authentication refusals, permissions and protocol errors do not.
The launcher wire build is now R21, so an older restart-broken Companion cannot
silently appear compatible with the updated bridge. The reader's Base permission
is separate and must already be valid. Keep the exact Base tab open and logged in,
with a public URL specifying table and view; no old view IDs or rows are cached.
Chrome sleep/discard/reboot recovery is bounded by the browser's own wake timing,
not a promise of instant reconnect. The R26 bridge waits for cold wake instead
of failing at its former ten-second metadata deadline. Actual signed-in Base
and machine reboot validation remain necessary after fixture verification.

20261005 — reconnect faster after Photoshop closes/reopens
Remembered local pairings retry a failed loopback connection after 1, 2, 4,
then at most 5 seconds while the Chrome worker is awake. Successful metadata
resets this backoff. Each attempt rechecks permission, the exact Base/tab and
enabled state before authenticated hello; no saved order snapshot is substituted.
Pause/Forget or new setup cancels the retry timer. AUTH/REVOKED, tab conflicts,
permission/setup errors and malformed server responses do not fast-retry.
If an active metadata poll loses its launcher owner during broker restart,
one authenticated re-hello is attempted; a repeated CLIENT refusal stops it.
A dispatched open/close job is not automatically replayed when acknowledging
its result fails. Chrome suspension or sleeping tabs can still defer reconnect;
the 30-second alarm remains only a fallback, not a normal awake reconnect wait.
Update and Reload the SAME Companion folder, preserving its key and storage.
This update does not change the single-tab guard or copy pairing to other PCs.

20261005 — faster current-view handoff and truthful setup status
Install this Companion together with the supplied updated Photoshop Base bridge.
Reload the SAME existing unpacked Chrome folder; do not Remove, Forget or clear
Chrome storage. The update preserves this machine's pairing and taught buttons.
Copying update files to another machine does not copy authorization: pair the
official Order reader and Companion once on that machine if not already paired.
Controls are taught for the Base, not tied to a view. A different view in that
same Base does not require another code; the exact table/view is checked for
every read and before any open/close action. A different Base is paired separately.
Authenticated metadata polling now resumes after one second between sessions.
The isolated helper wakes on public URL view changes; it does not read rows,
cookies, account data or Lark internals. Pausing automation still stops this work.
If required controls are missing, Companion reports the exact view and missing
setup instead of leaving Photoshop waiting silently. Teach only the controls
named in the popup. Never teach the destructive X of Order itself.
VM protocol tests do not prove the signed-in tenant's actual UI structure.

History follows; historical release numbers below are not current instructions.

R22 — teach the actual non-semantic Order title in Lark Customize
The observed custom Order entry is a div, not a button or menuitem. R22
recognizes only that exact public title control inside its custom-extension
list, with the exact Order label; it does not enable generic div/data clicks.
The taught control must remain unique, visible and in its original scope.
Raw title length is checked before matching; truncation cannot create a match.
All saved pairings and previously taught controls are retained. Update the
same Chrome folder and Reload v1.0.5; no new code, Forget or Remove needed.
Keep automation paused while finishing Order teaching, then enable it.
CEP/SDK/broker remain byte-identical to R18; Photoroom/Canva/UXP are unchanged.
Verify fresh reads and actual Photoshop restart; cached rows are not proof.

R20 — distinguish generic Lark header buttons by their public icon
Live Lark header buttons share generic classes. The optional bounded SVG
data-icon fingerprint distinguishes a taught Back button from an Order X;
close controls additionally must belong to the verified local reader sidebar.
No SVG paths, HTML, row content, coordinates or positional guesses are saved.
Existing pairing and learned controls remain valid. Update the same eight
Chrome files and Reload; the popup shows R18/v1.0.4. Do not Forget/re-pair.
Keep automation paused while teaching the controls; enable after setup.
R20 changes only Chrome; CEP, SDK reader, broker, Photoroom/Canva and PSDs stay
unchanged. Verify teaching and Nạp on the actual Base before claiming success.

R19 history — optional Customize route retained in R20
R19 — Order nested under Custom / Tùy chỉnh
The existing R18 broker and official reader are unchanged. The popup deliberately
still reports wire build 20261004-R18, now with v1.0.3. If R18 is already installed,
update only the eight files in the SAME loaded Chrome-Base-Companion folder and
Reload the extension. Do not reinstall CEP, close Photoshop, Forget, Remove the
extension, clear storage or paste another pairing code for this update.
For Bases whose Order is under Tùy chỉnh, teach the optional 2a Customize control
once in addition to the original four controls. Open the extension list before
teaching it. Automation uses only this explicitly taught control if Order is
absent; it never guesses a menu, changes a view or grants permission. Direct
Order lists and their existing four learned controls remain compatible.
When teaching, pause Tự mở/ẩn Order khi Nạp; re-enable after setup. Teach toolbar
with the sidebar hidden, Customize on the list, then Order inside Customize,
then Back at the LEFT of Order, then X of the extension LIST. Never teach Order X.
Verify actual Lark calibration and fresh Nạp after updating; fixture tests alone
do not establish the signed-in tenant's menu structure or iframe retention.

R18 — retained reader recovery after Photoshop restart
Keep the whole Base tab open and signed in. If the official Order iframe is
still retained after Back then LIST X, restarting Photoshop changes the broker
instance, not the saved Base permission. R18 allows that SAME remembered Base
reader to perform a narrowly authenticated hello again before any fresh read.
It does not accept an old instance for poll/result, grant another Base, restore
revoked trust or substitute an old order snapshot. No API key is required.
Explicit Forget/revocation is different from Photoshop restart: AUTH/REVOKED
means the supplied trust is no longer accepted, not proof that Chrome failed
to save it. Pair the affected reader/Companion once again after an intentional
Forget; do not erase browser storage or assume automatic recovery can undo it.
The R18 release updated the existing loaded folder and preserved its key/ID;
its popup showed 20261004-R18 / v1.0.2 (R19 now shows v1.0.3). Load reader R18
once by reopening ONLY Order
if it still reports R17; do not close the whole Base tab. Existing valid saved
pairing, field mapping and all four learned controls remain in place.

R17 history — retained in R18
R17/v1.0.1 introduced the 360px intrinsic popup width, truthful saved/session
status, identity-preserving reconnect and Back then LIST X instead of Order X.
R16 upgrades retain toolbar/Order calibration and teach only the new Back/list
X steps. Published R17 archives are unchanged; current installation uses R18.

Purpose
Keep the Base tab open and signed in. After one-time setup, Photoshop's explicit
Nạp từ Base asks this Chrome companion to open the public Order sidebar, waits
for the existing Order SDK reader to return the selected view, then asks it to
hide its sidebar via Back to extension list, then the LIST X (never Order X).
The same official reader iframe must remain connected. No Lark API key, cookies,
private API or order-row scraping.
The first reader connection can also request an automatic close after readiness.
The companion does not itself read orders; the existing reader retains that job.

Installation (human steps)
1. In Chrome, open chrome://extensions, enable Developer mode yourself and Load
   unpacked this directory (the one containing manifest.json).
2. Keep the intended exact Base tab selected in Chrome. Select a view whose URL includes
   table=... and view=... . Open/allow and pair the existing UOY Order Custom
   Base extension with Photoshop first. Existing saved reader pairing is retained.
3. In Photoshop > Kết nối Base, copy the separate Chrome Companion code. It has
   role "uoy-base-launcher". Do not paste the reader/Order pairing code here.
4. Open the Chrome companion popup on the Base tab, paste the companion code,
   and press Kết nối Base đang mở. You personally approve Chrome's permission
   for this exact Base origin. This does not ask for access to all websites.
5. Teach four controls once. For each step, press the popup's corresponding
   Dạy button; the popup closes and instructions appear on the Base page. Click
   the real public control yourself:
   - Phần mở rộng toolbar button: your normal click opens the extension list.
   - Order/UOY Order Custom entry: your normal click opens the existing reader.
   - Back to extensions at the LEFT of the Order header: returns to the list.
   - X of the EXTENSION LIST after going back: hides that list, retaining Order.
   Do NOT teach X of Order. R16's old close fingerprint is discarded intentionally;
   existing toolbar/Order fingerprints and remembered pairing remain valid.
   Each recording lasts at most 60 seconds and has Hủy. Tool records only bounded
   control labels/IDs/public class names, never input values, row text or HTML.
   A generic control additionally needs public tabindex and pointer-cursor
   button-like evidence. Ambiguous/unnamed-and-unidentified controls or an X
   outside the verified local Order iframe are rejected, not guessed.
   View tabs (role tab or inside a tablist) are never accepted as learned buttons.
6. Press Nạp từ Base in Photoshop. Order may appear briefly and hide afterward.
   If Lark changes its controls, teach again. Never teach login/security/share/
   delete controls. CAPTCHA, login or browser permissions always remain manual.
   Uncheck Tự mở/đóng Order khi Nạp to pause automation while manually editing
   Order settings. This stops polling and cancels pending content-script clicks;
   re-check it when ready. A nameless Lark toolbar icon cannot be taught safely:
   there is no position-based fallback or selector guessed from a screenshot.

Limits and recovery
- Keep the paired Base tab open. Multiple matching Base tabs use the active
  exact-Base tab in Chrome's last-focused window; unresolvable conflicts stop.
  Different table/view or target during a command cancels the operation;
  select your intended view and press Nạp again. It never changes selected view.
- Only the exact paired Base is controlled; only one Base is configured at a
  time. Connecting another Base is an explicit popup action and permission.
- Back must belong to exactly one visible local Order iframe. The list X must
  share its bounded sidebar with the SAME retained hidden iframe. Another web
  sidebar is not closed/replaced; deleted/proxy/nested/ambiguous layouts stop.
- Chrome worker sessions are bounded and reconstructed from storage. Chrome
  120+ alarms remain a 30-second suspension fallback. Awake remembered local
  outages use the capped reconnect timer above; sleeping Chrome cannot respond
  immediately. Kiểm tra kết nối wakes it without copying another pairing code.
- Durable launcher trust is stored only in extension-local storage, inaccessible
  to content scripts. If Photoshop cannot remember the separate launcher trust,
  it stays in browser session storage and popup reports remembered=false.
  Quên Companion removes its configuration and Base permission, not Base data.
- Closing only the popup does not Forget. An explicit Quên action is not a
  temporary disconnect: pairing that was removed/revoked needs one fresh,
  human-authorized setup for that role. AUTH/REVOKED is never bypassed.
- Reopening the popup uses stored configuration. "Chưa có cấu hình ghép" means
  Chrome has no completed pairing; the remembered Order pairing is separate.
  Once remembered, use Tiếp tục / Kiểm tra kết nối without copying code again.
  Reconnecting the same Base preserves client identity; late hello responses
  cannot overwrite Pause, Forget or learned controls. Temporary bridge failure
  while Photoshop is off never deletes remembered configuration.
- Update the existing loaded folder and Reload; do not Remove/reinstall or erase
  Chrome storage. Keep its stable ID/public key so saved configuration survives.
- The manifest contains a PUBLIC RSA identity key only; no private key exists in
  this package. Permissions: storage/scripting/alarms/activeTab, required localhost,
  optional Lark/Feishu origin granted only by your explicit connection click.
- There is no page postMessage command bridge, hidden iframe, page-JS evaluation,
  debugger, cookie/history access, or external network request from this addon.

Verification status
Automated tests use synthetic DOM/Chrome/network fixtures. Actual Lark control
calibration, installation, permissions and end-to-end reads on your signed-in
Base still need human validation. Do not interpret fixture tests as a successful
real Lark test or as a guarantee of Lark's DOM stability. R26 restart recovery
must also be checked on the user's retained real SDK iframe after installation.

Official references
https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts
https://developer.chrome.com/docs/extensions/reference/api/permissions
https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle
https://developer.chrome.com/docs/extensions/reference/api/alarms
