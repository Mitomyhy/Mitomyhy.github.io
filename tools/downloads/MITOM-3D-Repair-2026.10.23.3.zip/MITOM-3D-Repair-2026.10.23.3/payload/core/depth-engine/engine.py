"""Local Photoshop depth worker. NDJSON pipes only; no HTTP or image uploads.

MoGe-2 supplies the global geometry and normals. Depth Anything V2 Small adds
the semantic shape prior in one generate request; MobileSAM handles clicked
region masks. Old Marigold heights remain readable without its model. Dependencies remain
lazy so ``status`` works before model setup.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
from datetime import datetime, timezone
import gc
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
import traceback
import uuid

from png_resolution import normalize_dpi, read_dpi, save_png
import ceramic_product as product

MODEL = "Ruicheng/moge-2-vitl-normal"
SCULPT_MODEL = "depth-anything/Depth-Anything-V2-Small"
SCULPT_CACHE_VERSION = "sculpt-da2-small-v1"
MARIGOLD_MODEL = "prs-eth/marigold-depth-v1-1"
MARIGOLD_CACHE_VERSION = "marigold-depth-v1.1-height-v1"
MAX_PIXELS = 40_000_000
MAX_REQUEST_BYTES = 1_000_000
JOB_ID_RE = re.compile(r"^[a-f0-9]{32}$")
WARNING = ("Single-image AI depth estimate, normalized for visual relief; not a measured 3D scan "
           "or manufacturing depth in millimetres. Normals describe the original MoGe surface, "
           "not the refined or manually adjusted relief.")


class DepthEngine:
    def __init__(self, root, models, progress=None):
        self._root_requested = Path(root).expanduser().absolute()
        self.root = Path(root).expanduser().resolve()
        self.models = Path(models).expanduser().resolve()
        self.progress = progress or (lambda value, message: None)
        self._moge = self._da2 = self._marigold = self._sam = self._predictor = None
        self._predictor_job = None
        self._predictor_size = None
        self._torch = None
        self._relief_cache = None
        self._current_job_id = None

    def _temp_jobs(self):
        from temp_jobs import TempJobs
        return TempJobs(self._root_requested)

    def clear(self, params):
        """Discard owned worker snapshots, never the original PNG or models."""
        if any(key not in ("job_id", "keep_job_id", "product_type") for key in params):
            raise ValueError("Clear accepts only job_id, keep_job_id and product_type.")
        if any(not isinstance(value, str) for value in params.values()):
            raise ValueError("Clear job identifiers must be strings.")
        result = self._temp_jobs().clear(**params)
        keep = params.get("keep_job_id")
        explicit = params.get("job_id")
        removed = set(result["removed_jobs"])
        if "product_type" not in params and (not explicit or self._current_job_id == explicit):
            self._current_job_id = keep
        elif self._current_job_id in removed:
            self._current_job_id = keep
        cache_job = self._relief_cache[0][0] if self._relief_cache else None
        if (("product_type" not in params and ((not explicit and cache_job != keep) or explicit == cache_job))
                or cache_job in removed):
            self._relief_cache = None
        if (("product_type" not in params and ((not explicit and self._predictor_job != keep) or explicit == self._predictor_job))
                or self._predictor_job in removed):
            self._predictor_job = self._predictor_size = None
            if self._predictor is not None and callable(getattr(self._predictor, "reset_image", None)):
                self._predictor.reset_image()
        return result

    def _discard_failed_job(self, job_id):
        try:
            report = self.clear({"job_id": job_id})
            if report["retained_jobs"]:
                print("Temporary cleanup retained unsafe/locked data: " + json.dumps(report), file=sys.stderr)
        except (ValueError, OSError) as exc:
            print("Temporary cleanup retained data: " + str(exc), file=sys.stderr)

    def ack(self, params):
        """Release obsolete files only after the UI accepted the new result.

        Inference completion is not publication: cancellation can race the
        final NDJSON reply. Until this acknowledgment the old job/PNG remains
        available, including the preceding Apply version in the same job.
        """
        if set(params) != {"job_id", "version"}:
            raise ValueError("Acknowledge requires only job_id and version.")
        version = params["version"]
        if not isinstance(version, int) or isinstance(version, bool) or version < 1:
            raise ValueError("Acknowledge version must be a positive integer.")
        store = self._temp_jobs()
        folder, metadata, _, _ = store.inspect(params["job_id"])
        if (not metadata or metadata.get("temporary_session") is not True
                or isinstance(metadata.get("version"), bool)
                or metadata.get("version") != version):
            raise ValueError("Acknowledge does not match the current temporary result.")
        if not all(metadata.get(field) and (folder / metadata[field]).is_file()
                   for field in ("depth_file", "preview_file")):
            raise ValueError("Acknowledge requires both completed current PNGs.")
        if metadata.get("imported_template") is True:
            from template_depth_import import acknowledge
            return acknowledge(self, params, folder, metadata)
        local = metadata.get("local_refinement", {})
        if (not isinstance(local, dict) or local.get("profile") != "sculpt"
                or local.get("available") is not True):
            raise ValueError("Acknowledge requires completed DA2 refinement.")
        self._sculpt_height(folder, metadata, tuple(metadata["raw_depth_shape"]))
        self._current_job_id = metadata["job_id"]
        try:
            pruning = store.prune(metadata["job_id"])
        except (ValueError, OSError) as exc:
            pruning = {"retained": True, "reason": str(exc)}
        try:
            cleanup = self.clear(dict(keep_job_id=metadata["job_id"],
                **({"product_type": metadata["product_type"]} if "product_type" in metadata else {})))
        except (ValueError, OSError) as exc:
            cleanup = {"cleared": False, "retained_jobs": [], "error": str(exc)}
        return {"acknowledged": True, "job_id": metadata["job_id"], "version": version,
                "temp_cleanup": cleanup, "temp_pruning": pruning}

    def status(self):
        core_names = ["numpy", "PIL", "torch", "torchvision", "moge", "timm",
                      "scipy", "cv2", "huggingface_hub"]
        names = core_names + ["mobile_sam"]  # Optional legacy segmentation only.
        dependencies = {}
        for name in names:
            try:
                dependencies[name] = importlib.util.find_spec(name) is not None
            except (ValueError, ImportError, ModuleNotFoundError):
                dependencies[name] = False
        # Older MoGe-2 packages use utils3d; newer compatible source uses utils3d_moge.
        geometry_modules = []
        for name in ("utils3d", "utils3d_moge"):
            try:
                geometry_modules.append(importlib.util.find_spec(name) is not None)
            except (ValueError, ImportError, ModuleNotFoundError):
                geometry_modules.append(False)
        dependencies["utils3d"] = any(geometry_modules)
        missing = [name for name in core_names if not dependencies[name]]
        model_files = {"moge": "moge-2-vitl-normal.pt", "mobile_sam": "mobile_sam.pt",
                       "depth_anything_v2": "depth-anything-v2-vits.pth"}
        missing_models = [model_files[name] for name in ("moge", "depth_anything_v2")
                          if not (self.models / model_files[name]).is_file()]
        da2_checkpoint = self.models / model_files["depth_anything_v2"]
        da2_source_root = self.models / "depth-anything-v2-source"
        missing_sculpt_models = []
        sculpt_error = None
        try:
            from download_models import MODELS, source_install_valid, verify
            da2_checkpoint_spec = next(
                item for item in MODELS if item["name"] == model_files["depth_anything_v2"])
            da2_source_spec = next(
                item for item in MODELS if item.get("extract_to") == "depth-anything-v2-source")
            checkpoint_valid = verify(da2_checkpoint, da2_checkpoint_spec)
            source_valid = source_install_valid(da2_source_root, da2_source_spec)
        except (ImportError, OSError, StopIteration, TypeError, ValueError) as exc:
            checkpoint_valid = source_valid = False
            sculpt_error = "Depth Anything V2 integrity check failed: " + str(exc)
        if not checkpoint_valid:
            if model_files["depth_anything_v2"] not in missing_models:
                missing_models.append(model_files["depth_anything_v2"])
            missing_sculpt_models.append(model_files["depth_anything_v2"])
        if not source_valid:
            missing_sculpt_models.append("depth-anything-v2-source")
        common = ["numpy", "PIL", "torch", "torchvision"]
        depth_ready = all(dependencies[n] for n in common + ["moge", "scipy", "cv2", "huggingface_hub", "utils3d"]) and model_files["moge"] not in missing_models
        segment_ready = (all(dependencies[n] for n in common + ["mobile_sam", "timm", "cv2"])
                         and (self.models / model_files["mobile_sam"]).is_file())
        sculpt_ready = depth_ready and dependencies["cv2"] and not missing_sculpt_models
        return {"runtime_schema": 2,
                "generation_pipeline": product.ACRYLIC_COMPOSITION_PIPELINE,
                "supported_generation_pipelines": [product.SHARED_PIPELINE, product.ACRYLIC_COMPOSITION_PIPELINE],
                "job_store_isolation": "exclusive-data-root-v1",
                "ready": sculpt_ready, "depth_ready": depth_ready,
                "segment_ready": segment_ready, "sculpt_ready": sculpt_ready,
                "generate_ready": sculpt_ready,
                "missing_models": missing_models, "missing_sculpt_models": missing_sculpt_models,
                "missing_dependencies": missing, "dependencies": dependencies, "device": "cpu",
                "model": MODEL, "sculpt_model": SCULPT_MODEL,
                "models_dir": str(self.models), "warning": WARNING,
                **({"sculpt_error": sculpt_error} if sculpt_error else {})}

    def _numeric(self):
        try:
            import numpy as np
            from PIL import Image
            import depth_math
        except ImportError as exc:
            raise RuntimeError("Depth runtime is not installed. Run the 3D Depth Map setup first.") from exc
        return np, Image, depth_math

    def _torch_runtime(self):
        if self._torch is None:
            try:
                import torch
            except ImportError as exc:
                raise RuntimeError("PyTorch is not installed in the depth runtime.") from exc
            torch.set_num_threads(max(1, min(4, (os.cpu_count() or 1) - 2)))
            self._torch = torch
        return self._torch

    def _release_heavy_models(self, *attributes):
        """Drop mutually exclusive CPU-heavy inference models before a load."""
        released = False
        for attribute in attributes:
            if getattr(self, attribute, None) is not None:
                setattr(self, attribute, None)
                released = True
        if released:
            gc.collect()

    def _load_moge(self):
        if self._moge is None:
            self._release_heavy_models("_marigold")
            checkpoint = self.models / "moge-2-vitl-normal.pt"
            if not checkpoint.is_file():
                raise RuntimeError("Missing moge-2-vitl-normal.pt. Finish model setup before generating.")
            self.progress(12, "Loading MoGe-2 Large + Normal on CPU (first run only).")
            self._torch_runtime()
            from moge.model.v2 import MoGeModel
            self._moge = MoGeModel.from_pretrained(str(checkpoint)).to("cpu").eval()
            if not hasattr(self._moge, "normal_head"):
                self._moge = None
                raise RuntimeError("The checkpoint has no normal head; install MoGe-2 Large + Normal.")
            if hasattr(self._moge, "enable_pytorch_native_sdpa"):
                self._moge.enable_pytorch_native_sdpa()
        return self._moge

    def _load_da2(self):
        if self._da2 is None:
            self._release_heavy_models("_marigold")
            self.progress(18, "Loading Depth Anything V2 Small on CPU (first Sculpt run only).")
            try:
                from da2_backend import load_model
                self._da2 = load_model(self.models, self._torch_runtime())
            except (ImportError, FileNotFoundError) as exc:
                raise RuntimeError("Missing Depth Anything V2 Small runtime. Run the 3D Depth Map setup again.") from exc
        return self._da2

    def _load_predictor(self):
        if self._predictor is None:
            checkpoint = self.models / "mobile_sam.pt"
            if not checkpoint.is_file():
                raise RuntimeError("Missing mobile_sam.pt. Finish model setup before selecting a region.")
            self.progress(15, "Loading MobileSAM for point selection.")
            self._torch_runtime()
            from mobile_sam import sam_model_registry, SamPredictor
            self._sam = sam_model_registry["vit_t"](checkpoint=str(checkpoint)).to("cpu").eval()
            self._predictor = SamPredictor(self._sam)
        return self._predictor

    def _job(self, job_id):
        if not isinstance(job_id, str) or not JOB_ID_RE.fullmatch(job_id):
            raise ValueError("Invalid depth job ID.")
        folder = self._temp_jobs().path(job_id)
        path = folder / "metadata.json"
        if not path.is_file():
            raise ValueError("Depth job was not found. Generate the depth map first.")
        with path.open(encoding="utf-8") as handle:
            metadata = json.load(handle)
        if metadata.get("job_id") != job_id:
            raise ValueError("Depth job metadata does not match the selected job.")
        product.is_shared_pipeline(metadata)
        return folder, metadata

    @staticmethod
    def _metadata(folder, metadata):
        temp = folder / "metadata.pending.json"
        with temp.open("w", encoding="utf-8") as handle:
            json.dump(metadata, handle, indent=2, ensure_ascii=False, allow_nan=False)
        temp.replace(folder / "metadata.json")

    @staticmethod
    def _local_png(path):
        if not isinstance(path, str) or not path or "\x00" in path:
            raise ValueError("Choose an existing local PNG file.")
        if path.startswith(("\\\\", "//")) or re.match(r"^[a-zA-Z]+://", path):
            raise ValueError("Choose a local PNG, not a URL or network share.")
        source = Path(path).expanduser().resolve()
        if str(source).startswith(("\\\\", "//")):
            raise ValueError("Choose a local PNG, not a network share.")
        if source.suffix.lower() != ".png" or not source.is_file():
            raise ValueError("Choose an existing local PNG file.")
        return source

    @staticmethod
    def _option_bool(params, key, default=False):
        value = params.get(key, default)
        if not isinstance(value, bool):
            raise ValueError(f"{key} must be true or false.")
        return value

    @staticmethod
    def _rgba_png(opened, np, Image):
        # Pillow clips integer-mode grayscale to [0,255] when converting directly
        # to RGBA. Normalize the PNG's full 16-bit range first so a Photoshop
        # grayscale 16-bit export does not become almost entirely white.
        if opened.mode == "I" or opened.mode.startswith("I;16"):
            pixels = np.asarray(opened)
            gray = np.rint(np.clip(pixels.astype(np.float32), 0, 65535) / 257).astype(np.uint8)
            rgba = Image.fromarray(gray).convert("RGBA")
            transparent_value = opened.info.get("transparency")
            if isinstance(transparent_value, int):
                alpha = np.where(pixels == transparent_value, 0, 255).astype(np.uint8)
                rgba.putalpha(Image.fromarray(alpha))
            return rgba
        return opened.convert("RGBA")

    def generate(self, params):
        """Produce only the completed fixed UHD MoGe + DA2 result.

        The first stage persists raw geometry, not an intermediate depth PNG.
        A failed/cancelled request discards its owned new raw cache and leaves
        the previous completed job intact. UI acknowledgment keeps one job.
        """
        fixed = {"image_path": params.get("image_path"), "resolution": 2048,
                 "quality": "ultra_hd", "relief_mode": "ornament",
                 "surface_finish": "balanced", "detail": .91, "flatten": .65,
                 "smoothing": .17, "source_detail": 1., "invert": False,
                 "local_detail": False}
        for name in ("detail", "flatten", "smoothing", "source_detail", "invert", "fullprint", "color_path", "text_manifest", "product_type", "ceramic_shape_path"):
            if name in params:
                fixed[name] = params[name]
        original_progress = self.progress
        original_base_only = getattr(self, "_generate_base_only", False)
        last_progress = 0
        base_result = None
        completed = False

        def phase_progress(start, span):
            def report(value, message):
                nonlocal last_progress
                mapped = start + round(span * max(0., min(100., float(value))) / 100.)
                # Load callbacks can be emitted after a higher inference marker.
                last_progress = max(last_progress, min(99, mapped))
                original_progress(last_progress, message)
            return report

        try:
            self._generate_base_only = True
            self.progress = phase_progress(0, 70)
            base_result = self.depth(fixed)
            self._generate_base_only = False
            self.progress = phase_progress(70, 29)
            refined = self.refine(dict(fixed, job_id=base_result["job_id"],
                                       profile="sculpt", local_detail=True))
            refinement = refined.get("local_refinement", {})
            if (refined.get("job_id") != base_result["job_id"]
                    or refined.get("cached_sculpt_available") is not True
                    or not isinstance(refinement, dict)
                    or refinement.get("profile") != "sculpt"
                    or refinement.get("available") is not True):
                raise RuntimeError("Generate did not complete a validated DA2 result; previous map preserved.")
            completed = True
            original_progress(100, "Depth map ready: UHD geometry and DA2 detail completed.")
            return refined
        except BaseException:
            if base_result is not None and not completed:
                self._discard_failed_job(base_result["job_id"])
            raise
        finally:
            self.progress = original_progress
            self._generate_base_only = original_base_only

    def depth(self, params):
        # Track only the folder created by this invocation, not a directory
        # difference which could accidentally collect a concurrent user's job.
        previous_tracker = getattr(self, "_creation_tracker", None)
        created = []
        self._creation_tracker = created
        try:
            return self._depth(params)
        except BaseException:
            for job_id in created:
                self._discard_failed_job(job_id)
            raise
        finally:
            self._creation_tracker = previous_tracker

    def _depth(self, params):
        np, Image, dm = self._numeric()
        kind = product.input_identity(self, params)
        source = self._local_png(params.get("image_path"))
        resolution = int(dm.bounded_number(params.get("resolution", 768), 256, 2048, "resolution"))
        quality = params.get("quality", "balanced")
        tokens = {"fast": 1200, "balanced": 1200, "detail": 1800, "high": 2500,
                  "ultra": 3600, "hd": 8100, "ultra_hd": 14400}.get(quality)
        if tokens is None:
            raise ValueError("Quality must be fast, balanced, detail, high, ultra, hd or ultra_hd.")
        if resolution > 1536 and quality not in ("hd", "ultra_hd"):
            raise ValueError("Resolution above 1536 requires experimental hd or ultra_hd quality.")
        high_feature_quality = quality in ("hd", "ultra_hd")
        invert = self._option_bool(params, "invert")
        relief_options = {}
        self._relief_options(relief_options, params)
        if "fullprint" in params:
            relief_options["fullprint"] = product.options(
                params["fullprint"], kind, generation_pipeline=product.ACRYLIC_COMPOSITION_PIPELINE)
            relief_options["alpha_policy"] = "original-fullprint-alpha"
        elif kind != "acrylic":
            relief_options["fullprint"] = product.options(
                None, kind, generation_pipeline=product.ACRYLIC_COMPOSITION_PIPELINE)
        # A new PNG must never inherit another job's cached local geometry.
        relief_options["local_detail"] = False
        self.progress(3, "Checking PNG and transparency.")
        # Validate the actual image format, not only the extension. Never overwrite source.
        with Image.open(source) as opened:
            if opened.format != "PNG" or getattr(opened, "n_frames", 1) != 1:
                raise ValueError("Use a single-frame PNG image.")
            width, height = opened.size
            if width < 8 or height < 8 or width * height > MAX_PIXELS:
                raise ValueError("PNG dimensions must be at least 8 x 8 and at most 40 megapixels.")
            dpi = read_dpi(opened)
            rgba = self._rgba_png(opened, np, Image)
        alpha = np.asarray(rgba.getchannel("A"), dtype=np.uint8)
        if not np.any(alpha):
            raise ValueError("This PNG is completely transparent.")
        job_id = uuid.uuid4().hex
        folder = self._temp_jobs().create(job_id)
        self._creation_tracker.append(job_id)
        product.mark_slot(folder, kind)
        product_capture = product.capture_shape(self, folder, params, (width, height), dpi)
        # Snapshot the decoded pixels now. The user can modify the original while inference runs.
        save_png(rgba, folder / "source.png", dpi)
        from text_layer_commands import capture_snapshot
        text_capture = capture_snapshot(self, folder, params, rgba, dpi)
        input_size = dm.fit_size(width, height, resolution)
        neutral = Image.new("RGBA", rgba.size, (127, 127, 127, 255))
        rgb = Image.alpha_composite(neutral, rgba).convert("RGB").resize(input_size, Image.Resampling.LANCZOS)
        model = self._load_moge()
        torch = self._torch_runtime()
        image = torch.from_numpy(np.asarray(rgb, dtype=np.float32).copy() / 255).permute(2, 0, 1)
        self.progress(30, "Estimating depth and surface normals on CPU. Photoshop remains available.")
        with torch.inference_mode():
            # Keep the raw prediction in HQ so explicit PNG alpha can recover
            # a narrowly bounded model-mask erosion at the subject boundary.
            output = model.infer(image, num_tokens=tokens, use_fp16=False,
                                 apply_mask=not high_feature_quality)
        if not all(key in output for key in ("depth", "mask", "normal")):
            raise RuntimeError("MoGe-2 did not return depth, validity and normals; no substitute map was made.")
        as_array = lambda value: value.detach().cpu().numpy().copy()
        raw_depth, raw_valid, raw_normal = (as_array(output[key]) for key in ("depth", "mask", "normal"))
        intrinsics = as_array(output["intrinsics"]).tolist() if "intrinsics" in output else None
        del output, image
        expected_shape = (input_size[1], input_size[0])
        if raw_depth.shape != expected_shape or raw_valid.shape != expected_shape or raw_normal.shape != (*expected_shape, 3):
            raise RuntimeError("MoGe returned unexpected dimensions; the image was not exported.")
        alpha_small = np.asarray(rgba.getchannel("A").resize(input_size, Image.Resampling.NEAREST))
        geometry_repair = {"repaired_pixels": 0, "enabled": False}
        if high_feature_quality:
            from geometry_validity import (recover_alpha_edge_geometry,
                                           repair_tiny_geometry_holes)
            np.save(folder / "model-valid.npy", raw_valid.astype(bool), allow_pickle=False)
            raw_depth, raw_normal, raw_valid, alpha_recovery = recover_alpha_edge_geometry(
                raw_depth, raw_normal, raw_valid, alpha_small)
            raw_depth, raw_normal, raw_valid, geometry_repair = repair_tiny_geometry_holes(
                raw_depth, raw_normal, raw_valid, alpha_small)
            geometry_repair["enabled"] = True
            geometry_repair["alpha_edge_recovery"] = alpha_recovery
        small_height, small_valid, normalization = dm.depth_to_height(raw_depth, raw_valid.astype(bool) & (alpha_small > 0))
        self.progress(80, "Restoring original PNG dimensions and writing 16-bit depth.")
        base, valid = dm.restore_height(small_height, small_valid, (width, height))
        valid &= alpha > 0
        normal = dm.encode_normal(raw_normal, small_valid, (width, height))
        normal[~valid] = 0
        np.save(folder / "raw-depth.npy", raw_depth.astype(np.float32), allow_pickle=False)
        np.save(folder / "raw-normal.npy", raw_normal.astype(np.float32), allow_pickle=False)
        np.save(folder / "raw-valid.npy", small_valid, allow_pickle=False)
        np.save(folder / "base-height.npy", base, allow_pickle=False)
        np.save(folder / "valid.npy", valid, allow_pickle=False)
        save_png(Image.fromarray(alpha), folder / "alpha.png", dpi)
        save_png(Image.fromarray(normal, "RGB"), folder / "normal.png", dpi)
        metadata = {"job_id": job_id, "width": width, "height": height, "dpi": dpi,
                    "inference_width": input_size[0], "inference_height": input_size[1],
                    "model": MODEL, "device": "cpu", "quality": quality, "num_tokens": tokens,
                    "feature_sampling": self._feature_sampling(input_size, tokens),
                    "geometry_repair": geometry_repair,
                    "normal_coordinates": "OpenCV: x right, y down, z forward; RGB = (normal + 1) / 2",
                    "raw_depth_scale": "MoGe-2 estimated metric depth, not measured physical dimensions",
                    "raw_depth_shape": list(raw_depth.shape), "intrinsics": intrinsics,
                    "normalization": normalization, "source_name": source.name,
                    "created_utc": datetime.now(timezone.utc).isoformat(), "version": 0,
                    "invert": invert, "strength": 0.35, "feather": 2.0, "mask_file": None,
                    "warning": WARNING}
        metadata.update(relief_options)
        metadata.update(text_capture)
        metadata.update(product_capture)
        # Fresh jobs share unchanged Acrylic geometry and artwork composition. This marker
        # is internal, never copied from request fields or an old job's recipe.
        # Unmarked saved ceramic jobs still replay their recorded v0/v1/v2.
        metadata["generation_pipeline"] = product.ACRYLIC_COMPOSITION_PIPELINE
        metadata["temporary_session"] = bool(getattr(self, "_generate_base_only", False))
        return self._export(folder, metadata, base, valid, alpha)

    @staticmethod
    def _feature_sampling(input_size, tokens):
        # MoGe's encoder samples a token grid, not the requested PNG dimensions.
        # Record both grids so a 2000px export is never described as 2000px of
        # independent model evidence. This mirrors the pinned MoGe v2 forward.
        import math
        width, height = input_size
        aspect = width / height
        rows = round(math.sqrt(tokens / aspect))
        columns = round(math.sqrt(tokens * aspect))
        return {"encoder_width": columns * 14, "encoder_height": rows * 14,
                "decoder_width": columns * 16, "decoder_height": rows * 16,
                "experimental": tokens > 3600,
                "checkpoint_recommended_token_range": [1200, 3600]}

    def _arrays(self, folder):
        np, Image, _ = self._numeric()
        base = np.load(folder / "base-height.npy", allow_pickle=False)
        valid = np.load(folder / "valid.npy", allow_pickle=False)
        with Image.open(folder / "alpha.png") as image:
            alpha = np.asarray(image.convert("L"))
        return base, valid, alpha

    def _export(self, folder, metadata, base, valid, alpha):
        from text_layer_commands import require_plain
        require_plain(metadata)
        if getattr(self, "_generate_base_only", False):
            self._metadata(folder, metadata)
            return {"job_id": metadata["job_id"]}
        np, Image, dm = self._numeric()
        base = self._compose_base(folder, metadata, base, valid)
        if "fullprint" in metadata:
            from fullprint_prepare import canonical_height
            base, valid, metadata["fullprint_alpha"] = canonical_height(base, valid, alpha)
        mask_file = metadata.get("mask_file")
        mask = None
        if mask_file:
            # Persisted metadata is not allowed to address a path outside its own job.
            if not re.fullmatch(r"mask-[a-f0-9]{12}\.png", mask_file):
                raise ValueError("Invalid saved mask filename.")
            with Image.open(folder / mask_file) as image:
                mask = np.asarray(image.convert("L")) > 0
        relief = dm.apply_relief(base, valid, alpha, mask, metadata["strength"], metadata["feather"], metadata["invert"])
        metadata.pop("manual_edit", None)
        metadata.pop("manual_undo_available", None)
        if "fullprint" in metadata:
            from fullprint_commands import publish_layer
            return publish_layer(self, folder, metadata, relief)
        return self._publish_relief(folder, metadata, relief)

    def _publish_relief(self, folder, metadata, relief):
        """Publish native final heights without re-running or reapplying the AI."""
        np, Image, _ = self._numeric()
        product_fields = product.result_fields(folder, metadata)
        if (relief.shape != (metadata["height"], metadata["width"])
                or not np.isfinite(relief).all() or np.min(relief) < 0 or np.max(relief) > 1):
            raise ValueError("Invalid final relief heights.")
        mask_file = metadata.get("mask_file")
        if metadata.get("text_layers_applied") is not True:
            metadata.pop("text_pending", None)
        version = metadata.get("version", 0) + 1
        depth_file, preview_file = f"depth-{version:04d}.png", f"preview-{version:04d}.png"
        if (folder / depth_file).exists() or (folder / preview_file).exists():
            # A previously interrupted export must not overwrite its partial output.
            while (folder / depth_file).exists() or (folder / preview_file).exists():
                version += 1
                depth_file, preview_file = f"depth-{version:04d}.png", f"preview-{version:04d}.png"
        dpi = normalize_dpi(metadata.get("dpi"))
        save_png(Image.fromarray(np.rint(relief * 65535).astype(np.uint16)), folder / depth_file, dpi)
        preview = Image.fromarray(np.rint(relief * 255).astype(np.uint8)).convert("RGBA")
        from text_layer_commands import alpha_file, result_fields
        final_alpha_file = alpha_file(metadata)
        with Image.open(folder / final_alpha_file) as alpha_image:
            if alpha_image.size != preview.size:
                raise ValueError("Source alpha dimensions disagree with this job.")
            preview.putalpha(alpha_image.convert("L"))
        save_png(preview, folder / preview_file, dpi)
        metadata.update(version=version, depth_file=depth_file, preview_file=preview_file, dpi=dpi)
        self._metadata(folder, metadata)
        completion = ("Local AI preview ready; full MoGe + DA2 Generate remains separate."
                      if metadata.get("preview_ai") is True else
                      "Source-relief estimate ready; no AI inference has run."
                      if metadata.get("estimate") is True else
                      "Depth map ready: 16-bit PNG, near/raised white.")
        self.progress(100, completion)
        result = {key: metadata[key] for key in ("job_id", "width", "height", "inference_width", "inference_height",
                                                "model", "device", "version", "invert", "strength", "feather", "warning")}
        result.update(dpi=dpi, depth_path=str(folder / depth_file), preview_path=str(folder / preview_file),
                      normal_path=str(folder / "normal.png"), source_path=str(folder / "source.png"),
                      mask_path=str(folder / mask_file) if mask_file else None)
        result.update(alpha_path=str(folder / final_alpha_file), depth_alpha_path=str(folder / final_alpha_file),
                      estimate=metadata.get("estimate", False),
                      depth_kind=metadata.get("depth_kind", "ai-relief"),
                      normal_source=metadata.get("normal_source", "MoGe-2"),
                      temporary_session=metadata.get("temporary_session", False))
        if metadata.get("imported_template") is True:
            result.update(imported_template=True, preview_ai=False,
                          template_import=metadata.get("template_import", {}))
        result.update(result_fields(folder, metadata))
        result.update(product_fields)
        if metadata.get("preview_ai") is True:
            result.update(preview_ai=True, preview_revision=metadata.get("preview_revision", 1),
                          preview_inference=metadata.get("preview_inference", {}))
        if "fullprint" in metadata:
            result.update(fullprint=metadata["fullprint"],
                          fullprint_processing=metadata.get("fullprint_processing", {}),
                          fullprint_alpha=metadata.get("fullprint_alpha", {}),
                          support_mask_path=str(folder / "support-mask.png"),
                          support_info=metadata.get("fullprint_processing", {}).get("support", {}))
        result.update(relief_mode=metadata.get("relief_mode", "depth"), detail=metadata.get("detail", 0.65),
                      flatten=metadata.get("flatten", 0.65), quality=metadata.get("quality"),
                      num_tokens=metadata.get("num_tokens"), relief_processing=metadata.get("relief_processing"))
        result["source_detail"] = metadata.get("source_detail", 0.0)
        result["manual_edit"] = metadata.get("manual_edit", False)
        result["manual_undo_available"] = metadata.get("manual_undo_available", False)
        result["feature_sampling"] = metadata.get("feature_sampling")
        result["geometry_repair"] = metadata.get("geometry_repair")
        result.update(local_detail=metadata.get("local_detail", False),
                      local_refinement=metadata.get("local_refinement", {"available": False}))
        result.update(surface_finish=metadata.get("surface_finish", "legacy"),
                      smoothing=metadata.get("smoothing", .25))
        result["cached_sculpt_available"] = False
        result["requires_ack"] = metadata.get("temporary_session") is True
        if self._profile_refinement(metadata, "sculpt").get("available") is True:
            try:
                self._sculpt_height(folder, metadata, tuple(metadata["raw_depth_shape"]))
                result["cached_sculpt_available"] = True
            except (ValueError, OSError, TypeError, KeyError):
                pass
        return result

    def _relief_options(self, metadata, params):
        _, _, dm = self._numeric()
        mode = params.get("relief_mode", metadata.get("relief_mode", "depth"))
        if mode not in ("depth", "ornament"):
            raise ValueError("Relief mode must be depth or ornament.")
        metadata["relief_mode"] = mode
        metadata["local_detail"] = self._option_bool(params, "local_detail", metadata.get("local_detail", False))
        finish = params.get("surface_finish", metadata.get("surface_finish", "balanced"))
        if finish not in ("legacy", "balanced"):
            raise ValueError("Surface finish must be legacy or balanced.")
        metadata["surface_finish"] = finish
        metadata["smoothing"] = dm.bounded_number(params.get("smoothing", metadata.get("smoothing", .25)), 0, 1, "smoothing")
        for name in ("detail", "flatten"):
            metadata[name] = dm.bounded_number(params.get(name, metadata.get(name, .65)), 0, 1, name)
        metadata["source_detail"] = dm.bounded_number(
            params.get("source_detail", metadata.get("source_detail", 0.0)),
            0, 1, "source_detail")

    def _compose_base(self, folder, metadata, base, valid):
        """Compose immutable inferred geometry, never a previously exported PNG."""
        shared_pipeline = product.is_shared_pipeline(metadata)
        ceramic_version = metadata.get("ceramic_geometry_version", 0)
        if type(ceramic_version) is not int or ceramic_version not in (0, 1, 2):
            raise ValueError("Unsupported ceramic geometry version.")
        if ceramic_version and not product.is_ceramic(metadata):
            raise ValueError("Ceramic geometry cannot be used by an Acrylic job.")
        if shared_pipeline and ceramic_version:
            raise ValueError("Shared AI jobs cannot contain a ceramic geometry recipe.")
        if metadata.get("depth_kind") == "local-ai-preview":
            # This bounded preview intentionally has no MoGe normals/raw-depth
            # caches. Reusing it must not fall into full-resolution refinement.
            return base
        if metadata.get("estimate") is True:
            metadata["relief_processing"] = {"method": "source-relief-estimate", "physical_depth_claim": False}
            return base
        if metadata.get("relief_mode", "depth") == "depth":
            metadata["relief_processing"] = {"method": "original_depth_percentiles", "version": 1}
            return base
        np, Image, dm = self._numeric()
        from relief_detail import enhance_relief
        raw_depth = np.load(folder / "raw-depth.npy", allow_pickle=False)
        cache_key = (metadata["job_id"], metadata.get("detail", .65), metadata.get("flatten", .65),
                     metadata.get("local_detail", False), metadata.get("local_correction_file"),
                     metadata.get("surface_finish", "balanced"), metadata.get("smoothing", .25),
                     metadata.get("source_detail", 0.0))
        options = dict(surface_finish=cache_key[5], smoothing=cache_key[6])
        local_refinement = metadata.get("local_refinement", {})
        if not isinstance(local_refinement, dict):
            local_refinement = {}
        local_profile = local_refinement.get("profile")
        dense = metadata.get("local_detail") and local_profile == "dense"
        sculpt = metadata.get("local_detail") and local_profile == "sculpt"
        ceramic_geometry = not shared_pipeline and sculpt and ceramic_version in (1, 2)
        if ceramic_geometry:
            cache_key += ("ceramic-geometry", ceramic_version)
        marigold = metadata.get("local_detail") and local_profile == "marigold"
        micro = None
        semantic_height = None
        if sculpt:
            semantic_height, sculpt_path = self._sculpt_height(
                folder, metadata, raw_depth.shape)
            sculpt_stat = sculpt_path.stat()
            cache_key += ("sculpt", metadata.get("sculpt_height_file"),
                          sculpt_stat.st_mtime_ns, sculpt_stat.st_size)
        elif marigold:
            semantic_height, marigold_path = self._marigold_height(
                folder, metadata, raw_depth.shape)
            marigold_stat = marigold_path.stat()
            cache_key += ("marigold", metadata.get("marigold_height_file"),
                          marigold_stat.st_mtime_ns, marigold_stat.st_size)
        elif dense:
            from dense_workflow import load_dense_correction
            micro, dense_path = load_dense_correction(folder, metadata)
            dense_stat = dense_path.stat()
            cache_key += ("dense", metadata.get("dense_correction_file"), dense_stat.st_mtime_ns, dense_stat.st_size)
        elif metadata.get("local_detail"):
            options["local_correction"] = self._local_correction(folder, metadata,
                raw_depth.shape)
            cache_stat = (folder / metadata["local_correction_file"]).stat()
            cache_key += (cache_stat.st_mtime_ns, cache_stat.st_size)
        if self._relief_cache and self._relief_cache[0] == cache_key:
            metadata["relief_processing"] = self._relief_cache[2]
            return self._relief_cache[1]
        self.progress(85, "Integrating surface normals into ornament relief detail.")
        raw_normal = np.load(folder / "raw-normal.npy", allow_pickle=False)
        raw_valid_path = folder / "raw-valid.npy"
        if raw_valid_path.is_file():
            raw_valid = np.load(raw_valid_path, allow_pickle=False).astype(bool)
        else:
            # Older completed jobs can be recomposed without running MoGe again.
            raw_valid = np.asarray(Image.fromarray(valid.astype(np.uint8) * 255).resize(
                (raw_depth.shape[1], raw_depth.shape[0]), Image.Resampling.NEAREST)) > 0
        raw_valid &= np.isfinite(raw_depth) & (raw_depth > 0)
        if dense:
            from artistic_relief import compose_artistic_base
            height, processing = compose_artistic_base(raw_depth, raw_normal, raw_valid,
                detail=cache_key[1], flatten=cache_key[2], smoothing=metadata.get("smoothing", .25))
        else:
            height, processing = enhance_relief(raw_depth, raw_normal, raw_valid, metadata.get("intrinsics"),
                                               mode="ornament", detail=cache_key[1], flatten=cache_key[2], **options)
        if sculpt or marigold:
            from sculpt_relief import compose_sculpt_relief
            global_processing = {key: processing[key] for key in
                                 ("algorithm", "version", "normal_used", "surface_finish")
                                 if key in processing}
            if ceramic_geometry:
                from ceramic_geometry import compose_ceramic_geometry
                height, semantic_processing = compose_ceramic_geometry(
                    height, semantic_height, raw_valid, detail=cache_key[1],
                    flatten=cache_key[2], smoothing=metadata.get("smoothing", .25),
                    algorithm_version=ceramic_version)
            else:
                height, semantic_processing = compose_sculpt_relief(
                    height, semantic_height, raw_valid, detail=cache_key[1],
                    flatten=cache_key[2], smoothing=metadata.get("smoothing", .25))
            if marigold:
                # The shared fusion math accepts any normalized near-white
                # semantic field. Keep Marigold metadata semantic and do not
                # leak DA2-specific field names into its public result schema.
                semantic_processing["fusion_core_algorithm"] = semantic_processing["algorithm"]
                semantic_processing["algorithm"] = "marigold-conservative-global-anchor-fusion"
                controls = dict(semantic_processing.get("controls", {}))
                if "requested_da2_weight" in controls:
                    controls["requested_semantic_weight"] = controls.pop("requested_da2_weight")
                semantic_processing["controls"] = controls
                for old, new in (("da2_coarse_weight", "semantic_coarse_weight"),
                                 ("da2_alignment", "semantic_alignment"),
                                 ("da2_fallback_reason", "semantic_fallback_reason")):
                    if old in semantic_processing:
                        semantic_processing[new] = semantic_processing.pop(old)
                alignment = semantic_processing.get("semantic_alignment")
                if isinstance(alignment, dict) and "da2_input_quantiles" in alignment:
                    alignment["semantic_input_quantiles"] = alignment.pop("da2_input_quantiles")
                if isinstance(alignment, dict) and isinstance(alignment.get("fallback_reason"), str):
                    alignment["fallback_reason"] = alignment["fallback_reason"].replace("da2", "semantic")
                fallback = semantic_processing.get("semantic_fallback_reason")
                if isinstance(fallback, str):
                    semantic_processing["semantic_fallback_reason"] = fallback.replace("da2", "semantic")
            processing.update(semantic_processing)
            processing.update(global_base_processing=global_processing,
                              local_detail_used=True, local_profile=local_profile,
                              semantic_model=(MARIGOLD_MODEL if marigold else SCULPT_MODEL))
            if marigold:
                processing["marigold_model"] = MARIGOLD_MODEL
            else:
                processing["sculpt_model"] = SCULPT_MODEL
        if sculpt and not ceramic_geometry:
            from relief_balance import balance_relief_plane
            height, balance_processing = balance_relief_plane(
                height, raw_valid, flatten=cache_key[2])
            processing["broad_height_balance"] = balance_processing
        refined, _ = dm.restore_height(height, raw_valid, (metadata["width"], metadata["height"]))
        if sculpt and not ceramic_geometry and metadata.get("surface_finish", "balanced") == "balanced":
            from relief_transition import smooth_relief_transitions
            refined, transition_processing = smooth_relief_transitions(
                refined, valid, smoothing=metadata.get("smoothing", .25))
            processing["transition_smoothing"] = transition_processing
        if dense:
            from dense_workflow import restore_dense_detail
            from artistic_relief import finish_artistic
            micro = restore_dense_detail(micro, valid)
            refined, finishing = finish_artistic(refined, micro, valid, detail=cache_key[1])
            processing.update(finishing)
            processing.update(algorithm="native-artistic-relief-hd-v1", version=4,
                local_detail_used=True, local_profile="dense",
                normal_fallback_reason=processing.get("normal_fallback"),
                detail_width=metadata["local_refinement"]["detail_width"],
                detail_height=metadata["local_refinement"]["detail_height"])
        source_detail_amount = cache_key[7]
        if source_detail_amount > 0:
            with Image.open(folder / "source.png") as source:
                if source.size != (metadata["width"], metadata["height"]):
                    raise ValueError("Source snapshot dimensions disagree with this job.")
                source_rgb = source.convert("RGB")
                if sculpt:
                    colour = np.asarray(source_rgb, dtype=np.uint8)
                else:
                    # Retain the previous tiny luma band for legacy cached
                    # profiles. The DA2 fullprint stage replaces, not stacks
                    # on top of, that old microtexture adjustment.
                    luminance = (np.asarray(source_rgb.convert("L"),
                                            dtype=np.float32) / np.float32(255))
            if sculpt:
                from fullprint_detail import apply_fullprint_detail
                refined, source_processing = apply_fullprint_detail(
                    refined, colour, valid, raw_normal,
                    source_detail=source_detail_amount,
                    mode=metadata.get("relief_mode", "depth"))
                source_policy = ("opt-in source-aligned shallow fullprint: dark marks incised, light marks raised; "
                                 "source colours are artistic cues, not measured geometry")
            else:
                from source_detail import apply_source_detail
                refined, source_processing = apply_source_detail(
                    refined, luminance, valid, source_detail=source_detail_amount,
                    mode=metadata.get("relief_mode", "depth"))
                source_policy = ("opt-in masked micro-detail only; bounded to 0.5/255 RMS "
                                 "and 1.5/255 peak at full strength; never used for macro depth")
            processing.update(
                source_detail=source_processing,
                source_grayscale_detail_used=source_processing.get("enabled", False),
                source_grayscale_policy=source_policy)
        else:
            processing["source_detail"] = {
                "algorithm": "masked-log-luma-source-detail", "version": 1,
                "source_detail": 0.0, "enabled": False,
                "fallback_reason": "source_detail_disabled",
            }
        refined = np.where(valid, refined, 0).astype(np.float32)
        metadata["relief_processing"] = processing
        self._relief_cache = (cache_key, refined, processing)
        return refined

    def _local_correction(self, folder, metadata, shape):
        np, _, _ = self._numeric()
        name = metadata.get("local_correction_file", "")
        if not isinstance(name, str) or not re.fullmatch(r"local-[a-f0-9]{12}/correction\.npy", name):
            raise ValueError("No cached local refinement. Click Tinh chinh AI local first.")
        path = (folder / name).resolve()
        if not path.is_relative_to(folder.resolve()):
            raise ValueError("Local geometry must remain inside this depth job.")
        correction = np.load(path, allow_pickle=False)
        if correction.shape != shape or not np.isfinite(correction).all():
            raise ValueError("Cached local geometry is invalid; the previous export was preserved.")
        return correction

    @staticmethod
    def _profile_refinement(metadata, profile):
        """Prefer a profile cache record, falling back to legacy active metadata."""
        refinement = metadata.get(profile + "_refinement")
        if isinstance(refinement, dict):
            return refinement
        refinement = metadata.get("local_refinement", {})
        if isinstance(refinement, dict) and refinement.get("profile") == profile:
            return refinement
        return {}

    def _semantic_height(self, folder, metadata, shape, *, profile,
                         metadata_key, cache_version, display_name):
        """Load one job's immutable semantic-height cache safely."""
        np, _, _ = self._numeric()
        name = metadata.get(metadata_key, "")
        refinement = self._profile_refinement(metadata, profile)
        if (not isinstance(name, str)
                or not re.fullmatch(re.escape(profile) + r"-[a-f0-9]{12}/height\.npy", name)
                or refinement.get("profile") != profile
                or refinement.get("cache_version") != cache_version):
            raise ValueError(f"No compatible cached {display_name} refinement. Run that local profile first.")
        path = (folder / name).resolve()
        if not path.is_relative_to(folder.resolve()):
            raise ValueError(f"{display_name} geometry must remain inside this depth job.")
        try:
            height = np.load(path, allow_pickle=False)
        except (OSError, ValueError) as exc:
            raise ValueError(f"Cached {display_name} geometry is invalid; the previous export was preserved.") from exc
        if (height.shape != shape or not np.isfinite(height).all()
                or float(np.min(height)) < 0 or float(np.max(height)) > 1):
            raise ValueError(f"Cached {display_name} geometry is invalid; the previous export was preserved.")
        return height.astype(np.float32, copy=False), path

    def _sculpt_height(self, folder, metadata, shape):
        """Load one job's immutable DA2 semantic-height cache safely."""
        return self._semantic_height(
            folder, metadata, shape, profile="sculpt",
            metadata_key="sculpt_height_file", cache_version=SCULPT_CACHE_VERSION,
            display_name="Sculpt")

    def _marigold_height(self, folder, metadata, shape):
        """Load one job's immutable Marigold semantic-height cache safely."""
        return self._semantic_height(
            folder, metadata, shape, profile="marigold",
            metadata_key="marigold_height_file", cache_version=MARIGOLD_CACHE_VERSION,
            display_name="Marigold")

    def _seed_legacy_active_refinement(self, folder, metadata, shape):
        """Preserve a valid pre-profile-cache record before switching profiles."""
        active = metadata.get("local_refinement", {})
        if not isinstance(active, dict) or active.get("available") is not True:
            return
        profile = active.get("profile")
        if profile not in ("sculpt", "marigold"):
            return
        key = profile + "_refinement"
        if isinstance(metadata.get(key), dict):
            return
        try:
            if profile == "sculpt":
                self._sculpt_height(folder, metadata, shape)
            else:
                self._marigold_height(folder, metadata, shape)
        except (ValueError, OSError):
            return
        metadata[key] = dict(active)

    def _refine_sculpt(self, params):
        """Infer one cached semantic prior, then compose it with global MoGe relief."""
        np, Image, dm = self._numeric()
        folder, metadata = self._job(params.get("job_id"))
        self._adjust_options(metadata, params)
        if metadata["relief_mode"] != "ornament":
            raise ValueError("Choose Relief Ornament before refining Sculpt AI detail.")
        base, valid, alpha = self._arrays(folder)
        raw_depth = np.load(folder / "raw-depth.npy", allow_pickle=False)
        raw_shape = raw_depth.shape
        self._seed_legacy_active_refinement(folder, metadata, raw_shape)
        refinement = self._profile_refinement(metadata, "sculpt")
        if refinement.get("available") and refinement.get("profile") == "sculpt":
            try:
                self._sculpt_height(folder, metadata, raw_shape)
            except (ValueError, OSError):
                # An explicit Sculpt run may rebuild an obsolete/corrupt cache.
                # Adjust/toggle still fails closed through _compose_base.
                pass
            else:
                metadata.update(sculpt_refinement=dict(refinement), local_detail=True,
                                local_refinement=dict(refinement))
                return self._export(folder, metadata, base, valid, alpha)

        with Image.open(folder / "source.png") as opened:
            if opened.size != (metadata["width"], metadata["height"]):
                raise ValueError("Source snapshot dimensions disagree with this job.")
            rgba = np.asarray(opened.convert("RGBA"), dtype=np.uint8)
        from da2_backend import infer_height, prepare_rgba
        rgb, da2_valid, resize_metadata = prepare_rgba(rgba, max_side=1024, background=127)
        self.progress(28, "Sculpt AI: estimating broad semantic shape with Depth Anything V2 Small.")
        small_height, inference_metadata = infer_height(
            self._load_da2(), rgb, da2_valid, input_size=1024)
        restored, restored_valid = dm.restore_height(
            small_height, da2_valid, (raw_shape[1], raw_shape[0]))
        raw_valid_path = folder / "raw-valid.npy"
        raw_valid = (np.load(raw_valid_path, allow_pickle=False).astype(bool)
                     if raw_valid_path.is_file() else
                     np.asarray(Image.fromarray(valid.astype(np.uint8)).resize(
                         (raw_shape[1], raw_shape[0]), Image.Resampling.NEAREST)) > 0)
        raw_valid &= np.isfinite(raw_depth) & (raw_depth > 0)
        coverage = float(np.count_nonzero(restored_valid & raw_valid) /
                         max(1, np.count_nonzero(raw_valid)))
        if coverage < .98:
            raise RuntimeError("Depth Anything did not cover enough visible geometry; the previous map was preserved.")
        restored[~raw_valid] = 0
        if not np.isfinite(restored).all():
            raise RuntimeError("Depth Anything returned invalid Sculpt geometry; the previous map was preserved.")

        cache_name = "sculpt-" + uuid.uuid4().hex[:12]
        cache_folder = folder / cache_name
        cache_folder.mkdir(exist_ok=False)
        np.save(cache_folder / "height.npy", restored.astype(np.float32), allow_pickle=False)
        refinement = {"available": True, "profile": "sculpt",
                      "algorithm": "depth-anything-v2-small-semantic-prior-v1",
                      "cache_version": SCULPT_CACHE_VERSION, "model": SCULPT_MODEL,
                      "semantic_width": int(rgb.shape[1]), "semantic_height": int(rgb.shape[0]),
                      "coverage_fraction": coverage,
                      "resize": resize_metadata, "inference": inference_metadata,
                      "warning": "Sculpt AI approximates a visual relief; it is not SculptOK's proprietary model or measured geometry."}
        metadata.update(sculpt_height_file=cache_name + "/height.npy",
                        sculpt_refinement=dict(refinement), local_detail=True,
                        local_refinement=dict(refinement))
        self._relief_cache = None
        self.progress(78, "Sculpt AI: fusing semantic shape with the original MoGe surface detail.")
        return self._export(folder, metadata, base, valid, alpha)

    def refine(self, params):
        """Run a selected local profile; publish only a complete valid result.

        Global arrays, previous PNGs and the customer's original PNG are never
        modified. Cancellation may leave an unreferenced cache directory, but
        cannot mark a partially inferred set of crops as a completed result.
        """
        profile = params.get("profile", "classic")
        if profile not in ("classic", "dense", "sculpt", "marigold"):
            raise ValueError("Refinement profile must be classic, dense, sculpt or marigold.")
        if profile == "sculpt":
            return self._refine_sculpt(params)
        if profile == "marigold":
            raise ValueError("Marigold inference was removed. Use Generate for DA2; existing cached maps can still be adjusted.")
        if profile == "dense":
            from dense_workflow import refine_dense
            return refine_dense(self, params)
        np, Image, dm = self._numeric()
        from local_detail import merge_local_detail, plan_local_crops
        from relief_detail import _pixel_intrinsics
        folder, metadata = self._job(params.get("job_id"))
        self._adjust_options(metadata, params)
        if metadata["relief_mode"] != "ornament":
            raise ValueError("Choose Relief Ornament before refining local AI detail.")
        base, valid, alpha = self._arrays(folder)
        raw_depth = np.load(folder / "raw-depth.npy", allow_pickle=False)
        raw_normal = np.load(folder / "raw-normal.npy", allow_pickle=False)
        size = (raw_depth.shape[1], raw_depth.shape[0])
        if _pixel_intrinsics(metadata.get("intrinsics"), *size)[0] is None:
            raise ValueError("This old result has no camera calibration. Generate again before local refinement.")
        if metadata.get("local_refinement", {}).get("available") and metadata.get("local_refinement", {}).get("profile") != "dense":
            self._local_correction(folder, metadata, raw_depth.shape)
            metadata["local_detail"] = True
            return self._export(folder, metadata, base, valid, alpha)
        raw_valid_path = folder / "raw-valid.npy"
        raw_valid = (np.load(raw_valid_path, allow_pickle=False).astype(bool) if raw_valid_path.is_file() else
                     np.asarray(Image.fromarray(valid.astype(np.uint8)).resize(size, Image.Resampling.NEAREST)) > 0)
        raw_valid &= np.isfinite(raw_depth) & (raw_depth > 0)
        boxes = plan_local_crops(raw_valid)
        if not boxes:
            raise ValueError("Visible object is too small for local refinement. Use a larger PNG and Generate at 1536.")
        with Image.open(folder / "source.png") as opened:
            rgba = opened.convert("RGBA")
        if rgba.size != (metadata["width"], metadata["height"]):
            raise ValueError("Source snapshot dimensions disagree with this job.")
        local_name = "local-" + uuid.uuid4().hex[:12]
        local_folder = folder / local_name
        local_folder.mkdir(exist_ok=False)
        model, torch = self._load_moge(), self._torch_runtime()
        tiles = []
        for index, box in enumerate(boxes):
            self.progress(18 + round(55 * index / len(boxes)),
                          f"AI local: reading region {index + 1}/{len(boxes)} on CPU.")
            original_box = tuple(round(v * (rgba.width / size[0] if i % 2 == 0 else rgba.height / size[1]))
                                 for i, v in enumerate(box))
            crop = rgba.crop(original_box)
            crop_size = dm.fit_size(*crop.size, 1024)
            rgb = Image.alpha_composite(Image.new("RGBA", crop.size, (127, 127, 127, 255)), crop).convert("RGB")
            rgb = rgb.resize(crop_size, Image.Resampling.LANCZOS)
            image = torch.from_numpy(np.asarray(rgb, dtype=np.float32).copy() / 255).permute(2, 0, 1)
            with torch.inference_mode():
                output = model.infer(image, num_tokens=3600, use_fp16=False, apply_mask=True)
            if not all(k in output for k in ("depth", "normal", "mask", "intrinsics")):
                raise RuntimeError("MoGe crop did not return calibrated depth and normals; previous map was preserved.")
            arrays = {k: output[k].detach().cpu().numpy().copy() for k in ("depth", "normal", "mask", "intrinsics")}
            del image, output
            expected = (crop_size[1], crop_size[0])
            if (arrays["depth"].shape != expected or arrays["mask"].shape != expected
                    or arrays["normal"].shape != (*expected, 3)):
                raise RuntimeError("Local model output dimensions are invalid; previous map was preserved.")
            arrays["mask"] = arrays["mask"].astype(bool) & (np.asarray(crop.getchannel("A").resize(crop_size, Image.Resampling.NEAREST)) > 0)
            for key, array in arrays.items():
                np.save(local_folder / f"tile-{index}-{key}.npy", array, allow_pickle=False)
            tiles.append(dict(box=box, depth=arrays["depth"], normal=arrays["normal"],
                              valid=arrays["mask"], intrinsics=arrays["intrinsics"]))
        self.progress(77, "Merging local surface geometry, preserving the global shape and silhouette.")
        correction, fusion = merge_local_detail(raw_depth, raw_normal, raw_valid, metadata["intrinsics"], tiles,
                                                strength=1.0, max_work_edge=768)
        if not fusion["accepted_tiles"]:
            raise RuntimeError("No reliable local geometry was recovered; the previous map was preserved.")
        np.save(local_folder / "correction.npy", correction, allow_pickle=False)
        with (local_folder / "fusion.json").open("w", encoding="utf-8") as handle:
            json.dump(fusion, handle, indent=2, allow_nan=False)
        metadata.update(local_correction_file=local_name + "/correction.npy", local_detail=True,
                        local_refinement={"available": True, "algorithm": fusion["algorithm"],
                                          "accepted_tiles": fusion["accepted_tiles"], "tile_count": len(tiles),
                                          "num_tokens_per_tile": 3600, "coverage_fraction": fusion["coverage_fraction"],
                                          "warning": "Local estimates can improve detail, not reconstruct unobserved sculpted geometry."})
        self._relief_cache = None
        return self._export(folder, metadata, base, valid, alpha)

    def _adjust_options(self, metadata, params):
        from text_layer_commands import require_plain, validate_controls
        require_plain(metadata)
        validate_controls(metadata, params.get("fullprint"))
        _, _, dm = self._numeric()
        if "fullprint" in params:
            metadata["fullprint"] = product.options(
                params["fullprint"], metadata.get("product_type", "acrylic"),
                generation_pipeline=metadata.get("generation_pipeline"))
            if not product.is_ceramic(metadata):
                metadata["alpha_policy"] = "original-fullprint-alpha"
        for key, low, high in (("strength", 0, 1), ("feather", 0, 20)):
            metadata[key] = dm.bounded_number(params.get(key, metadata[key]), low, high, key)
        metadata["invert"] = self._option_bool(params, "invert", metadata["invert"])
        self._relief_options(metadata, params)

    def _select_cached_profile(self, folder, metadata, params):
        """Apply/selection may switch to DA2 only when its saved cache is valid."""
        if "profile" not in params:
            return  # Old requests may still recompose their recorded profile.
        if params["profile"] != "sculpt":
            raise ValueError("Only the saved DA2 profile can be selected. Use Generate first.")
        refinement = self._profile_refinement(metadata, "sculpt")
        if refinement.get("available") is not True:
            raise ValueError("No completed DA2 cache is available. Use Generate first.")
        shape = metadata.get("raw_depth_shape")
        if not isinstance(shape, (tuple, list)) or len(shape) != 2:
            raise ValueError("Saved depth geometry is incomplete. Use Generate first.")
        self._sculpt_height(folder, metadata, tuple(shape))
        metadata.update(local_refinement=dict(refinement), local_detail=True)

    def segment(self, params):
        np, Image, dm = self._numeric()
        folder, metadata = self._job(params.get("job_id"))
        self._select_cached_profile(folder, metadata, params)
        self._adjust_options(metadata, params)
        size = dm.fit_size(metadata["width"], metadata["height"], 1024)
        coordinates, labels = dm.prompt_coordinates(params.get("points"), *size)
        predictor = self._load_predictor()
        torch = self._torch_runtime()
        with torch.inference_mode():
            if self._predictor_job != metadata["job_id"]:
                self.progress(30, "Encoding the image with MobileSAM.")
                with Image.open(folder / "source.png") as source:
                    rgba = source.convert("RGBA")
                rgb = Image.alpha_composite(Image.new("RGBA", rgba.size, (127, 127, 127, 255)), rgba).convert("RGB").resize(size, Image.Resampling.LANCZOS)
                predictor.set_image(np.asarray(rgb).copy(), image_format="RGB")
                self._predictor_job = metadata["job_id"]
                self._predictor_size = size
            self.progress(60, "Selecting the clicked region and applying concavity.")
            masks, scores, _ = predictor.predict(point_coords=coordinates, point_labels=labels,
                                                  multimask_output=True)
        if not len(masks) or not np.any(np.isfinite(scores)):
            raise RuntimeError("MobileSAM could not select a region; try another positive point.")
        mask = masks[int(np.argmax(np.where(np.isfinite(scores), scores, -np.inf)))]
        if mask.shape != (size[1], size[0]):
            raise RuntimeError("MobileSAM mask dimensions do not match the image.")
        mask = np.asarray(Image.fromarray(mask.astype(np.uint8) * 255).resize(
            (metadata["width"], metadata["height"]), Image.Resampling.NEAREST)) > 0
        base, valid, alpha = self._arrays(folder)
        mask &= valid & (alpha > 0)
        if not np.any(mask):
            raise RuntimeError("The selected region contains no valid visible depth pixels.")
        mask_file = f"mask-{uuid.uuid4().hex[:12]}.png"
        save_png(Image.fromarray(mask.astype(np.uint8) * 255), folder / mask_file, metadata.get("dpi"))
        metadata.update(mask_file=mask_file, points=params["points"])
        return self._export(folder, metadata, base, valid, alpha)

    def adjust(self, params, clear=False):
        folder, metadata = self._job(params.get("job_id"))
        self._select_cached_profile(folder, metadata, params)
        self._adjust_options(metadata, params)
        if clear:
            metadata.update(mask_file=None, points=[])
        return self._export(folder, metadata, *self._arrays(folder))

    def dispatch(self, command, params):
        if not isinstance(params, dict):
            raise ValueError("Request params must be an object.")
        from template_depth_import import guard_command
        guard_command(self, command, params)
        if command in ("template_preview_slot", "template_preview_import"):
            from template_depth_import import input_slot, import_preview
            return (input_slot if command == "template_preview_slot" else import_preview)(self, params)
        if params.get("job_id") and command != "clear":
            params = product.guard_job(self, params)
        if command in ("paint", "undo_paint", "import_edit", "fullprint_adjust", "adjust", "clear_mask", "segment", "refine", "preview_ai"):
            from text_layer_commands import guard_command
            guard_command(self, command, params)
        if command in ("text_layer_slot", "apply_text_layers", "clear_text_layers"):
            from text_layer_commands import dispatch
            return dispatch(self, command, params)
        if command == "status":
            return self.status()
        if command == "clear":
            return self.clear(params)
        if command == "ack":
            return self.ack(params)
        if command in ("input_slot", "prepare", "fullprint_adjust"):
            import fullprint_commands
            handler = {"input_slot": fullprint_commands.input_slot, "prepare": fullprint_commands.prepare,
                       "fullprint_adjust": fullprint_commands.adjust}[command]
            return handler(self, params)
        if command == "preview_ai":
            from preview_ai import preview
            return preview(self, params)
        if command in ("paint", "undo_paint", "view_data", "exchange_path", "import_edit"):
            from depth_edit import dispatch_edit
            return dispatch_edit(self, command, params)
        if command == "generate":
            return self.generate(params)
        if command == "depth":
            return self.depth(params)
        if command == "refine":
            return self.refine(params)
        if command == "segment":
            return self.segment(params)
        if command == "adjust":
            return self.adjust(params)
        if command == "clear_mask":
            return self.adjust(params, clear=True)
        if command == "shutdown":
            return {"shutdown": True}
        raise ValueError("Unknown depth worker command.")


def serve(engine, input_stream=None, output_stream=None, error_stream=None):
    incoming = input_stream or sys.stdin
    outgoing = output_stream or sys.stdout
    errors = error_stream or sys.stderr
    emit_lock = threading.Lock()
    def emit(payload):
        with emit_lock:
            outgoing.write(json.dumps(payload, ensure_ascii=False, allow_nan=False) + "\n")
            outgoing.flush()
    for line in incoming:
        request_id = None
        stop = threading.Event()
        heartbeat = None
        try:
            if len(line.encode("utf-8")) > MAX_REQUEST_BYTES:
                raise ValueError("Depth worker request is too large.")
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError("Depth request must be an object.")
            request_id = request.get("id")
            if not isinstance(request_id, (str, int)) or isinstance(request_id, bool):
                raise ValueError("Depth request requires a string or integer id.")
            started = time.monotonic()
            phase = {"progress": 0, "message": "Starting depth operation."}
            phase_lock = threading.Lock()
            def report(value, message):
                with phase_lock:
                    phase.update(progress=max(phase["progress"], min(100, value)), message=message)
                    payload = dict(phase)
                emit({"id": request_id, "type": "progress", **payload,
                      "elapsed_seconds": round(time.monotonic() - started, 1)})
            def pulse():
                # Repeat actual stage progress; never invent inference percent.
                while not stop.wait(1):
                    with phase_lock:
                        payload = dict(phase)
                    emit({"id": request_id, "type": "progress", **payload,
                          "elapsed_seconds": round(time.monotonic() - started, 1), "heartbeat": True})
            engine.progress = report
            if request.get("command") == "generate":
                heartbeat = threading.Thread(target=pulse, daemon=True)
                heartbeat.start()
            # Keep library warnings and print statements out of the NDJSON protocol.
            with redirect_stdout(errors):
                result = engine.dispatch(request.get("command"), request.get("params", {}))
            stop.set()
            if heartbeat is not None:
                heartbeat.join()
            emit({"id": request_id, "type": "result", "result": result})
            if request.get("command") == "shutdown":
                break
        except Exception as exc:
            stop.set()
            if heartbeat is not None:
                heartbeat.join()
            traceback.print_exc(file=errors)
            emit({"id": request_id, "type": "error", "error": str(exc) or type(exc).__name__})


def main(argv=None):
    parser = argparse.ArgumentParser(description="Local MoGe-2/DA2/MobileSAM worker for Photoshop")
    parser.add_argument("--root", required=True)
    parser.add_argument("--models", required=True)
    options = parser.parse_args(argv)
    # Model paths are explicit and verified before loaders; prohibit hub fallback downloads.
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    from worker_lock import WorkerRootLock
    lease = WorkerRootLock(options.root)
    try:
        lease.acquire()
    except (ValueError, OSError) as exc:
        # Reply to the queued startup command, then exit so a later retry can
        # launch a fresh worker. Do not enter any engine command without a lease.
        request_id = None
        try:
            pending = json.loads(sys.stdin.readline(MAX_REQUEST_BYTES + 1))
            candidate = pending.get("id") if isinstance(pending, dict) else None
            if isinstance(candidate, (str, int)) and not isinstance(candidate, bool):
                request_id = candidate
        except (ValueError, OSError):
            pass
        sys.stdout.write(json.dumps({"id": request_id, "type": "error", "error": str(exc)}) + "\n")
        sys.stdout.flush()
        return 1
    try:
        serve(DepthEngine(options.root, options.models))
    finally:
        lease.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
