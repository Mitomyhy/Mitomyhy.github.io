MITOM GPT/Codex → Web 3D R82 — bản vá riêng

1. Giải nén ZIP vào một thư mục bình thường trên máy.
2. Check.cmd chỉ kiểm tra các file đang cài; không sửa dữ liệu hay đóng ứng dụng.
3. Để cài: lưu PSD và công việc GPT/Codex, tự đóng UOY ChatGPT workplace
   environment, Photoshop và OrderStudio. Sau đó chạy Install.cmd.
4. Mở lại Photoshop/Panel rồi mở GPT/Codex bằng nút của MITOM.
   Nút Generate 3D mới dùng ảnh đang chọn trong GPT hoặc đầu ra Codex.
   Chọn template Acrylic / Circle Ceramic / Heart Ceramic và CPU / GPU.
   Web MITOM nhận artwork rồi chạy flow 3D hiện tại; Photoshop không phải
   thực hiện Generate và có thể tiếp tục công việc khác.

Artwork được chuyển qua cầu nối nội bộ trên máy tới trang MITOM, không gửi
lên máy chủ AI. Web vẫn cần Internet để tải trang/mô hình nếu chưa có cache.
Chọn GPU là lựa chọn rõ ràng; không âm thầm chuyển sang CPU nếu GPU lỗi.
Với Acrylic nên dùng artwork đã tách nền theo flow web hiện tại.

Gói chỉ chứa sáu file runtime đã xác minh: js/chatgpt-workspace.js,
chatgpt-workspace/UOYChatGPTWorkspace.exe, chatgpt-workspace/ui/index.html,
chatgpt-workspace/ui/workspace.js, js/web-tools-panel.js, js/web-tools-bridge.js.
Không đổi tài khoản, cookie, profile, lịch sử chat, state GPT/Codex, PSD,
cấu hình từng máy, Save Task, R81 Order Custom, Companion hoặc mô hình 3D.
Đường dẫn cài theo APPDATA của người đang dùng, không cố định ADMIN/ổ đĩa.
Bản cũ được giữ trong .mitom-gpt-web3d-r82-backups dưới thư mục Panel.
Installer in đường dẫn receipt.json chính xác để hoàn tác khi cần.

Hoàn tác (đóng UOYChatGPTWorkspace, Photoshop và OrderStudio trước):
powershell.exe -NoProfile -File Install.ps1 -Rollback -ReceiptPath "đường dẫn receipt.json đã in"

Không tự đóng ứng dụng, không gọi GPT/AI/upload và không xóa bản sao lưu.
Nếu PowerShell bị chính sách công ty chặn, nhờ IT cho phép/chạy mã đã duyệt;
gói này không tắt hoặc vượt qua execution policy.
Đây là ZIP riêng; không tự đổi phiên bản Launcher hoặc cài gói đầy đủ.
