#requires -Version 5.1
[CmdletBinding()]
param([switch]$CheckOnly,[switch]$Rollback,[string]$TargetRoot,[string]$ReceiptPath)
$ErrorActionPreference = 'Stop'
$Owner = 'MITOM.GPT.Web3D.R82'
$Pins = @(
    [pscustomobject]@{relative='js/chatgpt-workspace.js';before='66cb589768c64a88a7ea8b8091063760ab3a66ccbe7d5a1faac30a557bc1bb27';after='27d8a3f6ecfaf0423168eaf77e8e1cafca9ff19df5110a035e678377b5bd46d2'}
    [pscustomobject]@{relative='chatgpt-workspace/UOYChatGPTWorkspace.exe';before='d03769c2b85e8ec542562846f7e045042eea270491ec871b77086f94fd3a4e64';after='64c34f7c5fd70ac66bdaac0f26a92c1ac1e796a82742de8b3c6aa1b9212964e0'}
    [pscustomobject]@{relative='chatgpt-workspace/ui/index.html';before='3f352d3fe223989f8c99efbe3a278612622fb56ff5a40da2cbf3816031d081ed';after='22d264cc13f0fb93ccc4360df1ed1d4f328c257b15fee7f5b304e0177b382c1c'}
    [pscustomobject]@{relative='chatgpt-workspace/ui/workspace.js';before='21a9ec165316987c4d516598613a9f8eab803676fee60225bc8af19874ce26d0';after='e65b317e2b580e10f2cc13100d4753518d68dd589bff2fd61d47fa6ef805c2cc'}
    [pscustomobject]@{relative='js/web-tools-panel.js';before='9802b85ed5c5f6fbcc9d9e34240815ecd99300b94cba46ade5f601705e3b852c';after='7de784e39187c0d7d992f288e395df34f9df3698b3b7b2b40ae66d24b90c1546'}
    [pscustomobject]@{relative='js/web-tools-bridge.js';before='46debde4136ccd2afccd7382446342734d506034fbc2c62c683a51ee79bcfe4d';after='4313759e14b234107b50b3eaba48179fcb4d5cfa811f18c5d9affa253fc77493'}
)
function Full([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value) -or -not [IO.Path]::IsPathRooted($Value) -or $Value.StartsWith('\\') -or $Value.IndexOf([char]0) -ge 0) { throw 'An absolute local path is required.' }
    $result = [IO.Path]::GetFullPath($Value).TrimEnd('\','/')
    if ($result -eq [IO.Path]::GetPathRoot($result).TrimEnd('\','/')) { throw 'A drive root is not a Panel folder.' }
    return $result
}
function Safe([string]$Value) {
    $resolved = Full $Value
    for ($cursor = $resolved; $cursor; $cursor = [IO.Path]::GetDirectoryName($cursor)) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Redirected path refused: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if (-not $parent -or $parent -eq $cursor) { break }
    }
    return $resolved
}
function Inside([string]$Base,[string]$Child) {
    $baseFull = Full $Base; $childFull = Safe $Child
    if (-not $childFull.StartsWith($baseFull + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Patch path escaped its verified root.' }
    return $childFull
}
function Hash([string]$File) {
    [void](Safe $File)
    if (-not (Test-Path -LiteralPath $File)) { return $null }
    if ((Get-Item -LiteralPath $File -Force).PSIsContainer) { throw "Expected a regular file: $File" }
    return (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Closed {
    $apps = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -eq 'Photoshop' -or $_.ProcessName -like '*OrderStudio*' -or $_.ProcessName -eq 'UOYChatGPTWorkspace'})
    if ($apps.Count) { throw 'Save your work and close Photoshop, OrderStudio and UOYChatGPTWorkspace first. No application was stopped.' }
}
function WriteJson([string]$File,$Value) { [IO.File]::WriteAllText($File,($Value | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false)) }
function BackupName([string]$Relative) { return (($Relative -replace '[/\\]','_') + '.before') }
function AtomicCopy([string]$Source,[string]$Destination,[string]$ExpectedSource,[string]$ExpectedTarget,[string]$BackupFolder) {
    if ((Hash $Source) -cne $ExpectedSource -or (Hash $Destination) -cne $ExpectedTarget) { throw 'Source or target changed during the operation; no unverified data was copied.' }
    $stage = Inside $TargetRoot (Join-Path (Split-Path -Parent $Destination) ('.mitom-gpt-web3d-r82-' + [guid]::NewGuid().ToString('N') + '.tmp'))
    $replaced = Inside $BackupFolder (Join-Path $BackupFolder ('atomic-replaced-' + [guid]::NewGuid().ToString('N') + '.before'))
    try {
        [IO.File]::Copy($Source,$stage,$false)
        if ((Hash $stage) -cne $ExpectedSource -or (Hash $Destination) -cne $ExpectedTarget) { throw 'Source or target changed before commit.' }
        Closed
        # An explicit unique backup path works in Windows PowerShell 5.1 and 7.
        [IO.File]::Replace($stage,$Destination,$replaced)
        if ((Hash $Destination) -cne $ExpectedSource -or (Hash $replaced) -cne $ExpectedTarget) { throw 'Atomic write verification failed. Keep all backups and the receipt for repair.' }
    } finally {
        if ((Test-Path -LiteralPath $stage) -and (Hash $stage) -ceq $ExpectedSource) { Remove-Item -LiteralPath $stage -Force }
    }
}
if (-not $TargetRoot) {
    if (-not $env:APPDATA) { throw 'APPDATA is unavailable. Supply -TargetRoot for the installed Panel.' }
    $TargetRoot = Join-Path $env:APPDATA 'Adobe/CEP/extensions/com.uoy.orderpanel'
}
$TargetRoot = Safe $TargetRoot
if (-not (Test-Path -LiteralPath (Join-Path $TargetRoot 'js/chatgpt-workspace.js') -PathType Leaf)) { throw 'Installed Panel/js/chatgpt-workspace.js was not found. No files changed.' }
$pinMap=@{}
foreach($pin in $Pins) {
    if ($pin.relative -cnotmatch '^(js/chatgpt-workspace\.js|chatgpt-workspace/UOYChatGPTWorkspace\.exe|chatgpt-workspace/ui/index\.html|chatgpt-workspace/ui/workspace\.js|js/web-tools-panel\.js|js/web-tools-bridge\.js)$' -or $pinMap.ContainsKey($pin.relative) -or $pin.before -cnotmatch '^[a-f0-9]{64}$' -or $pin.after -cnotmatch '^[a-f0-9]{64}$') { throw 'Invalid sealed package pins.' }
    $pinMap[$pin.relative]=$pin
}
if($pinMap.Count -ne 6) { throw 'Expected exactly six sealed runtime files.' }
$backupParent = Inside $TargetRoot (Join-Path $TargetRoot '.mitom-gpt-web3d-r82-backups')
$marker = Join-Path $backupParent '.owner.json'
function ValidateBackupParent {
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'Unrecognized backup folder.' }
    [void](Safe $marker);$value=Get-Content -Raw -LiteralPath $marker | ConvertFrom-Json
    if ($value.owner -cne $Owner -or $value.schema -ne 1) { throw 'Unrecognized backup folder.' }
}
if ($Rollback) {
    ValidateBackupParent
    $receiptFile = Inside $backupParent $ReceiptPath;$backup=Split-Path -Parent $receiptFile
    if ([IO.Path]::GetFileName($receiptFile) -cne 'receipt.json' -or [IO.Path]::GetFileName($backup) -cnotmatch '^run-[a-f0-9]{32}$' -or (Split-Path -Parent $backup) -cne $backupParent) { throw 'Unrecognized rollback receipt path.' }
    $receipt=Get-Content -Raw -LiteralPath $receiptFile | ConvertFrom-Json
    if ($receipt.owner -cne $Owner -or $receipt.schema -ne 1 -or $receipt.target -cne $TargetRoot -or @($receipt.files).Count -lt 1 -or @($receipt.files).Count -gt 6 -or $receipt.status -cnotmatch '^(Prepared|Complete|RolledBack|RolledBackOnError|RepairRequired)$') { throw 'Unrecognized rollback receipt.' }
    $seen=@{}
    foreach($row in $receipt.files) {
        $pin=$pinMap[$row.relative]
        if (-not $pin -or $seen.ContainsKey($row.relative) -or $row.before -cne $pin.before -or $row.after -cne $pin.after) { throw 'Unrecognized rollback file or hashes.' }
        $seen[$row.relative]=$true
        $original=Inside $backup (Join-Path $backup (BackupName $row.relative));$target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative)
        if((Hash $original) -cne $row.before) { throw 'Rollback backup hash mismatch.' }
        $now=Hash $target
        if($now -cne $row.before -and $now -cne $row.after) { throw 'Patched code changed after installation. Rollback refused to overwrite it.' }
    }
    if($CheckOnly) { [pscustomobject]@{Status='RollbackReady';Changed=0;Target=$TargetRoot;Receipt=$receiptFile};return }
    Closed
    $lockPath=Inside $TargetRoot (Join-Path $TargetRoot '.mitom-gpt-web3d-r82.lock');$lock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try {
        foreach($row in $receipt.files) {
            $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$original=Inside $backup (Join-Path $backup (BackupName $row.relative));$now=Hash $target
            if($now -ceq $row.after) { AtomicCopy $original $target $row.before $row.after $backup }
            elseif($now -cne $row.before) { throw 'Target changed during rollback.' }
        }
        $receipt.status='RolledBack';WriteJson $receiptFile $receipt
    } finally { $lock.Dispose() }
    [pscustomobject]@{Status='RolledBack';Target=$TargetRoot;Receipt=$receiptFile};return
}
$changes=@()
foreach($pin in $Pins) {
    $source=Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/'+$pin.relative));$target=Inside $TargetRoot (Join-Path $TargetRoot $pin.relative)
    if((Hash $source) -cne $pin.after) { throw "Package hash mismatch: $($pin.relative). No files changed." }
    $existing=Hash $target
    if($existing -ceq $pin.after) { continue }
    if($existing -cne $pin.before) { throw "Unknown Panel code: $($pin.relative). This patch requires the verified MITOM GPT/Codex and web bridge release; no files changed." }
    $changes+=[pscustomobject]@{relative=$pin.relative;before=$existing;after=$pin.after}
}
if(-not $changes.Count) { [pscustomobject]@{Status='AlreadyInstalled';Changed=0;Target=$TargetRoot};return }
if($CheckOnly) { [pscustomobject]@{Status='Ready';WouldChange=$changes.Count;Changed=0;Target=$TargetRoot};return }
Closed
if(Test-Path -LiteralPath $backupParent) { ValidateBackupParent }
$lockPath=Inside $TargetRoot (Join-Path $TargetRoot '.mitom-gpt-web3d-r82.lock');$lock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {
    foreach($row in $changes) {
        if((Hash (Inside $TargetRoot (Join-Path $TargetRoot $row.relative))) -cne $row.before -or (Hash (Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/'+$row.relative)))) -cne $row.after) { throw 'Panel or package changed during preflight; no code was overwritten.' }
    }
    if(Test-Path -LiteralPath $backupParent) { ValidateBackupParent }
    else { New-Item -ItemType Directory -Path $backupParent | Out-Null;WriteJson $marker @{owner=$Owner;schema=1} }
    $backup=Inside $backupParent (Join-Path $backupParent ('run-'+[guid]::NewGuid().ToString('N')));New-Item -ItemType Directory -Path $backup | Out-Null
    foreach($row in $changes) {
        $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$original=Inside $backup (Join-Path $backup (BackupName $row.relative))
        if((Hash $target) -cne $row.before) { throw 'Panel changed while preparing backups; no code was overwritten.' }
        [IO.File]::Copy($target,$original,$false)
        if((Hash $original) -cne $row.before) { throw 'Backup verification failed. No code was overwritten.' }
    }
    $receiptFile=Join-Path $backup 'receipt.json';$receipt=[ordered]@{owner=$Owner;schema=1;status='Prepared';target=$TargetRoot;files=$changes;createdAt=[DateTime]::UtcNow.ToString('o')};WriteJson $receiptFile $receipt
    try {
        foreach($row in $changes) {
            $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$source=Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/'+$row.relative))
            AtomicCopy $source $target $row.after $row.before $backup
        }
        $receipt.status='Complete';WriteJson $receiptFile $receipt
    } catch {
        $failure=$_.Exception.Message;$repair=$false
        foreach($row in $changes) {
            $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$now=Hash $target
            if($now -ceq $row.after) {
                try { $original=Inside $backup (Join-Path $backup (BackupName $row.relative));AtomicCopy $original $target $row.before $row.after $backup } catch { $repair=$true }
            } elseif($now -cne $row.before) { $repair=$true }
        }
        $receipt.status=if($repair){'RepairRequired'}else{'RolledBackOnError'};WriteJson $receiptFile $receipt
        throw "Installation stopped: $failure. Receipt and verified originals retained at $receiptFile"
    }
} finally { $lock.Dispose() }
[pscustomobject]@{Status='Installed';Changed=$changes.Count;Target=$TargetRoot;Receipt=$receiptFile}
