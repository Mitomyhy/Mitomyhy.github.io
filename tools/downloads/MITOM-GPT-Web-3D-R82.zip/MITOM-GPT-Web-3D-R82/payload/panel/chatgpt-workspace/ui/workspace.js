(function () {
  'use strict';
  var Model = window.UOYChatGPTModel;
  var state = Model.createState();
  var host = window.chrome && window.chrome.webview;
  var dialogLayer = document.getElementById('dialog-layer');
  var currentDialog = null;
  var previousFocus = null;
  var currentBusy = false;
  var layoutFrame = 0;
  var lastLayoutRect = null;
  var toastTimer = 0;
  var lastToastMessage = null;
  var lastToastBusy = false;
  var currentMode = 'chatgpt';
  var hostStateReceived = false;
  var initialNavigationPending = false;
  function webMode(mode) { return mode === 'photoroom' || mode === 'canva'; }

  function node(tag, className, text) {
    var element = document.createElement(tag);
    if (className) element.className = className;
    if (typeof text === 'string') element.textContent = text;
    return element;
  }
  function byId(id) { return document.getElementById(id); }
  function actionButton(label, className, click) {
    var button = node('button', className || 'button', label);
    button.type = 'button';
    if (click) button.addEventListener('click', click);
    return button;
  }
  function send(message) {
    if (message && message.action !== 'ready' && message.action !== 'layout' && message.action !== 'persist') clearTransientStatus();
    if (host) {
      host.postMessage(message);
      return true;
    }
    status('Mở từ nút ChatGPT trong Photoshop để kết nối.', false);
    return false;
  }
  function syncBusyControls() {
    function disable(button) { if (button.disabled !== currentBusy) button.disabled = currentBusy; }
    ['import-image', 'export-layers', 'remove-background'].forEach(function (id) { disable(byId(id)); });
    var generateDisabled = currentBusy || webMode(currentMode);
    if (byId('generate-3d').disabled !== generateDisabled) byId('generate-3d').disabled = generateDisabled;
    if (currentMode === 'chatgpt') {
      ['new-tab', 'switch-account', 'project-select', 'connect-browser', 'browser-external', 'pin-project', 'save-chat'].forEach(function (id) { disable(byId(id)); });
      document.querySelectorAll('.tab-select, .tab-close, .saved-link').forEach(disable);
    }
  }
  function status(message, busy) {
    var text = message || '';
    var toast = byId('status-toast');
    var repeated = text === lastToastMessage && !!busy === lastToastBusy;
    // Native health/readiness messages can repeat while the user is typing.
    // Do not mutate the shell or resize its sibling WebView for identical
    // messages. render() independently synchronizes newly created controls.
    if (repeated) return;
    lastToastMessage = text;
    lastToastBusy = !!busy;
    if (!repeated) {
      if (toastTimer) window.clearTimeout(toastTimer);
      toastTimer = 0;
    }
    byId('status-message').textContent = text;
    byId('status-dot').classList.toggle('busy', !!busy);
    currentBusy = !!busy;
    syncBusyControls();
    if (currentMode === 'codex' && window.UOYCodexUI) window.UOYCodexUI.renderChrome();
    // This transient row is below the tab controls and outside the native
    // browser rectangle. It never obscures Pin/Save, even at narrow sizes.
    var instructional = !currentBusy && (!text || /^Sẵn sàng\.?$/i.test(text) || text.indexOf('Tool không lưu mật khẩu') >= 0);
    var error = !currentBusy && /không|lỗi|thất bại|chưa|error|failed|invalid|cannot/i.test(text);
    toast.classList.toggle('busy', currentBusy);
    toast.classList.toggle('error', error);
    toast.title = text;
    // Polling must not keep an unchanged warning alive or make a dismissed
    // warning reappear. A new user action resets this deduplication context.
    if (instructional) toast.hidden = true;
    else if (!repeated) toast.hidden = false;
    if (!instructional && !currentBusy && !repeated) toastTimer = window.setTimeout(hideToast, error ? 6000 : 3000);
    scheduleLayout();
    if (!currentBusy && initialNavigationPending) {
      initialNavigationPending = false;
      navigateCurrent();
    }
  }
  function hideToast() {
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = 0;
    var toast = byId('status-toast');
    if (!toast.hidden) { toast.hidden = true; scheduleLayout(); }
  }
  function clearTransientStatus() {
    if (currentBusy) return;
    hideToast();
    lastToastMessage = null;
    lastToastBusy = false;
  }
  function persist() {
    if (host) host.postMessage({ action: 'persist', state: state });
  }
  function update(next, navigate) {
    if (navigate && currentBusy) return;
    state = next;
    persist();
    render();
    if (navigate) navigateCurrent();
  }
  function navigateCurrent() {
    if (currentBusy || currentMode !== 'chatgpt') return;
    var account = Model.activeAccount(state);
    var tab = Model.getCurrentTab(state);
    send({ action: 'navigate', url: tab.url, accountId: account.id, tabId: tab.id });
    scheduleLayout();
  }
  function scheduleLayout() {
    if (layoutFrame) return;
    layoutFrame = window.requestAnimationFrame(function () {
      layoutFrame = 0;
      if (!host) return;
      var rect = byId('browser-surface').getBoundingClientRect();
      var output = currentDialog || currentMode === 'codex' ? { left: 0, top: 0, width: 0, height: 0 } : {
        left: Math.round(rect.left + 1), top: Math.round(rect.top + 1),
        width: Math.max(0, Math.round(rect.width - 2)), height: Math.max(0, Math.round(rect.height - 2))
      };
      // ResizeObserver, status changes and window.resize may report the same
      // physical rectangle. Keep the native browser bounds stable unless one
      // coordinate actually changes; the host retains this rectangle for tabs.
      if (lastLayoutRect && output.left === lastLayoutRect.left && output.top === lastLayoutRect.top && output.width === lastLayoutRect.width && output.height === lastLayoutRect.height) return;
      host.postMessage({ action: 'layout', rect: output });
      lastLayoutRect = output;
    });
  }
  function render() {
    if (currentMode === 'codex' && window.UOYCodexUI) { syncBusyControls(); window.UOYCodexUI.renderChrome(); scheduleLayout(); return; }
    if (webMode(currentMode)) {
      byId('tabs').replaceChildren(node('span', 'web-tab-name', currentMode === 'photoroom' ? 'Photoroom · Web' : 'Canva · Web'));
      byId('account-label').textContent = 'Phiên web riêng';
      byId('codex-unsaved').hidden = true;
      syncBusyControls();
      scheduleLayout(); return;
    }
    byId('codex-unsaved').hidden = true;
    byId('pin-project').textContent = '⌖ Ghim';
    byId('save-chat').disabled = currentBusy;
    byId('new-tab').disabled = currentBusy;
    byId('switch-account').disabled = currentBusy;
    byId('project-select').disabled = currentBusy;
    byId('pin-project').disabled = currentBusy;
    var account = Model.activeAccount(state);
    var tab = Model.getCurrentTab(state);
    var project = account.projects.find(function (item) { return item.id === account.currentProjectId; });
    byId('account-label').textContent = account.label;
    byId('account-label').title = account.label;
    byId('project-name').textContent = project ? project.title : 'Project của tôi';
    byId('project-select').title = project ? project.title + ' · Chọn project' : 'Ghim project đang mở trong ChatGPT';
    byId('chat-section-label').textContent = project ? 'CHAT TRONG PROJECT' : 'CHAT ĐÃ LƯU';
    var chats = account.savedChats.filter(function (chat) { return !project || chat.projectId === project.id; });
    byId('chat-count').textContent = String(chats.length);
    byId('saved-chats').replaceChildren();
    chats.forEach(function (chat) {
      var row = node('div', 'saved-row' + (chat.url === tab.url ? ' selected' : ''));
      var open = actionButton('', 'saved-link', function () {
        var existing = account.tabs.find(function (item) { return item.url === chat.url; });
        update(existing ? Model.selectTab(state, existing.id) : Model.createTab(state, chat.url, chat.title), true);
      });
      open.title = chat.title;
      open.disabled = currentBusy;
      open.appendChild(node('span', 'chat-symbol', '◌'));
      open.appendChild(node('span', 'saved-title', chat.title));
      var edit = actionButton('⋯', 'saved-menu', function () { chatDialog(chat); });
      edit.setAttribute('aria-label', 'Đổi tên hoặc bỏ lưu ' + chat.title);
      row.append(open, edit);
      byId('saved-chats').appendChild(row);
    });
    byId('tabs').replaceChildren();
    account.tabs.forEach(function (item) {
      var active = item.id === account.currentTabId;
      var tabElement = node('div', 'tab' + (active ? ' active' : ''));
      var select = actionButton(item.title, 'tab-select', function () { update(Model.selectTab(state, item.id), true); });
      select.title = item.title;
      select.disabled = currentBusy;
      select.setAttribute('role', 'tab');
      select.setAttribute('aria-selected', String(active));
      var close = actionButton('×', 'tab-close', function () {
        update(Model.closeTab(state, item.id), active);
        status('Đã đóng tab.', false);
      });
      close.title = 'Đóng tab · Không xoá cuộc hội thoại';
      close.disabled = currentBusy;
      close.setAttribute('aria-label', 'Đóng tab ' + item.title);
      tabElement.append(select, close);
      byId('tabs').appendChild(tabElement);
      if (active) select.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    });
    syncBusyControls();
    scheduleLayout();
  }

  function setMode(mode, notify, deferNavigation) {
    if (mode !== 'codex' && mode !== 'chatgpt' && !webMode(mode)) return false;
    // The native host confirms a selected mode, including directly after its
    // initial state. Confirmation is not a request to reload the current page.
    if (mode === currentMode) return false;
    if (currentDialog) closeDialog();
    clearTransientStatus();
    currentMode = mode;
    ['chatgpt', 'codex', 'photoroom', 'canva'].forEach(function (name) { byId('mode-' + name).classList.toggle('active', mode === name); byId('mode-' + name).setAttribute('aria-selected', String(mode === name)); });
    ['project-select', 'saved-chats', 'pin-project', 'save-chat', 'new-tab', 'switch-account', 'prompt-library'].forEach(function (id) { byId(id).hidden = webMode(mode); });
    document.querySelector('.sidebar-caption').hidden = webMode(mode);
    byId('web-actions').hidden = !webMode(mode);
    byId('browser-placeholder').hidden = mode !== 'chatgpt';
    byId('browser-external').hidden = mode !== 'chatgpt';
    if (notify) send({ action: 'setMode', mode: mode });
    window.UOYCodexUI.setActive(mode === 'codex');
    render(); scheduleLayout();
    if (mode === 'chatgpt' && !deferNavigation) navigateCurrent();
    return true;
  }

  function closeDialog() {
    if (!currentDialog) return;
    currentDialog = null;
    dialogLayer.hidden = true;
    dialogLayer.replaceChildren();
    scheduleLayout();
    if (previousFocus && previousFocus.isConnected) previousFocus.focus();
    previousFocus = null;
  }
  function showDialog(title, wide) {
    if (currentDialog) closeDialog();
    clearTransientStatus();
    previousFocus = document.activeElement;
    var dialog = node('section', 'dialog' + (wide ? ' wide' : ''));
    dialog.setAttribute('role', 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-label', title);
    var heading = node('div', 'dialog-heading');
    heading.append(node('h2', '', title), actionButton('×', 'dialog-close', closeDialog));
    heading.lastChild.setAttribute('aria-label', 'Đóng hộp thoại');
    dialog.appendChild(heading);
    dialogLayer.replaceChildren(dialog);
    dialogLayer.hidden = false;
    currentDialog = dialog;
    scheduleLayout();
    // Focus synchronously. A delayed autofocus can steal focus after typing has
    // already started (especially when opening the prompt editor).
    heading.lastChild.focus();
    return dialog;
  }
  function field(parent, label, value, multiline) {
    var element = node(multiline ? 'textarea' : 'input');
    if (!multiline) element.type = 'text';
    element.value = value || '';
    element.maxLength = multiline ? 30000 : 2048;
    var id = 'field-' + Math.random().toString(36).slice(2);
    element.id = id;
    var labelElement = node('label', '', label);
    labelElement.htmlFor = id;
    parent.append(labelElement, element);
    return element;
  }
  function actions(parent, list) {
    var row = node('div', 'dialog-actions');
    list.forEach(function (item) { row.appendChild(actionButton(item.label, 'button ' + (item.style || ''), item.action)); });
    parent.appendChild(row);
    return row;
  }
  function enterSaves(input, callback) {
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') { event.preventDefault(); callback(); }
    });
  }

  function accountDialog() {
    var dialog = showDialog('Tài khoản ChatGPT');
    dialog.appendChild(node('p', '', 'Mỗi tài khoản có hồ sơ trình duyệt riêng. Đăng nhập trên trang ChatGPT chính thức; tool không hỏi và không lưu mật khẩu. ChatGPT có thể yêu cầu đăng nhập lại khi phiên hết hạn.'));
    state.accounts.forEach(function (account) {
      var active = account.id === state.activeAccountId;
      var row = node('div', 'dialog-row' + (active ? ' active' : ''));
      row.appendChild(node('span', 'account-avatar', account.label.slice(0, 1).toUpperCase()));
      var select = actionButton('', 'row-main', function () {
        update(Model.setActiveAccount(state, account.id), true);
        closeDialog();
        status('Đã đổi tài khoản: ' + account.label + '.', false);
      });
      select.append(node('span', '', account.label), node('small', '', active ? 'Đang sử dụng · mở lại phiên đăng nhập' : 'Mở phiên đã lưu của tài khoản này'));
      row.append(select, actionButton('Đổi tên', 'row-edit', function () { renameAccountDialog(account); }));
      dialog.appendChild(row);
    });
    actions(dialog, [{ label: '+ Đăng nhập tài khoản khác', style: 'accent', action: addAccountDialog }]);
    dialog.appendChild(node('p', 'dialog-footnote', 'Tên hồ sơ do bạn đặt; không phải danh sách tài khoản được đọc từ ChatGPT.'));
    var firstAccount = dialog.querySelector('.row-main');
    if (firstAccount) firstAccount.focus();
  }
  function addAccountDialog() {
    var dialog = showDialog('Thêm tài khoản');
    dialog.appendChild(node('p', '', 'Tạo một hồ sơ riêng rồi đăng nhập tài khoản trên ChatGPT. Có thể lưu nhiều hồ sơ và đổi qua lại.'));
    var label = field(dialog, 'Tên dễ nhớ', 'Tài khoản ' + (state.accounts.length + 1));
    label.maxLength = 100;
    var error = node('div', 'dialog-error');
    dialog.appendChild(error);
    function save() {
      try { update(Model.addAccount(state, label.value), true); closeDialog(); status('Đã mở hồ sơ mới.', false); }
      catch (exception) { error.textContent = exception.message; }
    }
    actions(dialog, [{ label: 'Quay lại', action: accountDialog }, { label: 'Tạo hồ sơ & đăng nhập', style: 'accent', action: save }]);
    enterSaves(label, save);
    label.focus();
  }
  function renameAccountDialog(account) {
    var dialog = showDialog('Đổi tên hồ sơ');
    var label = field(dialog, 'Tên tài khoản', account.label);
    label.maxLength = 100;
    function save() { update(Model.renameAccount(state, account.id, label.value)); accountDialog(); }
    actions(dialog, [{ label: 'Quay lại', action: accountDialog }, { label: 'Lưu tên', style: 'accent', action: save }]);
    enterSaves(label, save);
    label.focus();
  }
  function projectDialog() {
    var account = Model.activeAccount(state);
    var dialog = showDialog('Projects đã ghim');
    dialog.appendChild(node('p', '', 'Chọn project để mở trong ChatGPT và lọc những đoạn chat bạn đã lưu. Các bookmark của từng tài khoản được giữ riêng.'));
    var all = node('div', 'dialog-row' + (!account.currentProjectId ? ' active' : ''));
    all.appendChild(actionButton('Tất cả chat đã lưu', 'row-main', function () { update(Model.selectProject(state, null)); closeDialog(); }));
    dialog.appendChild(all);
    account.projects.forEach(function (project) {
      var row = node('div', 'dialog-row' + (project.id === account.currentProjectId ? ' active' : ''));
      var select = actionButton('', 'row-main', function () {
        var next = Model.selectProject(state, project.id);
        var existing = account.tabs.find(function (tab) { return tab.url === project.url; });
        update(existing ? Model.selectTab(next, existing.id) : Model.createTab(next, project.url, project.title), true);
        closeDialog();
      });
      select.append(node('span', '', project.title), node('small', '', project.url));
      row.appendChild(select);
      dialog.appendChild(row);
    });
    if (!account.projects.length) dialog.appendChild(node('p', 'dialog-footnote', 'Chưa có project. Mở project ở ChatGPT và bấm Ghim, hoặc dán đường dẫn bên dưới.'));
    actions(dialog, [{ label: 'Ghim bằng đường dẫn', style: 'accent', action: function () { bookmarkDialog('pin', {}); } }]);
    dialog.querySelector('.row-main').focus();
  }
  function bookmarkDialog(purpose, page) {
    var isPin = purpose === 'pin';
    var account = Model.activeAccount(state);
    var dialog = showDialog(isPin ? 'Ghim project' : 'Lưu đoạn chat');
    dialog.appendChild(node('p', '', isPin ? 'Lưu bookmark project đang mở trong ChatGPT vào cột bên trái. Nếu trang chưa nhận diện được, hãy dán đường dẫn project.' : 'Lưu bookmark cuộc hội thoại vào workspace này. Không sao chép hoặc xoá lịch sử trên ChatGPT. Bạn có thể đổi tên sau.'));
    var title = field(dialog, isPin ? 'Tên project' : 'Tên đoạn chat', page.title && page.title !== 'ChatGPT' ? page.title : '');
    title.maxLength = 200;
    title.placeholder = isPin ? 'Ví dụ: Thiết kế ornament' : 'Ví dụ: Prompt mẫu ceramic';
    var url = field(dialog, 'Đường dẫn ChatGPT', (isPin ? Model.projectUrlFromPage(page.url) : Model.normalizeChatGPTUrl(page.url)) || '');
    url.placeholder = isPin ? 'https://chatgpt.com/g/g-p-…/project' : 'https://chatgpt.com/c/…';
    var projectSelect;
    if (!isPin && account.projects.length) {
      var label = node('label', '', 'Lưu vào project');
      projectSelect = node('select');
      projectSelect.id = 'save-project-select';
      label.htmlFor = projectSelect.id;
      var none = node('option', '', 'Không thuộc project');
      none.value = '';
      projectSelect.appendChild(none);
      account.projects.forEach(function (project) { var option = node('option', '', project.title); option.value = project.id; projectSelect.appendChild(option); });
      projectSelect.value = account.currentProjectId || '';
      dialog.append(label, projectSelect);
    }
    var error = node('div', 'dialog-error');
    dialog.appendChild(error);
    function save() {
      try {
        var next = isPin ? Model.pinProject(state, url.value, title.value) : Model.saveChat(state, url.value, title.value, projectSelect ? projectSelect.value || null : account.currentProjectId);
        update(next);
        closeDialog();
        status(isPin ? 'Đã ghim project.' : 'Đã lưu đoạn chat.', false);
      } catch (exception) { error.textContent = exception.message; }
    }
    actions(dialog, [{ label: 'Huỷ', action: closeDialog }, { label: isPin ? 'Ghim project' : 'Lưu đoạn chat', style: 'accent', action: save }]);
    enterSaves(title, save);
    enterSaves(url, save);
    title.focus();
  }
  function capture(purpose) {
    if (!send({ action: 'capturePage', purpose: purpose })) bookmarkDialog(purpose, { url: Model.getCurrentTab(state).url, title: Model.getCurrentTab(state).title });
  }
  function chatDialog(chat) {
    var dialog = showDialog('Đoạn chat đã lưu');
    var title = field(dialog, 'Tên dễ nhớ', chat.title);
    title.maxLength = 200;
    dialog.appendChild(node('p', 'dialog-footnote', '“Bỏ lưu” chỉ xoá bookmark khỏi tool. Cuộc hội thoại trên ChatGPT không bị xoá.'));
    function rename() { update(Model.renameChat(state, chat.id, title.value)); closeDialog(); }
    actions(dialog, [{ label: 'Bỏ lưu', style: 'danger-button', action: function () { update(Model.deleteSavedChat(state, chat.id)); closeDialog(); status('Đã bỏ lưu đoạn chat.', false); } }, { label: 'Huỷ', action: closeDialog }, { label: 'Lưu tên', style: 'accent', action: rename }]);
    enterSaves(title, rename);
    title.focus();
  }
  function promptDialog(selectedId) {
    var dialog = showDialog('Nơi lưu prompt', true);
    dialog.appendChild(node('p', '', 'Lưu những prompt quan trọng để dùng lại. “Chèn vào GPT” chỉ điền nội dung, không tự gửi.'));
    var layout = node('div', 'prompt-layout');
    var listPane = node('div', 'prompt-list-pane');
    var search = node('input');
    search.type = 'search';
    search.placeholder = 'Tìm prompt…';
    search.setAttribute('aria-label', 'Tìm prompt đã lưu');
    var list = node('div', 'prompt-items');
    var editor = node('div', 'prompt-editor');
    listPane.append(search, actionButton('+ Prompt mới', 'button muted-button', function () { selectPrompt(null); }), list);
    layout.append(listPane, editor);
    dialog.appendChild(layout);
    var title = field(editor, 'Tên prompt', '');
    title.maxLength = 200;
    title.placeholder = 'Ví dụ: 3D ceramic mockup';
    var text = field(editor, 'Nội dung prompt', '', true);
    text.placeholder = 'Nhập prompt của bạn…';
    var error = node('div', 'dialog-error');
    editor.appendChild(error);
    var selected = selectedId || null;
    var deleteButton;
    var buttons = actions(editor, [
      { label: 'Lưu prompt', style: 'accent', action: function () {
        try {
          var next = Model.savePrompt(state, selected, title.value, text.value);
          selected = selected || next.prompts[0].id;
          update(next); error.textContent = ''; renderList(); status('Đã lưu prompt trên máy.', false);
          deleteButton.disabled = false;
        } catch (exception) { error.textContent = exception.message; }
      } },
      { label: 'Copy', action: function () { if (text.value.trim()) { send({ action: 'copyPrompt', text: text.value }); } else error.textContent = 'Nhập hoặc chọn prompt trước.'; } },
      { label: currentMode === 'codex' ? 'Chèn vào Codex' : 'Chèn vào GPT', action: function () { if (text.value.trim()) { if (currentMode === 'codex') window.UOYCodexUI.insertPrompt(text.value); else send({ action: 'insertPrompt', text: text.value }); closeDialog(); } else error.textContent = 'Nhập hoặc chọn prompt trước.'; } },
      { label: 'Xoá', style: 'danger-button', action: function () { if (selected) confirmDeletePrompt(selected); } }
    ]);
    deleteButton = buttons.lastChild;
    function renderList() {
      list.replaceChildren();
      var query = search.value.trim().toLocaleLowerCase();
      var prompts = state.prompts.filter(function (prompt) { return !query || (prompt.title + ' ' + prompt.text).toLocaleLowerCase().indexOf(query) >= 0; });
      if (!prompts.length) list.appendChild(node('div', 'prompt-empty', query ? 'Không tìm thấy prompt.' : 'Chưa có prompt đã lưu.\nTạo prompt đầu tiên của bạn.'));
      prompts.forEach(function (prompt) {
        var item = actionButton('', 'prompt-item' + (prompt.id === selected ? ' active' : ''), function () { selectPrompt(prompt.id); });
        item.append(node('strong', '', prompt.title), node('small', '', prompt.text.replace(/\s+/g, ' ')));
        list.appendChild(item);
      });
    }
    function selectPrompt(promptId) {
      var prompt = state.prompts.find(function (item) { return item.id === promptId; });
      selected = prompt ? prompt.id : null;
      title.value = prompt ? prompt.title : '';
      text.value = prompt ? prompt.text : '';
      error.textContent = '';
      deleteButton.disabled = !selected;
      renderList();
      title.focus();
    }
    search.addEventListener('input', renderList);
    selectPrompt(selected);
    dialog.appendChild(node('p', 'dialog-footnote', 'Thư viện prompt lưu cục bộ cho workspace, không lưu mật khẩu hoặc API key.'));
  }
  function confirmDeletePrompt(promptId) {
    var prompt = state.prompts.find(function (item) { return item.id === promptId; });
    if (!prompt) return;
    var dialog = showDialog('Xoá prompt đã lưu');
    dialog.appendChild(node('p', '', 'Xoá “' + prompt.title + '” khỏi thư viện trên máy? Nội dung các cuộc hội thoại ChatGPT không thay đổi.'));
    actions(dialog, [{ label: 'Huỷ', action: function () { promptDialog(promptId); } }, { label: 'Xoá prompt', style: 'danger-button', action: function () { update(Model.deletePrompt(state, promptId)); promptDialog(); } }]);
  }

  function generate3DDialog() {
    if (currentBusy || webMode(currentMode)) return;
    var ownerMode = currentMode;
    var dialog = showDialog('Generate 3D trên web');
    dialog.appendChild(node('p', '', 'Chọn artwork trong cuộc chat hiện tại ở bước tiếp theo. Ảnh gốc được chuyển sang MITOM Web để chạy flow 3D; không lấy hoặc thay đổi PSD đang mở.'));
    var templateLabel = node('label', '', 'Template');
    var template = node('select', ''); template.id = 'generate-3d-template';
    [['acrylic', 'Acrylic'], ['ceramic_circle', 'Circle Ceramic'], ['ceramic_heart', 'Heart Ceramic']].forEach(function (row) {
      var option = node('option', '', row[1]); option.value = row[0]; template.appendChild(option);
    });
    template.value = 'acrylic';
    templateLabel.htmlFor = template.id; dialog.append(templateLabel, template);
    var deviceLabel = node('label', '', 'AI device');
    var device = node('select', ''); device.id = 'generate-3d-device';
    [['cpu', 'CPU'], ['gpu', 'GPU · cần WebGPU']].forEach(function (row) {
      var option = node('option', '', row[1]); option.value = row[0]; device.appendChild(option);
    });
    device.value = 'cpu';
    deviceLabel.htmlFor = device.id; dialog.append(deviceLabel, device);
    actions(dialog, [{ label: 'Huỷ', action: closeDialog }, { label: 'Chọn artwork và Generate 3D', style: 'accent', action: function () {
      if (currentBusy || currentMode !== ownerMode || webMode(currentMode)) { closeDialog(); return; }
      var chosenTemplate = template.value, chosenDevice = device.value;
      if (['acrylic', 'ceramic_circle', 'ceramic_heart'].indexOf(chosenTemplate) < 0 || ['cpu', 'gpu'].indexOf(chosenDevice) < 0) return;
      closeDialog();
      // closeDialog schedules the native browser rectangle restoration first.
      // Let that layout message reach the host before selecting visible images.
      window.requestAnimationFrame(function () {
        if (currentBusy || currentDialog || currentMode !== ownerMode || webMode(currentMode)) return;
        send({action: 'generate3D', template: chosenTemplate, device: chosenDevice});
      });
    } }]);
  }

  byId('new-tab').addEventListener('click', function () {
    if (currentMode === 'codex') { window.UOYCodexUI.newChat(); return; }
    var account = Model.activeAccount(state);
    var project = account.projects.find(function (item) { return item.id === account.currentProjectId; });
    try { update(Model.createTab(state, project ? project.url : Model.HOME, project ? project.title : 'Chat mới'), true); }
    catch (exception) { status(exception.message, false); }
  });
  byId('project-select').addEventListener('click', function () { if (currentMode === 'codex') window.UOYCodexUI.chooseWorkspace(); else projectDialog(); });
  byId('pin-project').addEventListener('click', function () { if (currentMode === 'codex') window.UOYCodexUI.chooseWorkspace(); else capture('pin'); });
  byId('save-chat').addEventListener('click', function () { if (currentMode === 'codex') window.UOYCodexUI.saveChat(); else capture('save'); });
  byId('switch-account').addEventListener('click', function () { if (currentMode === 'codex') window.UOYCodexUI.profileDialog(); else accountDialog(); });
  byId('prompt-library').addEventListener('click', function () { promptDialog(); });
  byId('connect-browser').addEventListener('click', navigateCurrent);
  byId('browser-external').addEventListener('click', function () { send({ action: 'openExternal', url: Model.getCurrentTab(state).url }); });
  byId('import-image').addEventListener('click', function () { send({ action: 'importImage' }); });
  byId('export-layers').addEventListener('click', function () { send({ action: 'exportLayers' }); });
  byId('generate-3d').addEventListener('click', generate3DDialog);
  byId('remove-background').addEventListener('click', function () { send({ action: 'removeBackground' }); });
  byId('status-dismiss').addEventListener('click', hideToast);
  byId('mode-chatgpt').addEventListener('click', function () { setMode('chatgpt', true); });
  byId('mode-codex').addEventListener('click', function () { setMode('codex', true); });
  byId('mode-photoroom').addEventListener('click', function () { setMode('photoroom', true); });
  byId('mode-canva').addEventListener('click', function () { setMode('canva', true); });
  byId('web-retry').addEventListener('click', function () { send({ action: 'webRetry' }); });
  byId('web-cancel').addEventListener('click', function () { send({ action: 'webCancel' }); });
  dialogLayer.addEventListener('click', function (event) { if (event.target === dialogLayer) closeDialog(); });
  document.addEventListener('keydown', function (event) {
    if (!currentDialog) return;
    if (event.key === 'Escape') { event.preventDefault(); closeDialog(); return; }
    if (event.key === 'Tab') {
      var focusable = Array.from(currentDialog.querySelectorAll('button:not(:disabled), input, textarea, select, [tabindex="0"]'));
      if (!focusable.length) return;
      var first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  window.addEventListener('resize', scheduleLayout);
  if (window.ResizeObserver) new ResizeObserver(scheduleLayout).observe(byId('browser-surface'));
  if (host) {
    host.addEventListener('message', function (event) {
      var message = event.data;
      if (!message || typeof message !== 'object') return;
      if (message.type === 'state') {
        var nextState = Model.normalizeState(message.state);
        var changed = JSON.stringify(nextState) !== JSON.stringify(state);
        state = nextState;
        var modeChanged = setMode(message.mode, false, true);
        if (changed && !modeChanged) render();
        if (changed) persist();
        // A busy navigation rejection also returns authoritative state. It
        // must never start another navigation (and another rejection) in a
        // message loop. Only the initial restore may navigate automatically.
        if (!hostStateReceived && message.restoreOnly !== true) {
          hostStateReceived = true;
          initialNavigationPending = currentBusy && currentMode === 'chatgpt';
          if (!initialNavigationPending) navigateCurrent();
        }
      } else if (message.type === 'status') {
        status(message.message, message.busy);
      } else if (message.type === 'page' && (message.purpose === 'pin' || message.purpose === 'save')) {
        clearTransientStatus();
        bookmarkDialog(message.purpose, message.page || {});
      } else if (message.type === 'navigate' && typeof message.accountId === 'string' && typeof message.tabId === 'string') {
        var account = state.accounts.find(function (item) { return item.id === message.accountId; });
        var tab = account && account.tabs.find(function (item) { return item.id === message.tabId; });
        var url = Model.normalizeChatGPTUrl(message.url);
        var title = typeof message.title === 'string' ? message.title.trim().slice(0, 200) : '';
        if (title) title = title.replace(/\s*[|–-]\s*ChatGPT\s*$/i, '') || 'ChatGPT';
        if (!tab || !url || (tab.url === url && (!title || tab.title === title))) return;
        clearTransientStatus();
        update(Model.updateTab(state, message.accountId, message.tabId, message.url, message.title));
      } else if (message.type === 'mode') setMode(message.mode, false);
      else if (/^codex/.test(message.type || '')) window.UOYCodexUI.receive(message);
    });
  }
  window.UOYCodexUI.init({ send: send, showDialog: showDialog, closeDialog: closeDialog, field: field, actions: actions,
    status: status, requestLayout: scheduleLayout, hasDialog: function () { return !!currentDialog; }, isDialog: function (dialog) { return currentDialog === dialog; } });
  window.UOYWorkspaceInsertPrompt = function (text) { return currentMode === 'codex' ? window.UOYCodexUI.insertPrompt(text) : false; };
  render();
  send({ action: 'ready' });
}());
