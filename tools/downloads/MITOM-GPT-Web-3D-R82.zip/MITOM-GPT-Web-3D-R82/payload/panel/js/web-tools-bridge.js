/* Dedicated MITOM PNG receiver. No filesystem path, URL, JSX or host command
 * crosses this API. Only the trusted panel callback may import decoded images.
 */
'use strict';
var PORT = 8791, ORIGIN = 'https://mitomyhy.github.io', MAX_BYTES = 60 * 1024 * 1024, MAX_PIXELS = 40000000;
var MOON_MAX_BYTES = 2 * 1024 * 1024, MOON_CACHE_BYTES = 20 * 1024 * 1024;
var PSD_MAX_BYTES = 256 * 1024 * 1024, TEMPLATE_CLAIM_MS = 5 * 60 * 1000;
var SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), CRC_TABLE = [];
for (var ci = 0; ci < 256; ci++) { var cv = ci; for (var cb = 0; cb < 8; cb++) cv = cv & 1 ? 0xedb88320 ^ cv >>> 1 : cv >>> 1; CRC_TABLE[ci] = cv >>> 0; }
function crc32(bytes) { var c = 0xffffffff; for (var i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 255] ^ c >>> 8; return (c ^ 0xffffffff) >>> 0; }
function error(code, message) { var e = new Error(message || code); e.code = code; return e; }
function wipe(bytes) { if (Buffer.isBuffer(bytes)) bytes.fill(0); }
function validatePng(bytes, zlib, artwork) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 57 || bytes.length > MAX_BYTES || !bytes.slice(0, 8).equals(SIGNATURE)) throw error('PNG_INVALID', 'Kết quả không phải PNG hoàn chỉnh.');
  var at = 8, width = 0, height = 0, channels = 0, sampleBytes = 1, idats = [], ended = false, seenIdat = false, afterIdat = false, count = 0, inflated, palette=false, seenPalette=false;
  while (at < bytes.length) {
    if (++count > 2048 || at + 12 > bytes.length) throw error('PNG_INVALID');
    var size = bytes.readUInt32BE(at), type = bytes.toString('ascii', at + 4, at + 8), next = at + 12 + size;
    if (size > MAX_BYTES || next > bytes.length || !/^[A-Za-z]{4}$/.test(type) || crc32(bytes.slice(at + 4, at + 8 + size)) !== bytes.readUInt32BE(at + 8 + size)) throw error('PNG_INVALID');
    if (count === 1) {
      if (type !== 'IHDR' || size !== 13) throw error('PNG_INVALID');
      width = bytes.readUInt32BE(at + 8); height = bytes.readUInt32BE(at + 12);
      var depth = bytes[at + 16], color = bytes[at + 17];
      if (!width || !height || width > 32768 || height > 32768 || width * height > MAX_PIXELS) throw error('IMAGE_SIZE', 'Kết quả vượt 40 megapixel.');
      if(artwork&&(width<2||height<2||Math.max(width,height)>8192||width*height>16000000))throw error('IMAGE_SIZE','Artwork vượt giới hạn web 16 MP / 8192 px.');
      // Depth exports intentionally retain 16-bit scalar samples and alpha.
      // Validate exact decoded scanline size instead of downcasting to canvas8.
      palette=!!artwork&&color===3;
      var normal=[8,16].indexOf(depth)>=0&&[0,2,4,6].indexOf(color)>=0,compact=!!artwork&&[1,2,4,8].indexOf(depth)>=0&&[0,3].indexOf(color)>=0;
      if ((!normal&&!compact) || bytes[at + 18] !== 0 || bytes[at + 19] !== 0 || bytes[at + 20] !== 0) throw error('PNG_FORMAT', 'PNG phải là RGB, palette hoặc thang xám, không interlace.');
      channels = color === 6 ? 4 : color === 2 ? 3 : color === 4 ? 2 : 1; sampleBytes = depth / 8;
    } else if (type === 'IHDR') throw error('PNG_INVALID');
    else if(type==='PLTE'&&palette){if(seenPalette||seenIdat||size<3||size%3||size>3*Math.pow(2,sampleBytes*8))throw error('PNG_INVALID');seenPalette=true;}
    else if (type === 'IDAT') { if (afterIdat||palette&&!seenPalette) throw error('PNG_INVALID'); seenIdat = true; idats.push(bytes.slice(at + 8, at + 8 + size)); }
    else if (type === 'IEND') { if (size || !seenIdat || next !== bytes.length) throw error('PNG_INVALID'); ended = true; at = next; break; }
    else {
      if (seenIdat) afterIdat = true;
      if (type.charCodeAt(0) < 97) throw error('PNG_FORMAT');
      if (type === 'acTL' || type === 'fcTL' || type === 'fdAT') throw error('PNG_ANIMATED');
    }
    at = next;
  }
  if (!ended || at !== bytes.length) throw error('PNG_INVALID');
  var rowBytes = Math.ceil(width * channels * sampleBytes) + 1, expected = rowBytes * height, packed = Buffer.concat(idats);
  try {
    inflated = zlib.inflateSync(packed, { maxOutputLength: expected });
    if (inflated.length !== expected) throw error('PNG_INVALID');
    for (var row = 0; row < height; row++) if (inflated[row * rowBytes] > 4) throw error('PNG_INVALID');
  } catch (e) { throw error('PNG_INVALID', 'Dữ liệu PNG thiếu hoặc không hợp lệ.'); }
  finally { wipe(inflated); wipe(packed); }
  return { width: width, height: height, bitDepth: sampleBytes * 8 };
}
function validatePsd(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 42 || bytes.length > PSD_MAX_BYTES || bytes.toString('ascii', 0, 4) !== '8BPS' || bytes.readUInt16BE(4) !== 1) throw error('PSD_INVALID', 'Cần file PSD đầy đủ, không phải ảnh preview.');
  for (var r = 6; r < 12; r++) if (bytes[r]) throw error('PSD_INVALID');
  var channels = bytes.readUInt16BE(12), height = bytes.readUInt32BE(14), width = bytes.readUInt32BE(18), bits = bytes.readUInt16BE(22), mode = bytes.readUInt16BE(24);
  if (!width || !height || width > 32768 || height > 32768 || width * height > MAX_PIXELS || channels < 1 || channels > 16 || [8, 16].indexOf(bits) < 0 || [1, 3].indexOf(mode) < 0) throw error('PSD_FORMAT', 'PSD phải RGB/thang xám 8/16 bit và tối đa 40 MP.');
  var at = 26;
  for (var part = 0; part < 3; part++) { if (at + 4 > bytes.length) throw error('PSD_INVALID'); var length = bytes.readUInt32BE(at); at += 4; if (length > bytes.length - at) throw error('PSD_INVALID'); if (part === 2 && length < 6) throw error('PSD_LAYERS', 'PSD không có các layer template.'); at += length; }
  if (at + 2 > bytes.length || bytes.readUInt16BE(at) > 3) throw error('PSD_INVALID');
  return { width: width, height: height, bitDepth: bits };
}
// R82: JPEG is transferred verbatim; browser decoding is still mandatory before
// acknowledgement. Bound every marker and image dimension before queueing it.
function validateJpeg(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 12 || bytes.length > MAX_BYTES || bytes[0] !== 255 || bytes[1] !== 216 || bytes[bytes.length-2] !== 255 || bytes[bytes.length-1] !== 217) throw error('JPEG_INVALID');
  var at=2, width=0, height=0, scans=0, count=0;
  while(at<bytes.length) {
    if(++count>100000 || bytes[at++]!==255) throw error('JPEG_INVALID');
    while(at<bytes.length&&bytes[at]===255)at++;
    var marker=bytes[at++];
    if(marker===217){if(at!==bytes.length||!width||!scans)throw error('JPEG_INVALID');return {width:width,height:height,bitDepth:8};}
    if(marker===0||marker===216||marker===1||marker>=208&&marker<=215||at+2>bytes.length)throw error('JPEG_INVALID');
    var size=bytes.readUInt16BE(at);if(size<2||size>bytes.length-at)throw error('JPEG_INVALID');
    if(marker>=192&&marker<=207&&[196,200,204].indexOf(marker)<0){
      if([192,194].indexOf(marker)<0||size<11||width||bytes[at+2]!==8)throw error('JPEG_FORMAT');
      height=bytes.readUInt16BE(at+3);width=bytes.readUInt16BE(at+5);var channels=bytes[at+7];
      if([1,3].indexOf(channels)<0||size!==8+3*channels||width<2||height<2||Math.max(width,height)>8192||width*height>16000000)throw error('IMAGE_SIZE');
    }
    at+=size;
    if(marker===218){
      if(!width||++scans>100)throw error('JPEG_INVALID');
      while(at<bytes.length){if(bytes[at]!==255){at++;continue;}var start=at;while(at<bytes.length&&bytes[at]===255)at++;var next=bytes[at];if(next===0||next>=208&&next<=215){at++;continue;}at=start;break;}
    }
  }
  throw error('JPEG_INVALID');
}
function create(options) {
  options = options || {};
  var http = options.http || require('http'), crypto = options.crypto || require('crypto'), zlib = options.zlib || require('zlib');
  var https = options.https || require('https'), timerSet = options.setTimeout || setTimeout, timerClear = options.clearTimeout || clearTimeout;
  var token = crypto.randomBytes(32).toString('hex'), server = null, starting = null, active = null, receipts = [], sockets = new Set(), closed = false;
  var now = options.now || Date.now, onImport = options.onImport;
  var templates = [], templateBytes = 0, handoffs = new Map(), onImportPsd = options.onImportPsd;
  function clearTemplate(item) { templateBytes -= item.bytes.length; wipe(item.bytes); }
  // A weak CPU may spend hours downloading/inferencing. Native snapshots must
  // survive that wait; only explicit acknowledgment or panel dispose removes
  // them. Count/byte bounds prevent an unbounded queue without a lossy TTL.
  function releaseHandoff(key) { handoffs.delete(key); templates.forEach(function (item) { if (item.handoffId === key) item.handoffId = ''; }); }
  function pruneHandoffs() { handoffs.forEach(function (value, key) { if (now() > value.until) releaseHandoff(key); }); templates.forEach(function (item) { if (item.claimUntil <= now()) { item.clientId = ''; item.claimUntil = 0; } }); }
  function templateMetadata(item) { return { id: item.id, name: item.name, bytes: item.bytes.length, sha256: item.sha256, sourceDocumentId: item.sourceDocumentId, autoGenerate: true }; }
  function artworkMetadata(item) { return { id:item.id, kind:'artwork', name:item.name, bytes:item.bytes.length, sha256:item.sha256, mime:item.mime, width:item.width, height:item.height, templateKey:item.templateKey, device:item.device, autoGenerate:true }; }
  var moonCache = new Map(), moonCacheBytes = 0, moonFlights = new Map(), moonRequests = new Set();
  if (typeof onImport !== 'function') throw error('IMPORT_REQUIRED');
  function send(res, code, value) {
    if (res.destroyed || res.writableEnded) return;
    var body = value == null ? '' : JSON.stringify(value);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(body);
  }
  function fail(res, code, kind, message) { send(res, code, { error: kind, message: message || kind }); }
  function moonImage(leaf) {
    if (!/^(?:[0-9]|1[0-5])\.png$/.test(leaf)) return Promise.reject(error('MOON_LEAF', 'Chỉ nhận ảnh pha trăng 0.png đến 15.png.'));
    if (closed) return Promise.reject(error('CLOSED'));
    if (moonCache.has(leaf)) { var hit = moonCache.get(leaf); moonCache.delete(leaf); moonCache.set(leaf, hit); return Promise.resolve(hit); }
    if (moonFlights.has(leaf)) return moonFlights.get(leaf);
    // There are exactly 16 possible public assets. Same-leaf calls share one
    // bounded request. No file cache, source URL, redirect, cookies or auth.
    var promise = new Promise(function (resolve, reject) {
      var request, response, chunks = [], received = 0, done = false, timer;
      function finish(failure, bytes) {
        if (done) return; done = true; timerClear(timer); if (request) moonRequests.delete(request);
        chunks.forEach(wipe); chunks = [];
        if (failure) { if (response) response.destroy(); if (request) request.destroy(); reject(failure); return; }
        resolve(bytes);
      }
      timer = timerSet(function () { finish(error('MOON_TIMEOUT', 'MoonPhases chưa trả ảnh trong 20 giây. Thử lại sau.')); }, 20000);
      try {
        request = https.request({ protocol: 'https:', hostname: 'moonphases.co.uk', port: 443, path: '/images/moons/big/' + leaf, method: 'GET', rejectUnauthorized: true, agent: false, headers: { Accept: 'image/png', 'User-Agent': 'MITOM-Web-Bridge/20261022-R2' } }, function (incoming) {
          response = incoming;
          if (done) { incoming.destroy(); return; }
          if (incoming.statusCode !== 200) { finish(error('MOON_UPSTREAM', 'MoonPhases không trả ảnh gốc hợp lệ; không theo chuyển hướng.')); return; }
          if (String(incoming.headers['content-type'] || '').split(';')[0].trim().toLowerCase() !== 'image/png' || incoming.headers['content-encoding'] && incoming.headers['content-encoding'] !== 'identity') { finish(error('MOON_TYPE', 'MoonPhases trả định dạng không phải PNG gốc.')); return; }
          var declared = incoming.headers['content-length'];
          if (declared !== undefined && (!/^\d+$/.test(String(declared)) || Number(declared) < 1 || Number(declared) > MOON_MAX_BYTES)) { finish(error('MOON_SIZE', 'Ảnh MoonPhases vượt giới hạn 2 MiB.')); return; }
          incoming.on('data', function (chunk) {
            if (done) return;
            received += chunk.length;
            if (received > MOON_MAX_BYTES || declared !== undefined && received > Number(declared)) { finish(error('MOON_SIZE', 'Ảnh MoonPhases vượt giới hạn 2 MiB.')); return; }
            chunks.push(Buffer.from(chunk));
          });
          incoming.once('aborted', function () { finish(error('MOON_TRUNCATED', 'Ảnh MoonPhases bị ngắt giữa chừng.')); });
          incoming.once('error', function () { finish(error('MOON_UPSTREAM', 'Không đọc được ảnh MoonPhases.')); });
          incoming.once('end', function () {
            if (done) return;
            if (!received || declared !== undefined && received !== Number(declared)) { finish(error('MOON_TRUNCATED')); return; }
            var bytes = Buffer.concat(chunks, received), dimensions;
            try { dimensions = validatePng(bytes, zlib); if (dimensions.width !== 1000 || dimensions.height !== 1000) throw error('MOON_DIMENSIONS', 'Ảnh MoonPhases phải đúng 1000 × 1000 px.'); }
            catch (failure) { wipe(bytes); finish(error(failure.code || 'MOON_PNG', 'Ảnh MoonPhases gốc chưa hợp lệ hoặc không đúng 1000 × 1000 px.')); return; }
            if (closed) { wipe(bytes); finish(error('CLOSED')); return; }
            moonCache.set(leaf, bytes); moonCacheBytes += bytes.length;
            while (moonCache.size > 16 || moonCacheBytes > MOON_CACHE_BYTES) { var oldest = moonCache.keys().next().value; moonCacheBytes -= moonCache.get(oldest).length; moonCache.delete(oldest); }
            // Public immutable cache entries are dropped for GC, not wiped
            // while an existing response may still hold a reference.
            finish(null, bytes);
          });
        });
        moonRequests.add(request);
        request.once('error', function () { finish(error('MOON_UPSTREAM', 'Không kết nối được MoonPhases.')); });
        request.end();
      } catch (_) { finish(error('MOON_UPSTREAM', 'Không kết nối được MoonPhases.')); }
    });
    moonFlights.set(leaf, promise);
    promise.then(function () { if (moonFlights.get(leaf) === promise) moonFlights.delete(leaf); }, function () { if (moonFlights.get(leaf) === promise) moonFlights.delete(leaf); });
    return promise;
  }
  function handle(req, res) {
    if (String(req.headers.host || '') !== '127.0.0.1:' + PORT) { fail(res, 403, 'HOST_DENIED'); req.resume(); return; }
    if (req.headers.origin !== ORIGIN) { fail(res, 403, 'ORIGIN_DENIED'); req.resume(); return; }
    res.setHeader('Access-Control-Allow-Origin', ORIGIN); res.setHeader('Vary', 'Origin');
    if (req.method === 'OPTIONS') {
      var method = String(req.headers['access-control-request-method'] || ''), headers = String(req.headers['access-control-request-headers'] || '').toLowerCase().split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      if (['GET', 'POST'].indexOf(method) < 0 || headers.some(function (s) { return ['authorization', 'content-type', 'x-mitom-request-id', 'x-mitom-tool', 'x-mitom-client-id'].indexOf(s) < 0; })) { fail(res, 403, 'PREFLIGHT_DENIED'); return; }
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Mitom-Request-Id, X-Mitom-Tool, X-Mitom-Client-Id'); res.setHeader('Access-Control-Allow-Private-Network', 'true'); res.setHeader('Access-Control-Max-Age', '300'); send(res, 204); return;
    }
    pruneHandoffs();
    var handoff = /^\/v1\/handoff\/([a-f0-9]{64})$/.exec(String(req.url || ''));
    if (req.method === 'GET' && handoff) {
      if (!handoffs.has(handoff[1]) || now() > handoffs.get(handoff[1]).until) { fail(res, 401, 'HANDOFF_EXPIRED', 'Mở lại từ nút Add template to web trong Photoshop.'); return; }
      var handoffValue = handoffs.get(handoff[1]);
      if (handoffValue.templateId) {
        var handoffClient = String(req.headers['x-mitom-client-id'] || '');
        if (!/^[a-f0-9]{32}$/.test(handoffClient)) { fail(res, 400, 'TEMPLATE_CLIENT_REQUIRED'); return; }
        for (var hi = 0; hi < templates.length; hi++) if (templates[hi].id === handoffValue.templateId && templates[hi].handoffId === handoff[1]) { templates[hi].clientId = handoffClient; templates[hi].claimUntil = now() + TEMPLATE_CLAIM_MS; }
      }
      releaseHandoff(handoff[1]); send(res, 200, { ok: true, token: token }); return;
    }
    var auth = /^Bearer ([a-f0-9]{64})$/.exec(String(req.headers.authorization || ''));
    if (!auth || !token || !crypto.timingSafeEqual(Buffer.from(auth[1]), Buffer.from(token))) { fail(res, 401, 'AUTH', 'Mã kết nối hết hạn hoặc không đúng. Lấy mã mới trong panel.'); req.resume(); return; }
    if (req.method === 'GET' && req.url === '/v1/health') { send(res, 200, { ok: true, service: 'mitom-web-image', version: 1, build: '20261102-R82', capabilities: ['moon-image-v1', 'png16-import-v1', 'psd-import-v1', 'psd-template-export-v1', 'artwork-3d-export-v1'], busy: !!active }); return; }
    var clientId = String(req.headers['x-mitom-client-id'] || '');
    if (/^\/v1\/(?:templates|artworks)\//.test(String(req.url || '')) && !/^[a-f0-9]{32}$/.test(clientId)) { fail(res, 400, 'TEMPLATE_CLIENT_REQUIRED'); req.resume(); return; }
    if(req.method==='GET'&&req.url==='/v1/artworks/next') {
      // Artwork requires the originating one-use handoff; an already-paired
      // unrelated tab must never steal and auto-run another GPT image.
      var artwork=null;for(var ai=0;ai<templates.length;ai++){var candidate=templates[ai];if(candidate.kind==='artwork'&&!candidate.handoffId&&candidate.clientId===clientId){artwork=candidate;break;}}
      if(artwork)artwork.claimUntil=now()+TEMPLATE_CLAIM_MS;
      send(res,200,{ok:true,artwork:artwork?artworkMetadata(artwork):null});return;
    }
    if (req.method === 'GET' && req.url === '/v1/templates/next') {
      var nextTemplate = null, unclaimed = null;
      for (var qi = 0; qi < templates.length; qi++) { if (templates[qi].handoffId || templates[qi].kind==='artwork') continue; if (templates[qi].clientId === clientId) { nextTemplate = templates[qi]; break; } if (!templates[qi].clientId && !unclaimed) unclaimed = templates[qi]; }
      nextTemplate = nextTemplate || unclaimed;
      if (nextTemplate) { nextTemplate.clientId = clientId; nextTemplate.claimUntil = now() + TEMPLATE_CLAIM_MS; }
      send(res, 200, { ok: true, template: nextTemplate ? templateMetadata(nextTemplate) : null }); return;
    }
    var templateRoute = /^\/v1\/(templates|artworks)\/([a-f0-9]{32})(\/ack)?$/.exec(String(req.url || ''));
    if (templateRoute && (req.method === 'GET' && !templateRoute[3] || req.method === 'POST' && templateRoute[3])) {
      var index = -1; for (var ti = 0; ti < templates.length; ti++) if (templates[ti].id === templateRoute[2] && (templates[ti].kind==='artwork')===(templateRoute[1]==='artworks')) { index = ti; break; }
      if (index < 0) { fail(res, 404, 'TEMPLATE_EXPIRED'); req.resume(); return; }
      var template = templates[index];
      if (template.clientId !== clientId) { fail(res, 409, 'TEMPLATE_CLAIMED', 'Template đang chờ một tab MITOM khác nhận. Không chạy trùng tác vụ.'); req.resume(); return; }
      if (templateRoute[3]) { templates.splice(index, 1); clearTemplate(template); send(res, 200, { ok: true }); req.resume(); return; }
      template.claimUntil = now() + TEMPLATE_CLAIM_MS;
      var output = Buffer.from(template.bytes); res.once('close', function () { wipe(output); });
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': output.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(output); return;
    }
    var moonRoute = /^\/v1\/moon-image\/((?:[0-9]|1[0-5])\.png)$/.exec(String(req.url || ''));
    if (req.method === 'GET' && moonRoute) {
      moonImage(moonRoute[1]).then(function (bytes) {
        if (res.destroyed || res.writableEnded) return;
        var output = Buffer.from(bytes);
        if (typeof res.once === 'function') res.once('close', function () { wipe(output); });
        res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': output.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(output);
      }).catch(function (failure) { fail(res, failure.code === 'MOON_TIMEOUT' ? 504 : 502, failure.code || 'MOON_UPSTREAM', failure.message); }); return;
    }
    var psdImport = req.url === '/v1/import-psd';
    if ((req.url !== '/v1/import' && !psdImport) || req.method !== 'POST') { fail(res, 404, 'ROUTE'); req.resume(); return; }
    if (psdImport && typeof onImportPsd !== 'function') { fail(res, 501, 'PSD_IMPORT_UNAVAILABLE'); req.resume(); return; }
    var id = String(req.headers['x-mitom-request-id'] || ''), label;
    try { label = decodeURIComponent(String(req.headers['x-mitom-tool'] || 'MITOM Tools')); } catch (_) { fail(res, 400, 'LABEL'); req.resume(); return; }
    if (!/^[a-f0-9]{32}$/.test(id) || label.length < 1 || label.length > 80 || /[\x00-\x1f\x7f]/.test(label)) { fail(res, 400, 'REQUEST'); req.resume(); return; }
    if (req.headers['content-type'] !== (psdImport ? 'application/octet-stream' : 'image/png')) { fail(res, 415, psdImport ? 'PSD_REQUIRED' : 'PNG_REQUIRED'); req.resume(); return; }
    var maxBody = psdImport ? PSD_MAX_BYTES : MAX_BYTES;
    var length = String(req.headers['content-length'] || '');
    if (req.headers['transfer-encoding'] || !/^\d+$/.test(length) || !Number.isSafeInteger(Number(length)) || Number(length) < 1 || Number(length) > maxBody) { fail(res, 413, 'BODY_SIZE'); req.resume(); return; }
    if (active) { fail(res, 409, 'BUSY', 'Photoshop đang nhận một ảnh. Chờ xác nhận trước khi gửi tiếp.'); req.resume(); return; }
    var job = { id: id, bytes: null, chunks: [], size: 0, reading: true, settled: false, cancelled: false }; active = job;
    function finish() { job.chunks.forEach(wipe); job.chunks.length = 0; wipe(job.bytes); job.bytes = null; job.settled = true; if (active === job) active = null; }
    function abort() { if (!job.reading || job.settled) return; job.cancelled = true; finish(); }
    req.once('aborted', abort); req.once('error', abort);
    req.on('data', function (chunk) {
      if (job.settled) return;
      job.size += chunk.length;
      if (job.size > Number(length) || job.size > maxBody) { fail(res, 413, 'BODY_SIZE'); job.cancelled = true; finish(); req.resume(); return; }
      job.chunks.push(Buffer.from(chunk));
    });
    req.on('end', function () {
      if (job.settled) return;
      job.reading = false;
      if (job.size !== Number(length)) { fail(res, 400, 'BODY_TRUNCATED'); finish(); return; }
      job.bytes = Buffer.concat(job.chunks, job.size); job.chunks.forEach(wipe); job.chunks.length = 0;
      var dimensions, sha = crypto.createHash('sha256').update(job.bytes).digest('hex');
      try { dimensions = psdImport ? validatePsd(job.bytes) : validatePng(job.bytes, zlib); } catch (e) { fail(res, 422, e.code || (psdImport ? 'PSD_INVALID' : 'PNG_INVALID'), e.message); finish(); return; }
      receipts = receipts.filter(function (r) { return now() - r.at < 300000; });
      var prior = receipts.filter(function (r) { return r.id === id; })[0];
      if (prior) { if (prior.sha !== sha || prior.label !== label || prior.format !== (psdImport ? 'psd' : 'png')) fail(res, 409, 'REQUEST_REUSE'); else send(res, 200, prior.result); finish(); return; }
      Promise.resolve().then(function () { if (closed || job.cancelled) throw error('CLOSED'); return (psdImport ? onImportPsd : onImport)({ bytes: job.bytes, label: label, requestId: id, width: dimensions.width, height: dimensions.height }); }).then(function (result) {
        if (!result || ['layer', 'document'].indexOf(result.mode) < 0) throw error('NATIVE_RECEIPT', 'Photoshop chưa xác nhận ảnh; kiểm tra Photoshop trước khi gửi lại.');
        var value = { ok: true, mode: result.mode, requestId: id };
        receipts.push({ id: id, sha: sha, label: label, format: psdImport ? 'psd' : 'png', result: value, at: now() }); if (receipts.length > 32) receipts.shift(); finish(); send(res, 200, value);
      }).catch(function (e) { finish(); fail(res, 500, 'IMPORT_FAILED', String(e && e.message || 'Photoshop chưa nhận ảnh.').slice(0, 240)); });
    });
  }
  return {
    enqueueArtwork: function(value) {
      if(closed)throw error('CLOSED');pruneHandoffs();
      if(!value||!Buffer.isBuffer(value.bytes)||['image/png','image/jpeg'].indexOf(value.mime)<0||['acrylic','ceramic_circle','ceramic_heart'].indexOf(value.templateKey)<0||['cpu','gpu'].indexOf(value.device)<0)throw error('ARTWORK_METADATA');
      var info=value.mime==='image/png'?validatePng(value.bytes,zlib,true):validateJpeg(value.bytes);
      if(Math.max(info.width,info.height)>8192||info.width*info.height>16000000)throw error('IMAGE_SIZE','Artwork vượt giới hạn web 16 MP / 8192 px.');
      if(templates.length>=3||templateBytes+value.bytes.length>PSD_MAX_BYTES)throw error('TEMPLATE_QUEUE_FULL','Web chưa nhận hết ảnh trước. Chờ nhận xong rồi gửi tiếp.');
      var name=String(value.label||'GPT artwork').replace(/[\x00-\x1f\x7f\\/]/g,'_').replace(/\.(?:png|jpe?g)$/i,'').slice(0,150)+(value.mime==='image/png'?'.png':'.jpg');
      var item={id:crypto.randomBytes(16).toString('hex'),kind:'artwork',name:name,bytes:Buffer.from(value.bytes),sha256:crypto.createHash('sha256').update(value.bytes).digest('hex'),mime:value.mime,width:info.width,height:info.height,templateKey:value.templateKey,device:value.device,at:now(),clientId:'',claimUntil:0,handoffId:''};
      templates.push(item);templateBytes+=item.bytes.length;return artworkMetadata(item);
    },
    cancelArtwork: function(id) {
      for(var i=0;i<templates.length;i++)if(templates[i].kind==='artwork'&&templates[i].id===id&&!templates[i].clientId){var item=templates.splice(i,1)[0];if(item.handoffId)releaseHandoff(item.handoffId);clearTemplate(item);return true;}return false;
    },
    enqueueTemplate: function (value) {
      if (closed) throw error('CLOSED'); pruneHandoffs();
      if (!value || !Buffer.isBuffer(value.bytes) || !/^[1-9]\d*$/.test(String(value.sourceDocumentId)) || !Number.isSafeInteger(Number(value.sourceDocumentId))) throw error('TEMPLATE_METADATA');
      validatePsd(value.bytes);
      if (templates.length >= 3 || templateBytes + value.bytes.length > PSD_MAX_BYTES) throw error('TEMPLATE_QUEUE_FULL', 'Web chưa nhận hết template trước. Mở web và chờ nhận xong rồi gửi tiếp.');
      var name = String(value.name || 'Photoshop template.psd').replace(/[\x00-\x1f\x7f\\/]/g, '_').slice(0, 160);
      if (!/\.psd$/i.test(name)) name += '.psd';
      var item = { id: crypto.randomBytes(16).toString('hex'), name: name, bytes: Buffer.from(value.bytes), sha256: crypto.createHash('sha256').update(value.bytes).digest('hex'), sourceDocumentId: Number(value.sourceDocumentId), at: now(), clientId: '', claimUntil: 0, handoffId: '' };
      templates.push(item); templateBytes += item.bytes.length; return templateMetadata(item);
    },
    createHandoff: function (templateId) {
      if (closed) throw error('CLOSED'); pruneHandoffs();
      var selected = null;
      if (templateId !== undefined) { for (var si = 0; si < templates.length; si++) if (templates[si].id === templateId) selected = templates[si]; if (!selected || selected.clientId || selected.handoffId) throw error('TEMPLATE_HANDOFF_INVALID'); }
      var key = crypto.randomBytes(32).toString('hex'); if (handoffs.size >= 4) releaseHandoff(handoffs.keys().next().value);
      handoffs.set(key, { until: now() + 60000, templateId: selected ? selected.id : '' }); if (selected) selected.handoffId = key; return key;
    },
    start: function () {
      if (closed) return Promise.reject(error('CLOSED'));
      if (starting) return starting;
      var version = String(options.nodeVersion || process.versions.node).split('.').map(Number);
      if (!(version[0] > 14 || version[0] === 14 && version[1] >= 5 || version[0] === 12 && version[1] >= 19)) return Promise.reject(error('RUNTIME', 'Cần Photoshop có Node 12.19+/14.5+ để nhận PNG an toàn.'));
      starting = new Promise(function (resolve, reject) {
        server = http.createServer(function (req, res) { try { handle(req, res); } catch (_) { fail(res, 500, 'RECEIVER_ERROR'); req.resume(); } });
        server.requestTimeout = 30000; server.headersTimeout = 10000; server.keepAliveTimeout = 1000; server.maxHeadersCount = 40;
        server.on('connection', function (socket) { sockets.add(socket); socket.on('close', function () { sockets.delete(socket); }); });
        server.once('error', function () { starting = null; reject(error('PORT_UNAVAILABLE', 'Cổng MITOM Web đang được panel khác dùng; không dừng ứng dụng nào.')); });
        server.listen(PORT, '127.0.0.1', function () { resolve({ port: PORT, token: token }); });
      }); return starting;
    },
    dispose: function () { closed = true; token = ''; receipts.length = 0; handoffs.clear(); templates.forEach(clearTemplate); templates = []; moonRequests.forEach(function (request) { request.destroy(); }); moonRequests.clear(); moonCache.clear(); moonCacheBytes = 0; if (active && active.reading) { active.cancelled = true; active.chunks.forEach(wipe); active.chunks.length = 0; active.settled = true; active = null; } sockets.forEach(function (s) { s.destroy(); }); if (server) server.close(); },
    status: function () { return { listening: !!(server && server.listening), busy: !!active, moonCache: { items: moonCache.size, bytes: moonCacheBytes, inFlight: moonFlights.size } }; }
  };
}
module.exports = { create: create, validatePng: validatePng, validateJpeg:validateJpeg, validatePsd: validatePsd, port: PORT, origin: ORIGIN, maxBytes: MAX_BYTES, psdMaxBytes: PSD_MAX_BYTES };
