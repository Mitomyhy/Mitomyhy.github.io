/* Account/password handling belongs exclusively to ChatGPT/WebView2 and
 * the isolated local Codex App Server. This CEP bridge exchanges only
 * user-requested image transfers and mode switches with one session-owned
 * native window. It does not read browser or Codex credentials. */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) { root.UOYChatGPTWorkspace = api; if (root.document) api.autoInit(root); }
})(typeof window !== "undefined" ? window : null, function () {
  "use strict";
  var MAX_BYTES = 60 * 1024 * 1024, MAX_PIXELS = 40000000, LEASE_MS = 10000;
  function pathKey(path,value) { value=path.resolve(value);return process.platform === "win32" ? value.toLowerCase() : value; }
  function safePath(deps,value,directory) {
    var fs=deps.fs,path=deps.path;
    if(typeof value!=="string"||!path.isAbsolute(value)||/[\x00-\x1f\x7f]/.test(value))throw new Error("Đường dẫn workspace không an toàn.");
    value=path.resolve(value);
    // Check every existing parent, not just the leaf: a junction/symlink must
    // never redirect a registry, owner marker or a bridge write elsewhere.
    for(var at=value;;at=path.dirname(at)){
      var stat=fs.lstatSync(at);
      if(stat.isSymbolicLink()||(at!==value&&!stat.isDirectory())||pathKey(path,fs.realpathSync(at))!==pathKey(path,at))throw new Error("Đường dẫn workspace không an toàn.");
      if(at===value&&(directory?!stat.isDirectory():!stat.isFile()))throw new Error("Đường dẫn workspace không an toàn.");
      if(path.dirname(at)===at)break;
    }
    return value;
  }
  function boundedJSON(deps,file) {
    safePath(deps,file,false);
    var stat=deps.fs.statSync(file);if(stat.size<2||stat.size>4096)throw new Error("Thông tin nối lại workspace không hợp lệ.");
    var bytes=deps.fs.readFileSync(file);if(bytes.length<2||bytes.length>4096)throw new Error("Thông tin nối lại workspace không hợp lệ.");
    safePath(deps,file,false);return JSON.parse(bytes.toString("utf8").replace(/^\uFEFF/,""));
  }
  function exactObject(value,keys) {return !!value&&typeof value==="object"&&!Array.isArray(value)&&Object.keys(value).sort().join("|")===keys.slice().sort().join("|");}
  function freshLease(value,now) {return Number.isSafeInteger(value)&&value>=0&&value<=now+1000&&now-value<=LEASE_MS;}
  function panelKey(deps,root) {var actual=safePath(deps,root,true);return deps.crypto.createHash("sha256").update(pathKey(deps.path,actual),"utf8").digest("hex");}
  function bridgeDirectory(deps,dir) {
    var root=safePath(deps,deps.os.tmpdir(),true),path=deps.path;
    if(typeof dir!=="string"||!path.isAbsolute(dir)||pathKey(path,path.dirname(dir))!==pathKey(path,root)||!/^uoy-chatgpt-[a-z0-9]{6}$/i.test(path.basename(dir)))throw new Error("Thư mục workspace không thuộc phiên tạm.");
    return safePath(deps,dir,true);
  }
  function discoverWorkspace(deps,key,now) {
    try {
      if(!/^[a-f0-9]{64}$/.test(key))return null;
      var path=deps.path,root=safePath(deps,deps.os.tmpdir(),true),file=path.join(root,"uoy-chatgpt-links",key+".json");
      if(!deps.fs.existsSync(file))return null;
      var value=boundedJSON(deps,file);
      if(!exactObject(value,["version","panelKey","bridge","token","pid","at"])||value.version!==1||value.panelKey!==key||typeof value.token!=="string"||!/^[a-f0-9]{64}$/.test(value.token)||!Number.isSafeInteger(value.pid)||value.pid<1||value.pid>2147483647||!freshLease(value.at,now))return null;
      var dir=bridgeDirectory(deps,value.bridge),owner=boundedJSON(deps,path.join(dir,".owner.json"));
      if(!exactObject(owner,["scope","pid","createdAt","panelKey"])||owner.scope!=="uoy-chatgpt-transfer-v1"||owner.panelKey!==key||!Number.isSafeInteger(owner.pid)||owner.pid<1||owner.pid>2147483647||!Number.isSafeInteger(owner.createdAt)||owner.createdAt<0||owner.createdAt>now+1000)return null;
      return {bridge:dir,token:value.token,pid:value.pid,at:value.at,panelKey:key};
    }catch(_){return null;} // Never expose registry JSON, paths or session tokens.
  }
  function panelStillLive(deps,host,now) {
    var closed=deps.path.join(host.bridge,".panel-closed");
    if(deps.fs.existsSync(closed)){safePath(deps,closed,false);return false;}
    var file=deps.path.join(host.bridge,".panel-live.json");if(!deps.fs.existsSync(file))return false;
    var value=boundedJSON(deps,file);
    return exactObject(value,["version","token","at"])&&value.version===1&&value.token===host.token&&freshLease(value.at,now);
  }
  function message(error) { return String(error && error.message || error || "Lỗi không xác định").replace(/[\x00-\x1f\x7f]/g, " ").slice(0, 700); }
  function psBridgeError(code, operation, detail, stage, line) {
    var hint = code === "JSX_MISSING" || code === "JSX_LOAD_ERROR" || code === "JSX_ENTRY_MISSING" || code === "PS_EVALSCRIPT_ERROR" ? " Cài lại gói ChatGPT mới nhất và mở lại panel Photoshop." : "";
    var error = new Error("Photoshop [" + code + "] (" + operation + "): " + message(detail || "Chưa hoàn thành tác vụ.") + (line ? " · dòng " + String(line) : "") + hint);
    error.code=code;error.operation=operation;error.stage=stage || "callback";if(line)error.line=Number(line);return error;
  }
  function parsePSResponse(raw, operation) {
    var value=typeof raw === "string" ? raw.replace(/^\uFEFF/,"").trim() : "";
    if (!value) throw psBridgeError("PS_EMPTY_RESPONSE",operation,"Photoshop chưa trả kết quả. Không tự chạy lại thao tác thêm ảnh.");
    if (/^EvalScript error[.!]?$/i.test(value)) throw psBridgeError("PS_EVALSCRIPT_ERROR",operation,"Photoshop không thực thi được cầu nối ExtendScript. Kiểm tra file jsx/chatgpt-workspace.jsx và bản panel đang mở.","execute");
    if (value.indexOf("ERR:")===0) throw psBridgeError("PS_ACTION_ERROR",operation,value.slice(4),"action");
    var parsed;
    try {parsed=JSON.parse(value);}catch(_){throw psBridgeError("PS_INVALID_RESPONSE",operation,"Photoshop trả dữ liệu không đúng định dạng cầu nối. Không tự chạy lại thao tác thêm ảnh.");}
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || typeof parsed.ok !== "boolean") throw psBridgeError("PS_INVALID_RESPONSE",operation,"Kết quả Photoshop thiếu trạng thái tác vụ.");
    if (parsed.ok!==true) throw psBridgeError(typeof parsed.code === "string" && /^[A-Z0-9_]{1,60}$/.test(parsed.code) ? parsed.code : "PS_ACTION_ERROR",operation,parsed.message || "Photoshop chưa hoàn thành tác vụ.",parsed.stage,parsed.line);
    var emptyTarget=operation === "uoyChatGPTCaptureTarget" && parsed.targetKind === "new-document" && !parsed.documentId;
    if ((operation === "uoyChatGPTCaptureTarget" || operation === "uoyChatGPTSnapshot" || operation === "uoyChatGPTValidateTarget" || operation === "uoyChatGPTImportImage" || operation === "uoyChatGPTCreateDocumentFromImage") && !emptyTarget && !/^\d{1,12}$/.test(String(parsed.documentId || ""))) throw psBridgeError("PS_INVALID_RESPONSE",operation,"Kết quả thiếu khóa tài liệu Photoshop. Chưa chuyển ảnh sang tài liệu khác.");
    if (operation === "uoyChatGPTSnapshot" && (!Array.isArray(parsed.layerIds) || !parsed.layerIds.length || parsed.layerIds.some(function(id){return !/^\d{1,12}$/.test(String(id));}))) throw psBridgeError("PS_INVALID_RESPONSE",operation,"Không đọc được các layer đang chọn.");
    if (operation === "uoyChatGPTExportLayers" && (!Array.isArray(parsed.files) || !parsed.files.length || parsed.files.some(function(file){return !file || typeof file.path!=="string" || typeof file.name!=="string";}))) throw psBridgeError("PS_INVALID_RESPONSE",operation,"Photoshop chưa trả danh sách ảnh layer.");
    if ((operation === "uoyChatGPTImportImage" || operation === "uoyChatGPTCreateDocumentFromImage") && !/^\d{1,12}$/.test(String(parsed.layerId || ""))) throw psBridgeError("PS_INVALID_RESPONSE",operation,"Photoshop chưa xác nhận layer đã thêm. Kiểm tra layer trước khi bấm lại.");
    if (operation === "uoyChatGPTCreateDocumentFromImage" && (parsed.createdDocument !== true || !Number.isInteger(parsed.width) || !Number.isInteger(parsed.height) || parsed.width < 1 || parsed.height < 1 || parsed.width * parsed.height > MAX_PIXELS || parsed.width > 32768 || parsed.height > 32768)) throw psBridgeError("PS_INVALID_RESPONSE",operation,"Photoshop chưa xác nhận tài liệu mới ở kích thước ảnh gốc. Kiểm tra tài liệu trước khi bấm lại.");
    return parsed;
  }
  function makePSScript(jsxPath, operation, args) {
    // This wrapper is itself ES3 and does not depend on JSON or on a helper
    // from the JSX that may fail to load. Load/runtime errors cross CEP as
    // structured data instead of the opaque "EvalScript error." sentinel.
    function bridgeQuote(value) {
      return '"'+String(value).replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\r/g,"\\r").replace(/\n/g,"\\n").replace(/\t/g,"\\t").replace(/[\x00-\x1f]/g,function(ch){return "\\u"+("0000"+ch.charCodeAt(0).toString(16)).slice(-4);})+'"';
    }
    return '(function(){var _uoyStage="load";var _uoyOperation='+JSON.stringify(operation)+';var _uoyQuote='+bridgeQuote.toString()+';'+
      'function _uoyFailure(code,detail,line){return "{\\"ok\\":false,\\"code\\":"+_uoyQuote(code)+",\\"stage\\":"+_uoyQuote(_uoyStage)+",\\"message\\":"+_uoyQuote(detail)+",\\"line\\":"+(Number(line)||0)+"}";}'+
      'try{var _uoyFile=new File('+JSON.stringify(jsxPath)+');if(!_uoyFile.exists)return _uoyFailure("JSX_MISSING","Không tìm thấy jsx/chatgpt-workspace.jsx trong panel đang mở.",0);'+
      '$.evalFile(_uoyFile);if(typeof '+operation+'!=="function")return _uoyFailure("JSX_ENTRY_MISSING","File JSX chưa có hàm "+_uoyOperation+". Gói panel không đồng bộ.",0);'+
      '_uoyStage="action";return '+operation+'('+args.map(function(value){return JSON.stringify(String(value));}).join(",")+');'+
      '}catch(_uoyError){return _uoyFailure(_uoyStage==="load"?"JSX_LOAD_ERROR":"PS_RUNTIME_ERROR",String(_uoyError.message||_uoyError),_uoyError.line||_uoyError.lineNumber||0);}})()';
  }
  function inspectImage(bytes) {
    if (!Buffer.isBuffer(bytes) || bytes.length < 24 || bytes.length > MAX_BYTES) throw new Error("Ảnh phải là PNG/JPEG hợp lệ, tối đa 60 MB.");
    var width = 0, height = 0, mime = "", at, marker, size;
    if (bytes.slice(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])) && bytes.toString("ascii",12,16) === "IHDR") {
      width = bytes.readUInt32BE(16); height = bytes.readUInt32BE(20); mime = "image/png";
    } else if (bytes[0] === 255 && bytes[1] === 216) {
      at = 2; mime = "image/jpeg";
      while (at + 4 < bytes.length) {
        if (bytes[at++] !== 255) break;
        while (at < bytes.length && bytes[at] === 255) at++;
        marker = bytes[at++];
        if (marker === 217 || marker === 218) break;
        if (marker === 1 || marker >= 208 && marker <= 215) continue;
        size = bytes.readUInt16BE(at);
        if (size < 2 || at + size > bytes.length) break;
        if ([192,193,194,195,197,198,199,201,202,203,205,206,207].indexOf(marker) >= 0 && size >= 7) {
          height = bytes.readUInt16BE(at+3); width = bytes.readUInt16BE(at+5); break;
        }
        at += size;
      }
    }
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width * height > MAX_PIXELS || width > 32768 || height > 32768) throw new Error("Ảnh phải có kích thước hợp lệ, tối đa 40 megapixel.");
    return {mime:mime, width:width, height:height};
  }
  function createPSInvoker(win,deps,panelRoot,options,onLate) {
    options=options || {};
    var pending=null, timeout=options.setTimeout || setTimeout, cancelTimeout=options.clearTimeout || clearTimeout;
    // Finish before the native bridge's two-minute wait. A missing callback
    // is an uncertain outcome, NOT proof that Photoshop did not add a layer.
    var deadline=105000;
    function invoke(name,args) {
      if(pending)return Promise.reject(psBridgeError("PS_CALLBACK_PENDING",name,"Photoshop chưa phản hồi tác vụ trước. Kiểm tra tài liệu/layer; chưa gửi thêm thao tác để tránh chạy trùng.","callback"));
      return new Promise(function(resolve,reject){
        var settleIdle, record={expired:false,done:false,timer:null};
        record.idle=new Promise(function(done){settleIdle=done;});pending=record;
        function finish(error,value) {
          if(record.done)return;record.done=true;cancelTimeout(record.timer);
          if(pending===record)pending=null;settleIdle();
          if(record.expired){if(typeof onLate==="function")onLate();return;}
          if(error)reject(error);else resolve(value);
        }
        record.timer=timeout(function(){
          if(record.done)return;record.expired=true;
          reject(psBridgeError("PS_CALLBACK_TIMEOUT",name,"Chờ Photoshop quá lâu. Chưa xác định tác vụ đã chạy hay chưa; kiểm tra tài liệu/layer trước khi bấm lại. Tool không tự chạy lại.","callback"));
          // Keep this exact invocation quarantined until its late callback.
          // Its image files must not be removed while Photoshop may use them.
        },deadline);
        if(record.timer&&typeof record.timer.unref==="function")record.timer.unref();
        if(typeof options.evalPS==="function") {
          try{Promise.resolve(options.evalPS(name,args)).then(function(value){finish(null,value);},finish);}catch(error){finish(error);}return;
        }
        if(!win.__adobe_cep__||typeof win.__adobe_cep__.evalScript!=="function"){finish(psBridgeError("CEP_UNAVAILABLE",name,"Chức năng này cần panel trong Photoshop."));return;}
        var jsxPath=deps.path.join(panelRoot,"jsx","chatgpt-workspace.jsx"),script;
        try{
          if(!deps.fs.existsSync(jsxPath)||!deps.fs.statSync(jsxPath).isFile()){finish(psBridgeError("JSX_MISSING",name,"Không tìm thấy "+jsxPath,"load"));return;}
          script=makePSScript(jsxPath,name,args);
        }catch(error){finish(psBridgeError("JSX_LOAD_ERROR",name,message(error),"load"));return;}
        try{win.__adobe_cep__.evalScript(script,function(raw){
          if(record.expired){finish();return;}
          try{finish(null,parsePSResponse(raw,name));}catch(error){finish(error);}
        });}catch(error){finish(psBridgeError("CEP_EXECUTE_ERROR",name,message(error),"execute"));}
      });
    }
    return {invoke:invoke,whenIdle:function(){return pending?pending.idle:Promise.resolve();},isPending:function(){return !!pending;}};
  }
  function createSession(deps) {
    var fs = deps.fs, path = deps.path, tempRoot = safePath(deps,deps.os.tmpdir(),true);
    var dir = fs.mkdtempSync(path.join(tempRoot, "uoy-chatgpt-"));
    var token = deps.crypto.randomBytes(32).toString("hex"), closed = false;
    var marker = path.join(dir, ".owner.json");
    function key(value) {return pathKey(path,value);}
    var owner={scope:"uoy-chatgpt-transfer-v1",pid:process.pid,createdAt:Date.now()};if(deps.panelKey)owner.panelKey=deps.panelKey;
    fs.writeFileSync(marker, JSON.stringify(owner), {flag:"wx",mode:384});
    function checkDir() {
      if (closed || !/^uoy-chatgpt-[a-z0-9]{6}$/i.test(path.basename(dir)) || key(path.dirname(dir)) !== key(tempRoot)) throw new Error("Phiên chuyển ảnh đã đóng.");
      safePath(deps,dir,true);
    }
    function checkedFile(value, pattern, mustExist) {
      checkDir();
      if (typeof value !== "string" || /[\x00\r\n]/.test(value) || !path.isAbsolute(value) || key(path.dirname(value)) !== key(dir) || !pattern.test(path.basename(value))) throw new Error("Ảnh không thuộc phiên ChatGPT hiện tại.");
      if (fs.existsSync(value)) {
        var stat = fs.lstatSync(value);
        if (!stat.isFile() || stat.isSymbolicLink() || key(fs.realpathSync(value)) !== key(value)) throw new Error("File chuyển ảnh không an toàn.");
      } else if (mustExist) throw new Error("Chưa nhận được file ảnh ChatGPT.");
      return value;
    }
    function assertConnected() {
      var file=checkedFile(path.join(dir,".panel-closed"),/^\.panel-closed$/,false);
      if(fs.existsSync(file))throw new Error("Phiên chuyển ảnh đã ngắt hoặc được nối sang panel mới.");
    }
    function readRequest() {
      assertConnected();
      var file = checkedFile(path.join(dir,"request.json"), /^request\.json$/, false);
      if (!fs.existsSync(file)) return null;
      var stat = fs.statSync(file);
      if (stat.size < 2 || stat.size > 4096) throw new Error("Lệnh chuyển ảnh không hợp lệ.");
      var request = JSON.parse(fs.readFileSync(file,"utf8").replace(/^\uFEFF/, ""));
      if (!request || !/^[a-zA-Z0-9_-]{1,80}$/.test(String(request.id || ""))) throw new Error("ID lệnh chuyển ảnh không hợp lệ.");
      if (typeof request.token !== "string" || !/^[a-f0-9]{64}$/.test(request.token) || !deps.crypto.timingSafeEqual(Buffer.from(request.token),Buffer.from(token))) throw new Error("Không xác thực được phiên chuyển ảnh.");
      try {
        if (["captureTarget","exportLayers","importImage","removeBackground","generate3D"].indexOf(request.action) < 0) throw new Error("Tác vụ không được hỗ trợ.");
        if (request.action === "generate3D") {
          if (["acrylic","ceramic_circle","ceramic_heart"].indexOf(request.template) < 0 || ["cpu","gpu"].indexOf(request.device) < 0) throw new Error("Template hoặc thiết bị 3D không hợp lệ.");
          if (request.documentId || request.targetKind || request.targetToken || request.createDocument) throw new Error("Generate 3D chỉ chuyển artwork, không nhận đích Photoshop.");
          checkedFile(request.imagePath, /^import[a-zA-Z0-9_-]*\.(png|jpe?g)$/i, true);
        }
        if (request.action === "captureTarget" && request.allowNewDocument !== undefined && typeof request.allowNewDocument !== "boolean") throw new Error("Lựa chọn tài liệu mới không hợp lệ.");
        if (request.action === "importImage" || request.action === "removeBackground") {
          if(request.targetKind === "new-document") {
            if (request.createDocument !== true || request.documentId || !/^[a-f0-9]{32}$/.test(String(request.targetToken || ""))) throw new Error("Chưa khóa đích tạo tài liệu mới. Bấm tác vụ lại.");
          } else if (request.targetKind || request.targetToken || request.createDocument || !/^\d{1,12}$/.test(String(request.documentId || ""))) throw new Error("Chưa khóa tài liệu Photoshop đích. Bấm tác vụ lại.");
          checkedFile(request.imagePath, /^import[a-zA-Z0-9_-]*\.(png|jpe?g)$/i, true);
        }
      } catch (failure) { failure.requestId=request.id; throw failure; }
      return request;
    }
    function reply(value) {
      if (!value || !/^[a-zA-Z0-9_-]{1,80}$/.test(String(value.id || ""))) return;
      assertConnected();
      var target = checkedFile(path.join(dir,"response.json"), /^response\.json$/, false);
      var temporary = checkedFile(path.join(dir,"response-"+value.id+".tmp"), /^response-[a-zA-Z0-9_-]{1,80}\.tmp$/, false);
      if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
      fs.writeFileSync(temporary,JSON.stringify(value),{flag:"wx",mode:384});
      if (fs.existsSync(target)) fs.unlinkSync(target);
      fs.renameSync(temporary,target);
    }
    function readImage(file) {
      assertConnected();
      checkedFile(file, /^(import[a-zA-Z0-9_-]*\.(png|jpe?g)|export-[a-zA-Z0-9_-]+\.png)$/i, true);
      var stat = fs.statSync(file);
      if (stat.size > MAX_BYTES || stat.size < 24) throw new Error("Ảnh chuyển vượt giới hạn 60 MB hoặc chưa hoàn tất.");
      var bytes = fs.readFileSync(file);
      try { return {bytes:bytes,info:inspectImage(bytes)}; }
      catch (error) { bytes.fill(0); throw error; }
    }
    function switchMode(mode) {
      assertConnected();
      if (mode !== "chatgpt" && mode !== "codex" && mode !== "current" && mode !== "photoroom" && mode !== "canva") throw new Error("Chế độ workspace không hợp lệ.");
      var random=deps.crypto.randomBytes(16);random[6]=(random[6]&15)|64;random[8]=(random[8]&63)|128;
      var hex=random.toString("hex"),id=hex.slice(0,8)+"-"+hex.slice(8,12)+"-"+hex.slice(12,16)+"-"+hex.slice(16,20)+"-"+hex.slice(20);
      var target=checkedFile(path.join(dir,"control.json"),/^control\.json$/,false);
      var temporary=checkedFile(path.join(dir,"control.json."+hex+".tmp"),/^control\.json\.[a-f0-9]{32}\.tmp$/,false);
      var payload=JSON.stringify({id:id,token:token,mode:mode});
      if(Buffer.byteLength(payload,"utf8")>4096)throw new Error("Lệnh workspace vượt giới hạn.");
      deps.fs.writeFileSync(temporary,payload,{flag:"wx",mode:384});
      try { deps.fs.renameSync(temporary,target); }
      catch(error) { try{deps.fs.unlinkSync(temporary);}catch(_){} throw error; }
      return id;
    }
    function writeJSON(name,value) {
      var target=checkedFile(path.join(dir,name),/^\.(?:panel|workspace)-live\.json$/,false),id=deps.crypto.randomBytes(16).toString("hex");
      var temporary=checkedFile(path.join(dir,name+"."+id+".tmp"),/^\.(?:panel|workspace)-live\.json\.[a-f0-9]{32}\.tmp$/,false),payload=JSON.stringify(value);
      if(Buffer.byteLength(payload,"utf8")>4096)throw new Error("Thông tin workspace vượt giới hạn.");
      fs.writeFileSync(temporary,payload,{flag:"wx",mode:384});
      try{fs.renameSync(temporary,target);}catch(error){try{fs.unlinkSync(temporary);}catch(_){}throw error;}
    }
    function heartbeat(now) {assertConnected();writeJSON(".panel-live.json",{version:1,token:token,at:now});}
    function workspaceLive(pid,now) {
      var file=checkedFile(path.join(dir,".workspace-live.json"),/^\.workspace-live\.json$/,false);if(!fs.existsSync(file))return false;
      var value=boundedJSON(deps,file);
      if(!exactObject(value,["version","token","at","pid"])||value.version!==1||value.token!==token||value.pid!==pid||!Number.isSafeInteger(value.at))throw new Error("Không xác thực được workspace nối lại.");
      return freshLease(value.at,now);
    }
    function cleanup() {
      if (closed) return;
      checkDir();
      // Non-recursive: delete only known regular files from this exact session.
      var files = fs.readdirSync(dir), allowed = /^(\.owner\.json|\.panel-closed|\.(?:panel|workspace)-live\.json(?:\.[a-f0-9]{32}\.tmp)?|request\.json|request\.json\.[a-f0-9]{32}\.tmp|response\.json|response-[a-zA-Z0-9_-]{1,80}\.tmp|control\.json|control\.json\.[a-f0-9]{32}\.tmp|import[a-zA-Z0-9_-]*\.(png|jpe?g)|export-[a-zA-Z0-9_-]+\.png)$/i;
      files.forEach(function (name) { if (!allowed.test(name)) return; var file=checkedFile(path.join(dir,name),allowed,true); fs.unlinkSync(file); });
      if (!fs.readdirSync(dir).length) fs.rmdirSync(dir);
      closed = true; token = "";
    }
    function markDisconnected() {var file=checkedFile(path.join(dir,".panel-closed"),/^\.panel-closed$/,false);if(!fs.existsSync(file))fs.writeFileSync(file,"closed",{flag:"wx",mode:384});}
    return {dir:dir,token:token,readRequest:readRequest,reply:reply,readImage:readImage,checkedFile:checkedFile,switchMode:switchMode,heartbeat:heartbeat,workspaceLive:workspaceLive,assertConnected:assertConnected,markDisconnected:markDisconnected,cleanup:cleanup};
  }
  function createController(win, options) {
    options = options || {};
    var deps = {fs:options.fs || require("fs"),path:options.path || require("path"),os:options.os || require("os"),crypto:options.crypto || require("crypto")};
    var cp = options.childProcess || require("child_process"), path = deps.path;
    var panelRoot = options.panelRoot || path.dirname(decodeURIComponent(win.location.pathname).replace(/^\/([A-Za-z]:)/,"$1"));
    var session = null, child = null, mode = null, timer = null, busy = false, disposed = false, persistent = false, handled = Object.create(null), newTargets = Object.create(null), inFlight = null;
    var nativeConnected=false,pending=null,hostPid=0,lastDiscovery=-Infinity,retryAfter=0,now=options.now||Date.now,attemptToken="",attempts=0,requestedMode=null;
    deps.panelKey=panelKey(deps,panelRoot);
    var interval = options.setInterval || setInterval, clearIntervalFn = options.clearInterval || clearInterval;
    function say(value,error) { if (typeof options.onStatus === "function") options.onStatus(message(value),!!error); }
    var psInvoker=createPSInvoker(win,deps,panelRoot,options,function(){if(!disposed)say("Photoshop đã phản hồi tác vụ chậm. Kiểm tra tài liệu/layer trước khi chạy lại; không tự thêm ảnh lần nữa.");});
    function keepPanelResident() {
      // Adobe's documented PhotoshopPersistent event prevents the CEP HTML
      // context being reloaded merely because the panel is hidden/minimized.
      // Dispatch the same event object as CSInterface, only for this extension.
      var cep=win.__adobe_cep__;
      if(persistent || !cep || typeof cep.dispatchEvent!=="function") return;
      try {
        var extensionId=typeof cep.getExtensionId==="function"?cep.getExtensionId():"com.uoy.orderpanel.panel";
        if(extensionId!=="com.uoy.orderpanel.panel") return;
        cep.dispatchEvent({type:"com.adobe.PhotoshopPersistent",scope:"APPLICATION",appId:"",extensionId:extensionId,data:""});
        persistent=true;
      }catch(_){/* Unsupported CEP persistence must not close the workspace. */}
    }
    function reconnect() {
      if(disposed||child||nativeConnected||session||pending||busy||inFlight)return false;
      var host=discoverWorkspace(deps,deps.panelKey,now());if(!host)return false;
      if(attemptToken!==host.token){attemptToken=host.token;attempts=0;}
      // A trusted live host is enough to block a duplicate spawn, even while
      // its previous CEP owner is still alive or adoption is waiting for idle.
      try{if(panelStillLive(deps,host,now())||now()<retryAfter||attempts>=2)return true;}catch(_){return true;}
      attempts++;
      var owned=null,published=false,id=deps.crypto.randomBytes(16).toString("hex"),target=path.join(host.bridge,"reattach.json"),temporary=target+"."+id+".tmp";
      try {
        owned=createSession(deps);
        owned.heartbeat(now());
        // Revalidate the exact registry/owner immediately before publishing.
        // Nothing from the old request/response/image/grant files is consumed.
        var current=discoverWorkspace(deps,deps.panelKey,now());
        if(!current||current.bridge!==host.bridge||current.token!==host.token||current.pid!==host.pid)throw new Error("Workspace đã đổi phiên.");
        if(panelStillLive(deps,current,now()))throw new Error("Panel cũ vẫn đang hoạt động.");
        if(deps.fs.existsSync(target))safePath(deps,target,false);
        if(deps.fs.existsSync(temporary))throw new Error("Lệnh nối lại workspace đã tồn tại.");
        var payload=JSON.stringify({version:1,id:id,token:host.token,bridge:owned.dir,bridgeToken:owned.token,panelKey:deps.panelKey});
        if(Buffer.byteLength(payload,"utf8")>4096)throw new Error("Lệnh nối lại workspace vượt giới hạn.");
        deps.fs.writeFileSync(temporary,payload,{flag:"wx",mode:384});
        // After attempting publication the outcome can be uncertain. A native
        // host may already have observed the command even if a wrapper reports
        // an error, so preserve the fresh generation on this boundary too.
        published=true;
        try{deps.fs.renameSync(temporary,target);}catch(error){try{deps.fs.unlinkSync(temporary);}catch(_){}throw error;}
        pending={owned:owned,pid:host.pid,oldBridge:host.bridge,oldToken:host.token,startedAt:now(),waitingReported:false};return true;
      }catch(_){if(owned)try{owned.markDisconnected();if(!published)owned.cleanup();}catch(_){}retryAfter=now()+1500;return true;}
    }
    function abandonPending() {
      var prior=pending;pending=null;if(prior)try{prior.owned.markDisconnected();}catch(_){}
      // Adoption might be completing concurrently. Leave this exact fresh
      // generation intact; never delete files a live native host may use.
      retryAfter=now()+15000;
    }
    function assertCurrent(owned) {
      if(disposed||session!==owned)throw new Error("Phiên ChatGPT đã đóng.");
      owned.assertConnected();
      if(nativeConnected&&!owned.workspaceLive(hostPid,now()))throw new Error("Workspace chưa xác nhận phiên chuyển ảnh hiện tại.");
    }
    function detachCurrent() {
      var detached=session;session=null;child=null;nativeConnected=false;hostPid=0;mode=null;newTargets=Object.create(null);handled=Object.create(null);retryAfter=now()+1500;
      if(detached)try{detached.markDisconnected();}catch(_){}
      // An old child can now host another fresh bridge generation. Do not kill
      // it or clean a live native channel when this controller loses ownership.
    }
    function replyIfCurrent(owned,value) {
      try{assertCurrent(owned);owned.reply(value);return true;}
      catch(_){if(session===owned)detachCurrent();return false;}
    }
    function tick() {
      if(disposed)return;
      var at=now();
      if(pending){
        var joining=pending;
        try {
          joining.owned.heartbeat(at);
          if(joining.owned.workspaceLive(joining.pid,at)){
            session=joining.owned;hostPid=joining.pid;pending=null;nativeConnected=true;handled=Object.create(null);newTargets=Object.create(null);mode=null;
            keepPanelResident();say("Đã nối lại workspace hiện có; giữ nguyên tab đang làm việc.");
            if(requestedMode){session.switchMode(requestedMode);if(requestedMode!=="current")mode=requestedMode;requestedMode=null;}
          }else {
            var live=discoverWorkspace(deps,deps.panelKey,at),oldMatch=live&&live.pid===joining.pid&&live.bridge===joining.oldBridge&&live.token===joining.oldToken,newMatch=live&&live.pid===joining.pid&&live.bridge===joining.owned.dir&&live.token===joining.owned.token;
            if((!oldMatch&&!newMatch)||(oldMatch&&panelStillLive(deps,live,at))){abandonPending();say("Workspace đã đổi hoặc ngắt phiên; chưa chuyển ảnh.",true);}
            else if(at-joining.startedAt>LEASE_MS&&!joining.waitingReported){joining.waitingReported=true;say("Workspace hiện có đang bận; sẽ tự nối lại khi tác vụ hoàn tất, chưa chuyển ảnh.");}
            // Keep exactly one fresh generation while this exact host is live.
            // A long download must not create orphan channels or a new window.
          }
        }catch(_){abandonPending();say("Chưa xác thực được workspace để nối lại; chưa chuyển ảnh.",true);}
      }
      if(session){
        try {
          assertCurrent(session);session.heartbeat(at);poll();
        }catch(_){detachCurrent();say("Cầu nối workspace đã ngắt hoặc đổi phiên; chưa chuyển ảnh.",true);}
      }
      if(at-lastDiscovery>=1500){lastDiscovery=at;reconnect();}
    }
    function evalPS(name,args) {
      return psInvoker.invoke(name,args);
    }
    async function processRequest(request, owned) {
      // Native host captures the destination before it starts any download.
      // Never substitute the tab active after the download/Photoroom finishes.
      assertCurrent(owned);
      // R82: selected ChatGPT/Codex artwork goes directly to the existing web
      // handoff. No active Photoshop document is captured, validated or edited.
      if (request.action === "generate3D") {
        var web = win.__mitomWebTools;
        if (!web || typeof web.sendArtworkTo3D !== "function") throw new Error("Cần bản cập nhật MITOM Web Tools có flow Generate 3D từ GPT/Codex.");
        var artwork = owned.readImage(request.imagePath);
        try {
          // Match the browser's existing depth-pixels input contract. Other
          // Photoshop transfers retain their original forty-megapixel limit.
          if (artwork.info.width < 2 || artwork.info.height < 2 || artwork.info.width > 8192 || artwork.info.height > 8192 || artwork.info.width * artwork.info.height > 16000000) throw new Error("Web 3D nhận ảnh từ 2×2 px, tối đa 16 megapixel và 8192 px mỗi cạnh. Ảnh gốc được giữ nguyên; chưa gửi.");
          assertCurrent(owned);
          var queued = await web.sendArtworkTo3D({bytes:artwork.bytes,mime:artwork.info.mime,label:"GPT-Codex-artwork" + (artwork.info.mime === "image/png" ? ".png" : ".jpg"),templateKey:request.template,device:request.device});
          assertCurrent(owned);
          if (!queued || queued.ok !== true || typeof queued.id !== "string" || !/^[a-zA-Z0-9_-]{1,100}$/.test(queued.id)) throw new Error("Web chưa xác nhận đã nhận artwork 3D. Không tự chạy lại để tránh tạo tác vụ trùng.");
          return {id:request.id,ok:true,handoffId:queued.id,message:"Đã chuyển artwork sang MITOM Web và yêu cầu Generate 3D. Photoshop vẫn giữ nguyên."};
        } finally { artwork.bytes.fill(0); }
      }
      async function evalOwned(name,args){assertCurrent(owned);var result=await evalPS(name,args);assertCurrent(owned);return result;}
      var snapshot,createDocument=request.targetKind === "new-document";
      if(request.action === "captureTarget") snapshot=await evalOwned("uoyChatGPTCaptureTarget",[request.allowNewDocument === true ? "true" : "false"]);
      else if(request.action === "exportLayers") snapshot=await evalOwned("uoyChatGPTSnapshot",[]);
      else if(createDocument) {
        var granted=newTargets[request.targetToken];
        // This nonce can only have been issued after Photoshop reported zero
        // open documents. Claim it once, before upload or uncertain placement.
        if(!granted || granted.owner !== owned || granted.expiresAt < Date.now()) throw new Error("Đích tài liệu mới đã hết hạn hoặc chưa được xác nhận. Bấm tác vụ lại; chưa chuyển ảnh.");
        delete newTargets[request.targetToken];snapshot={targetKind:"new-document"};
      } else snapshot=await evalOwned("uoyChatGPTValidateTarget",[request.documentId]);
      assertCurrent(owned);
      if(request.action === "captureTarget") {
        if(snapshot.targetKind === "new-document") {
          if(request.allowNewDocument !== true || snapshot.documentId) throw new Error("Photoshop chưa xác nhận trạng thái không có tài liệu. Chưa chuyển ảnh.");
          // Only the latest explicit transfer can create a document. An abandoned
          // image selection is superseded rather than accumulating live grants.
          var now=Date.now();Object.keys(newTargets).forEach(function(key){delete newTargets[key];});
          var targetToken=deps.crypto.randomBytes(16).toString("hex");newTargets[targetToken]={owner:owned,expiresAt:now+30*60*1000};
          return {id:request.id,ok:true,message:"Photoshop chưa có tài liệu; sẽ tạo tài liệu mới từ ảnh kết quả, chưa lưu file.",targetKind:"new-document",targetToken:targetToken};
        }
        return {id:request.id,ok:true,message:"Đã khóa tài liệu Photoshop đích.",documentId:snapshot.documentId};
      }
      if (request.action === "exportLayers") {
        var exported = await evalOwned("uoyChatGPTExportLayers",[owned.dir,JSON.stringify(snapshot),request.id]);
        exported.files.forEach(function(file) { var image=owned.readImage(file.path); image.bytes.fill(0); });
        return {id:request.id,ok:true,message:"Đã lấy layer từ Photoshop. Nhập prompt trong ChatGPT.",files:exported.files,documentId:snapshot.documentId};
      }
      var input=owned.readImage(request.imagePath), resultFile=request.imagePath, finalInfo=input.info;
      try {
        if (request.action === "removeBackground") {
          var photoroom = options.photoroom || win.__uoyPhotoroom;
          if (!photoroom || typeof photoroom.processBytes !== "function") throw new Error("Cần bản cập nhật Photoroom có cầu nối ChatGPT. Mở Photoroom và ghép extension Chrome trước.");
          assertCurrent(owned);
          var result = await photoroom.processBytes({bytes:input.bytes,mime:input.info.mime,name:path.basename(request.imagePath)},function(progress){say(progress && progress.message || "Đang tách nền bằng Photoroom…");});
          try {
            assertCurrent(owned);
            var info=inspectImage(result.bytes);
            if (info.mime !== "image/png") throw new Error("Photoroom chưa trả PNG nền trong suốt.");
            finalInfo=info;
            resultFile=owned.checkedFile(path.join(owned.dir,"import-bg-"+request.id+".png"),/^import[a-zA-Z0-9_-]*\.png$/,false);
            assertCurrent(owned);
            deps.fs.writeFileSync(resultFile,result.bytes,{flag:"wx",mode:384});
          } finally { if (result && result.bytes) result.bytes.fill(0); }
        }
        assertCurrent(owned);
        var imageName=request.action === "removeBackground" ? "ChatGPT - Photoroom" : "ChatGPT";
        var imported = createDocument ? await evalOwned("uoyChatGPTCreateDocumentFromImage",[resultFile,imageName,finalInfo.width,finalInfo.height]) : await evalOwned("uoyChatGPTImportImage",[resultFile,snapshot.documentId,imageName]);
        return {id:request.id,ok:true,message:createDocument ? "Đã tạo tài liệu Photoshop mới từ ảnh kết quả ở kích thước gốc; chưa lưu file." : "Đã thêm ảnh vào đúng tài liệu Photoshop.",documentId:imported.documentId,layerId:imported.layerId,createdDocument:!!createDocument};
      } finally { input.bytes.fill(0); }
    }
    async function poll() {
      if (disposed || busy || !session || (!child&&!nativeConnected)) return;
      var owned=session, request;
      try{assertCurrent(owned);}catch(_){detachCurrent();return;}
      try { request=owned.readRequest(); }
      catch (error) { if(error.requestId && !handled[error.requestId]) {handled[error.requestId]=true;if(replyIfCurrent(owned,{id:error.requestId,ok:false,message:message(error)}))say(error,true);}return; }
      if (!request || handled[request.id]) return;
      handled[request.id]=true; busy=true;
      var pending=processRequest(request,owned); inFlight=pending;
      try { var response=await pending;if(replyIfCurrent(owned,response))say(response.message); }
      catch(error) { if (!disposed && session===owned) { var failure={id:request.id,ok:false,message:message(error)};if(error.code)failure.code=error.code;if(error.stage)failure.stage=error.stage;if(error.operation)failure.operation=error.operation;if(error.line)failure.line=error.line;if(replyIfCurrent(owned,failure))say(error,true); } }
      finally { busy=false; if (inFlight===pending) inFlight=null; }
    }
    function cleanupWhenIdle(owned) {
      var pending=inFlight || Promise.resolve();
      pending.catch(function(){}).then(function(){return psInvoker.whenIdle();}).then(function(){try {owned.cleanup();}catch(error){say("File tạm được giữ lại vì phiên chưa đóng an toàn: "+message(error),true);}});
    }
    function open(nextMode) {
      if (disposed) throw new Error("Panel đã đóng.");
      nextMode=typeof nextMode === "undefined" ? "chatgpt" : nextMode;
      if(nextMode!=="chatgpt"&&nextMode!=="codex"&&nextMode!=="photoroom"&&nextMode!=="canva")throw new Error("Chế độ workspace không hợp lệ.");
      var label=nextMode==="codex"?"Codex local":nextMode==="photoroom"?"Photoroom web":nextMode==="canva"?"Canva web":"ChatGPT";
      if (child || nativeConnected) {
        if(!session)throw new Error("Phiên workspace không còn hợp lệ. Đóng cửa sổ workspace rồi mở lại.");
        session.switchMode(nextMode);mode=nextMode;say("Đã yêu cầu mở "+label+" trong cùng cửa sổ workspace.");return false;
      }
      if(!pending&&attempts>=2&&now()>=retryAfter)attempts=0; // Explicit retry, never an automatic window launch.
      if(pending||reconnect()) {requestedMode=nextMode;say("Đang nối lại workspace hiện có; chưa mở cửa sổ khác.");return false;}
      var executable=path.join(panelRoot,"chatgpt-workspace","UOYChatGPTWorkspace.exe");
      if (!deps.fs.existsSync(executable) || !deps.fs.statSync(executable).isFile()) throw new Error("Chưa cài ChatGPT workplace environment. Chạy Install-ChatGPT từ gói cập nhật.");
      session=createSession(deps); handled=Object.create(null);newTargets=Object.create(null);requestedMode=null;
      var owned=session;
      try {
        // Keep the user-visible companion independent of CEP's panel window.
        // Photoshop lifetime is monitored by the native host, not focus events.
        owned.heartbeat(now());
        child=cp.spawn(executable,["--bridge",owned.dir,"--token",owned.token,"--mode",nextMode],{shell:false,windowsHide:false,stdio:"ignore",detached:true});mode=nextMode;
        var launched=child;
        function ended() { if (child !== launched) return; child=null;mode=null;if(session===owned)session=null;newTargets=Object.create(null);cleanupWhenIdle(owned); }
        child.once("error",function(){say("Không mở được cửa sổ workspace. Kiểm tra WebView2 và gói cài đặt.",true);ended();});
        child.once("exit",ended);
        if(typeof child.unref==="function") child.unref();
        keepPanelResident();
        say("Đã mở "+label+" trong workspace."); return true;
      } catch(error) { child=null;mode=null;session=null;owned.cleanup();throw error; }
    }
    function openCodex() { return open("codex"); }
    function openWorkspace() {
      if(disposed) throw new Error("Panel đã đóng.");
      if(!pending&&attempts>=2&&now()>=retryAfter)attempts=0;
      if(pending||(!child&&!nativeConnected&&reconnect())){requestedMode="current";say("Đang nối lại workspace hiện có; giữ nguyên tab đang làm việc.");return false;}
      if(!child&&!nativeConnected) return open();
      if(!session) throw new Error("Phiên workspace không còn hợp lệ. Đóng cửa sổ workspace rồi mở lại.");
      session.switchMode("current");keepPanelResident();
      say("Đã yêu cầu hiện GPT/Codex; giữ nguyên tab đang làm việc.");return false;
    }
    function dispose() {
      if (disposed)return;disposed=true;if(timer)clearIntervalFn(timer);timer=null;
      if(pending){try{pending.owned.markDisconnected();}catch(_){}pending=null;}
      if(session)try{session.markDisconnected();}catch(_){}
      // Do not kill the browser or delete a folder while the native host is
      // still using it. Its child exit callback performs scoped cleanup.
      // Adopted native windows have no child handle in this CEP context. Keep
      // their fresh generation intact too; they own their eventual shutdown.
      if(!child && session && !nativeConnected){var owned=session;session=null;cleanupWhenIdle(owned);}
    }
    reconnect();timer=interval(tick,750);if(timer&&typeof timer.unref==="function")timer.unref();
    return {open:open,openCodex:openCodex,openWorkspace:openWorkspace,poll:poll,dispose:dispose,state:function(){return {busy:busy,opened:!!child||nativeConnected,mode:mode,persistent:persistent,session:session && session.dir,pending:!!pending,nativeConnected:nativeConnected};}};
  }
  function initUI(win,options) {
    options=options || {};
    var doc=win.document, tabs=doc.querySelector(".tabs");
    if(!tabs)throw new Error("Không tìm thấy thanh nút panel.");
    var status=doc.getElementById("chatgptPanelStatus");
    // Replace only our exact legacy controls, leaving all other panel tools
    // and their event handlers untouched. A fresh node removes stale handlers.
    ["tabChatGPT","tabCodex","tabGPTCodex"].forEach(function(id){var old=doc.getElementById(id);if(old&&old.parentNode===tabs&&String(old.tagName).toLowerCase()==="button")tabs.removeChild(old);});
    var button=doc.createElement("button");button.id="tabGPTCodex";button.type="button";button.title="Mở GPT/Codex workspace";button.setAttribute("aria-label","GPT/Codex workspace");
    var logo=doc.createElement("img");logo.src="./chatgpt-workspace/ui/chatgpt-logo.svg";logo.alt="";logo.width=16;logo.height=16;logo.draggable=false;button.appendChild(logo);
    var label=doc.createElement("span");label.textContent="GPT/Codex";button.appendChild(label);tabs.appendChild(button);
    button.style.setProperty("grid-column","1 / -1","important");button.style.minWidth="0";button.style.display="flex";button.style.alignItems="center";button.style.justifyContent="center";button.style.gap="6px";button.style.overflow="hidden";button.style.color="#fff";button.style.background="#2c6a4c";
    if(!status){status=doc.createElement("div");status.id="chatgptPanelStatus";status.style.cssText="font-size:11px;color:#b7cfbf;padding:3px 0;display:none";tabs.parentNode.insertBefore(status,tabs.nextSibling);}
    var settings={};Object.keys(options).forEach(function(key){settings[key]=options[key];});settings.onStatus=function(value,error){status.textContent=value;status.style.display="block";status.style.color=error?"#ffad97":"#b7cfbf";};
    var controller=createController(win,settings);
    button.addEventListener("click",function(event){event.preventDefault();event.stopImmediatePropagation();try{controller.openWorkspace();}catch(error){settings.onStatus(message(error),true);}});
    // Keep the existing CEP Photoroom/Canva handlers intact. The separately
    // loaded UXP panel is an optional parallel workflow, not a replacement.
    // Do not capture their clicks or route them through GPT/Codex.
    win.addEventListener("beforeunload",controller.dispose);return controller;
  }
  function autoInit(win) {function start(){if(!win.__uoyChatGPTWorkspace){try{win.__uoyChatGPTWorkspace=initUI(win);}catch(_){}}}if(win.document.readyState==="loading")win.document.addEventListener("DOMContentLoaded",start);else start();}
  return {MAX_BYTES:MAX_BYTES,MAX_PIXELS:MAX_PIXELS,inspectImage:inspectImage,createPSInvoker:createPSInvoker,createSession:createSession,createController:createController,panelKey:panelKey,discoverWorkspace:discoverWorkspace,initUI:initUI,autoInit:autoInit};
});
