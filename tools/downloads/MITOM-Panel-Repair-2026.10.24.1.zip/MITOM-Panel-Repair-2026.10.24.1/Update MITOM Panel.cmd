@echo off
setlocal
set "MITOM_PATCH_PYTHON=%LOCALAPPDATA%\UOY\Launcher\current\python\python.exe"
if not exist "%MITOM_PATCH_PYTHON%" (
  echo Install the current MITOM Launcher panel before running this repair.
  pause
  exit /b 1
)
"%MITOM_PATCH_PYTHON%" -B "%~dp0apply_patch_update.py"
set "MITOM_PATCH_RESULT=%ERRORLEVEL%"
pause
exit /b %MITOM_PATCH_RESULT%
