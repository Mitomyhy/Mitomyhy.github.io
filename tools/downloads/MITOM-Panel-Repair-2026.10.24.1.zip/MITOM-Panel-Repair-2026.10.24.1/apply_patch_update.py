"""Apply the reviewed panel repair to an existing 2026.10.23.2 installation.

No package downloads, model/config changes, process termination or registry edits.
Every target is checked against the production preimage and backed up first.
"""
from __future__ import annotations
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import uuid

ALLOWED = frozenset(("panel/js/depth-map.js", "panel/js/depth-runtime-config.js", "panel/js/depth-toolbar.js", "core/depth-engine/engine.py",
    "core/depth-engine/da2_backend.py", "core/depth-engine/dense_workflow.py", "core/depth-engine/preview_ai.py", "core/depth-engine/setup_gpu.py",
    "panel/js/web-tools-bridge.js", "panel/js/web-tools-panel.js", "panel/jsx/web-tools-export.jsx", "panel/jsx/web-tools-import.jsx",
    "panel/js/main.js", "panel/js/system-login-runtime.js", "panel/jsx/depth-toolbar.jsx"))

def digest(data):
    return hashlib.sha256(data).hexdigest()

def checked(path):
    path = Path(path).absolute()
    if str(path).startswith("\\\\"):
        raise ValueError("Use the local managed installation, not a network path.")
    for item in (path, *path.parents):
        if item.exists() or item.is_symlink():
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise ValueError("A junction/link was found. Existing files were preserved.")
    return path

def existing(path):
    checked(path)
    if path.exists() and not path.is_file():
        raise ValueError("A repair target is not a file.")
    return path.read_bytes() if path.exists() else None

def target_path(roots, name):
    if name not in ALLOWED:
        raise ValueError("Unreviewed repair target was refused.")
    root, relative = name.split("/", 1)
    base = checked(roots[root])
    target = checked(base / relative)
    if not target.is_relative_to(base):
        raise ValueError("Repair target escaped the managed installation.")
    return target

def atomic(path, data, expected):
    previous = existing(path)
    if (digest(previous) if previous is not None else None) != expected:
        raise ValueError("A file changed during the repair. No replacement was made.")
    path.parent.mkdir(parents=True, exist_ok=True)
    checked(path.parent)
    handle, temporary = tempfile.mkstemp(prefix=".mitom-panel-", dir=path.parent)
    temporary = Path(temporary)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        current = existing(path)
        if (digest(current) if current is not None else None) != expected:
            raise ValueError("A file changed before replacement. Existing files were preserved.")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)

def photoshop_closed():
    if os.name != "nt":
        return
    tasklist = Path(os.environ["SystemRoot"]) / "System32/tasklist.exe"
    process = subprocess.run([str(tasklist), "/FO", "CSV", "/NH"], shell=False, check=True,
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
    if any(row and row[0].casefold() == "photoshop.exe" for row in csv.reader(io.StringIO(process.stdout))):
        raise RuntimeError("Save your documents and close Photoshop, then run this repair again. No process was closed.")

def apply(package, roots, receipt, backups, closed=photoshop_closed):
    package = checked(package)
    manifest = json.loads((package / "patch-manifest.json").read_text("utf-8"))
    if manifest.get("schema") != 2 or manifest.get("base_version") != "2026.10.23.2" or manifest.get("version") != "2026.10.24.1":
        raise ValueError("This package is not the reviewed panel repair.")
    baseline = json.loads(existing(checked(receipt)))
    if baseline.get("version") not in (manifest["base_version"], "2026.10.23.3", "2026.10.23.4", manifest["version"]):
        raise ValueError("Install panel 2026.10.23.2 or newer through MITOM Launcher before this repair. This patch does not replace an older full panel.")
    if not isinstance(manifest.get("files"), list) or {row.get("path") for row in manifest["files"]} != ALLOWED or len(manifest["files"]) != len(ALLOWED):
        raise ValueError("The repair inventory is incomplete or contains unknown targets.")
    plans = []
    for row in manifest["files"]:
        name = row["path"]
        data = existing(checked(package / "payload" / name))
        if data is None or len(data) != row["size"] or digest(data) != row["sha256"]:
            raise ValueError("Package verification failed for " + name)
        target = target_path(roots, name)
        old = existing(target)
        current = digest(old) if old is not None else None
        accepted = row.get("accepted_before_sha256")
        if not isinstance(accepted, list) or not accepted or len(accepted) > 3 or len(set(accepted)) != len(accepted) or any(
            value is not None and (not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value)) for value in accepted
        ):
            raise ValueError("The repair preimage inventory is invalid for " + name)
        if current == row["sha256"]:
            continue
        if current not in accepted:
            raise ValueError("The installed file differs from the supported production version: " + name + ". It was preserved; use the cumulative Launcher update.")
        plans.append(dict(path=name, target=target, before=old, after=data, before_sha256=current, sha256=row["sha256"]))
    closed()
    if not plans:
        return dict(updated=False, already_current=True, version=manifest["version"])
    backup = checked(backups) / ("mitom-panel-" + manifest["version"] + "-" + uuid.uuid4().hex)
    backup.mkdir(parents=True)
    for row in plans:
        if row["before"] is not None:
            destination = checked(backup / row["path"])
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(row["before"])
    journal = dict(schema=1, patch_version=manifest["version"], created_utc=datetime.now(timezone.utc).isoformat(),
        files=[{key: row[key] for key in ("path", "before_sha256", "sha256")} for row in plans], completed=False)
    (backup / "repair-journal.json").write_text(json.dumps(journal, indent=2), "utf-8")
    completed = []
    try:
        for row in plans:
            atomic(row["target"], row["after"], row["before_sha256"])
            completed.append(row)
    except BaseException:
        for row in reversed(completed):
            if digest(existing(row["target"]) or b"") != row["sha256"]:
                continue  # Never overwrite a newer unrelated edit during rollback.
            if row["before"] is None:
                row["target"].unlink()
            else:
                atomic(row["target"], row["before"], row["sha256"])
        raise
    journal["completed"] = True
    (backup / "repair-journal.json").write_text(json.dumps(journal, indent=2), "utf-8")
    return dict(updated=True, version=manifest["version"], files=len(plans), backup=str(backup),
        full_install_receipt_preserved=True, models_unchanged=True, machine_configuration_unchanged=True)

def main():
    local, roaming = Path(os.environ["LOCALAPPDATA"]), Path(os.environ["APPDATA"])
    roots = dict(panel=roaming / "Adobe/CEP/extensions/com.uoy.orderpanel", core=local / "UOY/Launcher/current")
    report = apply(Path(__file__).resolve().parent, roots, local / "UOY/Launcher/install-receipt.json", local / "UOY/UpdateBackups")
    print("MITOM Panel repair installed. Open Photoshop again. Models, Base Companion pairing and your data were preserved.")
    print("An expired login still requires signing in again through the real authorization flow.")
    print(json.dumps(report, ensure_ascii=False))

if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Repair stopped: " + str(error), file=sys.stderr)
        raise SystemExit(1)
