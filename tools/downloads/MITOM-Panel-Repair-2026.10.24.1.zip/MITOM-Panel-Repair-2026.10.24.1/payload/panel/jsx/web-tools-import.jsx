/* Narrow PNG import. Trusted panel supplies its owned temp path and plain label.
 * No save, action, expression, linked placement, or source-document close.
 */
function mitomWebImport(resultPath, label) {
    var original = null, originalId = null, oldLayer = null, created = null, opened = null, detached = null, success = false;
    var dialogs = app.displayDialogs;
    function stillOpen(doc, id) {
        for (var i = 0; i < app.documents.length; i++) try { if (app.documents[i] === doc || app.documents[i].id === id) return true; } catch (_) {}
        return false;
    }
    try {
        var file = new File(resultPath), parent = file.parent;
        if (file.name !== 'transfer.png' || !/^mitom-webtools-[a-z0-9]{6}$/i.test(parent.name) || !parent.exists || parent.alias ||
            parent.parent.fsName.toLowerCase() !== Folder.temp.fsName.toLowerCase() || file.alias || !file.exists) throw new Error('MITOM_TEMP_PATH');
        label = String(label || 'MITOM Tools');
        if (!label.length || label.length > 80 || /[\x00-\x1f\x7f]/.test(label)) throw new Error('MITOM_LABEL');
        if (app.documents.length) { original = app.activeDocument; originalId = original.id; oldLayer = original.activeLayer; }
        app.displayDialogs = DialogModes.NO;
        opened = app.open(file);
        if (original) {
            if (!stillOpen(original, originalId)) throw new Error('Tai lieu dich da dong; khong chuyen sang tai lieu khac.');
            var layer = opened.activeLayer;
            if (!layer || layer.typename !== 'ArtLayer' || layer.kind !== LayerKind.NORMAL) throw new Error('MITOM_PIXEL_LAYER');
            created = layer.duplicate(original, ElementPlacement.PLACEATBEGINNING);
            app.activeDocument = original; original.activeLayer = created; created.name = 'MITOM - ' + label;
            if (created.kind !== LayerKind.NORMAL || created.parent.typename !== 'Document' || created.parent.id !== originalId) throw new Error('MITOM_TARGET_LAYER');
            var b = created.bounds, left = b[0].as('px'), top = b[1].as('px'), width = b[2].as('px') - left, height = b[3].as('px') - top;
            var dw = original.width.as('px'), dh = original.height.as('px');
            if (!isFinite(left) || !isFinite(top) || !isFinite(width) || !isFinite(height) || width <= 0 || height <= 0 || !isFinite(dw) || !isFinite(dh) || dw <= 0 || dh <= 0) throw new Error('MITOM_BOUNDS');
            created.translate(new UnitValue(Math.round((dw - width) / 2 - left), 'px'), new UnitValue(Math.round((dh - height) / 2 - top), 'px'));
            opened.close(SaveOptions.DONOTSAVECHANGES); opened = null;
            app.activeDocument = original; original.activeLayer = created; success = true; return 'OK:LAYER';
        }
        detached = opened.duplicate('MITOM - ' + label, true);
        opened.close(SaveOptions.DONOTSAVECHANGES); opened = null;
        app.activeDocument = detached; success = true; return 'OK:DOCUMENT';
    } catch (e) { return 'ERR:' + e.toString(); }
    finally {
        try { if (!success && created && stillOpen(original, originalId)) { app.activeDocument = original; created.remove(); } } catch (_) {}
        try { if (opened) opened.close(SaveOptions.DONOTSAVECHANGES); } catch (_) {}
        try { if (!success && detached) detached.close(SaveOptions.DONOTSAVECHANGES); } catch (_) {}
        try { if (!success && original && stillOpen(original, originalId)) { app.activeDocument = original; if (oldLayer) original.activeLayer = oldLayer; } } catch (_) {}
        app.displayDialogs = dialogs;
    }
}

/* A complete website-generated PSD is opened as its own unsaved document.
 * No active-document overwrite, role replacement, flattening or source save.
 */
function mitomWebImportPsd(resultPath,label) {
    var opened=null,result=null,previous=app.documents.length?app.activeDocument:null,dialogs=app.displayDialogs,success=false;
    try{
        var file=new File(resultPath),dir=file.parent;
        if(file.name!=='transfer.psd'||!file.exists||file.alias||!dir.exists||dir.alias||!/^mitom-webtools-[a-z0-9]{6}$/i.test(dir.name)||dir.parent.fsName.toLowerCase()!==Folder.temp.fsName.toLowerCase())throw new Error('MITOM_TEMP_PATH');
        label=String(label||'3D template');if(!label.length||label.length>80||/[\x00-\x1f\x7f]/.test(label))throw new Error('MITOM_LABEL');
        app.displayDialogs=DialogModes.NO;opened=app.open(file);
        var names={},count=0;
        for(var i=0;i<opened.layers.length;i++){var layer=opened.layers[i],name=String(layer.name).toLowerCase().replace(/^\s+|\s+$/g,'');if(name==='layer in'||name==='layer depth map'||name==='layer c\u1eaft'){if(names[name]||layer.typename!=='ArtLayer'||layer.kind!==LayerKind.SMARTOBJECT)throw new Error('PSD role không phải Smart Object riêng.');names[name]=true;count++;}}
        if(!names['layer in']||!names['layer depth map']||count<2)throw new Error('PSD chưa có đủ IN / DEPTH template.');
        if(Math.round(opened.width.as('px'))===3543&&Math.round(opened.height.as('px'))===1181&&!names['layer c\u1eaft'])throw new Error('PSD Acrylic thiếu Smart Object CUT.');
        result=opened.duplicate('MITOM - '+label,false);opened.close(SaveOptions.DONOTSAVECHANGES);opened=null;
        app.activeDocument=result;success=true;return 'OK:DOCUMENT';
    }catch(error){return 'ERR:'+String(error.message||error);}
    finally{try{if(opened)opened.close(SaveOptions.DONOTSAVECHANGES);}catch(closeTemp){}try{if(!success&&result)result.close(SaveOptions.DONOTSAVECHANGES);}catch(closeCopy){}try{if(!success&&previous)app.activeDocument=previous;}catch(restore){}app.displayDialogs=dialogs;}
}
