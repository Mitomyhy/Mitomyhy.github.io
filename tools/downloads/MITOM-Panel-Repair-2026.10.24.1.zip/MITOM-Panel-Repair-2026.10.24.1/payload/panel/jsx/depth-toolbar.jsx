/* Ceramic source-shape receipt 20261009-R2. No source-eye change during capture.
 * Photoshop-only toolbar actions. Effects use the current selected layer;
 * Generate captures full In with automatic Type/SO text detection. */
(function () {
    function selectedIDs(doc) {
        app.activeDocument=doc;
        var ids=[],ref=new ActionReference(),key=stringIDToTypeID('targetLayersIDs');
        ref.putProperty(charIDToTypeID('Prpr'),key);ref.putEnumerated(charIDToTypeID('Dcmn'),charIDToTypeID('Ordn'),charIDToTypeID('Trgt'));
        try {var desc=executeActionGet(ref);if(desc.hasKey(key)){var list=desc.getList(key);for(var i=0;i<list.count;i++)ids.push(list.getReference(i).getIdentifier());}}catch(unavailable){}
        if(!ids.length)ids.push(Number(doc.activeLayer.id));
        return ids;
    }
    function selectedRoots(container,ids,out,ancestorSelected) {
        for(var i=0;i<container.layers.length;i++){
            var layer=container.layers[i],chosen=false;
            for(var n=0;n<ids.length;n++)if(Number(layer.id)===ids[n])chosen=true;
            if(chosen&&!ancestorSelected)out.push(layer);
            if(layer.typename==='LayerSet')selectedRoots(layer,ids,out,ancestorSelected||chosen);
        }
        return out;
    }
    function containsArt(layer) {
        if(layer.typename==='LayerSet'){for(var i=0;i<layer.layers.length;i++)if(layer.layers[i].visible&&containsArt(layer.layers[i]))return true;return false;}
        return layer.kind!==LayerKind.TEXT;
    }
    function layerPath(container,id,path){
        for(var i=0;i<container.layers.length;i++){var layer=container.layers[i],here=path.concat([i]);if(_uoyDTId(layer)===id)return here;if(layer.typename==='LayerSet'){var found=layerPath(layer,id,here);if(found)return found;}}return null;
    }
    function copyCaptureShape(source,input,helpers,session) {
        // The live shape belongs to the user. Replace only the bundled helper
        // in this newly-created, owned capture document, then bind its new ID.
        _uoyDTCopyCeramicCaptureShape(source,input,helpers,session);
    }
    function captureCanvas(source,spec,standalone,owned) {
        var size=_uoyDTSize(source),nativeSize=size.width===spec.width&&size.height===spec.height;
        // A different open document is never an implicit parent/template. The
        // currently selected source remains authoritative, including failures.
        if(source.mode!==DocumentMode.RGB)throw new Error('Generate can artwork RGB. Tab dang chon la '+String(source.mode).replace('DocumentMode.','')+' '+size.width+' x '+size.height+' px; chon tab In cua template hoac chuyen mot ban sao artwork sang RGB. Khong doi tai lieu goc.');
        if(source.bitsPerChannel!==BitsPerChannelType.EIGHT)throw new Error('Generate can artwork RGB 8-bit. Giu nguyen ban goc; dung mot ban sao RGB 8-bit trong In.');
        if(!standalone){
            if(!nativeSize)throw new Error('In cua template dang chon la '+size.width+' x '+size.height+' px; can '+spec.width+' x '+spec.height+' px. Khong resize In va khong chon template khac thay the.');
            _uoyDTGeometry(source,false,spec.product_type);return source;
        }
        if(nativeSize&&Math.abs(size.dpi-300)<=.02){_uoyDTRequireSRGB(source);return source;}
        if(spec.product_type!=='acrylic')throw new Error('Artwork Ceramic can dung canvas native cua In. Mo template Ceramic va dat artwork vao In; khong tu resize.');
        if(size.width<1||size.height<1||size.width>spec.width||size.height>spec.height||!isFinite(size.dpi)||size.dpi<=0)throw new Error('Artwork '+size.width+' x '+size.height+' px lon hon canvas In '+spec.width+' x '+spec.height+' px. Dat artwork vao In bang Smart Object truoc khi Generate; khong tu crop/resize ban goc.');
        if(Math.abs(Number(source.pixelAspectRatio)-1)>.000001)throw new Error('Artwork can pixel vuong; dat mot ban sao vao In. Khong doi pixel aspect ban goc.');
        _uoyDTRequireSRGB(source);
        app.activeDocument=source;
        var copy=source.duplicate('_UOY standalone artwork - native placement',false);owned.push(_uoyDTId(copy));
        var before=[],i;
        for(i=0;i<copy.layers.length;i++)before.push({layer:copy.layers[i],id:_uoyDTId(copy.layers[i]),kind:copy.layers[i].typename==='ArtLayer'?String(copy.layers[i].kind):'',type:String(copy.layers[i].typename),visible:copy.layers[i].visible,bounds:_uoyDTBounds(copy.layers[i])});
        // Change resolution metadata only in this owned layered copy. NONE
        // preserves its raster sample count; original/history stay untouched.
        copy.resizeImage(undefined,undefined,300,ResampleMethod.NONE);
        var same=_uoyDTSize(copy);
        if(same.width!==size.width||same.height!==size.height)throw new Error('Photoshop da thay so pixel khi dat artwork; dung lai va giu nguyen ban goc.');
        for(i=0;i<before.length;i++)if(!_uoyDTBoundsEqual(before[i].bounds,_uoyDTBounds(before[i].layer)))throw new Error('Photoshop da doi vi tri artwork khi dat DPI; khong dung ban sao nay.');
        // Canvas extension adds transparent margins. No image resize, flatten,
        // merge, type rasterization or destructive edit of the original source.
        if(copy.layers.length&&copy.layers[copy.layers.length-1].typename==='ArtLayer'&&copy.layers[copy.layers.length-1].isBackgroundLayer)copy.layers[copy.layers.length-1].isBackgroundLayer=false;
        copy.resizeCanvas(UnitValue(spec.width,'px'),UnitValue(spec.height,'px'),AnchorPosition.MIDDLECENTER);
        var dx=(spec.width-size.width)/2,dy=(spec.height-size.height)/2;
        for(i=0;i<before.length;i++){
            var row=before[i],layer=row.layer,bounds=_uoyDTBounds(layer);
            if(_uoyDTId(layer)!==row.id||(layer.typename==='ArtLayer'?String(layer.kind):'')!==row.kind||String(layer.typename)!==row.type||layer.visible!==row.visible)throw new Error('Photoshop khong giu editable layer khi dat artwork.');
            // Empty layers have no pixel bounds and remain empty. Nonempty
            // bounds may round an odd transparent margin to either pixel.
            if(row.bounds[2]>row.bounds[0]&&row.bounds[3]>row.bounds[1]){
                for(var edge=0;edge<4;edge++){
                    var delta=(edge%2===0?dx:dy),actual=bounds[edge]-row.bounds[edge];
                    if(Math.abs(actual-Math.floor(delta))>.02&&Math.abs(actual-Math.ceil(delta))>.02)throw new Error('Photoshop da scale/crop artwork khi them le canvas.');
                }
            }
        }
        _uoyDTGeometry(copy,false,spec.product_type);
        return copy;
    }
    function captureSelection(request) {
        if(!app.documents.length)throw new Error('Mở PSD rồi chọn layer hoặc group cần Generate.');
        var previous=app.activeDocument,source=previous,history=null,spec=_uoyDTSpec(request.product_type);
        var result=null,parent=null,input=null,success=false,owned=[],target=null,capturePhase='toolbar-resolve';
        try {
            var selected=_uoyDTModule('importPreview').selectContext(request,owned,source);
            // Parent/In/Depth/Cut are views of one current template. Resolve its
            // native In first; never use the highlighted Depth/Cut pixels as art.
            // selectContext proves the actual open Smart Object linkage and
            // never revives an unrelated parent merely from a cached hint.
            capturePhase='toolbar-open-role';if(!selected.standalone)source=_uoyDTModule('importPreview').openRole(selected.parent,selected.roles.input,owned);
            capturePhase='toolbar-match-canvas';history=_uoyDTHistory(source);
            var captureSource=captureCanvas(source,spec,!!selected.standalone,owned);
            if(!selected.standalone)target={parent:_uoyDTId(selected.parent),source:_uoyDTId(source),roles:selected.roles,parentHistory:_uoyDTHistory(selected.parent),sourceHistory:history};
            // Generate captures the full current In, not just the highlighted
            // text/SO. The capture phase detects Type leaves (including nested
            // Smart Objects) and removes only those from the owned AI copy.
            capturePhase='toolbar-helpers';var helpers=_uoyDTSourceHelpers(captureSource,spec.product_type,!!selected.standalone);
            var ceramicShape=null;
            if(spec.product_type!=='acrylic'&&helpers[1]){
                // Bind the user's ORIGINAL shape, not the helper copied into
                // the owned AI input. Keep its eye untouched until commit.
                app.activeDocument=source;
                var sourceShape=_uoyDTLayer(source,helpers[1]),shapeVisible=sourceShape.visible;
                if(typeof shapeVisible!=='boolean'||!history.id||!/^\d+$/.test(String(history.id)))throw new Error('Khong khoa duoc shape/history Ceramic nguon. Giu nguyen PSD; chua Generate.');
                ceramicShape={document:_uoyDTId(source),layer:_uoyDTId(sourceShape),visible:shapeVisible,history:{id:String(history.id)}};
            }
            capturePhase='toolbar-presets';_uoyDTReadPresets(owned);
            capturePhase='toolbar-open-template';result=_uoyDTOpenTemplate({product_type:spec.product_type});
            var session=_uoyDTLoadSession(result.template_token);parent=_uoyDTFindDoc(session.parent);input=_uoyDTFindDoc(session.input);
            capturePhase='toolbar-full-copy';_uoyDTOwnedQuiet(parent,function(){_uoyDTCopyLayers(captureSource,input,helpers);if(spec.product_type!=='acrylic'&&helpers[1])copyCaptureShape(source,input,helpers,session);});
            capturePhase='toolbar-verify';if(!_uoyDTSameHistory(source,history)||(target&&!_uoyDTSameHistory(selected.parent,target.parentHistory)))throw new Error('PSD nguồn thay đổi trong lúc lấy selection.');
            var registry=$.global._uoyToolbarCaptures||($.global._uoyToolbarCaptures={});
            var parentHistory=_uoyDTHistory(parent),record={parent:_uoyDTId(parent),input:_uoyDTId(input),source:_uoyDTId(source),history:{id:parentHistory.id},target:null};
            if(ceramicShape)record.ceramic_shape=ceramicShape;
            if(target)record.target={parent:target.parent,source:target.source,roles:target.roles,parentHistory:{id:target.parentHistory.id},sourceHistory:{id:target.sourceHistory.id}};
            capturePhase='toolbar-store';registry[result.template_token]=record;session.toolbar_capture=record;_uoyDTSaveSession(session);
            app.activeDocument=input;success=true;result.source_document_id=_uoyDTId(source);result.capture_scope='full_document';result.derived_native_placement=_uoyDTId(captureSource)!==_uoyDTId(source);return result;
        } catch (error) { throw _uoyDTGenerateError(error,capturePhase,source,null); } finally {
            // A newly-opened live In remains bound until async Generate commits
            // back to this exact native source. Other inspection tabs are owned
            // and disposable; pre-existing unsaved tabs are never closed.
            var keep={};if(success&&target)keep['d'+_uoyDTId(source)]=true;_uoyDTCleanup(owned,keep);
            if(!success){if(input)try{app.activeDocument=input;input.close(SaveOptions.DONOTSAVECHANGES);}catch(a){}if(parent)try{app.activeDocument=parent;parent.close(SaveOptions.DONOTSAVECHANGES);}catch(b){}try{app.activeDocument=previous;}catch(c){}}
            else app.activeDocument=input;
        }
    }
    function walkText(container,out) {
        for(var i=0;i<container.layers.length;i++){var layer=container.layers[i];if(layer.typename==='LayerSet')walkText(layer,out);else if(layer.kind===LayerKind.TEXT)out.push(layer);}
        return out;
    }
    function textInSelection(doc) {
        var roots=selectedRoots(doc,selectedIDs(doc),[],false),out=[];
        // A directly selected Smart Object is the user's text target. Apply
        // FX on that native layer, without inspecting/opening its contents.
        // Group traversal stays Type-only: never style unrelated artwork/map SOs.
        for(var i=0;i<roots.length;i++){if(roots[i].typename==='LayerSet')walkText(roots[i],out);else if(roots[i].kind===LayerKind.TEXT||roots[i].kind===LayerKind.SMARTOBJECT)out.push(roots[i]);}
        if(!out.length)throw new Error('Chọn layer chữ Type hoặc Smart Object chữ trước khi chọn Nổi/Lõm.');
        return out;
    }
    function context(request,owned) {
        if(!app.documents.length)throw new Error('Mở depth / template cần chỉnh trong Photoshop.');
        var source=request.document_id?_uoyDTFindDoc(String(request.document_id)):app.activeDocument,product=request.product_type||'acrylic',selected=null;
        var products=['acrylic','ceramic_circle','ceramic_heart'];
        for(var i=0;i<products.length;i++)try{selected={parent:source,roles:_uoyDTRoles(source,products[i])};product=products[i];break;}catch(notParent){}
        // The active tab always wins. Never revive a stale parent_document_id.
        if(!selected)selected=_uoyDTModule('importPreview').selectContext({product_type:product},owned,source);
        if(selected.standalone&&source.mode===DocumentMode.RGB){
            for(var alternative=0;alternative<products.length;alternative++)if(products[alternative]!==product){
                var other=_uoyDTModule('importPreview').selectContext({product_type:products[alternative]},owned,source);
                if(!other.standalone){selected=other;product=products[alternative];break;}
            }
        }
        if(selected.standalone&&source.mode===DocumentMode.GRAYSCALE){
            // A manually opened nested Gray16 tab must resolve its real parent
            // even after CEP/session state was lost. Names alone never bind it.
            var parents=[],initial=[];for(var di=0;di<app.documents.length;di++)initial.push(app.documents[di]);
            for(var pi=0;pi<initial.length;pi++)for(var pt=0;pt<products.length;pt++){
                var roles=null;try{roles=_uoyDTRoles(initial[pi],products[pt]);}catch(noParent){continue;}
                var depthDoc=_uoyDTModule('importPreview').openRole(initial[pi],roles.depth,owned),map=findMap(depthDoc);
                if(map){var rawDoc=_uoyDTNativeEditContents(depthDoc,map,owned,'raw Depth');if(_uoyDTId(rawDoc)===_uoyDTId(source))parents.push({parent:initial[pi],roles:roles,depth:depthDoc,product:products[pt]});}
                break;
            }
            if(parents.length>1)throw new Error('Depth đang dùng chung nhiều template. Chọn tab template cha cần chỉnh.');
            if(parents.length===1)return {source:source,depth:parents[0].depth,parent:parents[0].parent,roles:parents[0].roles,product:parents[0].product,standalone:false,raw:source};
        }
        if(selected.standalone)return {source:source,depth:source,parent:null,roles:null,product:product,standalone:true};
        var depth=_uoyDTModule('importPreview').openRole(selected.parent,selected.roles.depth,owned);
        return {source:source,depth:depth,parent:selected.parent,roles:selected.roles,product:product,standalone:false};
    }
    function replyContext(value){return {ok:true,product_type:value.product,document_id:_uoyDTId(value.parent||value.depth),depth_document_id:_uoyDTId(value.depth),parent_document_id:value.parent?_uoyDTId(value.parent):'',standalone:value.standalone};}
    function inspectContext(request){
        var previous=app.documents.length?app.activeDocument:null,owned=[],value;
        try{value=context(request,owned);return replyContext(value);}finally{_uoyDTCleanup(owned);if(previous)try{app.activeDocument=previous;}catch(restore){}}
    }
    function effectText(request) {
        if(!/^(raised|recessed|plain)$/.test(String(request.mode)))throw new Error('Chọn Nổi, Lõm hoặc Không effect.');
        if(!app.documents.length)throw new Error('Chọn layer chữ trong Photoshop.');
        var source=app.activeDocument,chosen=textInSelection(source),changed=false,history=_uoyDTHistory(source),owned=[];
        try {
            // An edit is not an import or a flow replay. Never resolve/open a
            // parent, copy Type into another document, save, or close any tab.
            var depth=source,targets=chosen,profiles=[],presets=request.mode==='plain'?null:_uoyDTReadPresets(owned);
            for(var t=0;t<targets.length;t++){var size=_uoyDTBounds(targets[t]),shortSide=Math.max(1,Math.min(size[2]-size[0],size[3]-size[1]));
                if(request.mode==='plain')_uoyDTPlainText(depth,targets[t]);
                else{var authoredWidth=_uoyDTWidthControls(presets[request.mode]).maximum||4,width=Math.max(authoredWidth*.85,Math.min(authoredWidth*1.15,shortSide*.025));profiles.push({authored_preset:true,width:width});_uoyDTSetTextFX(depth,targets[t],presets[request.mode],{mode:request.mode,relief:100,bevel_px:width,scalar_channels:true});}
            }
            // Text FX changes relief, not the manufacturing silhouette. Never
            // rewrite Cut or the original fullprint while styling a letter.
            changed=true;depth.activeLayer=targets[0];
            return {ok:true,document_id:_uoyDTId(depth),in_place:true,mode:request.mode,count:targets.length,profiles:_uoyDTDataJson(profiles)};
        } catch(error){if(history&&!changed)try{_uoyDTRestore(source,history);}catch(restore){}throw error;}finally{_uoyDTCleanup(owned);app.activeDocument=source;}
    }
    function findMap(container) {
        for(var i=0;i<container.layers.length;i++){var layer=container.layers[i];if(layer.typename==='LayerSet'){var found=findMap(layer);if(found)return found;}else if(layer.kind===LayerKind.SMARTOBJECT&&String(layer.name)==='UOY Plain Depth - Gray16')return layer;}
        return null;
    }
    function fixDepth(request) {
        if(!/^(dodge|burn)$/.test(String(request.tool)))throw new Error('Sai công cụ Fix.');
        if(!app.documents.length)throw new Error('Mở depth cần tô trong Photoshop.');
        var current=app.activeDocument,parentPreview=false,types=['acrylic','ceramic_circle','ceramic_heart'];
        for(var p=0;p<types.length;p++)try{_uoyDTRoles(current,types[p]);parentPreview=true;break;}catch(notParent){}
        if(parentPreview)throw new Error('Đây là PSD tổng In / Depth / Cut. Mở Smart Object layer depth map để tô tại chỗ; tool không tự đổi tab hoặc tô lên ảnh preview.');
        var raw=app.activeDocument,map=findMap(raw),active=raw.activeLayer,overlay=null,local=$.global._uoyToolbarLocalFix||($.global._uoyToolbarLocalFix={}),record=local['d'+_uoyDTId(raw)],brush=false;
        if(raw.mode!==DocumentMode.GRAYSCALE&&raw.mode!==DocumentMode.RGB)throw new Error('Fix hỗ trợ depth RGB hoặc Grayscale 8/16-bit.');
        if(raw.bitsPerChannel!==BitsPerChannelType.EIGHT&&raw.bitsPerChannel!==BitsPerChannelType.SIXTEEN)throw new Error('Fix không tự đổi bit depth.');
        if(record)overlay=_uoyDTFindTreeLayer(raw,record.layer);
        if(overlay&&overlay.kind!==LayerKind.NORMAL)overlay=null;
        if(overlay&&(map||_uoyDTId(active)===record.layer)){raw.activeLayer=overlay;brush=true;}
        else if(map||active.typename==='LayerSet'||active.kind===LayerKind.SMARTOBJECT){
            var anchor=map||(active.typename==='ArtLayer'?active:null);
            if(!anchor)throw new Error('Chọn layer ảnh/depth trong group để tô tại chỗ.');
            // Local clipped paint preserves the embedded Gray16 original and
            // every unsaved edit. No nested PSB is opened or flattened.
            overlay=raw.artLayers.add();overlay.name='UOY Fix - Local';overlay.blendMode=BlendMode.NORMAL;overlay.opacity=100;overlay.move(anchor,ElementPlacement.PLACEBEFORE);overlay.grouped=true;raw.activeLayer=overlay;
            local['d'+_uoyDTId(raw)]={layer:_uoyDTId(overlay),anchor:_uoyDTId(anchor)};brush=true;
        }else if(active.kind===LayerKind.TEXT){
            var found=null;for(var i=0;i<raw.artLayers.length;i++)if(raw.artLayers[i].visible&&raw.artLayers[i].kind===LayerKind.NORMAL){found=raw.artLayers[i];break;}
            if(!found)throw new Error('Chọn layer ảnh/depth để tô; không rasterize chữ.');raw.activeLayer=found;
        }
        raw.activeChannels=raw.componentChannels;
        $.evalFile(new File(_uoyDTToolbarAsset.parent.fsName+'/depth-map.jsx'));
        if(brush){
            _uoyDepthSelectTool('paintbrushTool');var opts=_uoyDepthToolOptions();opts.putInteger(stringIDToTypeID('opacity'),10);opts.putInteger(stringIDToTypeID('flow'),100);opts.putEnumerated(stringIDToTypeID('mode'),stringIDToTypeID('blendMode'),stringIDToTypeID('normal'));_uoyDepthSetToolOptions('paintbrushTool',opts);
            var color=new SolidColor();color.rgb.red=color.rgb.green=color.rgb.blue=request.tool==='dodge'?255:0;app.foregroundColor=color;
        }else{_uoyDepthSelectTool(request.tool==='dodge'?'dodgeTool':'burnInTool');var opts=_uoyDepthToolOptions();opts.putEnumerated(stringIDToTypeID('mode'),stringIDToTypeID('blendMode'),stringIDToTypeID(request.tool==='dodge'?'dodgeM':'burnInM'));opts.putInteger(stringIDToTypeID('exposure'),10);_uoyDepthSetToolOptions(request.tool==='dodge'?'dodgeTool':'burnInTool',opts);}
        $.global._uoyToolbarFix=null;
        return {ok:true,document_id:_uoyDTId(raw),tool:request.tool,in_place:true,local_paint:brush};
    }
    function mockupSourceRequest(request,active){
        var selected=request.document_id?_uoyDTFindDoc(String(request.document_id)):active;
        if(!selected)return request;
        var selectedId=_uoyDTId(selected),registry=$.global._uoyOwnedMockupSources||{},record=registry['d'+selectedId];
        if(!record){
            // A pre-update/reopened generated set has no proven source handle.
            // Recognize it only to refuse wrong input, never to guess its source.
            var names=['Main 1','Main 2','Main 3','Main 4','Main 5','Main 6','Back','Nghi\u00eang','Main 9'],legacy=/^3D Mockup - 9 views(?:\.psd|\.psb)?$/i.test(String(selected.name))&&selected.layers.length===9;
            for(var i=0;legacy&&i<names.length;i++)if(String(selected.layers[i].name)!==names[i])legacy=false;
            if(legacy)throw new Error('Dang chon PSD 9 Main, khong phai depth goc. Hay chon tab template goc roi bam Xem 3D.');
            return request;
        }
        var valid=false,source=null;
        try{
            if(record.schema===1&&record.output_id===selectedId&&String(record.output.id)===selectedId&&record.source&&/^[1-9]\d*$/.test(record.source_id)&&String(record.source.id)===record.source_id){
                app.activeDocument=record.output;
                if(_uoyDTId(app.activeDocument)!==selectedId)throw new Error('Owned output handle changed.');
                for(var n=0;n<app.documents.length;n++)if(_uoyDTId(app.documents[n])===record.source_id)valid=true;
                if(valid){
                    // Use the recorded native handle, not a replacement found by
                    // name or a stale numeric ID, and prove the activated ID.
                    app.activeDocument=record.source;
                    if(_uoyDTId(app.activeDocument)!==record.source_id)valid=false;
                    else source=record.source;
                }
            }
        }catch(closedSource){valid=false;}
        if(!valid||!source)throw new Error('PSD Main nay khong con lien ket voi template goc dang mo. Hay mo/chon template goc roi bam Xem 3D.');
        var routed={};for(var key in request)if(request.hasOwnProperty(key))routed[key]=request[key];
        routed.document_id=record.source_id;
        if(/^(acrylic|ceramic_circle|ceramic_heart)$/.test(record.product_type))routed.product_type=record.product_type;
        return routed;
    }
    function rawSyncInventory(){
        // Take this before native context inspection opens any disposable PSBs.
        // Do not activate unrelated tabs before proving this is a parent view.
        var rows=[];
        for(var i=0;i<app.documents.length;i++){
            var row={document:app.documents[i],id:''};
            try{row.id=_uoyDTId(row.document);}catch(unreadable){}
            rows.push(row);
        }
        return rows;
    }
    function isLiveOwnedMainOutput(entry){
        var record=($.global._uoyOwnedMockupSources||{})['d'+entry.id],previous=app.activeDocument,valid=false;
        if(!record||record.schema!==1||record.output_id!==entry.id||!/^[1-9]\d*$/.test(entry.id))return false;
        try{
            // Activating the recorded native handle rejects a closed handle even
            // if Photoshop reused its numeric ID. DOM proxy === is not identity.
            if(String(record.output.id)!==entry.id||_uoyDTId(entry.document)!==entry.id)return false;
            app.activeDocument=record.output;
            if(_uoyDTId(app.activeDocument)!==entry.id)return false;
            var doc=app.activeDocument,size=_uoyDTSize(doc),names=['Main 1','Main 2','Main 3','Main 4','Main 5','Main 6','Back','Nghi\u00eang','Main 9'];
            if(doc.mode!==DocumentMode.RGB||doc.bitsPerChannel!==BitsPerChannelType.EIGHT||doc.layers.length!==9)return false;
            if(!/^[1-9]\d*$/.test(String(size.width))||!/^[1-9]\d*$/.test(String(size.height))||size.width*size.height>40000000||!isFinite(size.dpi)||size.dpi<1||size.dpi>1200)return false;
            for(var i=0;i<names.length;i++)if(doc.layers[i].typename!=='ArtLayer'||String(doc.layers[i].name)!==names[i])return false;
            valid=true;
        }catch(unproven){valid=false;}
        finally{app.activeDocument=previous;}
        return valid;
    }
    function hasPendingRawSync(initial,context){
        var parentId=_uoyDTId(context.parent),depthId=_uoyDTId(context.depth),previous=app.activeDocument;
        try{
            for(var i=0;i<initial.length;i++){
                var entry=initial[i],same=false,clean=false;
                try{same=entry.id===_uoyDTId(entry.document)&&(entry.id===parentId||entry.id===depthId);}catch(unreadable){}
                if(same)continue;
                // Read native saved metadata only in its owning tab, after the
                // current parent is proven. Unknown is always potentially dirty.
                try{app.activeDocument=entry.document;clean=entry.document.saved===true;}catch(unknownSaved){}
                if(clean||isLiveOwnedMainOutput(entry))continue;
                // An unrelated/unknown dirty document might be the nested raw
                // PSB. Prove this through the existing single native open.
                return true;
            }
            return false;
        }finally{app.activeDocument=previous;}
    }
    function commitEdits(request){
        var owned=[],context=null,previous=app.documents.length?app.activeDocument:null,phase='resolve source';
        try{
        var initial=rawSyncInventory();
        request=mockupSourceRequest(request,previous);
        phase='resolve native In/Depth';context=resolveContext(request,owned);
        if(!context.parent)return replyContext(context);
        if(context.raw){phase='save raw Depth';app.activeDocument=context.raw;if(context.raw.saved!==true)context.raw.save();}
        else if(hasPendingRawSync(initial,context)){
            // Document IDs change on close/reopen. Only Photoshop's CURRENT
            // native SO linkage authorizes commit, never the last Fix hint.
            phase='open raw Depth';var map=findMap(context.depth);
            if(map){var before=_uoyDTDocs(),actual=_uoyDTNativeEditContents(context.depth,map,owned,'raw Depth');if(before['d'+_uoyDTId(actual)]&&actual.saved!==true){phase='save raw Depth';app.activeDocument=actual;actual.save();}}
        }
        phase='save Depth';app.activeDocument=context.depth;if(context.depth.saved!==true)context.depth.save();app.activeDocument=context.parent;
        return replyContext(context);
        }catch(error){throw new Error('Xem 3D ['+phase+(error.line?'; line '+error.line:'')+']: '+String(error.message||error));
        }finally{_uoyDTCleanup(owned);if(previous)try{app.activeDocument=previous;}catch(restoreTab){}}
    }
    function selectTextGroup(wrapper){
        var groups=[],populated=[],visited=0;
        function hasContent(container,level){
            if(level>16)throw new Error('Cây group chữ quá sâu; giữ nguyên Depth.');
            var found=false;
            for(var i=0;i<container.layers.length;i++){
                if(++visited>4000)throw new Error('Cụm chữ quá lớn; giữ nguyên Depth.');
                var layer=container.layers[i];
                // Hidden artwork, clipping textures and Smart Objects are not
                // empty. Never discard them merely because they are not Type.
                if(layer.typename==='LayerSet'){if(hasContent(layer,level+1))found=true;}
                else found=true;
            }
            return found;
        }
        for(var i=0;i<wrapper.layers.length;i++){
            var group=wrapper.layers[i];
            if(group.typename!=='LayerSet'||!/^(UOY Editable Text|UOY Synced Type)$/.test(String(group.name)))continue;
            groups.push(group);if(hasContent(group,0))populated.push(group);
        }
        if(populated.length>1){
            var labels=[];for(var n=0;n<populated.length;n++)labels.push(String(populated[n].name)+' #'+_uoyDTId(populated[n]));
            throw new Error('Có '+populated.length+' cụm chữ còn nội dung ('+labels.join(', ')+'); chưa ghép tự động để giữ artwork và effect.');
        }
        // Legacy Custom text leaves an empty Editable group beside Synced.
        // Ignore only recursively empty siblings, preserving them verbatim.
        // If all are empty, reuse one shell as the original single-group flow.
        return populated.length?populated[0]:(groups.length?groups[0]:null);
    }
    function syncText(request){
        var previous=app.documents.length?app.activeDocument:null,owned=[],value=null,depth=null,checkpoint=null,saving=false,mutated=false,backup=null,keep={},phase='resolve current PSD';
        try{
            value=resolveContext(request,owned);
            if(!value.parent)throw new Error('Mở tab In hoặc template chứa In/Depth cần cập nhật chữ. Lưu chữ bên trong Smart Object bằng Ctrl+S trước.');
            phase='open current In';var input=_uoyDTModule('importPreview').openRole(value.parent,value.roles.input,owned);depth=value.depth;
            if(_uoyDTId(input)===_uoyDTId(depth))throw new Error('In và Depth dùng chung nội dung; không cập nhật.');
            // Use native bindings, not an old Generate session or cached bitmap.
            phase='check native bindings';$.evalFile(_uoyDTTextSyncAsset);_uoyCTExclusive(value.parent,input,depth);
            var sourceHistory=_uoyDTHistory(input),depthHistory=_uoyDTHistory(depth),parentHistory=_uoyDTHistory(value.parent),map=findMap(depth),wrapper=null,oldText=null;
            if(!map)throw new Error('Không thấy UOY Plain Depth - Gray16. Generate một lần từ In đúng trước.');
            for(var w=0;w<depth.layers.length;w++)if(depth.layers[w].typename==='LayerSet'&&String(depth.layers[w].name)==='UOY Depth + Text'){if(wrapper)throw new Error('Có nhiều group Depth + Text; không đoán đích.');wrapper=depth.layers[w];}
            if(!wrapper||_uoyDTId(map.parent)!==_uoyDTId(wrapper))throw new Error('Cấu trúc map không rõ; giữ nguyên tài liệu.');
            phase='find current Depth text group';oldText=selectTextGroup(wrapper);
            app.activeDocument=depth;var mapID=_uoyDTId(map),mapContent=_uoyDTSmartId(map),mapTransform=_uoyDTTransform(map);
            phase='inspect current Type';app.activeDocument=input;var manifest=_uoyDTManifest(input,'toolbar-custom-text',true);
            if(!manifest.layers.length)throw new Error('In chưa có Type/Smart Text hiển thị. Không tự xoá chữ Depth.');
            var styles={},duplicates={},anchors={},ambiguousAnchors={},visited=0;
            function anchorKey(layer,names){
                var geometry;if(layer.kind===LayerKind.TEXT){var at=layer.textItem.position;geometry=[Math.round(Number(at[0].as('px'))*100)/100,Math.round(Number(at[1].as('px'))*100)/100];}
                else geometry=_uoyDTTransform(layer);
                return _uoyDTDataJson([names.slice(0,names.length-1),String(layer.kind),geometry]);
            }
            function scan(doc,container,prefix,level){
                if(level>4)throw new Error('Smart Text quá nhiều cấp.');
                var rows=[];for(var i=0;i<container.layers.length;i++)rows.push(container.layers[i]);
                for(var j=0;j<rows.length;j++){
                    var l=rows[j],names=prefix.concat([String(l.name)]),key=_uoyDTDataJson(names);
                    if(++visited>4000)throw new Error('Cụm chữ quá lớn.');
                    if(l.typename==='LayerSet'){scan(doc,l,names,level);continue;}
                    if(l.kind!==LayerKind.TEXT&&l.kind!==LayerKind.SMARTOBJECT)continue;
                    app.activeDocument=doc;var desc=_uoyDTLayerDesc(l),fx=stringIDToTypeID('layerEffects');
                    if(styles[key])duplicates[key]=true;
                    styles[key]={kind:l.kind,fx:desc.hasKey(fx)?desc.getObjectValue(fx).toStream():null,enabled:!desc.hasKey(stringIDToTypeID('layerFXVisible'))||desc.getBoolean(stringIDToTypeID('layerFXVisible')),opacity:Number(l.opacity),fill:Number(l.fillOpacity),blend:l.blendMode};
                    var atKey=anchorKey(l,names);if(anchors[atKey])ambiguousAnchors[atKey]=true;else anchors[atKey]=styles[key];
                    if(l.kind===LayerKind.SMARTOBJECT){doc.activeLayer=l;var before=_uoyDTDocs();executeAction(stringIDToTypeID('placedLayerEditContents'),undefined,DialogModes.NO);var child=app.activeDocument;if(!before['d'+_uoyDTId(child)])owned.push(_uoyDTId(child));scan(child,child,names,level+1);app.activeDocument=doc;}
                }
            }
            phase='read Depth text styles';if(oldText)scan(depth,oldText,[],0);
            for(var duplicate in duplicates)if(duplicates.hasOwnProperty(duplicate))throw new Error('Tên/path chữ bị trùng. Đặt tên riêng cho từng cụm chữ trước khi Custom text.');
            phase='copy current text and clipping';var tree=_uoyDTPreservedTextTree(input,manifest,owned),preserved=0;
            function apply(doc,container,prefix,level){
                var rows=[];for(var i=0;i<container.layers.length;i++)rows.push(container.layers[i]);
                for(var j=0;j<rows.length;j++){
                    var l=rows[j],names=prefix.concat([String(l.name)]),style=styles[_uoyDTDataJson(names)];
                    if(l.typename==='LayerSet'){apply(doc,l,names,level);continue;}
                    if(l.kind!==LayerKind.TEXT&&l.kind!==LayerKind.SMARTOBJECT)continue;
                    app.activeDocument=doc;
                    // Photoshop can rename a Type layer automatically when its
                    // contents change. Only a unique same-parent native anchor
                    // may retain that layer's depth FX; never match by text/OCR.
                    if(!style){var atKey=anchorKey(l,names);if(!ambiguousAnchors[atKey])style=anchors[atKey];}
                    if(style&&style.kind===l.kind){
                        if(style.used)throw new Error('Hai chữ mới cùng ghép vào một effect Depth; đặt tên/path riêng trước khi cập nhật.');style.used=true;
                        doc.activeLayer=l;var fx=stringIDToTypeID('layerEffects'),desc=_uoyDTLayerDesc(l);
                        if(style.fx){var copy=new ActionDescriptor();copy.fromStream(style.fx);var set=new ActionDescriptor(),ref=new ActionReference();ref.putProperty(charIDToTypeID('Prpr'),fx);ref.putIdentifier(charIDToTypeID('Lyr '),Number(l.id));set.putReference(charIDToTypeID('null'),ref);set.putObject(charIDToTypeID('T   '),fx,copy);executeAction(charIDToTypeID('setd'),set,DialogModes.NO);}
                        else if(desc.hasKey(fx)){var clear=new ActionDescriptor(),target=new ActionReference();target.putIdentifier(charIDToTypeID('Lyr '),Number(l.id));clear.putReference(charIDToTypeID('null'),target);executeAction(stringIDToTypeID('disableLayerFX'),clear,DialogModes.NO);}
                        if(style.fx){var currentDesc=_uoyDTLayerDesc(l),visibleKey=stringIDToTypeID('layerFXVisible'),currentEnabled=!currentDesc.hasKey(visibleKey)||currentDesc.getBoolean(visibleKey);if(currentEnabled!==style.enabled){var toggle=new ActionDescriptor(),toggleRef=new ActionReference();toggleRef.putIdentifier(charIDToTypeID('Lyr '),Number(l.id));toggle.putReference(charIDToTypeID('null'),toggleRef);executeAction(stringIDToTypeID(style.enabled?'enableLayerStyle':'disableLayerStyle'),toggle,DialogModes.NO);}}
                        l.opacity=style.opacity;l.fillOpacity=style.fill;l.blendMode=style.blend;preserved++;
                    }
                    if(l.kind===LayerKind.SMARTOBJECT){var opened=_uoyDTSmartOwned(doc,l,owned);apply(opened.child,opened.child,names,level+1);app.activeDocument=opened.child;opened.child.save();_uoyDTCloseOwned(opened.child,owned);app.activeDocument=doc;}
                }
            }
            phase='retain existing Depth styles';_uoyDTOwnedQuiet(tree,function(){apply(tree,tree,[],0);});
            if(!_uoyDTSameHistory(input,sourceHistory)||!_uoyDTSameHistory(depth,depthHistory)||!_uoyDTSameHistory(value.parent,parentHistory))throw new Error('In/Depth/template đã đổi trong lúc chuẩn bị; chưa thay chữ.');
            phase='checkpoint Depth';app.activeDocument=depth;checkpoint=_uoyDTHistory(depth);backup=depth.duplicate('RECOVERY - Depth before Custom text',false);owned.push(_uoyDTId(backup));
            app.activeDocument=depth;mutated=true;
            // Replace ONLY the owned editable-letter group. Never touch the
            // Gray16 map, local Fix layers, Cut, wrapper mask or user artwork.
            phase='replace letter group';var letters=oldText?oldText.duplicate():wrapper.layerSets.add();letters.name='UOY Editable Text';
            if(oldText){while(letters.layers.length)letters.layers[letters.layers.length-1].remove();}else letters.blendMode=BlendMode.NORMAL;
            var anchor=letters.artLayers.add();anchor.name='_UOY insertion anchor';letters=_uoyDTCopyTextTree(tree,depth,letters);anchor.remove();letters.move(oldText||map,ElementPlacement.PLACEBEFORE);if(oldText)oldText.remove();
            map=_uoyDTFindTreeLayer(depth,mapID);if(!map||_uoyDTSmartId(map)!==mapContent||_uoyDTTransform(map)!==mapTransform)throw new Error('Base map đổi; huỷ cập nhật.');
            if(!_uoyDTSameHistory(input,sourceHistory))throw new Error('In đổi; huỷ cập nhật.');
            // Commit the user's already-edited In to its native parent too;
            // saving changes no layer/color/FX and never closes an existing tab.
            phase='save current In';app.activeDocument=input;if(!input.saved)input.save();
            phase='save current Depth';saving=true;app.activeDocument=depth;depth.save();
            // Saving SO contents legitimately revises the native role record.
            // Re-read it, then require the SAME open PSB document identity.
            var currentRoles=_uoyDTRoles(value.parent,value.product),bound=_uoyDTModule('importPreview').openRole(value.parent,currentRoles.depth,owned);if(_uoyDTId(bound)!==_uoyDTId(depth))throw new Error('Liên kết Depth đã đổi.');
            var boundIn=_uoyDTModule('importPreview').openRole(value.parent,currentRoles.input,owned);if(_uoyDTId(boundIn)!==_uoyDTId(input))throw new Error('Liên kết In đã đổi.');
            var result=replyContext(value);result.updated_count=manifest.layers.length;result.preserved_styles=preserved;result.parent_unsaved=true;result.map_unchanged=true;return result;
        }catch(error){
            if(mutated){var restored=_uoyDTRestore(depth,checkpoint);if(restored&&saving)try{app.activeDocument=depth;depth.save();}catch(saveRollback){restored=false;}
                if(!restored){keep['d'+_uoyDTId(depth)]=true;if(backup)keep['d'+_uoyDTId(backup)]=true;throw new Error(String(error.message||error)+' · Giữ Depth và RECOVERY đang mở; kiểm tra trước khi lưu PSD tổng.');}}
            throw new Error(String(error.message||error)+' [Custom text: '+phase+'; line '+error.line+']');
        }finally{_uoyDTCleanup(owned,keep);if(previous)try{app.activeDocument=previous;}catch(restore){}}
    }
    function releaseCapture(request){
        var registry=$.global._uoyToolbarCaptures||{},record=registry[request.template_token],previous=app.activeDocument;
        if(!record)try{record=_uoyDTLoadSession(request.template_token).toolbar_capture;}catch(missing){}
        if(!record||record.parent===record.source||record.input===record.source)return {ok:true,released:false};
        // R6 completed this very template; it is no longer a disposable capture.
        try{if(_uoyDTLoadSession(request.template_token).done){delete registry[request.template_token];return {ok:true,released:false};}}catch(noSession){}
        try{
            var session=_uoyDTLoadSession(request.template_token),input=_uoyDTFindDoc(record.input),parent=_uoyDTFindDoc(record.parent),capture=session.captures['c'+request.capture_token];
            if(session.parent!==record.parent||session.input!==record.input||!capture||!_uoyDTSameHistory(input,capture.history)||!_uoyDTSameHistory(parent,record.history))return {ok:true,released:false};
            // Only the tool-created intermediate tabs, still exactly unchanged.
            // User source and the completed new template are never targets.
            app.activeDocument=input;input.close(SaveOptions.DONOTSAVECHANGES);app.activeDocument=parent;parent.close(SaveOptions.DONOTSAVECHANGES);
            delete registry[request.template_token];return {ok:true,released:true};
        }catch(retain){return {ok:true,released:false};}finally{try{app.activeDocument=previous;}catch(closed){}}
    }
    // Alias avoids the local variable named context in effectText/commitEdits.
    var resolveContext=context;
    return {module:'toolbar',schema:1,version:'20260918-scope1',api:{captureSelection:captureSelection,effectText:effectText,fixDepth:fixDepth,commitEdits:commitEdits,releaseCapture:releaseCapture,inspectContext:inspectContext,syncText:syncText}};
})();
