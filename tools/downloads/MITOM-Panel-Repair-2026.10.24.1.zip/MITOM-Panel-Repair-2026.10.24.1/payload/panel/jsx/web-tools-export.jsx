/* User-clicked native PSD snapshot. The caller loads depth-template.jsx first.
 * Preserve IN/DEPTH/CUT Smart Objects; never flatten or save the parent source.
 * A child tab is accepted only after Photoshop proves its native parent link.
 */
function mitomWebExport(resultPath) {
    var previous=app.documents.length?app.activeDocument:null,dialogs=app.displayDialogs,owned=[],copy=null,file=null,success=false;
    function reply(value){return encodeURIComponent(_uoyDTJson(value));}
    function candidate(doc){var types=['acrylic','ceramic_circle','ceramic_heart'];for(var p=0;p<types.length;p++)try{return {parent:doc,roles:_uoyDTRoles(doc,types[p]),product:types[p]};}catch(notTemplate){}return null;}
    function openRole(value,key){var role=value.roles[key];return _uoyDTNativeEditContents(value.parent,_uoyDTLayer(value.parent,role.layer),owned,key,role);}
    function nestedPath(doc,target,depth,seen,budget){
        if(_uoyDTId(doc)===target)return [doc];
        if(depth>=2||seen['d'+_uoyDTId(doc)]||budget.count>=40)return null;
        seen['d'+_uoyDTId(doc)]=true;
        function walk(container){for(var i=0;i<container.layers.length;i++){var layer=container.layers[i];if(layer.typename==='LayerSet'){var grouped=walk(layer);if(grouped)return grouped;}
            else if(layer.kind===LayerKind.SMARTOBJECT&&budget.count<40){var child=null;budget.count++;try{child=_uoyDTNativeEditContents(doc,layer,owned,'template embedded artwork');}catch(notEmbedded){continue;}var found=nestedPath(child,target,depth+1,seen,budget);if(found)return [doc].concat(found);}}
            return null;}
        return walk(doc);
    }
    try{
        if(!previous)throw new Error('Mở template PSD có IN / DEPTH / CUT trước.');
        file=new File(resultPath);var dir=file.parent;
        if(file.name!=='transfer.psd'||file.exists||file.alias||!dir.exists||dir.alias||!/^mitom-webtools-[a-z0-9]{6}$/i.test(dir.name)||dir.parent.fsName.toLowerCase()!==Folder.temp.fsName.toLowerCase())throw new Error('MITOM_TEMP_PATH');
        app.displayDialogs=DialogModes.NO;
        var selected=candidate(previous),path=null,sourceId=_uoyDTId(previous),initial=[],matches=[],budget={count:0};
        if(!selected){
            if(app.documents.length>64)throw new Error('Có quá nhiều tab. Chọn tab template cha rồi bấm lại.');
            for(var d=0;d<app.documents.length;d++)initial.push(app.documents[d]);
            for(var n=0;n<initial.length;n++){var value=candidate(initial[n]);if(!value)continue;var keys=value.product==='acrylic'?['input','depth','cut']:['input','depth'];
                for(var k=0;k<keys.length;k++){var child=openRole(value,keys[k]),found=nestedPath(child,sourceId,0,{},budget);if(found){matches.push({value:value,path:found});break;}}}
            if(matches.length!==1)throw new Error(matches.length?'Smart Object thuộc nhiều template. Chọn đúng tab template cha.':'Tab này chưa liên kết với template. Chọn PSD cha có IN / DEPTH / CUT rồi bấm lại.');
            selected=matches[0].value;path=matches[0].path;
        }
        // Pressing Add template commits edits only along the proven embedded
        // chain, equivalent to Ctrl+S inside that Smart Object. Parent PSD is
        // never saved over, and unrelated tabs are never saved or closed.
        if(path)for(var c=path.length-1;c>=0;c--){app.activeDocument=path[c];if(path[c].saved!==true)path[c].save();}
        var keys=selected.product==='acrylic'?['input','depth','cut']:['input','depth'];
        selected.roles=_uoyDTRoles(selected.parent,selected.product);
        for(var r=0;r<keys.length;r++){var roleDoc=openRole(selected,keys[r]);app.activeDocument=roleDoc;if(roleDoc.saved!==true)roleDoc.save();selected.roles=_uoyDTRoles(selected.parent,selected.product);}
        var parent=selected.parent,parentId=_uoyDTId(parent),history=_uoyDTHistory(parent),roles=_uoyDTRoles(parent,selected.product);
        app.activeDocument=parent;copy=parent.duplicate('_MITOM web template snapshot',false);
        var options=new PhotoshopSaveOptions();options.layers=true;options.embedColorProfile=true;options.alphaChannels=true;
        copy.saveAs(file,options,true,Extension.LOWERCASE);
        if(!file.exists||Number(file.length)<42||Number(file.length)>268435456)throw new Error('PSD snapshot trống hoặc vượt 256 MiB.');
        var copied=_uoyDTRoles(copy,selected.product);
        if(!copied.input||!copied.depth||(selected.product==='acrylic'&&!copied.cut)||!_uoyDTSameHistory(parent,history))throw new Error('Template thay đổi trong lúc chụp. Gửi lại khi Photoshop hoàn tất tác vụ.');
        success=true;return reply({ok:true,name:String(parent.name).replace(/\.(psd|psb)$/i,'')+'.psd',sourceDocumentId:parentId,productType:selected.product,bytes:Number(file.length)});
    }catch(error){return reply({ok:false,error:String(error.message||error)});}
    finally{try{if(copy)copy.close(SaveOptions.DONOTSAVECHANGES);}catch(closeCopy){} _uoyDTCleanup(owned);try{if(previous)app.activeDocument=previous;}catch(restore){}app.displayDialogs=dialogs;if(!success&&file&&file.exists)try{file.remove();}catch(removeFailed){} }
}
