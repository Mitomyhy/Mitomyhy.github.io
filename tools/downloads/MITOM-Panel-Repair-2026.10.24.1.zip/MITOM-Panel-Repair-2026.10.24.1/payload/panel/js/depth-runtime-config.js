/* Select the installed managed engine when an old local setup still emits v1.
 * No configuration, model, output or user file is written by this module. */
"use strict";
var PIPELINE = "shared-acrylic-ai-v2";
function inspectWorker(worker, fs, path) {
  try {
    if (typeof worker !== "string" || !path.isAbsolute(worker) || path.basename(worker).toLowerCase() !== "engine.py" || path.basename(path.dirname(worker)).toLowerCase() !== "depth-engine") return "unknown";
    var policy = path.join(path.dirname(worker), "ceramic_product.py");
    var stat = fs.lstatSync(policy), engineStat = fs.lstatSync(worker);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 131072 || !engineStat.isFile() || engineStat.isSymbolicLink()) return "unknown";
    var text = fs.readFileSync(policy, "utf8");
    if (/^ACRYLIC_COMPOSITION_PIPELINE\s*=\s*["']shared-acrylic-ai-v2["']\s*$/m.test(text)) return PIPELINE;
    if (/^SHARED_PIPELINE\s*=\s*["']shared-acrylic-ai-v1["']\s*$/m.test(text)) return "shared-acrylic-ai-v1";
  } catch (_) {}
  return "unknown";
}
function select(config, options) {
  options = options || {};
  var fs = options.fs || require("fs"), path = options.path || require("path"), env = options.env || require("process").env;
  var result = {}, key;
  for (key in config) if (Object.prototype.hasOwnProperty.call(config, key)) result[key] = config[key];
  var detected = inspectWorker(result.worker, fs, path);
  if (detected !== "shared-acrylic-ai-v1") return { config: result, migrated: false, pipeline: detected };
  var bases = [];
  if (typeof env.LOCALAPPDATA === "string" && path.isAbsolute(env.LOCALAPPDATA)) bases.push(env.LOCALAPPDATA);
  if (typeof env.USERPROFILE === "string" && path.isAbsolute(env.USERPROFILE)) bases.push(path.join(env.USERPROFILE, "AppData", "Local"));
  for (var i = 0; i < bases.length; i++) {
    var root = path.join(bases[i], "UOY", "Launcher", "current"), worker = path.join(root, "depth-engine", "engine.py"), python = path.join(root, "python", "python.exe");
    try {
      var pythonStat = fs.lstatSync(python);
      if (!pythonStat.isFile() || pythonStat.isSymbolicLink() || inspectWorker(worker, fs, path) !== PIPELINE) continue;
      // Data/model locations and every other machine-local option stay exact.
      result.worker = worker; result.python = python;
      return { config: result, migrated: true, pipeline: PIPELINE };
    } catch (_) {}
  }
  return { config: result, migrated: false, pipeline: detected };
}
module.exports = { select: select, inspectWorker: inspectWorker, pipeline: PIPELINE };
