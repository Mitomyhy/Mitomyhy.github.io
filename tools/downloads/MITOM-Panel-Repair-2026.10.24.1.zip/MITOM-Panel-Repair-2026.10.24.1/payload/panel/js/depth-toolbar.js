(function(win){
  "use strict";
  var doc=win.document,operation=null,operationId=0,product="acrylic",phase="",started=0,phaseStarted=0,timer=null,confirmed=0,visual=0,lastTick=0,lastMessage="",glossByProduct={},durations={capture:20,generate:120,template:20,import:15,render:15};
  var ranges={capture:[0,12],generate:[12,90],template:[90,99],import:[0,30],render:[30,99]},runtimeBusy=false,controlsLocked=false;
  try{var saved=JSON.parse(win.localStorage.getItem("uoyDepthPhaseSeconds")||"{}");Object.keys(durations).forEach(function(key){if(saved[key]>1&&saved[key]<3600)durations[key]=saved[key];});}catch(ignore){}
  function el(id){return doc.getElementById(id);}
  var gpuButton=doc.createElement("button"),cpuButton=el("tbGenerate");
  gpuButton.id="tbGenerateGPU";gpuButton.type="button";gpuButton.textContent="Generate GPU";
  gpuButton.title="NVIDIA CUDA · downloads GPU support once on first use";
  cpuButton.textContent="Generate CPU";
  var generateRow=doc.createElement("div"),mainRow=cpuButton.parentNode;
  generateRow.className="toolbar";generateRow.style.marginTop="3px";generateRow.setAttribute("aria-label","Generate device");
  mainRow.parentNode.insertBefore(generateRow,mainRow.nextSibling);generateRow.appendChild(cpuButton);generateRow.appendChild(gpuButton);
  function api(){var value=win.__uoyDepthMapUI;if(!value)throw new Error("Đang khởi động Depth runtime.");return value;}
  try{glossByProduct=JSON.parse(win.localStorage.getItem("uoyToolbarGloss")||"{}")||{};}catch(ignore){}
  function readGloss(){var n=Number(glossByProduct[product]);return isFinite(n)&&n>=0&&n<=100?n:50;}
  function showGloss(){el("tbGloss").value=String(readGloss());el("tbGlossValue").textContent=readGloss()+"%";}
  function updateControls(){var locked=controlsLocked||runtimeBusy||!!operation;["tbOpen","tbGenerate","tbGenerateGPU","tbLight","tbDark","tbText","tb3D","tbProduct","tbCustomText","tbGloss","tbPreviewClose"].forEach(function(id){el(id).disabled=locked;});}
  function controls(locked){controlsLocked=!!locked;updateControls();}
  function isBusy(){return !!operation||controlsLocked||runtimeBusy||!!(win.__uoyDepthMapUI&&api().toolbarBusy());}
  function resizePreview(expanded){
    // Adobe's bundled CSInterface.resizeContent forwards to this native API.
    // Docked hosts may ignore a resize; scrolling and manual resizing still work.
    var width=Math.max(430,Math.min(900,Number(win.innerWidth)||430)),height=expanded?Math.min(1000,Math.max(570,width+250)):120;
    try{if(win.__adobe_cep__&&typeof win.__adobe_cep__.resizeContent==="function")win.__adobe_cep__.resizeContent(width,height);}catch(ignore){}
  }
  function hidePreview(){
    var wasOpen=!el("tbPreview").hidden;
    el("tbPreview").hidden=true;el("dp3DPanel").hidden=true;doc.body.classList.remove("preview-open");
    if(win.__uoyDepthMapUI&&typeof api().toolbarHidePreview==="function")api().toolbarHidePreview();
    if(wasOpen)resizePreview(false);
  }
  function revealPreview(){
    if(el("dp3DPanel").hidden)throw new Error("Khung xem 3D chưa sẵn sàng. Bấm Xem 3D để thử lại.");
    el("tbPreview").hidden=false;doc.body.classList.add("preview-open");resizePreview(true);
    // The model was prepared while the wrapper was hidden. Re-measure only
    // after it has a real visible width, including hosts that ignore CEP resize.
    try{if(typeof win.Event==="function")win.dispatchEvent(new win.Event("resize"));}catch(ignore){}
  }
  el("tbPreview").appendChild(el("dp3DPanel"));
  resizePreview(false);
  el("dpMockupMain").hidden=true;
  // Keep the existing cancellable renderer control accessible while the
  // interactive viewer is hidden. Its own controller disables it at host import.
  el("tbProgressRow").appendChild(el("dpMockupCancel"));
  el("dpMockupCancel").className="";
  el("dpMockupCancel").textContent="Hủy xuất";
  el("dp3DGloss").parentNode.hidden=true;
  el("tbPreviewClose").onclick=function(){if(!isBusy())hidePreview();};
  function draw(){
    if(!operation)return;
    var now=Date.now(),dt=Math.min(.3,(now-lastTick)/1000),range=ranges[phase]||[0,99],elapsed=(now-phaseStarted)/1000;
    var estimate=range[0]+Math.max(0,range[1]-range[0]-.5)*(1-Math.exp(-elapsed/durations[phase]));
    var target=Math.min(99,Math.max(confirmed,estimate));visual=Math.min(target,visual+Math.max(.8,(target-visual)*2)*dt);lastTick=now;
    var seconds=Math.floor((now-started)/1000),clock=Math.floor(seconds/60)+":"+("0"+seconds%60).slice(-2);
    el("tbProgress").value=visual;el("tbPercent").textContent="~"+visual.toFixed(1)+"% · "+clock;
    el("tbPercent").title="Tiến độ ước tính liên tục; đã xác nhận "+confirmed.toFixed(1)+"%. Thời gian là thời gian chạy thực tế.";
    el("tbMessage").textContent=lastMessage||"Đang xử lý…";
  }
  function finish(message,error){
    var previewFailed=error&&operation==="preview";
    operation=null;if(timer!==null){clearInterval(timer);timer=null;}controls(false);el("tbProgressRow").className="";
    el("tbMessage").textContent=message;el("tbMessage").className=error?"error":"";
    if(error){if(previewFailed)hidePreview();el("tbProgressRow").hidden=true;return;}
    el("tbProgress").value=100;el("tbPercent").textContent="100%";setTimeout(function(){if(!operation)el("tbProgressRow").hidden=true;},1200);
  }
  function start(kind){
    if(isBusy())return false;operation=kind;operationId++;started=phaseStarted=lastTick=Date.now();confirmed=visual=0;
    el("tbMessage").className="";
    lastMessage=kind==="generate"?"Đang lấy toàn bộ In và tự tách chữ…":"Đang đọc depth hiện tại…";phase=kind==="generate"?"capture":"import";
    controls(true);el("tbProgressRow").hidden=false;el("tbProgressRow").className="running";timer=setInterval(draw,100);draw();return true;
  }
  function report(value){var range=ranges[phase]||[0,99];if(typeof value==="number"&&isFinite(value))confirmed=Math.max(confirmed,Math.min(99,range[0]+(range[1]-range[0])*value/100));}
  win.UOYDepthToolbar={
    busy:function(value){runtimeBusy=!!value;updateControls();},
    stage:function(value){
      if(value!==phase){var seconds=(Date.now()-phaseStarted)/1000;if(durations[phase]&&seconds>1){durations[phase]=durations[phase]*.7+seconds*.3;try{win.localStorage.setItem("uoyDepthPhaseSeconds",JSON.stringify(durations));}catch(ignore){}}
        phase=value;phaseStarted=Date.now();el("dpProgress").value=0;var range=ranges[value];if(range)confirmed=Math.max(confirmed,range[0]);}draw();
    },
    status:function(message,error){
      if(error){finish(String(message),true);return;}
      if(operation){lastMessage=String(message);if(phase==="render"){var frame=String(message).match(/(\d+)\/9\b/);if(frame)report(Number(frame[1])*100/9);}else report(Number(el("dpProgress").value));
      }else {el("tbMessage").className="";el("tbMessage").textContent=String(message);}
    }
  };
  function selectProduct(value){if(!value||value===product)return;product=value;el("tbProduct").value=value;api().switchProduct(value);showGloss();}
  function host(action,params,done){try{api().toolbarHost(action,params,function(error,value){if(error){finish(error.message,true);return;}selectProduct(value.product_type);done(value);});}catch(error){finish(error.message,true);}}
  el("tbOpen").onchange=function(){var selected=this.value;this.value="";if(!selected||isBusy())return;try{if(!api().toolbarReady())throw new Error("Runtime đang khởi động hoặc bận.");hidePreview();selectProduct(selected);controls(true);el("tbMessage").className="";api().toolbarOpen(function(){controls(false);el("tbMessage").className="";el("tbMessage").textContent="Đặt artwork và chữ vào In rồi Generate; tool tự tách chữ Type/Smart Object.";});}catch(error){finish(error.message,true);}};
  function generate(device){try{if(!api().toolbarReady())throw new Error("Runtime đang khởi động hoặc bận.");if(!start("generate"))return;hidePreview();api().toolbarGenerateDevice(device,function(){finish("Đã Generate "+(device==="cuda"?"GPU":"CPU")+" · giữ nguyên chữ, màu, effect và clipping. Vào Depth để đổi Nổi/Lõm.");});}catch(error){finish(error.message,true);}}
  el("tbGenerate").onclick=function(){generate("cpu");};
  el("tbGenerateGPU").onclick=function(){generate("cuda");};
  function fix(tool){if(isBusy())return;hidePreview();controls(true);el("tbMessage").className="";host("toolbar_fix_depth",{product_type:product,tool:tool},function(value){controls(false);el("tbMessage").className="";el("tbMessage").textContent="Tô "+(tool==="dodge"?"sáng":"tối")+" ngay trong tab này · "+(value.local_paint?"Brush 10%, layer Fix riêng.":"Midtones 10%.");});}
  el("tbLight").onclick=function(){fix("dodge");};el("tbDark").onclick=function(){fix("burn");};
  function effect(mode){if(isBusy())return;hidePreview();controls(true);el("tbMessage").className="";host("toolbar_effect_text",{product_type:product,mode:mode},function(value){controls(false);el("tbMessage").className="";el("tbMessage").textContent="Đã áp dụng "+(mode==="plain"?"Không effect · opacity 100%":mode==="raised"?"Nổi":"Lõm")+" cho "+value.count+" chữ ngay trong tab này.";});}
  el("tbText").onchange=function(){var mode=this.value;this.value="";if(mode==="raised"||mode==="recessed"||mode==="plain")effect(mode);};
  el("tbCustomText").onclick=function(){try{if(!api().toolbarReady())return;if(!start("text"))return;hidePreview();lastMessage="Đang cập nhật chữ In → Depth; giữ map và Fix…";host("toolbar_custom_text",{product_type:product},function(value){finish("Đã cập nhật "+value.updated_count+" chữ · giữ map, Fix và effect Depth. Ctrl+S để lưu PSD tổng.");});}catch(error){finish(error.message,true);}};
  el("tbGloss").oninput=function(){if(isBusy())return;glossByProduct[product]=Number(this.value);showGloss();try{api().toolbarSetGloss(readGloss());win.localStorage.setItem("uoyToolbarGloss",JSON.stringify(glossByProduct));}catch(error){el("tbMessage").textContent=error.message;} };
  showGloss();
  el("tb3D").onclick=function(){
    try{
      if(!api().toolbarReady())throw new Error("Runtime đang khởi động hoặc bận.");
      if(!start("preview"))return;
      var requestId=operationId;
      function current(){return operation==="preview"&&operationId===requestId;}
      hidePreview();
      host("toolbar_commit_depth",{product_type:product},function(live){
        if(!current())return;
        try{api().toolbarPreview(live,readGloss(),function(){
          if(!current())return;
          try{api().toolbarExportMain(function(error){
            if(!current())return;
            if(error){finish(error.message,true);return;}
            try{revealPreview();finish("Đã xuất 9 Main. Kéo xoay, chỉnh Nổi viền / Nổi bề mặt rồi xuất Góc đang xem → Photoshop.");}catch(failure){finish(failure.message,true);}
          });}catch(error){finish(error.message,true);}
        });}catch(error){finish(error.message,true);}
      });
    }catch(error){finish(error.message,true);}
  };
  win.addEventListener("beforeunload",function(){if(timer!==null)clearInterval(timer);});
})(window);
