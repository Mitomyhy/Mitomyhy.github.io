/* Resolve the installed uploader program without reading account credentials.
 * An older CAI_DAT installation may remain the configured upload directory
 * after the launcher installs the login-only API in its managed runtime. */
(function (factory) {
  "use strict";
  if (typeof module === "object" && module.exports) module.exports = factory();
})(function () {
  "use strict";
  function dependencies(options) {
    return { fs: options.fs || require("fs"), path: options.path || require("path") };
  }
  function safeDirectory(value, deps) {
    if (typeof value !== "string" || !value.trim() || /[\x00-\x1f\x7f"<>|?*]/.test(value) || !deps.path.isAbsolute(value)) return "";
    return deps.path.resolve(value.trim());
  }
  function regularFile(file, deps) {
    try { var stat = deps.fs.lstatSync(file); return stat.isFile() && !stat.isSymbolicLink(); }
    catch (_) { return false; }
  }
  function hasLogin(directory, deps) {
    return !!directory && regularFile(deps.path.join(directory, "run_login.vbs"), deps) &&
      regularFile(deps.path.join(directory, "upload_he_thong.py"), deps);
  }
  function managedDirectory(options, deps) {
    var root = safeDirectory(options.localRoot, deps);
    return root ? deps.path.join(root, "Launcher", "current", "upload-tool") : "";
  }
  function sameDirectory(a, b, deps) { return !!a && !!b && deps.path.resolve(a).toLowerCase() === deps.path.resolve(b).toLowerCase(); }
  function resolveUploaderDirectory(options) {
    options = options || {};
    var deps = dependencies(options), current = safeDirectory(options.configuredDir, deps), root = safeDirectory(options.localRoot, deps);
    var managed = managedDirectory(options, deps);
    // Migrate only the two known old installer locations, never a custom
    // uploader chosen by an operator. Account files and pending jobs stay put.
    var legacy = root && (sameDirectory(current, deps.path.join(root, "UploadHeThong"), deps) || sameDirectory(current, deps.path.join(root, "Upload He Thong"), deps));
    if (legacy && !hasLogin(current, deps) && hasLogin(managed, deps) && regularFile(deps.path.join(managed, "run_upload.vbs"), deps)) return managed;
    return current || options.configuredDir || "";
  }
  function resolveLoginRuntime(options) {
    options = options || {};
    var deps = dependencies(options), current = safeDirectory(options.configuredDir, deps), managed = managedDirectory(options, deps);
    var candidates = [current, managed];
    for (var i = 0; i < candidates.length; i++) {
      if (hasLogin(candidates[i], deps)) return { directory: candidates[i], script: deps.path.join(candidates[i], "run_login.vbs") };
    }
    var error = new Error("Chưa tìm thấy trình đăng nhập của uploader. Mở MITOM Launcher và chọn Cài / Cập nhật panel để sửa bộ công cụ, sau đó thử Đăng nhập hệ thống lại. Ghép nối Base và các đơn đang chờ vẫn được giữ.");
    error.code = "LOGIN_RUNTIME_MISSING";
    throw error;
  }
  return { resolveUploaderDirectory: resolveUploaderDirectory, resolveLoginRuntime: resolveLoginRuntime };
});
