"""Bounded, offline DA2 preview; deliberately separate from full MoGe Generate.

One bounded 1024-square DA2 Small pass supplies relative scene geometry. Source
marks contribute only the same shallow detail layer used by full Generate.
No network access, checkpoint download, or replacement of the input job.
"""
from datetime import datetime, timezone
import time
import uuid

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter

import da2_backend
import depth_math
import fullprint_prepare as fp
import fullprint_commands as commands
import ceramic_product as product
from png_resolution import normalize_dpi, save_png

INPUT_SIZE = 1024
PREVIEW_REVISION = 2
DEPTH_KIND = "local-ai-preview"
WARNING = ("Fast local AI preview v2: one bounded 1024px Depth Anything V2 Small pass, "
           "plus shallow source-print detail. This is relative relief, not measured "
           "geometry and not the full MoGe + DA2 Generate result. Normals are derived "
           "from the preview height, not inferred MoGe surface normals.")


def _current(engine, params):
    if (not isinstance(params, dict) or set(params) - {"job_id", "version", "fullprint"}
            or not {"job_id", "version"} <= set(params)):
        raise ValueError("AI preview requires job_id, version and optional fullprint controls.")
    folder, metadata, _, _ = engine._temp_jobs().inspect(params["job_id"])
    from text_layer_commands import require_plain, validate_snapshot
    require_plain(metadata or {})
    product.is_shared_pipeline(metadata or {})
    validate_snapshot(engine, folder, metadata or {})
    version = params["version"]
    if (not isinstance(version, int) or isinstance(version, bool) or version < 1
            or not metadata or metadata.get("version") != version):
        raise ValueError("The depth changed. Reload before preparing the AI preview.")
    kind = metadata.get("depth_kind")
    revision = metadata.get("preview_revision", 1)
    old_preview = (kind == DEPTH_KIND and metadata.get("preview_ai") is True
                   and isinstance(revision, int) and not isinstance(revision, bool)
                   and revision in (0, 1))
    if kind != "source-relief-estimate" and not old_preview:
        raise ValueError("This result already has AI geometry; reuse its cached 3D view.")
    return folder, metadata


def _manual_delta(folder, metadata, rgba):
    """Retain actual retouch strokes, excluding existing support/text controls."""
    from depth_edit import read_height
    current = read_height(folder / metadata["depth_file"], metadata["width"], metadata["height"])
    name = metadata.get("fullprint_base_file")
    if name not in commands.BASE_FILES:
        raise ValueError("The source preview has no safe fullprint baseline.")
    base = np.load(folder / name, allow_pickle=False)
    if (base.shape != current.shape or not np.isfinite(base).all()
            or base.min() < 0 or base.max() > 1):
        raise ValueError("The source preview baseline is invalid.")
    composed, _, _ = commands.previous_for_job(folder, metadata, base, rgba)
    previous = np.rint(composed * 65535).astype(np.float32) / 65535
    alpha = product.validate_shape(folder, metadata) if product.is_ceramic(metadata) else rgba[..., 3]
    return np.where(alpha > 0, current - previous, 0).astype(np.float32)


def restore_preview(small_height, valid, rgba):
    """Smooth single-pixel model noise, not source texture or the silhouette."""
    small_height = np.asarray(small_height, np.float32)
    valid = np.asarray(valid, bool)
    if (small_height.ndim != 2 or valid.shape != small_height.shape
            or not valid.any() or not np.isfinite(small_height[valid]).all()
            or small_height[valid].min() < 0 or small_height[valid].max() > 1):
        raise ValueError("AI preview returned invalid relative heights.")
    weights = gaussian_filter(valid.astype(np.float32), .45)
    smooth = gaussian_filter(np.where(valid, small_height, 0), .45) / np.maximum(weights, 1e-6)
    # Preserve a useful raised interval without clipping the near/far endpoints
    # to literal white/black. This remains a visual normalization, not mm.
    smooth = np.where(valid, .12 + .80 * np.clip(smooth, 0, 1), 0).astype(np.float32)
    # Compress only statistically dominant broad planar drift, without source
    # colour input or sharpening. This artistic guard is deliberately inactive
    # on ordinary non-planar object geometry; its confidence is reported.
    from relief_balance import balance_relief_plane
    smooth, balance = balance_relief_plane(smooth, valid, flatten=.45)
    height, restored_valid = depth_math.restore_height(smooth, valid, (rgba.shape[1], rgba.shape[0]))
    height, visible, alpha_info = fp.canonical_height(height, restored_valid, rgba[..., 3])
    from fullprint_detail import apply_fullprint_detail
    height, source_info = apply_fullprint_detail(height, rgba[..., :3], visible,
                                               source_detail=1., mode="ornament")
    return height, visible, dict(method="offline-da2-small-preview-v2", physical_depth_claim=False,
                                input_size=INPUT_SIZE, native_source_detail=source_info,
                                alpha=alpha_info, pre_balance_interval=[.12, .92],
                                broad_height_balance=balance, preview_revision=PREVIEW_REVISION)


def preview(engine, params):
    source_folder, previous = _current(engine, params)
    settings = product.options(
        params.get("fullprint", previous.get("fullprint")),
        previous.get("product_type", "acrylic"), generation_pipeline=product.ACRYLIC_COMPOSITION_PIPELINE)
    rgba = commands.source_rgba(source_folder, previous)
    dpi = normalize_dpi(previous.get("dpi"))
    alpha = rgba[..., 3]
    manual_delta = _manual_delta(source_folder, previous, rgba)
    started = time.monotonic()
    engine.progress(5, "Preparing fast local AI geometry v2 (DA2 Small, one 1024px pass).")
    rgb, valid, preparation = da2_backend.prepare_rgba(rgba, max_side=INPUT_SIZE, background=127)
    model = engine._load_da2()
    engine.progress(25, "Inferring relative product relief locally; full MoGe Generate is not running.")
    with engine._torch_runtime().inference_mode():
        small_height, inference = da2_backend.infer_height(model, rgb, valid, input_size=INPUT_SIZE)
    engine.progress(72, "Restoring source-size relief and shallow printed details.")
    base, visible, processing = restore_preview(small_height, valid, rgba)
    # Even if an external editor changed metadata while the model ran, never
    # attach this result to a different source/version or overwrite that edit.
    _current(engine, params)
    job_id = uuid.uuid4().hex
    folder = engine._temp_jobs().create(job_id)
    try:
        product.mark_slot(folder, previous.get("product_type", "acrylic"))
        product_capture = product.copy_shape(source_folder, folder, previous)
        save_png(Image.fromarray(rgba, "RGBA"), folder / "source.png", dpi)
        from text_layer_commands import copy_capture
        text_capture = copy_capture(source_folder, folder, previous)
        save_png(Image.fromarray(alpha), folder / "alpha.png", dpi)
        np.save(folder / "base-height.npy", base, allow_pickle=False)
        np.save(folder / "valid.npy", visible, allow_pickle=False)
        save_png(Image.fromarray(fp.approximate_normal(base, alpha), "RGB"), folder / "normal.png", dpi)
        mask_file, mask = previous.get("mask_file"), None
        if mask_file:
            # inspect() already validates a same-job, owned mask filename.
            with Image.open(source_folder / mask_file) as image:
                if image.size != (previous["width"], previous["height"]):
                    raise ValueError("Saved selection dimensions disagree with the fullprint.")
                mask = np.asarray(image.convert("L")) > 0
                save_png(image, folder / mask_file, dpi)
        metadata = dict(job_id=job_id, width=previous["width"], height=previous["height"], dpi=dpi,
            inference_width=rgb.shape[1], inference_height=rgb.shape[0],
            model=da2_backend.MODEL_ID, device=engine.device, version=0,
            invert=previous.get("invert", False), strength=previous.get("strength", 0.),
            feather=previous.get("feather", 0.), mask_file=mask_file,
            warning=WARNING, estimate=False, depth_kind=DEPTH_KIND, preview_ai=True,
            preview_revision=PREVIEW_REVISION,
            normal_source="analytic-da2-relative-height", relief_mode="depth",
            source_name=previous.get("source_name", "fullprint.png"),
            created_utc=datetime.now(timezone.utc).isoformat(), fullprint=settings,
            temporary_session=False, quality=DEPTH_KIND, local_detail=False,
            alpha_policy="original-fullprint-alpha", fullprint_alpha=processing["alpha"],
            preview_inference=dict(inference, preparation=preparation,
                                   elapsed_seconds=round(time.monotonic() - started, 3)),
            relief_processing=processing, preview_parent_job=previous["job_id"],
            preview_parent_version=previous["version"])
        metadata.update(text_capture)
        metadata.update(product_capture)
        # Explicit preview creates a new shared-policy job; the source job and
        # its recorded recipe remain unchanged, including legacy manual delta.
        metadata["generation_pipeline"] = product.ACRYLIC_COMPOSITION_PIPELINE
        relief = depth_math.apply_relief(base, visible, alpha, mask, metadata["strength"],
                                         metadata["feather"], metadata["invert"])
        result = commands.publish_layer(engine, folder, metadata, relief, manual_delta=manual_delta)
        engine._current_job_id = job_id
        return result
    except BaseException:
        # The original PNG, original preview, edits and controls are never in
        # this new job. Only a failed, owned candidate can be discarded.
        engine._discard_failed_job(job_id)
        raise
