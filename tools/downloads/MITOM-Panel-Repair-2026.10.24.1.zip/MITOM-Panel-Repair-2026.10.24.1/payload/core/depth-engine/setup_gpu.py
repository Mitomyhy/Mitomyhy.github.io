"""Optional isolated NVIDIA runtime. CPU Python, models and panel settings stay intact."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import urllib.request

WHEELS = (
    'https://download-r2.pytorch.org/whl/cu128/torch-2.7.1%2Bcu128-cp312-cp312-win_amd64.whl#sha256=2bb8c05d48ba815b316879a18195d53a6472a03e297d971e916753f8e1053d30',
    'https://download-r2.pytorch.org/whl/cu128/torchvision-0.22.1%2Bcu128-cp312-cp312-win_amd64.whl#sha256=650561ba326d21021243f5e064133dc62dc64d52f79623db5cd76637a9665f96',
)
PIP_URL = 'https://files.pythonhosted.org/packages/29/a2/d40fb2460e883eca5199c62cfc2463fd261f760556ae6290f88488c362c0/pip-25.1.1-py3-none-any.whl'
PIP_SHA256 = '2913a38a2abf4ea6b64ab507bd9e967f3b53dc1ede74b01b0931e1ce548751af'

def report(message):
    print(json.dumps({'message': str(message)}, ensure_ascii=False), flush=True)

def checked(path):
    path = Path(path).absolute()
    if str(path).startswith('\\\\'):
        raise ValueError('GPU runtime must be on a local disk.')
    for item in (path, *path.parents):
        if item.exists() or item.is_symlink():
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                raise ValueError('GPU runtime path contains a link or junction.')
    return path

def run(args):
    process = subprocess.Popen([str(x) for x in args], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        encoding='utf-8', errors='replace', shell=False,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    for line in process.stdout:
        report(line.rstrip()[:500])
    if process.wait():
        raise RuntimeError('GPU support installation failed. CPU support is unchanged; retry Generate GPU later.')

def install(target):
    if sys.platform != 'win32' or sys.version_info[:2] != (3, 12):
        raise RuntimeError('This optional GPU package supports Windows x64 Python 3.12.')
    smi = Path(os.environ.get('SystemRoot', 'C:/Windows')) / 'System32/nvidia-smi.exe'
    if not smi.is_file():
        raise RuntimeError('No NVIDIA CUDA driver was found. Generate CPU remains available.')
    probe = subprocess.run([str(smi), '--query-gpu=name', '--format=csv,noheader'],
        capture_output=True, text=True, timeout=20, shell=False,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if probe.returncode or not probe.stdout.strip():
        raise RuntimeError('NVIDIA GPU is unavailable. Install its driver or use Generate CPU.')
    target = checked(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(target.parent).free < 9 * 1024**3:
        raise RuntimeError('GPU support needs at least 9 GB of free disk space during installation.')
    python = target / 'Scripts/python.exe'
    report('Preparing separate NVIDIA runtime for ' + probe.stdout.strip())
    # Inherit the existing verified MoGe/DA2 dependencies; only torch/vision are
    # shadowed by GPU wheels in this venv. Never replace the CPU installation.
    if not python.is_file() or not (target / 'mitom-gpu-ready.json').is_file():
        run([sys.executable, '-m', 'venv', '--without-pip', '--system-site-packages', target])
    # The launcher carries a portable Python without ensurepip/pip. Run an
    # official hash-pinned pip wheel only inside this optional environment.
    bootstrap = target / 'mitom-bootstrap'
    bootstrap.mkdir(exist_ok=True)
    pip_wheel = bootstrap / 'pip-25.1.1-py3-none-any.whl'
    if not pip_wheel.is_file() or hashlib.sha256(pip_wheel.read_bytes()).hexdigest() != PIP_SHA256:
        report('Downloading verified installer helper.')
        with urllib.request.urlopen(PIP_URL, timeout=60) as response:
            data = response.read(3 * 1024**2)
        if hashlib.sha256(data).hexdigest() != PIP_SHA256:
            raise RuntimeError('GPU installer helper checksum mismatch.')
        pip_wheel.write_bytes(data)
    report('Downloading NVIDIA support once (approximately 3 GB).')
    run([python, '-c', "import runpy,sys;sys.path.insert(0,sys.argv.pop(1));runpy.run_module('pip',run_name='__main__')", pip_wheel,
        'install', '--no-deps', '--no-cache-dir', '--only-binary=:all:', *WHEELS])
    run([python, '-c', "import torch,torchvision; assert torch.__version__=='2.7.1+cu128'; assert torchvision.__version__=='0.22.1+cu128'; assert torch.cuda.is_available(), 'CUDA driver or GPU is unavailable'; x=torch.ones((8,8),device='cuda'); assert float((x@x).sum())==512; torch.cuda.synchronize(); print('CUDA ready: '+torch.cuda.get_device_name(0))"])
    (target / 'mitom-gpu-ready.json').write_text(json.dumps({'schema': 1, 'torch': '2.7.1+cu128',
        'torchvision': '0.22.1+cu128', 'python': str(python)}, indent=2), 'utf-8')
    report('GPU support is ready.')
    return python

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--target', default=str(Path(os.environ['LOCALAPPDATA']) / 'UOY/DepthGPU'))
    args = parser.parse_args()
    try:
        install(args.target)
    except Exception as exc:
        report(str(exc))
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
