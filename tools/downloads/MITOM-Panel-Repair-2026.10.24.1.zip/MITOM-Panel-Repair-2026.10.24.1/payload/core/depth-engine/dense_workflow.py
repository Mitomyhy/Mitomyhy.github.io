"""Offline native-resolution artistic detail; no web service or RGB bump maps."""
import json
import re
import uuid

import numpy as np
from PIL import Image

import depth_math as dm

DENSE_CACHE_VERSION = "native-hd-confidence-v1"


def load_dense_correction(folder, metadata):
    if metadata.get("dense_refinement", {}).get("cache_version") != DENSE_CACHE_VERSION:
        raise ValueError("HD cache uses an older method. Run AI local HD again; previous PNG is preserved.")
    name = metadata.get("dense_correction_file", "")
    if not isinstance(name, str) or not re.fullmatch(r"dense-[a-f0-9]{12}/micro\.npy", name):
        raise ValueError("No native HD detail cache. Run AI local HD first.")
    path = (folder / name).resolve()
    if not path.is_relative_to(folder.resolve()):
        raise ValueError("HD detail must remain inside this job.")
    micro = np.load(path, allow_pickle=False)
    size = dm.fit_size(metadata["width"], metadata["height"], 2560)
    if micro.shape != (size[1], size[0]) or not np.isfinite(micro).all() or np.max(np.abs(micro)) > .241:
        raise ValueError("Native HD detail cache is invalid; previous PNG was preserved.")
    return micro, path


def restore_dense_detail(micro, valid):
    if micro.shape == valid.shape:
        return np.where(valid, micro, 0).astype(np.float32)
    small_valid = np.asarray(Image.fromarray(valid.astype(np.uint8)).resize(
        (micro.shape[1], micro.shape[0]), Image.Resampling.NEAREST)) > 0
    weights = dm.resize_float(small_valid.astype(np.float32), (valid.shape[1], valid.shape[0]))
    numerator = dm.resize_float(np.where(small_valid, micro, 0), (valid.shape[1], valid.shape[0]))
    restored = np.divide(numerator, weights, out=np.zeros_like(numerator), where=weights > 1e-6)
    return np.where(valid, restored, 0).astype(np.float32)


def refine_dense(engine, params):
    from dense_detail import plan_dense_tiles, DenseDetailAccumulator
    folder, metadata = engine._job(params.get("job_id"))
    engine._adjust_options(metadata, params)
    if metadata["relief_mode"] != "ornament":
        raise ValueError("Choose Relief Ornament before AI local HD.")
    base, valid, alpha = engine._arrays(folder)
    if (metadata.get("dense_refinement", {}).get("available")
            and metadata["dense_refinement"].get("cache_version") == DENSE_CACHE_VERSION):
        load_dense_correction(folder, metadata)
        metadata.update(local_detail=True, local_refinement=metadata["dense_refinement"].copy())
        return engine._export(folder, metadata, base, valid, alpha)
    with Image.open(folder / "source.png") as opened:
        rgba = opened.convert("RGBA")
    if rgba.size != (metadata["width"], metadata["height"]):
        raise ValueError("Source snapshot dimensions do not match the selected job.")
    size = dm.fit_size(*rgba.size, 2560)
    # Composite before reduction to avoid hidden transparent RGB contaminating edges.
    rgb = Image.alpha_composite(Image.new("RGBA", rgba.size, (170, 170, 170, 255)), rgba).convert("RGB")
    rgb = rgb.resize(size, Image.Resampling.LANCZOS)
    native_valid = np.asarray(rgba.getchannel("A").resize(size, Image.Resampling.NEAREST)) > 127
    native_valid &= np.asarray(Image.fromarray(valid.astype(np.uint8)).resize(size, Image.Resampling.NEAREST)) > 0
    boxes = plan_dense_tiles(native_valid)
    if not boxes:
        raise ValueError("Visible source is too small for HD refinement.")
    if any(min(b[2]-b[0],b[3]-b[1]) < 64 or max(b[2]-b[0],b[3]-b[1]) > 2*min(b[2]-b[0],b[3]-b[1]) for b in boxes):
        raise ValueError("HD refinement needs crop aspect ratios between 1:2 and 2:1, at least 64px per edge.")
    model, torch = engine._load_moge(), engine._torch_runtime()
    tokens = 2500 if metadata.get("quality") == "ultra" else 1800
    name = "dense-" + uuid.uuid4().hex[:12]
    cache = folder / name
    cache.mkdir(exist_ok=False)
    tiles = []
    for index, box in enumerate(boxes):
        engine.progress(15 + round(55 * index / len(boxes)),
            f"AI local HD: reading region {index+1}/{len(boxes)} at native detail resolution.")
        crop = np.asarray(rgb.crop(box), np.float32).copy() / 255
        tensor = torch.from_numpy(crop).permute(2, 0, 1).unsqueeze(0).to(engine.device)
        with torch.inference_mode():
            output = model(tensor, num_tokens=tokens)
        if not all(key in output for key in ("points", "normal", "mask")):
            raise RuntimeError("MoGe did not return HD geometry; previous PNG was preserved.")
        arrays = {key: output[key].detach().cpu().numpy().copy() for key in ("points", "normal", "mask")}
        del output, tensor
        h, w = crop.shape[:2]
        if (arrays["points"].shape != (1, h, w, 3) or arrays["normal"].shape != (1, h, w, 3)
                or arrays["mask"].shape != (1, h, w)):
            raise RuntimeError("MoGe HD dimensions are invalid; previous PNG was preserved.")
        x0, y0, x1, y1 = box
        tile = dict(box=box, z=arrays["points"][0, ..., 2], normal=arrays["normal"][0],
                    reliability=arrays["mask"][0], valid=native_valid[y0:y1, x0:x1])
        for key in ("z", "normal", "reliability"):
            np.save(cache / f"tile-{index}-{key}.npy", tile[key], allow_pickle=False)
        tiles.append(tile)
    accumulator = DenseDetailAccumulator(native_valid)
    for index, tile in enumerate(tiles):
        engine.progress(74 + round(10 * index / len(tiles)),
            f"Integrating HD surface {index+1}/{len(tiles)}; preserving silhouette and holes.")
        accumulator.add(tile)
    micro, fusion = accumulator.finish()
    if not fusion.get("accepted_tiles"):
        raise RuntimeError("No reliable HD geometry recovered; previous PNG was preserved.")
    np.save(cache / "micro.npy", micro, allow_pickle=False)
    with (cache / "fusion.json").open("w", encoding="utf-8") as handle:
        json.dump(fusion, handle, indent=2, allow_nan=False)
    info = dict(available=True, profile="dense", cache_version=DENSE_CACHE_VERSION, algorithm=fusion["algorithm"],
                accepted_tiles=fusion["accepted_tiles"], tile_count=len(tiles),
                num_tokens_per_tile=tokens, detail_width=size[0], detail_height=size[1],
                coverage_fraction=fusion.get("coverage_fraction", 0),
                warning="Artistic native detail from local AI; not measured depth or guaranteed SculptOK match.")
    metadata.update(dense_correction_file=name + "/micro.npy", dense_refinement=info,
                    local_detail=True, local_refinement=info.copy())
    engine._relief_cache = None
    return engine._export(folder, metadata, base, valid, alpha)
