param(
    [string]$PanelRoot = '',
    [switch]$CheckOnly,
    [string]$Rollback = '',
    [switch]$LibraryOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:MitmRevision = '20261029-R78'
$script:MitmBaselinePins = @{
    'js/save-task-flow.js' = '1f1640873fc4ea470e0522c57f625778f5d6fd05534ec84659d35d01877c880c'
}
$script:MitmDependencyPins = @{
    'js/save-task-remote.py' = '8ea1971b1b13646a570030cd9bc79dc32107fe3e7c388cb67b626c76b657ff4b'
    'jsx/save-task-active.jsx' = '7e7e9b4dd9927378812ca1e0ac3f98fb3f7cbdbf59c391d9107a8fba0821c3f1'
}
# The builder replaces exactly this line after an independent source-pin review.
$script:MitmTargetPins = @{
    'js/save-task-flow.js' = '58a1539fbd98f4a1528707e230b719fc4228e011be036768c4845d5c50523bdf'
}

function Get-MitmHash([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Assert-MitmPlainPath([string]$Path, [string]$Kind = 'File') {
    $full = [IO.Path]::GetFullPath($Path)
    if (-not [IO.Path]::IsPathRooted($Path) -or $full.StartsWith('\\')) { throw 'A local absolute path is required.' }
    $cursor = $full
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Linked path refused: ' + $cursor) }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
    if ($Kind -eq 'File' -and -not (Test-Path -LiteralPath $full -PathType Leaf)) { throw ('Missing regular file: ' + $full) }
    if ($Kind -eq 'Directory' -and -not (Test-Path -LiteralPath $full -PathType Container)) { throw ('Missing directory: ' + $full) }
    return $full
}

function Get-MitmPanelRoot([string]$Requested) {
    if (-not $Requested) {
        if (-not $env:APPDATA) { throw 'APPDATA is unavailable; no default Panel location can be selected.' }
        $Requested = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.uoy.orderpanel'
    }
    $full = Assert-MitmPlainPath $Requested 'Directory'
    if ([IO.Path]::GetFileName($full.TrimEnd('\')) -ne 'com.uoy.orderpanel') { throw 'The target directory must be the existing com.uoy.orderpanel folder.' }
    [void](Assert-MitmPlainPath (Join-Path $full 'js') 'Directory')
    return $full
}

function Assert-MitmAppsClosed {
    $busy = @(Get-Process -ErrorAction Stop | Where-Object {
        $_.ProcessName -match '^(Photoshop|OrderStudio|UOY[-_ ]?OrderStudio|MITOM[-_ ]?OrderStudio)$'
    })
    if ($busy.Count) { throw 'Save your work and close Photoshop and OrderStudio yourself, then retry. This installer never closes them.' }
}

function Assert-MitmDependencies([string]$Target) {
    foreach ($relative in $script:MitmDependencyPins.Keys) {
        $file = Assert-MitmPlainPath (Join-Path $Target $relative.Replace('/', '\'))
        if ((Get-MitmHash $file) -cne $script:MitmDependencyPins[$relative]) {
            throw ('Required existing R76/R12 dependency differs; preserved: ' + $relative + '. Use the full matching managed update first.')
        }
    }
    # main.js is not part of this patch. Remember its bytes to detect concurrent
    # changes without replacing R77 Save Fix/Night Light or other panel work.
    return Get-MitmHash (Assert-MitmPlainPath (Join-Path $Target 'js\main.js'))
}

function Assert-MitmMainUnchanged([string]$Target, [string]$Expected) {
    if ((Get-MitmHash (Assert-MitmPlainPath (Join-Path $Target 'js\main.js'))) -cne $Expected) { throw 'main.js changed concurrently; this patch never replaces it.' }
}

function Assert-MitmNoR78Receipts([string]$ReceiptRoot = '') {
    if (-not $ReceiptRoot) {
        if (-not $env:USERPROFILE) { throw 'Cannot verify Save Task receipt compatibility; rollback refused.' }
        $ReceiptRoot = Join-Path $env:USERPROFILE '.huong_tool\save_task_incremental_r9'
    }
    $root = Assert-MitmPlainPath $ReceiptRoot 'Any'
    if (-not (Test-Path -LiteralPath $root)) { return }
    [void](Assert-MitmPlainPath $root 'Directory')
    $folders = @(Get-ChildItem -LiteralPath $root -Force -Directory)
    if ($folders.Count -gt 10000) { throw 'Too many receipt folders to verify safely; rollback refused.' }
    foreach ($folder in $folders) {
        if ($folder.Name -cnotmatch '^[0-9a-f]{64}$') { continue }
        [void](Assert-MitmPlainPath $folder.FullName 'Directory')
        $receipt = Join-Path $folder.FullName 'state.json'
        if (-not (Test-Path -LiteralPath $receipt)) { continue }
        $file = Assert-MitmPlainPath $receipt
        if ((Get-Item -LiteralPath $file).Length -gt 8388608) { throw 'Receipt exceeds safe inspection limit; rollback refused.' }
        try { $state = [IO.File]::ReadAllText($file) | ConvertFrom-Json }
        catch { throw 'A Save Task receipt cannot be verified; rollback refused without modifying it.' }
        if ($null -eq $state -or -not $state.PSObject.Properties['version']) { throw 'Unknown Save Task receipt schema; rollback refused.' }
        if ($state.version -ne 9) {
            throw 'R78 version 10/newer Save Task receipts may exist. R76 cannot read them; rollback refused. Keep receipts, exports and backup. Reinstall R78 and use its explicit Retry/reconciliation; do not delete or downgrade queue state.'
        }
    }
}

function Get-MitmManifest([string]$PackageRoot) {
    if ($null -eq $script:MitmTargetPins -or $script:MitmTargetPins.Count -ne 1) { throw 'Unsealed installer: reviewed target pins have not been embedded.' }
    $root = Assert-MitmPlainPath $PackageRoot 'Directory'
    $manifestPath = Assert-MitmPlainPath (Join-Path $root 'patch-manifest.json')
    $manifest = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    if ($manifest.schema -ne 1 -or $manifest.revision -ne $script:MitmRevision) { throw 'Package identity differs.' }
    $rows = @($manifest.files)
    if ($rows.Count -ne 1 -or @($rows.path | Select-Object -Unique).Count -ne 1) { throw 'The package must contain exactly one unique file record.' }
    foreach ($row in $rows) {
        if (-not $script:MitmBaselinePins.ContainsKey([string]$row.path) -or -not $script:MitmTargetPins.ContainsKey([string]$row.path)) { throw 'Unexpected payload path.' }
        if ($row.before_sha256 -cne $script:MitmBaselinePins[$row.path] -or $row.sha256 -cne $script:MitmTargetPins[$row.path]) { throw 'Package hash policy differs from the sealed installer.' }
        if ([string]$row.sha256 -cnotmatch '^[0-9a-f]{64}$' -or $row.size -le 0 -or $row.size -gt 2097152 -or $row.size -isnot [ValueType]) { throw 'Invalid payload metadata.' }
        $payload = Assert-MitmPlainPath (Join-Path $root ('payload\' + $row.path.Replace('/', '\')))
        if ((Get-Item -LiteralPath $payload).Length -ne $row.size -or (Get-MitmHash $payload) -cne $row.sha256) { throw ('Payload hash or size differs: ' + $row.path) }
    }
    return $rows
}

function Get-MitmDiskState([string]$Target, $Rows) {
    $states = @()
    foreach ($row in $Rows) {
        $file = Assert-MitmPlainPath (Join-Path $Target $row.path.Replace('/', '\'))
        $hash = Get-MitmHash $file
        if ($hash -ceq $row.before_sha256) { $states += 'before' }
        elseif ($hash -ceq $row.sha256) { $states += 'after' }
        else { throw ('Unknown or locally modified file preserved: ' + $row.path) }
    }
    if (@($states | Select-Object -Unique).Count -ne 1) { throw 'Mixed original/updated files were preserved. Use the matching backup rollback or the full managed update; no files changed.' }
    return $states[0]
}

function Copy-MitmVerified([string]$Source, [string]$Destination, [string]$Expected) {
    [void](Assert-MitmPlainPath $Source)
    [void](Assert-MitmPlainPath ([IO.Path]::GetDirectoryName($Destination)) 'Directory')
    if (Test-Path -LiteralPath $Destination) { throw 'Backup/stage destination already exists.' }
    [IO.File]::Copy($Source, $Destination, $false)
    if ((Get-MitmHash $Destination) -cne $Expected -or (Get-MitmHash $Source) -cne $Expected) { throw 'Source changed while copying; preserved transaction backup for inspection.' }
}

function Set-MitmAtomicFile([string]$Source, [string]$Destination) {
    # Source lives below the same Panel root, so replacement stays on one volume.
    # Windows PowerShell 5.1 otherwise marshals $null to an invalid empty path.
    [IO.File]::Replace($Source, $Destination, [System.Management.Automation.Language.NullString]::Value, $true)
}

function Write-MitmJournal([string]$Path, $Value) {
    $json = $Value | ConvertTo-Json -Depth 8
    [IO.File]::WriteAllText($Path, $json + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
}

function Restore-MitmOwnedFiles([string]$Target, [string]$Backup, $Rows, [switch]$BestEffort) {
    $failures = @()
    # Explicit rollback preflights everything before changing anything.
    foreach ($row in $Rows) {
        $original = Assert-MitmPlainPath (Join-Path $Backup ('original\' + [IO.Path]::GetFileName($row.path)))
        if ((Get-MitmHash $original) -cne $row.before_sha256) { throw 'Backup original hash differs; rollback refused.' }
        $dest = Assert-MitmPlainPath (Join-Path $Target $row.path.Replace('/', '\'))
        $actual = Get-MitmHash $dest
        if ($actual -cne $row.sha256 -and $actual -cne $row.before_sha256) {
            if (-not $BestEffort) { throw ('Rollback preserves an unknown concurrent change: ' + $row.path) }
            $failures += $row.path
        }
    }
    $reverseRows = @($Rows)
    [array]::Reverse($reverseRows)
    foreach ($row in $reverseRows) {
        if ($failures -contains $row.path) { continue }
        try {
            $dest = Assert-MitmPlainPath (Join-Path $Target $row.path.Replace('/', '\'))
            $actual = Get-MitmHash $dest
            if ($actual -ceq $row.before_sha256) { continue }
            if ($actual -cne $row.sha256) { throw 'Rollback compare-and-swap precondition changed.' }
            $restore = Join-Path $Backup ('restore-' + [guid]::NewGuid().ToString('N') + '-' + [IO.Path]::GetFileName($row.path))
            Copy-MitmVerified (Join-Path $Backup ('original\' + [IO.Path]::GetFileName($row.path))) $restore $row.before_sha256
            [void](Assert-MitmPlainPath $dest)
            if ((Get-MitmHash $dest) -cne $row.sha256) { throw 'Rollback compare-and-swap precondition changed.' }
            Set-MitmAtomicFile $restore $dest
            if ((Get-MitmHash $dest) -cne $row.before_sha256) { throw 'Rollback output verification failed.' }
        } catch {
            if (-not $BestEffort) { throw }
            $failures += $row.path
        }
    }
    if ($failures.Count) { throw ('Rollback left concurrent/unknown bytes untouched in: ' + ($failures -join ', ') + '. Keep backup: ' + $Backup) }
}

function Invoke-MitmUpdate([string]$PackageRoot, [string]$RequestedRoot = '', [switch]$OnlyCheck) {
    $rows = @(Get-MitmManifest $PackageRoot)
    $target = Get-MitmPanelRoot $RequestedRoot
    $mainPin = Assert-MitmDependencies $target
    $state = Get-MitmDiskState $target $rows
    if ($state -eq 'after') { return @{ status = 'already_installed'; changed = 0; panel_root = $target } }
    if ($OnlyCheck) { return @{ status = 'ready'; changed = 0; would_change = 1; panel_root = $target; apps_must_be_closed_for_install = $true; main_sha256 = $mainPin } }
    Assert-MitmAppsClosed
    $lockPath = Join-Path $target '.mitom-save-task-R78.lock'
    [void](Assert-MitmPlainPath $lockPath 'Any')
    $lock = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $backup = ''
    $journal = $null
    try {
        Assert-MitmAppsClosed
        [void](Assert-MitmDependencies $target)
        Assert-MitmMainUnchanged $target $mainPin
        if ((Get-MitmDiskState $target $rows) -ne 'before') { throw 'Preimage changed before acquiring the update lock.' }
        $parent = Join-Path $target '.mitom-save-task-backups'
        [void](Assert-MitmPlainPath $parent 'Any')
        if (-not (Test-Path -LiteralPath $parent)) { [void][IO.Directory]::CreateDirectory($parent) }
        $backup = Join-Path $parent ([guid]::NewGuid().ToString('N'))
        [void][IO.Directory]::CreateDirectory($backup)
        [void][IO.Directory]::CreateDirectory((Join-Path $backup 'original'))
        [void][IO.Directory]::CreateDirectory((Join-Path $backup 'staged'))
        foreach ($row in $rows) {
            $name = [IO.Path]::GetFileName($row.path)
            Copy-MitmVerified (Join-Path $target $row.path.Replace('/', '\')) (Join-Path $backup ('original\' + $name)) $row.before_sha256
            Copy-MitmVerified (Join-Path $PackageRoot ('payload\' + $row.path.Replace('/', '\'))) (Join-Path $backup ('staged\' + $name)) $row.sha256
        }
        $journal = @{ schema = 1; revision = $script:MitmRevision; panel_root = $target; state = 'prepared'; files = $rows }
        Write-MitmJournal (Join-Path $backup 'transaction.json') $journal
        Assert-MitmAppsClosed
        Assert-MitmMainUnchanged $target $mainPin
        if ((Get-MitmDiskState $target $rows) -ne 'before') { throw 'Preimage changed after backup; no replacement attempted.' }
        foreach ($row in $rows) {
            Assert-MitmAppsClosed
            $dest = Assert-MitmPlainPath (Join-Path $target $row.path.Replace('/', '\'))
            if ((Get-MitmHash $dest) -cne $row.before_sha256) { throw ('Compare-and-swap precondition changed: ' + $row.path) }
            $staged = Assert-MitmPlainPath (Join-Path $backup ('staged\' + [IO.Path]::GetFileName($row.path)))
            if ((Get-MitmHash $staged) -cne $row.sha256) { throw 'Staged payload changed before commit.' }
            Set-MitmAtomicFile $staged $dest
            if ((Get-MitmHash $dest) -cne $row.sha256) { throw 'Committed payload verification failed.' }
        }
        if ((Get-MitmDiskState $target $rows) -ne 'after') { throw 'Final update verification failed.' }
        [void](Assert-MitmDependencies $target)
        Assert-MitmMainUnchanged $target $mainPin
        $journal.state = 'complete'
        Write-MitmJournal (Join-Path $backup 'transaction.json') $journal
        return @{ status = 'updated'; changed = 1; panel_root = $target; backup = $backup; main_sha256 = $mainPin; rollback_requires_no_version10_receipts = $true }
    } catch {
        $originalError = $_.Exception.Message
        if ($journal) {
            # Photoshop may have been launched after our last precommit check.
            # Never restore R76 over a live R78 module or version10 receipts.
            try {
                Assert-MitmAppsClosed
                [void](Assert-MitmDependencies $target)
                Assert-MitmMainUnchanged $target $mainPin
                Assert-MitmNoR78Receipts
                Restore-MitmOwnedFiles $target $backup $rows -BestEffort
            }
            catch {
                $rollbackError = $_.Exception.Message
                $journal.state = 'recovery_required'
                $journal.recovery_reason = 'rollback-precondition-unproven'
                try { Write-MitmJournal (Join-Path $backup 'transaction.json') $journal } catch { }
                throw ($originalError + ' / Automatic rollback paused safely: ' + $rollbackError + ' Backup and current file retained: ' + $backup)
            }
            $journal.state = 'rolled_back'
            Write-MitmJournal (Join-Path $backup 'transaction.json') $journal
        }
        throw ($originalError + $(if ($backup) { ' Backup retained: ' + $backup } else { '' }))
    } finally {
        $lock.Dispose()
    }
}

function Invoke-MitmRollback([string]$PackageRoot, [string]$RequestedRoot, [string]$BackupPath, [switch]$OnlyCheck) {
    $rows = @(Get-MitmManifest $PackageRoot)
    $target = Get-MitmPanelRoot $RequestedRoot
    $mainPin = Assert-MitmDependencies $target
    Assert-MitmNoR78Receipts
    $backup = Assert-MitmPlainPath $BackupPath 'Directory'
    $parent = Join-Path $target '.mitom-save-task-backups'
    if ([IO.Path]::GetDirectoryName($backup) -ine $parent -or [IO.Path]::GetFileName($backup) -cnotmatch '^[0-9a-f]{32}$') { throw 'Rollback must use an exact backup created inside this Panel root.' }
    $journal = [IO.File]::ReadAllText((Assert-MitmPlainPath (Join-Path $backup 'transaction.json'))) | ConvertFrom-Json
    if ($journal.schema -ne 1 -or $journal.revision -ne $script:MitmRevision -or $journal.panel_root -ine $target -or @($journal.files).Count -ne 1) { throw 'Rollback ownership journal differs.' }
    foreach ($row in $rows) {
        $record = @($journal.files | Where-Object { $_.path -ceq $row.path })
        if ($record.Count -ne 1 -or $record[0].sha256 -cne $row.sha256 -or $record[0].before_sha256 -cne $row.before_sha256 -or $record[0].size -ne $row.size) { throw 'Rollback journal file policy differs.' }
        $original = Assert-MitmPlainPath (Join-Path $backup ('original\' + [IO.Path]::GetFileName($row.path)))
        if ((Get-MitmHash $original) -cne $row.before_sha256) { throw 'Rollback original hash differs.' }
        $actual = Get-MitmHash (Assert-MitmPlainPath (Join-Path $target $row.path.Replace('/', '\')))
        if ($actual -cne $row.sha256 -and $actual -cne $row.before_sha256) { throw 'Rollback preserves unknown current bytes.' }
    }
    if ($OnlyCheck) { return @{ status = 'rollback_ready'; changed = 0; backup = $backup } }
    Assert-MitmAppsClosed
    $lockPath = Join-Path $target '.mitom-save-task-R78.lock'
    [void](Assert-MitmPlainPath $lockPath 'Any')
    $lock = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    try {
        Assert-MitmAppsClosed
        [void](Assert-MitmDependencies $target)
        Assert-MitmMainUnchanged $target $mainPin
        Assert-MitmNoR78Receipts
        Restore-MitmOwnedFiles $target $backup $rows
        $journal.state = 'rolled_back'
        Write-MitmJournal (Join-Path $backup 'transaction.json') $journal
        return @{ status = 'rolled_back'; changed = 1; backup = $backup }
    } finally { $lock.Dispose() }
}

if (-not $LibraryOnly) {
    try {
        if ($Rollback) { $result = Invoke-MitmRollback $PSScriptRoot $PanelRoot $Rollback -OnlyCheck:$CheckOnly }
        else { $result = Invoke-MitmUpdate $PSScriptRoot $PanelRoot -OnlyCheck:$CheckOnly }
        $result | ConvertTo-Json -Depth 5
        exit 0
    } catch {
        [Console]::Error.WriteLine($_.Exception.Message)
        exit 1
    }
}
