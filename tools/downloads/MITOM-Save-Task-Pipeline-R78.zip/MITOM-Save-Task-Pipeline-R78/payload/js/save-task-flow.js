(function (root, factory) {
  var api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.UOYTaskRemote = api;
}(typeof window !== "undefined" ? window : this, function () {
  "use strict";
  var BUILD = "20261020-R9", LIMIT = 1024 * 1024;
  // R76 keeps the existing request/receipt protocol. Progress is advisory only;
  // it must never commit a file or turn a missing final receipt into success.
  var PROGRESS_PREFIX = "UOY_SAVE_TASK_PROGRESS ";
  function progressMessage(value) {
    if (!value || Object.keys(value).sort().join(',') !== 'build,part,parts,stage,total,transferred' || value.build !== BUILD || !/^(?:listing|destination|source-check|single-upload|multipart-init|multipart-part(?:-[1-9][0-9]{0,5})?|multipart-complete|remote-content-read|reconcile)$/.test(value.stage || "")) return null;
    var keys = ['transferred', 'total', 'part', 'parts'];
    for (var i = 0; i < keys.length; i++) if (!Number.isSafeInteger(value[keys[i]]) || value[keys[i]] < 0) return null;
    if (value.total > 2 * 1024 * 1024 * 1024 || value.transferred > value.total || value.parts > 10000 || value.part > value.parts) return null;
    var messages = { listing: 'Đang đọc danh sách file…', destination: 'Đang xác minh thư mục đích…', 'source-check': 'Đang kiểm tra file trước upload…', 'single-upload': 'Đang gửi file…', 'multipart-init': 'Đang mở phiên upload theo phần…', 'multipart-complete': 'Đang hoàn tất upload; chờ hệ thống xác nhận…', 'remote-content-read': 'Đang đối chiếu nội dung file trên hệ thống…', reconcile: 'Đang kiểm tra kết quả upload; không gửi trùng…' };
    if (/^multipart-part/.test(value.stage)) {
      if (value.total < 1 || value.parts < 1 || value.part > 10000) return null;
      var stagePart = /^multipart-part-([1-9][0-9]*)$/.exec(value.stage); if (stagePart && Number(stagePart[1]) > value.parts) return null;
      return 'Đang upload: ' + Math.floor(100 * (value.transferred || 0) / Math.max(1, value.total || 0)) + '% · ' + (value.part || 0) + '/' + (value.parts || 0) + ' phần đã xác nhận. Bạn có thể tiếp tục làm việc trong Photoshop.';
    }
    return messages[value.stage];
  }
  function problem(code, message) { var error = new Error(message); error.code = code; return error; }
  function create(options) {
    options = options || {};
    var fs = options.fs, path = options.path, cp = options.cp, os = options.os;
    if (!fs || !path || !cp || !os) throw problem("NODE_REQUIRED", "Thiếu Node.js để chạy Save Task.");
    function plain(file, directory) {
      if (!file || !path.isAbsolute(file)) throw problem("INVALID_RUNTIME", "Đường dẫn bộ Save Task không hợp lệ.");
      var cursor = path.resolve(file), first = true;
      while (cursor) {
        var info = fs.lstatSync(cursor);
        if (info.isSymbolicLink() || (first && (directory ? !info.isDirectory() : !info.isFile()))) throw problem("INVALID_RUNTIME", "Không dùng bộ Save Task qua đường dẫn liên kết.");
        var next = path.dirname(cursor); if (next === cursor) break; cursor = next; first = false;
      }
      return path.resolve(file);
    }
    var panelRoot = plain(options.panelRoot, true), helper = plain(path.join(panelRoot, "js", "save-task-remote.py"), false);
    if (path.dirname(helper).toLowerCase() !== path.join(panelRoot, "js").toLowerCase()) throw problem("INVALID_RUNTIME", "Không tìm thấy helper Save Task trong panel.");
    // No shell, command interpolation, browser/profile scan or private-file reads.
    // The old uploader directory is not executable authority for this new bridge.
    var runtimePromise = null;
    function isFile(candidate) { try { return plain(candidate, false); } catch (_) { return null; } }
    function discoveryCommand(executable, args) {
      return new Promise(function (resolve) {
        var child, output = "", done = false, timer;
        function finish(value) { if (done) return; done = true; clearTimeout(timer); resolve(value); }
        try { child = cp.spawn(executable, args, { shell: false, windowsHide: true, stdio: ["ignore", "pipe", "ignore"] }); }
        catch (_) { finish(null); return; }
        timer = setTimeout(function () { finish(null); try { child.kill(); } catch (_) {} }, 5000);
        child.once("error", function () { finish(null); });
        child.stdout.on("data", function (chunk) { output += String(chunk); if (output.length > 8192) { finish(null); try { child.kill(); } catch (_) {} } });
        child.once("close", function (code) { finish(code === 0 ? output : null); });
      });
    }
    function discover() {
      if (runtimePromise) return runtimePromise;
      runtimePromise = Promise.resolve().then(function () {
        var env = options.env || (typeof process !== "undefined" ? process.env : {}), roots = [];
        if (env.LOCALAPPDATA) { var ownedPython = isFile(path.join(env.LOCALAPPDATA, "UOY", "Launcher", "current", "python", "python.exe")); if (ownedPython) return { executable: ownedPython, prefix: [] }; }
        if (env.LOCALAPPDATA) roots.push(path.join(env.LOCALAPPDATA, "Programs", "Python"));
        if (env.ProgramFiles) roots.push(env.ProgramFiles);
        if (env["ProgramFiles(x86)"]) roots.push(env["ProgramFiles(x86)"]);
        for (var r = 0; r < roots.length; r++) {
          var names; try { plain(roots[r], true); names = fs.readdirSync(roots[r]).filter(function (name) { return /^python3[0-9.]*$/i.test(name); }).sort().reverse(); } catch (_) { continue; }
          for (var n = 0; n < names.length; n++) { var executable = isFile(path.join(roots[r], names[n], "python.exe")); if (executable) return { executable: executable, prefix: [] }; }
        }
        var where = path.join(env.SystemRoot || "C:\\Windows", "System32", "where.exe");
        return discoveryCommand(where, ["python.exe"]).then(function (output) {
          var rows = String(output || "").split(/[\r\n]+/);
          for (var i = 0; i < rows.length; i++) { if (/WindowsApps/i.test(rows[i])) continue; var found = isFile(rows[i].trim()); if (found) return { executable: found, prefix: [] }; }
          return discoveryCommand("py.exe", ["-3", "-c", "import sys;print(sys.executable)"]).then(function (python) {
            var found = python && isFile(python.trim());
            if (!found) throw problem("PYTHON_REQUIRED", "Không tìm thấy Python 3. Hãy cài Python 3 hoặc chạy bộ cài tool đầy đủ trên máy này.");
            return { executable: found, prefix: [] };
          });
        });
      });
      runtimePromise = runtimePromise.catch(function (error) { runtimePromise = null; throw error; });
      return runtimePromise;
    }
    function run(command, args, onProgress) {
      var request;
      try { request = JSON.stringify({ command: command, args: args }); if (request.length > LIMIT) throw problem("INVALID_REQUEST", "Yêu cầu Save Task quá lớn."); }
      catch (error) { return Promise.reject(error); }
      return discover().then(function (runtime) {
        // Recheck the owned helper at every invocation, not only at initialization.
        plain(helper, false);
        return new Promise(function (resolve, reject) {
          var child, stdout = "", stderrBytes = 0, progressBuffer = "", progressOverflow = false, done = false, timer, spawnNotified = false;
          function finish(error, result) { if (done) return; done = true; clearTimeout(timer); if (error) reject(error); else resolve(result); }
          try { child = cp.spawn(runtime.executable, runtime.prefix.concat(["-B", helper]), { shell: false, windowsHide: true, cwd: panelRoot, stdio: ["pipe", "pipe", "pipe"] }); }
          catch (_) { finish(problem("LAUNCH_FAILED", "Không mở được helper Save Task; file local vẫn được giữ.")); return; }
          timer = setTimeout(function () { finish(problem("REMOTE_TIMEOUT", "Chưa xác nhận được kết quả hệ thống. File local được giữ; lượt Save sau sẽ kiểm tra lại đúng thư mục trước khi tiếp tục.")); try { child.kill(); } catch (_) {} }, command === "upload" ? 3910000 : command === "reconcile" ? 361000 : command === "prepare" ? 100000 : 55000);
          child.once("error", function () { finish(problem("LAUNCH_FAILED", "Không mở được Python Save Task; chưa upload file nào.")); });
          child.stdin.on("error", function () { finish(problem("LAUNCH_FAILED", "Không gửi được yêu cầu Save Task; kiểm tra hệ thống trước khi thử lại.")); });
          child.stdout.on("data", function (chunk) { stdout += String(chunk); if (stdout.length > LIMIT) { finish(problem("INVALID_RESPONSE", "Kết quả hệ thống quá lớn; kiểm tra folder trước khi thử lại.")); try { child.kill(); } catch (_) {} } });
          child.stderr.on("data", function (chunk) {
            if (done) return;
            stderrBytes += chunk.length;
            if (stderrBytes > 4 * LIMIT) { finish(problem("INVALID_RESPONSE", "Helper Save Task trả dữ liệu lỗi; kiểm tra folder trước khi thử lại.")); try { child.kill(); } catch (_) {} return; }
            progressBuffer += String(chunk);
            var newline;
            while ((newline = progressBuffer.indexOf('\n')) >= 0) {
              var line = progressBuffer.slice(0, newline); progressBuffer = progressBuffer.slice(newline + 1);
              if (progressOverflow) { progressOverflow = false; continue; }
              if (line.length > 2048 || line.indexOf(PROGRESS_PREFIX) !== 0) continue;
              try { var message = progressMessage(JSON.parse(line.slice(PROGRESS_PREFIX.length))); var sink = typeof onProgress === 'function' ? onProgress : options.progress; if (message && typeof sink === 'function') sink(message); } catch (_) { /* Never render arbitrary helper stderr or raw exceptions. */ }
            }
            if (progressBuffer.length > 2048) { progressBuffer = ''; progressOverflow = true; }
          });
          child.once("close", function (code) {
            if (spawnNotified && onProgress && typeof onProgress.onClose === "function") { try { onProgress.onClose(command, child.pid); } catch (_) { finish(problem("CHILD_TRACKING", "Không chốt được biên nhận tiến trình upload; giữ nguyên để đối chiếu.")); } }
            if (done) return;
            var response;
            try { response = JSON.parse(stdout.trim()); } catch (_) { finish(problem("INVALID_RESPONSE", "Helper Save Task không trả kết quả hợp lệ. File local vẫn giữ; kiểm tra hệ thống trước khi thử lại.")); return; }
            if (code !== 0 || !response || response.build !== BUILD || typeof response.ok !== "boolean") { finish(problem("INVALID_RESPONSE", "Bộ Save Task chưa đồng bộ hoặc dừng bất thường; chưa xác nhận upload.")); return; }
            if (!response.ok) {
              var detail = response.error || {}, error = problem(/^[A-Z0-9_]{1,64}$/.test(detail.code || "") ? detail.code : "REMOTE_FAILED", typeof detail.message === "string" ? detail.message.substring(0, 1000) : "Hệ thống chưa xác nhận kết quả Save Task.");
              if (/^(?:listing|destination|single-upload|multipart-init|multipart-part(?:-[1-9][0-9]{0,5})?|multipart-complete|remote-content-read|reconcile)$/.test(detail.stage || "")) error.stage = detail.stage;
              if (Number.isInteger(detail.http_status) && detail.http_status >= 100 && detail.http_status <= 599) error.httpStatus = detail.http_status;
              if (error.stage) error.message += " [" + error.stage + (error.httpStatus ? " · HTTP " + error.httpStatus : "") + "]";
              error.uploaded = Array.isArray(detail.uploaded) ? detail.uploaded : []; finish(error); return;
            }
            var result = response.result;
            if (!result || !/^[1-9][0-9]{0,19}$/.test(result.folderId) || result.link !== "https://files.uoymedia.com/shared/" + result.folderId || !Array.isArray(result.names) || result.names.length > 5000 || result.names.some(function (name) { return typeof name !== "string" || name.length > 1024; }) || !result.scope || result.scope.anchor !== "01_TASK" || !/^20[0-9]{2}$/.test(result.scope.year) || !/^T[0-9]{2}-[0-9]{2}$/.test(result.scope.day)) { finish(problem("INVALID_RESPONSE", "Hệ thống trả folder SKU không hợp lệ; đã dừng an toàn.")); return; }
            if (command === "reconcile" && (!Array.isArray(result.verified) || !result.verified.length || result.verified.length > 32 || result.verified.some(function (entry) { return !entry || typeof entry.name !== "string" || !Number.isSafeInteger(entry.size) || entry.size < 1 || !/^[a-f0-9]{64}$/.test(entry.sha256 || "") || !/^[1-9][0-9]{0,19}$/.test(String(entry.fileId)); }))) { finish(problem("INVALID_RESPONSE", "Chưa có xác nhận nội dung file từ hệ thống.")); return; }
            finish(null, result);
          });
          try { if (onProgress && typeof onProgress.onSpawn === "function") { if (!Number.isSafeInteger(child.pid) || child.pid < 1) throw problem("CHILD_TRACKING", "Chưa xác nhận được tiến trình helper; chưa gửi yêu cầu."); spawnNotified = true; onProgress.onSpawn(command, child.pid); } child.stdin.end(request, "utf8"); } catch (_) { finish(problem("CHILD_TRACKING", "Không ghi được biên nhận tiến trình helper; chưa xác nhận upload.")); try { child.kill(); } catch (_) {} }
        });
      });
    }
    return { lifecycle: "owned-child-v1", prepare: function (args, progress) { return run("prepare", args, progress); }, link: function (args, progress) { return run("link", args, progress); }, upload: function (args, progress) { return run("upload", args, progress); }, reconcile: function (args, progress) { return run("reconcile", args, progress); } };
  }
  return { build: BUILD, create: create };
}));

;
(function(root,factory){
  var api=factory(typeof require==='function'?require('crypto'):null);
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.UOYTaskJpegProof=api;
}(typeof window==='undefined'?this:window,function(crypto){
  'use strict';
  // This is a narrow byte-identity proof, NOT a C2PA signature/trust validator.
  // C2PA 2.4 A.3.1 / 11.1.4.2: JPEG XT APP11, JP/En/Z framing,
  // JUMBF Manifest Store UUID 63327061-0011-0010-8000-00AA00389B71,
  // label c2pa. Recovery deliberately supports only ONE complete packet.
  var UUID='6332706100110010800000aa00389b71',MAX_BOXES=4096,MAX_DEPTH=32;
  function reject(){var e=new Error('Khong du bang chung JPEG chi duoc chen them mot khoi C2PA APP11; giu nguyen bien nhan va file.');e.code='JPEG_C2PA_PROOF';throw e;}
  function u16(b,p){if(p<0||p+2>b.length)reject();return b[p]*256+b[p+1];}
  function u32(b,p){if(p<0||p+4>b.length)reject();return b[p]*16777216+b[p+1]*65536+b[p+2]*256+b[p+3];}
  function ascii(b,p,n){if(p<0||p+n>b.length)reject();var s='';for(var i=0;i<n;i++)s+=String.fromCharCode(b[p+i]);return s;}
  function hex(b,p,n){if(p<0||p+n>b.length)reject();var s='';for(var i=0;i<n;i++)s+=('0'+b[p+i].toString(16)).slice(-2);return s;}
  function hash(parts){if(!crypto||typeof crypto.createHash!=='function')reject();var h=crypto.createHash('sha256');parts.forEach(function(p){h.update(p);});return h.digest('hex');}
  function box(b,p,end,state){
    if(p+8>end||++state.boxes>MAX_BOXES)reject();var size=u32(b,p),type=ascii(b,p+4,4);
    // Extended/EOF-sized boxes are not needed by the observed single packet;
    // do not guess boundaries or reinterpret an incomplete packet as complete.
    if(size<8||p+size>end||!/^[\x20-\x7e]{4}$/.test(type))reject();
    return{start:p,data:p+8,end:p+size,type:type,size:size};
  }
  function description(b,d,state){
    if(d.type!=='jumd'||d.size<26)reject();var p=d.data,uuid=hex(b,p,16),flags=b[p+16];p+=17;
    if((flags&3)!==3||(flags&224)!==0)reject();
    var start=p;while(p<d.end&&b[p]!==0)p++;if(p===d.end)reject();var label=ascii(b,start,p-start);p++;
    if(flags&4)p+=4;if(flags&8)p+=32;if(p>d.end)reject();
    if(flags&16){var privateBox=box(b,p,d.end,state);if(privateBox.type!=='c2sh')reject();p=privateBox.end;}
    if(p!==d.end)reject();return{uuid:uuid,label:label};
  }
  function superbox(b,top,state,depth){
    if(top.type!=='jumb'||depth>MAX_DEPTH)reject();var p=top.data,desc=box(b,p,top.end,state),identity=description(b,desc,state);p=desc.end;var count=0,manifests=0;
    while(p<top.end){var child=box(b,p,top.end,state);if(child.type==='jumd')reject();if(child.type==='jumb'){var nested=superbox(b,child,state,depth+1);if(/^6332(?:6d61|636d|756d|6d64)00110010800000aa00389b71$/.test(nested.uuid)&&nested.label.indexOf('urn:c2pa:')===0)manifests++;}p=child.end;count++;}
    if(p!==top.end||count<1||identity.uuid===UUID&&manifests<1)reject();return identity;
  }
  function c2paPacket(b,segment){
    var p=segment.data,end=segment.end;if(end-p<2||ascii(b,p,2)!=='JP')return false;
    if(end-p<16||u32(b,p+4)!==1)reject();var state={boxes:0},top=box(b,p+8,end,state);
    if(top.end!==end||top.type!=='jumb')reject();var id=superbox(b,top,state,0);
    if(id.uuid===UUID||id.label==='c2pa'){if(id.uuid!==UUID||id.label!=='c2pa')reject();return true;}return false;
  }
  function quantization(b,p,end){
    if(p===end)reject();while(p<end){var v=b[p++],precision=v>>>4;if(precision>1||(v&15)>3)reject();p+=precision?128:64;if(p>end)reject();}if(p!==end)reject();
  }
  function huffman(b,p,end){
    if(p===end)reject();while(p<end){var v=b[p++];if((v>>>4)>1||(v&15)>3||p+16>end)reject();var symbols=0;for(var i=0;i<16;i++)symbols+=b[p+i];p+=16;if(symbols<1||symbols>256||p+symbols>end)reject();p+=symbols;}if(p!==end)reject();
  }
  function jpeg(b){
    if(!b||typeof b.subarray!=='function'||!Number.isSafeInteger(b.length)||b.length<20||b[0]!==255||b[1]!==216)reject();
    var p=2,frame=null,scans=0,hasDqt=false,hasDht=false,candidates=[],markers=0;
    while(p<b.length){
      if(++markers>65536||b[p]!==255)reject();var markerStart=p;while(p<b.length&&b[p]===255)p++;if(p===b.length)reject();var marker=b[p++],exactStart=p-2;
      if(marker===217){if(!frame||!scans||p!==b.length)reject();return candidates;}
      if(marker===0||marker===216||(marker>=208&&marker<=215))reject();
      if(marker===1)continue;
      if(p+2>b.length)reject();var length=u16(b,p),data=p+2,end=p+length;if(length<2||end>b.length)reject();
      if(marker===192||marker===193||marker===194){
        if(frame||length<11||b[data]!==8)reject();var height=u16(b,data+1),width=u16(b,data+3),components=b[data+5],ids={};
        if(!height||!width||[1,3,4].indexOf(components)<0||length!==8+3*components)reject();
        for(var n=0;n<components;n++){var at=data+6+3*n,id=b[at],sampling=b[at+1];if(ids[id]||!(sampling>>>4)||!(sampling&15)||(sampling>>>4)>4||(sampling&15)>4||b[at+2]>3)reject();ids[id]=true;}
        frame={marker:marker,ids:ids,components:components};
      }else if(marker===219){quantization(b,data,end);hasDqt=true;
      }else if(marker===196){huffman(b,data,end);hasDht=true;
      }else if(marker===221){if(length!==4)reject();
      }else if(marker===235){
        var segment={start:exactStart,data:data,end:end};if(c2paPacket(b,segment)){if(scans||markerStart!==exactStart)reject();candidates.push(segment);}
      }else if(marker===218){
        if(!frame||!hasDqt||!hasDht||length<8)reject();var ns=b[data],seen={};if(ns<1||ns>frame.components||length!==6+2*ns)reject();
        for(var s=0;s<ns;s++){var sid=b[data+1+2*s],tables=b[data+2+2*s];if(!frame.ids[sid]||seen[sid]||(tables>>>4)>3||(tables&15)>3)reject();seen[sid]=true;}
        var ss=b[end-3],se=b[end-2],approx=b[end-1];if(ss>se||se>63||(approx>>>4)>13||(approx&15)>13)reject();
        if(frame.marker!==194&&(ss!==0||se!==63||approx!==0)||frame.marker===194&&((ss===0&&se!==0)||(ss>0&&ns!==1)))reject();
        scans++;p=end;var entropy=0;
        while(p<b.length){if(b[p]!==255){p++;entropy++;continue;}var ff=p;p++;while(p<b.length&&b[p]===255)p++;if(p===b.length)reject();var next=b[p];
          if(next===0){p++;entropy++;continue;}if(next>=208&&next<=215){p++;continue;}p=ff;break;}
        if(!entropy)reject();continue;
      }else if(!((marker>=224&&marker<=239)||marker===254))reject();
      p=end;
    }
    reject();
  }
  function proofInsertedC2pa(currentBuffer,oldSize,oldSHA){
    if(!Number.isSafeInteger(oldSize)||oldSize<20||typeof oldSHA!=='string'||!/^[a-f0-9]{64}$/.test(oldSHA))reject();
    var candidates=jpeg(currentBuffer);if(candidates.length!==1)reject();var item=candidates[0],bytes=item.end-item.start;
    if(currentBuffer.length-bytes!==oldSize)reject();
    var prior=hash([currentBuffer.subarray(0,item.start),currentBuffer.subarray(item.end)]);if(prior!==oldSHA)reject();
    return{version:1,kind:'c2pa-app11-insertion',oldSize:oldSize,oldSHA:oldSHA,currentSize:currentBuffer.length,currentSHA:hash([currentBuffer]),offset:item.start,bytes:bytes,segmentSHA:hash([currentBuffer.subarray(item.start,item.end)])};
  }
  return{proofInsertedC2pa:proofInsertedC2pa};
}));

;
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.UOYTaskJpegFinalizeProof = api;
}(typeof window === 'undefined' ? this : window, function () {
  'use strict';
  // Container/framing inspection only. NOT a signature, trust, pixels, or
  // Adobe writer-completion validator. Never changes or strips input bytes.
  // C2PA 2.4 A.3.1; JPEG XT JP/En/Z framing follows contentauth/c2pa-rs.
  var STORE = '6332706100110010800000aa00389b71';
  var PREFIX = '00110010800000aa00389b71';
  var MAX_MARKERS = 131072, MAX_BOXES = 65536, MAX_DEPTH = 32;
  function issue(state, reason) { var e = new Error(reason); e.state = state; throw e; }
  function u16(b, p) { return b[p] * 256 + b[p + 1]; }
  function u32(b, p) { return b[p] * 16777216 + b[p + 1] * 65536 + b[p + 2] * 256 + b[p + 3]; }
  function ascii(b, p, n) { var s = ''; for (var i = 0; i < n; i++) s += String.fromCharCode(b[p + i]); return s; }
  function hex(b, p, n) { var s = ''; for (var i = 0; i < n; i++) s += ('0' + b[p + i].toString(16)).slice(-2); return s; }
  function join(parts, length) { var b = new Uint8Array(length), p = 0; parts.forEach(function (x) { b.set(x, p); p += x.length; }); return b; }
  function equal(a, p, b, q, n) { for (var i = 0; i < n; i++) if (a[p + i] !== b[q + i]) return false; return true; }
  function nonzero(b, start, end) { for (var p = start; p < end; p++) if (b[p] !== 0) return true; return false; }
  // Bounded definite-length CBOR framing: only used to avoid treating the
  // standard temporary COSE_Sign1 (empty protected/signature + pad) as fast-path
  // completion. No signature, certificate, or assertion validation is done.
  function cbor(b, p, end, count, depth) {
    if (p >= end || depth > MAX_DEPTH || ++count.n > MAX_BOXES) issue('incomplete', 'signature-cbor-uninspected');
    var start = p, head = b[p++], major = head >>> 5, ai = head & 31, value = ai;
    if (ai >= 24) {
      var n = ai === 24 ? 1 : ai === 25 ? 2 : ai === 26 ? 4 : ai === 27 ? 8 : 0;
      if (!n || p + n > end) issue('incomplete', 'signature-cbor-uninspected');
      value = 0; for (var i = 0; i < n; i++) { value = value * 256 + b[p++]; if (!Number.isSafeInteger(value)) issue('incomplete', 'signature-cbor-uninspected'); }
    }
    var node = { major: major, value: value, start: start, data: p, children: [] };
    if (major === 2 || major === 3) { if (value > end - p) issue('incomplete', 'signature-cbor-uninspected'); p += value; }
    else if (major === 4 || major === 5 || major === 6) {
      var size = major === 6 ? 1 : major === 5 ? value * 2 : value;
      if (size > MAX_BOXES) issue('incomplete', 'signature-cbor-uninspected');
      for (var j = 0; j < size; j++) { var child = cbor(b, p, end, count, depth + 1); p = child.end; node.children.push(child); }
    }
    node.end = p; return node;
  }
  function signaturePresent(b, entry) {
    var sig = cbor(b, entry.start, entry.end, { n: 0 }, 0);
    if (sig.end !== entry.end || sig.major !== 6 || sig.value !== 18 || sig.children.length !== 1) issue('incomplete', 'signature-cbor-uninspected');
    var fields = sig.children[0], protectedHeader = fields.children[0], unprotectedHeader = fields.children[1], payload = fields.children[2], signature = fields.children[3];
    if (fields.major !== 4 || fields.value !== 4 || !protectedHeader || protectedHeader.major !== 2 || !protectedHeader.value || !unprotectedHeader || unprotectedHeader.major !== 5 || !payload || payload.major !== 7 || payload.value !== 22 || !signature || signature.major !== 2 || !signature.value || !nonzero(b, signature.data, signature.end)) issue('incomplete', 'signature-placeholder-or-uninspected');
  }
  function box(b, p, end, count) {
    if (++count.n > MAX_BOXES) issue('invalid', 'box-limit');
    if (p + 8 > end) issue('incomplete', 'box-header-incomplete');
    var size = u32(b, p), header = 8, type = ascii(b, p + 4, 4);
    if (!/^[\x20-\x7e]{4}$/.test(type)) issue('invalid', 'box-type-invalid');
    if (size === 1) {
      if (p + 16 > end) issue('incomplete', 'extended-box-header-incomplete');
      var high = u32(b, p + 8), low = u32(b, p + 12);
      if (high > 2097151) issue('invalid', 'box-size-unsafe');
      size = high * 4294967296 + low; header = 16;
    }
    // An EOF-sized box has no positive final-size proof while a writer is active.
    if (size === 0) issue('incomplete', 'box-size-unbounded');
    if (size < header) issue('invalid', 'box-size-invalid');
    if (size > end - p) issue('incomplete', 'box-body-incomplete');
    return { start: p, data: p + header, end: p + size, type: type, size: size };
  }
  function description(b, d, count) {
    if (d.type !== 'jumd' || d.end - d.data < 17) issue('invalid', 'description-invalid');
    var p = d.data, uuid = hex(b, p, 16), flags = b[p + 16]; p += 17;
    if ((flags & 224) !== 0) issue('invalid', 'description-flags-invalid');
    var label = '';
    if (flags & 2) {
      var start = p; while (p < d.end && b[p] !== 0) p++;
      if (p === d.end) issue('incomplete', 'description-label-incomplete');
      label = ascii(b, start, p - start); p++;
    }
    if (flags & 4) p += 4;
    if (flags & 8) p += 32;
    if (p > d.end) issue('incomplete', 'description-fields-incomplete');
    if (flags & 16) { var privateBox = box(b, p, d.end, count); p = privateBox.end; }
    if (p !== d.end) issue('invalid', 'description-tail-invalid');
    return { uuid: uuid, label: label, flags: flags };
  }
  function superbox(b, top, count, depth) {
    if (depth > MAX_DEPTH) issue('invalid', 'box-depth-limit');
    var d = box(b, top.data, top.end, count), identity = description(b, d, count);
    var node = { identity: identity, children: [] }, p = d.end;
    while (p < top.end) {
      var child = box(b, p, top.end, count), entry = { type: child.type, start: child.data, end: child.end };
      if (child.type === 'jumd') issue('invalid', 'duplicate-description');
      if (child.type === 'jumb') entry.node = superbox(b, child, count, depth + 1);
      node.children.push(entry); p = child.end;
    }
    if (!node.children.length) issue('incomplete', 'empty-superbox');
    return node;
  }
  function content(b, node, uuid, labelPrefix) {
    var found = null;
    node.children.forEach(function (entry) {
      if (!entry.node) return;
      var id = entry.node.identity;
      if (id.uuid !== uuid || id.label.indexOf(labelPrefix) !== 0) return;
      if (found) issue('invalid', 'duplicate-manifest-content');
      found = entry.node;
    });
    if (!found) issue('incomplete', 'manifest-content-missing');
    var cbor = found.children.filter(function (x) { return x.type === 'cbor'; });
    if (cbor.length !== 1 || found.children.some(function (x) { return x.type !== 'cbor' && x.type !== 'free'; })) issue('incomplete', 'manifest-cbor-incomplete');
    if (cbor[0].start === cbor[0].end || !nonzero(b, cbor[0].start, cbor[0].end)) issue('incomplete', 'manifest-placeholder');
    if (labelPrefix === 'c2pa.signature') signaturePresent(b, cbor[0]);
  }
  function storeComplete(b, node) {
    var manifests = 0;
    node.children.forEach(function (entry) {
      if (!entry.node) return;
      var id = entry.node.identity, prefix = id.uuid.slice(0, 8), suffix = id.uuid.slice(8);
      if (suffix !== PREFIX || ['63326d61', '63326d64', '6332756d', '6332636d'].indexOf(prefix) < 0) return;
      if (id.label.indexOf('urn:c2pa:') !== 0 && id.label.indexOf('urn:uuid:') !== 0) issue('invalid', 'manifest-label-invalid');
      manifests++;
      // Do not call an opaque compressed stream signer-complete without decoding.
      // It is retained for retry/manual handling; unknown metadata stays untouched.
      if (prefix === '6332636d') issue('incomplete', 'compressed-manifest-not-inspected');
      content(b, entry.node, '6332636c' + PREFIX, 'c2pa.claim');
      content(b, entry.node, '63326373' + PREFIX, 'c2pa.signature');
    });
    if (!manifests) issue('incomplete', 'manifest-missing-or-placeholder');
  }
  function inspectGroup(group) {
    var bytes = join(group.parts, group.length), count = { n: 0 }, containerComplete = false;
    // Detect identity before checking the outer declared length, so truncated
    // positively identified stores cannot be reclassified as credential-absent.
    var hint = bytes.length >= 32 && ascii(bytes, 4, 4) === 'jumb' && ascii(bytes, 12, 4) === 'jumd' && hex(bytes, 16, 16) === STORE;
    try {
      var top = box(bytes, 0, bytes.length, count);
      if (top.type !== 'jumb') return { c2pa: 'absent' };
      if (top.end !== bytes.length) issue('invalid', 'jumbf-trailing-bytes');
      var node = superbox(bytes, top, count, 0), id = node.identity;
      if (id.uuid !== STORE && id.label !== 'c2pa') return { c2pa: 'absent' };
      if (id.uuid !== STORE || id.label !== 'c2pa' || (id.flags & 3) !== 3) issue('invalid', 'store-identity-mismatch');
      containerComplete = true;
      storeComplete(bytes, node);
      return { c2pa: 'complete', containerComplete: true, reason: 'complete-container-not-signature-validation' };
    } catch (e) {
      // Incomplete JP framing may still be the beginning of the writer's store;
      // conservatively retain it. Fully parsed non-C2PA JUMBF is ignored above.
      return { c2pa: e.state || 'invalid', containerComplete: containerComplete, reason: e.message, potential: !hint };
    }
  }
  function inspect(input) {
    var result = { jpegComplete: false, c2pa: 'absent', c2paContainerComplete: null, structuralOnly: true, ranges: [], reason: 'jpeg-incomplete', counts: { app11Packets: 0, jumbfGroups: 0, manifestStores: 0 } };
    if (!input || typeof input.subarray !== 'function' || !Number.isSafeInteger(input.length)) { result.reason = 'byte-buffer-required'; return result; }
    var b = input, groups = [], current = null, markerCount = 0, frame = null, scans = 0, p = 2, jpegReason = '';
    function packet(data, end, start, order) {
      if (end - data < 2 || ascii(b, data, 2) !== 'JP') { current = null; return; }
      result.counts.app11Packets++;
      if (end - data < 16) issue('incomplete', 'app11-header-incomplete');
      var en = u16(b, data + 2), seq = u32(b, data + 4);
      if (seq === 1) {
        current = { en: en, seq: 1, lastOrder: order, header: b.subarray(data + 8, data + 16), parts: [b.subarray(data + 8, end)], length: end - data - 8, ranges: [{ start: start, end: end }] };
        groups.push(current);
      } else {
        if (!current || current.en !== en || current.lastOrder !== order - 1) issue('incomplete', 'app11-fragment-not-contiguous');
        if (seq !== current.seq + 1) issue('invalid', 'app11-fragment-sequence');
        if (!equal(current.header, 0, b, data + 8, 8)) issue('invalid', 'app11-fragment-header-mismatch');
        current.parts.push(b.subarray(data + 16, end)); current.length += end - data - 16;
        current.seq = seq; current.lastOrder = order; current.ranges.push({ start: start, end: end });
      }
    }
    try {
      if (b.length < 4 || b[0] !== 255 || b[1] !== 216) issue('invalid', 'jpeg-soi-invalid');
      while (p < b.length) {
        if (++markerCount > MAX_MARKERS) issue('invalid', 'jpeg-marker-limit');
        if (b[p] !== 255) issue('invalid', 'jpeg-marker-invalid');
        var start = p; while (p < b.length && b[p] === 255) p++;
        if (p === b.length) issue('incomplete', 'jpeg-marker-incomplete');
        var marker = b[p++];
        if (marker === 217) {
          if (!frame || !scans) issue('invalid', 'jpeg-image-data-missing');
          if (p !== b.length) issue('invalid', 'jpeg-trailing-bytes');
          result.jpegComplete = true; break;
        }
        if (marker === 0 || marker === 216 || (marker >= 208 && marker <= 215)) issue('invalid', 'jpeg-marker-context-invalid');
        if (marker === 1) { current = null; continue; }
        if (p + 2 > b.length) issue('incomplete', 'jpeg-length-incomplete');
        var length = u16(b, p), data = p + 2, end = p + length;
        if (length < 2) issue('invalid', 'jpeg-length-invalid');
        if (end > b.length) issue('incomplete', 'jpeg-segment-incomplete');
        if (marker === 235) {
          // APP11's declared JPEG length is already checked. A malformed or
          // unrecognized JUMBF/fragment is NOT a broken JPEG framing verdict:
          // it disables the positive CC fast path, but the caller may retain
          // every byte and use its bounded generic-JPEG advisory fallback.
          try { packet(data, end, start, markerCount); }
          catch (packetError) {
            if (result.c2pa !== 'invalid') { result.c2pa = packetError.state || 'invalid'; result.reason = packetError.message; }
            result.c2paContainerComplete = false; result.ranges.push({ start: start, end: end }); current = null;
          }
        } else current = null;
        if (marker >= 192 && marker <= 207 && [196, 200, 204].indexOf(marker) < 0) {
          if (frame || length < 11) issue('invalid', 'jpeg-frame-invalid');
          var components = b[data + 5];
          if (!u16(b, data + 1) || !u16(b, data + 3) || !components || length !== 8 + 3 * components) issue('invalid', 'jpeg-dimensions-invalid');
          frame = { components: components };
        }
        p = end;
        if (marker === 218) {
          if (!frame || length < 8 || b[data] < 1 || b[data] > frame.components || length !== 6 + 2 * b[data]) issue('invalid', 'jpeg-scan-header-invalid');
          scans++;
          var entropy = 0;
          while (p < b.length) {
            if (b[p] !== 255) { entropy++; p++; continue; }
            var ff = p; while (p < b.length && b[p] === 255) p++;
            if (p === b.length) issue('incomplete', 'jpeg-entropy-incomplete');
            var next = b[p];
            if (next === 0) { entropy++; p++; continue; }
            if (next >= 208 && next <= 215) { p++; continue; }
            p = ff; break;
          }
          if (!entropy) issue('invalid', 'jpeg-empty-scan');
        }
      }
      if (!result.jpegComplete) jpegReason = 'jpeg-eoi-missing';
    } catch (e) {
      jpegReason = e.message || 'jpeg-invalid';
      if (e.message && e.message.indexOf('app11-') === 0) { result.c2pa = e.state || 'invalid'; result.reason = jpegReason; }
    }
    var complete = 0;
    result.counts.jumbfGroups = groups.length;
    groups.forEach(function (group) {
      var status = inspectGroup(group);
      if (status.c2pa === 'absent') return;
      result.counts.manifestStores++;
      result.ranges = result.ranges.concat(group.ranges);
      result.c2paContainerComplete = result.c2paContainerComplete === false ? false : !!status.containerComplete;
      if (status.c2pa === 'complete') complete++;
      if (result.c2pa === 'absent' || result.c2pa === 'complete' || status.c2pa === 'invalid') { result.c2pa = status.c2pa; result.reason = status.reason; }
    });
    if (complete > 1) { result.c2pa = 'invalid'; result.reason = 'multiple-manifest-stores'; }
    if (!result.jpegComplete) result.reason = jpegReason || result.reason;
    else if (result.c2pa === 'absent') result.reason = 'complete-jpeg-credentials-absent';
    return result;
  }
  return { inspect: inspect };
}));

;
(function(root,factory){var api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.UOYTaskFlow=api;}(typeof window==='undefined'?this:window,function(root){
  'use strict';
  var BUILD='20261020-R9',NATIVE_BUILD='20261022-R12';
  function fail(code,message){var e=new Error(message);e.code=code;throw e;}
  function segment(value,label,max){
    if(typeof value!=='string'||!value.trim()||value!==value.trim()||value.length>(max||120)||/[\\/:*?"<>|\x00-\x1f\x7f]/.test(value)||/[. ]$/.test(value)||value==='.'||value==='..'||/^(?:con|prn|aux|nul|conin\$|conout\$|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i.test(value))fail('NAME',label+' trống hoặc không hợp lệ trên Windows.');
    return value;
  }
  function product(value){value=segment(value,'Product type',80);if(/^(?:fullprint|mockup\d+)(?:__|$)/i.test(value))fail('NAME','Product type trùng tên dành riêng cho fullprint/mockup.');return value;}
  function configuredExportRoot(options){var env=options.env||(typeof process!=='undefined'?process.env:{});return options.exportRoot||options.path.join(env.LOCALAPPDATA||options.path.join(options.os.homedir(),'AppData','Local'),'UOY','Export');}
  function nextName(sku,kind,existing,type){
    sku=segment(sku,'SKU');var names=Object.create(null),maximum=0;
    existing.forEach(function(name){if(typeof name!=='string'||/[\\/\x00-\x1f]/.test(name))fail('LISTING','Danh sách tên file chưa hợp lệ.');names[name.toLowerCase()]=true;
      var lower=name.toLowerCase(),prefix=(sku+'__'+(kind==='mockup'?'mockup':'fullprint__design')).toLowerCase();
      if(lower.indexOf(prefix)!==0)return;var tail=lower.slice(prefix.length),m=(kind==='mockup'?/^(\d+)\.(?:jpg|jpeg|png)$/:/^(\d*)\.png$/).exec(tail);
      if(m){var number=m[1]?Number(m[1]):1;if(!Number.isSafeInteger(number)||number<1||number>99999)fail('NUMBER','Số thứ tự file vượt giới hạn.');maximum=Math.max(maximum,number);}
    });
    var result;if(kind==='psd')result=sku+'__'+product(type)+'.psd';
    else if(kind==='mockup')result=sku+'__mockup'+(maximum+1)+'.jpg';
    else if(kind==='fullprint')result=sku+'__fullprint__design'+(maximum?maximum+1:'')+'.png';
    else fail('KIND','Loại file Save Task không hợp lệ.');
    if(names[result.toLowerCase()])fail('EXISTS','Đã có '+result+'. Không ghi đè file đã lưu; chọn Product type khác nếu là option mới.');return result;
  }
  function createService(options){
    options=options||{};var fs=options.fs,path=options.path,crypto=options.crypto,os=options.os,remote=options.remote;
    var background=options.backgroundUploads===true,networkTail=Promise.resolve(),scheduled=Object.create(null),activeJobs=Object.create(null),knownContexts=Object.create(null);
    if(background&&options.requireOwnedChildren===true&&(!remote||remote.lifecycle!=='owned-child-v1'))fail('CHILD_TRACKING','Bộ upload chưa hỗ trợ theo dõi tiến trình con; chưa chạy Save Task. Hãy cài đủ bản R78.');
    var output=configuredExportRoot(options),privateRoot=options.privateRoot||path.join(os.homedir(),'.huong_tool','save_task_incremental_r9');
    var stageEnv=options.env||(typeof process!=='undefined'?process.env:{}),jpegStageRoot=path.join(stageEnv.APPDATA||path.join(os.homedir(),'AppData','Roaming'),'MITOM','SaveTaskCache');
    function plain(file,must){var cursor=path.resolve(file);while(true){try{if(fs.lstatSync(cursor).isSymbolicLink())fail('PATH','Không dùng đường dẫn liên kết.');}catch(e){if(e.code!=='ENOENT')throw e;if(must&&cursor===path.resolve(file))throw e;}var parent=path.dirname(cursor);if(parent===cursor)break;cursor=parent;}return path.resolve(file);}
    function uuid(){var id=crypto.randomBytes(16);id[6]=(id[6]&15)|64;id[8]=(id[8]&63)|128;var h=id.toString('hex');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);}
    function proofModule(option,globalName,file){var value=options[option]||root&&root[globalName];if(!value&&typeof require==='function')value=require('./'+file);if(!value)fail('JPEG_MODULE','Thiếu bộ kiểm tra JPEG; chưa upload ảnh.');return value;}
    var jpegNow=options.jpegNow||Date.now,jpegSleep=options.jpegSleep||function(ms){return new Promise(function(resolve){setTimeout(resolve,ms);});};
    function bytesProof(file){plain(file,true);var before=fs.lstatSync(file),fields=['size','mtimeMs','ctimeMs','birthtimeMs','dev','ino','mode'];if(!before.isFile()||before.size<1||before.size>512*1024*1024)fail('JPEG_FINALIZATION_PENDING','JPEG chưa có nội dung ổn định hoặc vượt giới hạn 512 MiB.');var bytes=fs.readFileSync(file);plain(file,true);var after=fs.lstatSync(file);if(!after.isFile()||bytes.length!==after.size||fields.some(function(k){return before[k]!==after[k];}))fail('JPEG_FINALIZATION_PENDING','Photoshop vẫn đang hoàn tất JPEG.');return{bytes:bytes,size:after.size,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),identity:JSON.stringify(fields.map(function(k){return after[k];}))};}
    function jpegStage(ctx,p){if(p.kind!=='mockup'||!/^[a-f0-9]{32}$/.test(p.jpegToken||''))fail('STATE','Lượt JPEG chưa có thư mục tạm riêng hợp lệ.');if(p.jpegStageLocation&&p.jpegStageLocation!=='appdata-web-v1')fail('STATE','Vị trí cache JPEG không hợp lệ.');var dir=plain(p.jpegStageLocation==='appdata-web-v1'?path.join(jpegStageRoot,p.jpegToken):path.join(ctx.folder,'.uoy-save-task-'+p.jpegToken),true);if(!fs.lstatSync(dir).isDirectory())fail('PATH','Thư mục tạm JPEG không hợp lệ.');return{dir:dir,raw:plain(path.join(dir,'raw.jpg'),false)};}
    function sameProof(a,b){return a.size===b.size&&a.sha256===b.sha256;}
    function stageOwner(ctx,p){return{version:1,token:p.jpegToken,sku:ctx.sku,designer:ctx.designer,name:p.name,exportRoot:plain(output,false),stagingLocation:'appdata-web-v1'};}
    function cleanupJpeg(ctx,p){
      // Only the current verified upload owns these exact generated files.
      // Never recurse, follow a link, clear a SKU, or let cleanup retry upload.
      if(p.kind!=='mockup'||p.jpegWebProfile!=='web-jpeg-v1'||p.jpegStageLocation!=='appdata-web-v1')return{status:'legacy-retained'};
      try{
        var stage=jpegStage(ctx,p),ownerPath=plain(path.join(stage.dir,'owner.json'),true),owner=bytesProof(ownerPath);
        if(owner.size>4096||JSON.stringify(JSON.parse(owner.bytes.toString('utf8')))!==JSON.stringify(stageOwner(ctx,p)))return{status:'retained',reason:'owner-mismatch'};
        if(!p.jpegSnapshot||!/^frozen-[a-f0-9]{32}\.jpg$/.test(p.jpegSnapshot.name||''))return{status:'retained',reason:'snapshot-missing'};
        var names=fs.readdirSync(stage.dir).sort(),expected=['owner.json','raw.jpg',p.jpegSnapshot.name].sort();
        if(JSON.stringify(names)!==JSON.stringify(expected))return{status:'retained',reason:'unknown-child'};
        var frozenPath=plain(path.join(stage.dir,p.jpegSnapshot.name),true),raw=bytesProof(stage.raw),frozen=bytesProof(frozenPath),published=bytesProof(assetPath(ctx,p.name));
        if(!sameProof(raw,p.jpegSnapshot)||!sameProof(frozen,p.jpegSnapshot)||!sameProof(published,p.jpegSnapshot))return{status:'retained',reason:'bytes-changed'};
        var files=[{file:stage.raw,proof:raw},{file:frozenPath,proof:frozen},{file:ownerPath,proof:owner}];
        for(var i=0;i<files.length;i++){var current=bytesProof(files[i].file);if(!sameProof(current,files[i].proof)||current.identity!==files[i].proof.identity)return{status:'retained',reason:'changed-during-cleanup'};fs.unlinkSync(files[i].file);}
        plain(stage.dir,true);fs.rmdirSync(stage.dir);return{status:'removed'};
      }catch(error){return{status:'retained',reason:error.code||'cleanup-unavailable'};}
    }
    async function finalizeJpeg(ctx,s){
      var p=s.pending,stage=jpegStage(ctx,p),target=assetPath(ctx,p.name),parser=proofModule('jpegFinalizeProof','UOYTaskJpegFinalizeProof','jpeg-finalize-proof.js');
      if(p.jpegPhase!=='finalizing'||p.jpegNativeClosed!==true||!Number.isFinite(p.jpegClosedAt)||p.jpegClosedAt<0)fail('STATE','Chưa xác nhận Photoshop đã đóng bản xuất JPEG; không tự công bố file.');
      // A saved snapshot is journaled before exclusive publication, so a crash
      // after publication can resume only these exact bytes, never an unknown file.
      if(fs.existsSync(target)){if(!p.jpegSnapshot)fail('EXISTS','Tên mockup đã có file khác; không ghi đè.');var existing=bytesProof(target);if(!sameProof(existing,p.jpegSnapshot))fail('CHANGED','File mockup đích khác bản snapshot đã ghi nhận; không ghi đè.');p.size=existing.size;p.sha256=existing.sha256;p.status='ready';p.jpegPhase='published';write(ctx,s);return;}
      if(typeof options.progress==='function')options.progress(p.jpegWebProfile==='web-jpeg-v1'?'Đang chốt ảnh Save for Web…':'Đang hoàn tất JPEG và giữ nguyên Content Credentials nếu đã có…');
      var started=jpegNow(),lastKey='',quietSince=started,lastReason='',candidate=null,copyAttempts=0;
      while(jpegNow()-started<=16000){
        try{candidate=bytesProof(stage.raw);var info=parser.inspect(candidate.bytes),now=jpegNow(),signature=candidate.sha256+'|'+candidate.identity;if(signature!==lastKey){lastKey=signature;quietSince=now;}
          // Credentials are optional. Only physically incomplete JPEG framing
          // blocks publication; opaque/unfinished semantic credentials are
          // retained byte-for-byte with an advisory after the finite grace.
          var completed=info&&info.jpegComplete===true,web=p.jpegWebProfile==='web-jpeg-v1',grace=web||info&&info.c2pa==='complete'||now-p.jpegClosedAt>=15000;
          lastReason=info&&info.reason||'JPEG hoặc Content Credentials chưa ghi xong.';
          if(completed&&grace&&now-quietSince>=500){
            if(++copyAttempts>3)fail('JPEG_SNAPSHOT_BUSY','JPEG tiếp tục đổi trong lúc chốt ảnh; giữ tối đa ba bản tạm. Bấm lại Save mockup để kiểm tra cùng ảnh, không xuất ảnh mới.');
            var copyName='frozen-'+crypto.randomBytes(16).toString('hex')+'.jpg',copy=plain(path.join(stage.dir,copyName),false);
            // This is a NEW inode, never a rename or hardlink of Adobe's raw
            // exporter-owned file. Late Adobe writes can touch only raw.jpg.
            fs.writeFileSync(copy,candidate.bytes,{flag:'wx'});var frozen=bytesProof(copy),rawAfter=bytesProof(stage.raw);
            if(!sameProof(candidate,frozen)||!sameProof(candidate,rawAfter)||candidate.identity!==rawAfter.identity){lastKey='';candidate=null;await jpegSleep(100);continue;}
            p.jpegSnapshot={name:copyName,size:frozen.size,sha256:frozen.sha256,c2pa:info.c2pa};
            p.jpegAdvisory=!web&&info.c2pa!=='complete'?'JPEG đã chốt sau 15 giây; Content Credentials chưa được xác nhận hoàn tất tại thời điểm chốt. Mọi byte hiện có và bản tạm đều được giữ; dữ liệu Adobe thêm về sau không nằm trong ảnh đã upload.':'';write(ctx,s);
            try{if(typeof fs.linkSync==='function')fs.linkSync(copy,target);else fs.copyFileSync(copy,target,fs.constants.COPYFILE_EXCL);}catch(e){if(['EPERM','ENOTSUP','EOPNOTSUPP','ENOSYS','EXDEV'].indexOf(e.code)<0)throw e;fs.copyFileSync(copy,target,fs.constants.COPYFILE_EXCL);}
            var published=bytesProof(target);if(!sameProof(frozen,published))fail('CHANGED','Bản JPEG đích khác snapshot; giữ nguyên để kiểm tra, chưa upload.');
            p.size=published.size;p.sha256=published.sha256;p.status='ready';p.jpegPhase='published';write(ctx,s);return;
          }
        }catch(error){if(error.code!=='JPEG_FINALIZATION_PENDING'&&error.code!=='ENOENT')throw error;lastReason=error.message;lastKey='';}
        await jpegSleep(100);
      }
      fail('JPEG_FINALIZATION_PENDING','JPEG/Content Credentials vẫn chưa hoàn tất: '+lastReason+' Bản tạm được giữ. Bấm lại Save mockup để tiếp tục kiểm tra cùng ảnh, không xuất ảnh mới.');
    }
    async function recoverC2pa(ctx,s,file){
      var p=s.pending,current=bytesProof(file),module=proofModule('jpegMetadataProof','UOYTaskJpegProof','jpeg-metadata-proof.js'),proof;
      try{proof=module.proofInsertedC2pa(current.bytes,p.size,p.sha256);}catch(_){return false;}
      if(!proof||proof.kind!=='c2pa-app11-insertion'||proof.oldSize!==p.size||proof.oldSHA!==p.sha256||proof.currentSize!==current.size||proof.currentSHA!==current.sha256)return false;
      var archiveDir=plain(path.join(ctx.dir,'recovery'),false);fs.mkdirSync(archiveDir,{recursive:true});
      var archive=plain(path.join(archiveDir,'jpeg-receipt-'+crypto.randomBytes(16).toString('hex')+'.json'),false),record={version:1,reason:'exact-c2pa-insertion-and-authoritative-remote-absence',sku:ctx.sku,designer:ctx.designer,scope:s.scope,folderId:s.folderId,pending:JSON.parse(JSON.stringify(p)),proof:proof};
      fs.writeFileSync(archive,JSON.stringify(record),{flag:'wx',encoding:'utf8'});
      if(!sameProof(current,bytesProof(file)))fail('CHANGED','JPEG tiếp tục thay đổi trong lúc xác minh metadata; biên nhận cũ được giữ.');
      p.size=current.size;p.sha256=current.sha256;p.uploadId=uuid();p.status='ready';p.jpegMetadataRecovery=true;p.jpegRecoveryArchive=path.basename(archive);write(ctx,s);return true;
    }
    function digest(file){plain(file,true);return new Promise(function(resolve,reject){var h=crypto.createHash('sha256'),s=fs.createReadStream(file);s.on('data',function(b){h.update(b);});s.on('error',reject);s.on('end',function(){resolve(h.digest('hex'));});});}
    async function fingerprint(file,code,message){plain(file,true);var before=fs.lstatSync(file);if(!before.isFile()||before.size<1)fail(code,message);var hash=await digest(file);plain(file,true);var after=fs.lstatSync(file),fields=['size','mtimeMs','ctimeMs','birthtimeMs','dev','ino','mode'];if(!after.isFile()||fields.some(function(key){return before[key]!==after[key];}))fail(code,message);return{size:after.size,sha256:hash};}
    function key(value){return crypto.createHash('sha256').update(value.toLowerCase()).digest('hex');}
    function context(args){var sku=segment(args.sku,'SKU'),designer=segment(args.designer,'Tên',100),folder=plain(path.join(output,sku),false),privateDir=plain(path.join(privateRoot,key(sku)),false);plain(output,false);plain(privateRoot,false);return{sku:sku,designer:designer,folder:folder,dir:privateDir,file:path.join(privateDir,'state.json'),raw:null};}
    function load(ctx){
      if(!fs.existsSync(ctx.file))return{version:background?10:9,sku:ctx.sku,designer:ctx.designer,scope:null,folderId:null,link:'',files:{},pending:null,types:['','','',''],...(background?{jobs:[]}:{} )};
      plain(ctx.file,true);if(fs.statSync(ctx.file).size>1024*1024)fail('STATE','Biên nhận Save Task quá lớn.');ctx.raw=fs.readFileSync(ctx.file,'utf8');var s=JSON.parse(ctx.raw);
      if((s.version!==9&&!(background&&s.version===10))||typeof s.sku!=='string'||s.sku.toLowerCase()!==ctx.sku.toLowerCase()||typeof s.designer!=='string'||s.designer.toLowerCase()!==ctx.designer.toLowerCase()||!s.files||typeof s.files!=='object'||Array.isArray(s.files)||Object.keys(s.files).length>512||!Array.isArray(s.types)||s.types.length!==4)fail('STATE','SKU local thuộc tên khác hoặc biên nhận chưa hợp lệ; giữ nguyên file.');
      Object.keys(s.files).forEach(function(name){assetPath(ctx,name);var r=s.files[name];if(!r||!Number.isSafeInteger(r.size)||r.size<1||!/^[a-f0-9]{64}$/.test(r.sha256))fail('STATE','Biên nhận file chưa hợp lệ.');});
      if(s.pending){assetPath(ctx,s.pending.name);if(!['psd','fullprint','mockup','fonts'].includes(s.pending.kind)||!['exporting','ready','uploading','uncertain','export_failed'].includes(s.pending.status))fail('STATE','Lượt Save trước chưa hợp lệ.');if(!['exporting','export_failed'].includes(s.pending.status)&&(!Number.isSafeInteger(s.pending.size)||s.pending.size<1||!/^[a-f0-9]{64}$/.test(s.pending.sha256||'')))fail('STATE','Biên nhận file chờ chưa đủ size/SHA-256; không tự xác nhận hay upload.');if(s.pending.uploadId&&!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(s.pending.uploadId))fail('STATE','Mã upload đã lưu không hợp lệ; không tự tạo giao dịch khác.');}
      if(s.pending&&s.pending.jpegPhase){var j=s.pending;if(j.kind!=='mockup'||!['exporting','finalizing','published'].includes(j.jpegPhase)||!/^[a-f0-9]{32}$/.test(j.jpegToken||''))fail('STATE','Biên nhận staging JPEG chưa hợp lệ.');if(j.jpegPhase!=='exporting'&&(j.jpegNativeClosed!==true||!Number.isFinite(j.jpegClosedAt)||j.jpegClosedAt<0))fail('STATE','Chưa có xác nhận đóng bản xuất JPEG.');if(j.jpegSnapshot&&(!/^frozen-[a-f0-9]{32}\.jpg$/.test(j.jpegSnapshot.name||'')||!Number.isSafeInteger(j.jpegSnapshot.size)||j.jpegSnapshot.size<1||!/^[a-f0-9]{64}$/.test(j.jpegSnapshot.sha256||'')))fail('STATE','Biên nhận snapshot JPEG chưa hợp lệ.');}
      if(s.pending&&s.pending.jpegStageLocation&&s.pending.jpegStageLocation!=='appdata-web-v1')fail('STATE','Vị trí staging JPEG chưa được hỗ trợ.');
      if(s.pending&&s.pending.jpegWebProfile&&(s.pending.kind!=='mockup'||s.pending.jpegWebProfile!=='web-jpeg-v1'||s.pending.jpegStageLocation!=='appdata-web-v1'))fail('STATE','Profile Save for Web chưa hợp lệ.');
      if(background){
        if(s.version===9)s.jobs=[];
        else if(!Array.isArray(s.jobs)||s.jobs.length>512)fail('STATE','Hàng đợi Save Task không hợp lệ; giữ nguyên biên nhận.');
        var ids=Object.create(null),jobNames=Object.create(null),uploadIds=Object.create(null);s.jobs.forEach(function(j){
          if(!j||typeof j.name!=='string'||!/^[a-f0-9]{32}$/.test(j.jobId||'')||ids[j.jobId]||!['psd','fullprint','mockup','fonts'].includes(j.kind)||!['ready','uploading','uncertain','complete'].includes(j.status)||!Number.isSafeInteger(j.size)||j.size<1||!/^[a-f0-9]{64}$/.test(j.sha256||'')||!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(j.uploadId||''))fail('STATE','Biên nhận hàng đợi chưa hợp lệ; không tự upload.');
          ids[j.jobId]=true;assetPath(ctx,j.name);if(jobNames[j.name.toLowerCase()]||uploadIds[j.uploadId])fail('STATE','Hàng đợi trùng tên file hoặc mã upload; giữ nguyên biên nhận.');jobNames[j.name.toLowerCase()]=true;uploadIds[j.uploadId]=true;
          if(j.jpegPhase){if(j.kind!=='mockup'||j.jpegPhase!=='published'||!/^[a-f0-9]{32}$/.test(j.jpegToken||'')||j.jpegNativeClosed!==true||!Number.isFinite(j.jpegClosedAt)||j.jpegClosedAt<0)fail('STATE','Biên nhận JPEG hàng đợi chưa hoàn tất.');if(j.jpegSnapshot&&(!/^frozen-[a-f0-9]{32}\.jpg$/.test(j.jpegSnapshot.name||'')||!Number.isSafeInteger(j.jpegSnapshot.size)||j.jpegSnapshot.size!==j.size||!/^[a-f0-9]{64}$/.test(j.jpegSnapshot.sha256||'')||j.jpegSnapshot.sha256!==j.sha256))fail('STATE','Snapshot JPEG hàng đợi chưa hợp lệ.');}
          if(j.jpegStageLocation&&j.jpegStageLocation!=='appdata-web-v1')fail('STATE','Vị trí JPEG hàng đợi không hợp lệ.');if(j.jpegWebProfile&&(j.kind!=='mockup'||j.jpegWebProfile!=='web-jpeg-v1'||j.jpegStageLocation!=='appdata-web-v1'||!j.jpegSnapshot))fail('STATE','Profile JPEG hàng đợi không hợp lệ.');
          if(String(j.folderId)!==String(s.folderId)||j.link!==s.link||!j.scope||!s.scope||['anchor','year','day'].some(function(k){return j.scope[k]!==s.scope[k];}))fail('STATE','Đích hàng đợi khác biên nhận SKU; không tự đổi đích.');
        });knownContexts[key(ctx.sku)]={sku:ctx.sku,designer:ctx.designer};
      }
      return s;
    }
    function assetPath(ctx,name){var parts=String(name).split('/');if(parts.length===2&&parts[0]==='Fonts'&&/\.(?:otf|ttf|ttc|otc)$/i.test(parts[1]))segment(parts[1],'Tên font',240);else if(parts.length!==1||name.toLowerCase().indexOf((ctx.sku+'__').toLowerCase())!==0||!/\.(?:psd|png|jpg)$/i.test(name))fail('PATH','File nằm ngoài tài nguyên SKU.');else segment(name,'Tên file',240);return plain(path.join(ctx.folder,...parts),false);}
    function write(ctx,s){
      fs.mkdirSync(plain(ctx.dir,false),{recursive:true});plain(ctx.file,false);
      if(ctx.raw===null&&fs.existsSync(ctx.file)||ctx.raw!==null&&(!fs.existsSync(ctx.file)||fs.readFileSync(ctx.file,'utf8')!==ctx.raw))fail('STATE_CHANGED','Biên nhận đã đổi; giữ nguyên để kiểm tra.');
      var raw=JSON.stringify(s),temp=path.join(ctx.dir,'state-'+crypto.randomBytes(12).toString('hex')+'.tmp');fs.writeFileSync(temp,raw,{flag:'wx',encoding:'utf8'});try{fs.renameSync(temp,ctx.file);ctx.raw=raw;}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}
    }
    function locked(args,work){var ctx=context(args);fs.mkdirSync(plain(privateRoot,false),{recursive:true});var lock=plain(path.join(privateRoot,'lock-'+key(ctx.sku)+'.json'),false),nonce=crypto.randomBytes(16).toString('hex'),proc=options.process||process,body=JSON.stringify({nonce:nonce,pid:proc.pid,sku:ctx.sku});
      function reserve(attempt){try{fs.writeFileSync(lock,body,{flag:'wx'});return;}catch(e){if(e.code!=='EEXIST')throw e;}
        if(attempt>=2)fail('BUSY','SKU đang được xử lý ở panel khác; không chạy chồng.');plain(lock,true);var info=fs.lstatSync(lock);if(!info.isFile()||info.size>2048)fail('LOCK','Khóa Save Task không hợp lệ; giữ nguyên để kiểm tra.');var oldRaw=fs.readFileSync(lock,'utf8'),old;try{old=JSON.parse(oldRaw);}catch(_){fail('LOCK','Khóa Save Task không hợp lệ; giữ nguyên để kiểm tra.');}
        if(!old||Object.keys(old).sort().join(',')!=='nonce,pid,sku'||!/^[a-f0-9]{32}$/.test(old.nonce)||!Number.isSafeInteger(old.pid)||old.pid<1||old.sku!==ctx.sku)fail('LOCK','Khóa Save Task không hợp lệ; giữ nguyên để kiểm tra.');var exited=false;try{proc.kill(old.pid,0);}catch(e){if(e.code==='ESRCH')exited=true;}
        if(!exited)fail('BUSY','SKU này đang có lượt Save khác. Nếu panel cũ bị kẹt, lưu việc và tự mở lại Photoshop; không chạy chồng.');plain(lock,true);var now=fs.lstatSync(lock);if(now.ino!==info.ino||now.dev!==info.dev||fs.readFileSync(lock,'utf8')!==oldRaw)fail('BUSY','Khóa SKU vừa đổi; không lấy khóa của panel khác.');var recovery=plain(path.join(privateRoot,'recovery'),false);fs.mkdirSync(recovery,{recursive:true});fs.renameSync(lock,path.join(recovery,'lock-'+old.nonce+'-'+nonce+'.json'));reserve(attempt+1);
      }reserve(0);
      return Promise.resolve().then(function(){return work(ctx,load(ctx));}).finally(function(){plain(lock,true);if(fs.readFileSync(lock,'utf8')===body)fs.unlinkSync(lock);});
    }
    function resolved(ctx,s,result){if(!result||!/^\d+$/.test(String(result.folderId))||result.link!=='https://files.uoymedia.com/shared/'+String(result.folderId)||!Array.isArray(result.names)||result.names.length>10000||!result.scope||result.scope.anchor!=='01_TASK'||!/^20\d{2}$/.test(result.scope.year)||!/^T(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$/.test(result.scope.day))fail('REMOTE','Hệ thống chưa xác nhận folder SKU.');if(s.folderId&&s.folderId!==String(result.folderId))fail('REMOTE_CHANGED','Folder SKU trên hệ thống khác biên nhận đã lưu; chưa tự đổi đích upload.');s.scope=result.scope;s.folderId=String(result.folderId);s.link=result.link;write(ctx,s);return result;}
    function localNames(ctx){if(!fs.existsSync(ctx.folder))return[];plain(ctx.folder,true);if(!fs.statSync(ctx.folder).isDirectory())fail('PATH','Đường dẫn SKU không phải folder.');return fs.readdirSync(ctx.folder).filter(function(n){return fs.lstatSync(plain(path.join(ctx.folder,n),true)).isFile();});}
    function uploadPending(ctx,s,prepared,freshExport){var p=s.pending;if(!p||p.status==='exporting'||p.status==='export_failed')fail('PENDING','Lượt xuất trước chưa có biên nhận nội dung ổn định. Giữ file để kiểm tra Photoshop và xử lý biên nhận; không tự upload file có thể còn thiếu. Bấm Save lặp lại không xác nhận được lượt này. Có thể tiếp tục SKU khác.');
      var file=assetPath(ctx,p.name),missing=!fs.existsSync(file),localChanged=false,reconciled=false;
      return Promise.resolve().then(async function(){
        // A fresh export has just been fingerprinted above. The Python bridge
        // still verifies its bytes before any POST; avoid a redundant CEP hash
        // pass here. Recovery/retries retain their full local SHA comparison.
        if(!missing){if(!fs.lstatSync(file).isFile()||fs.lstatSync(file).size!==p.size)localChanged=true;else if(!freshExport)try{var current=await fingerprint(file,'CHANGED','File local thay đổi trong lúc kiểm tra.');localChanged=current.sha256!==p.sha256;}catch(error){if(error.code==='CHANGED'||error.code==='ENOENT'){missing=!fs.existsSync(file);localChanged=!missing;}else throw error;}}
        var payload={name:path.basename(file),size:p.size,sha256:p.sha256};if(p.kind==='fonts')payload.subfolder='Fonts';
        var args={designer:ctx.designer,sku:ctx.sku,scope:s.scope,folderId:s.folderId,exportRoot:plain(output,false),files:[payload]};
        if(missing||localChanged||prepared.names.some(function(n){return n.toLowerCase()===p.name.toLowerCase();})){
          if(typeof remote.reconcile!=='function')fail(localChanged?'CHANGED':'UNCERTAIN','Cần xác nhận biên nhận cũ trên hệ thống trước khi xử lý file local. Chưa hỗ trợ đối chiếu nội dung; không tự upload lại.');
          if(typeof options.progress==='function')options.progress('Đang đối chiếu SHA-256 của '+p.name+' trên hệ thống; không upload trùng…');
          if(typeof options.networkPhase==='function')options.networkPhase();
          var result,metadataRecoveredNow=false;try{result=await remote.reconcile(args);}catch(error){if(error.code==='REMOTE_MISSING'&&localChanged){if(p.kind==='mockup'&&!prepared.names.some(function(n){return n.toLowerCase()===p.name.toLowerCase();})&&await recoverC2pa(ctx,s,file)){payload.size=p.size;payload.sha256=p.sha256;localChanged=false;metadataRecoveredNow=true;}else fail('CHANGED','File local đã khác biên nhận cũ và chưa tìm thấy bản đúng biên nhận trên hệ thống. Không upload file khác dưới lượt cũ.');}else throw error;}
          if(result){var verified=result.verified;if(String(result.folderId)!==s.folderId||result.link!==s.link||!result.scope||['anchor','year','day'].some(function(k){return result.scope[k]!==s.scope[k];})||!Array.isArray(verified)||verified.length!==1||verified[0].name!==p.name||verified[0].size!==p.size||verified[0].sha256!==p.sha256||!/^[1-9][0-9]{0,19}$/.test(String(verified[0].fileId)))fail('UNCERTAIN','Chưa xác nhận đúng nội dung file trên hệ thống; không tự upload lại.');reconciled=true;return{folderId:s.folderId,uploaded:[p.name]};}
          else if(!metadataRecoveredNow)fail('UNCERTAIN','Chưa có kết quả đối chiếu nội dung trên hệ thống.');
        }
        if(!p.uploadId)p.uploadId=uuid();
        args.uploadId=p.uploadId;p.status='uploading';p.uploadStartedAt=Date.now();write(ctx,s);if(typeof options.networkPhase==='function')options.networkPhase();if(typeof options.progress==='function')options.progress('Đang upload '+p.name+'… Bạn có thể tiếp tục làm việc trong Photoshop; giữ panel mở và không bấm Save lặp lại.');payload.path=file;return remote.upload(args);
      }).then(function(result){if(!result||String(result.folderId)!==s.folderId||!Array.isArray(result.uploaded)||result.uploaded.length!==1||result.uploaded[0]!==p.name)fail('REMOTE','Chưa nhận xác nhận đúng file vừa upload.');
        s.files[p.name]={kind:p.kind,size:p.size,sha256:p.sha256,sourcePath:p.sourcePath||'',uploaded:true};if(p.jpegSnapshot)s.files[p.name].jpegSnapshot=p.jpegSnapshot;if(p.jpegWebProfile){s.files[p.name].jpegWebProfile=p.jpegWebProfile;s.files[p.name].jpegToken=p.jpegToken;s.files[p.name].jpegStageLocation=p.jpegStageLocation;}if(p.jpegMetadataRecovery)s.files[p.name].jpegMetadataRecovery=true;s.pending=null;write(ctx,s);var cleanup=cleanupJpeg(ctx,p);return{file:file,name:p.name,folder:ctx.folder,link:s.link,uploaded:true,retried:!!p.retry,reconciled:reconciled,localMissing:!fs.existsSync(file),localChanged:localChanged,jpegAdvisory:p.jpegAdvisory||'',jpegMetadataRecovery:!!p.jpegMetadataRecovery,jpegStageCleanup:cleanup};
      }).catch(function(e){p.status='uncertain';p.lastUploadError={at:Date.now(),code:/^[A-Z0-9_]{1,64}$/.test(e.code||'')?e.code:'REMOTE_FAILED'};if(/^(?:listing|destination|single-upload|multipart-init|multipart-part(?:-[1-9][0-9]{0,5})?|multipart-complete|remote-content-read|reconcile)$/.test(e.stage||''))p.lastUploadError.stage=e.stage;if(Number.isInteger(e.httpStatus)&&e.httpStatus>=100&&e.httpStatus<=599)p.lastUploadError.httpStatus=e.httpStatus;write(ctx,s);var permanent=['CHANGED','REMOTE_CONTENT_MISMATCH','REMOTE_AMBIGUOUS','REMOTE_NAME_MISMATCH','WRONG_PARENT','FOLDER_CHANGED','UNCERTAIN'].indexOf(e.code)>=0||e.code==='REMOTE_MISSING'&&(missing||localChanged);e.message+=(fs.existsSync(file)?' File local được giữ: ':' Không còn thấy file local tại: ')+file+(permanent?'. Giữ nguyên biên nhận; mở folder SKU bằng Copy link để kiểm tra bản đã upload tay hoặc nhờ xử lý biên nhận. Bấm Save lặp lại không thay thế được bản cũ. Có thể tiếp tục SKU khác.':'. Bấm lại '+(p.kind==='fonts'?'Xuất font':'đúng nút Save')+' khi kết nối ổn định để đối chiếu file này; không xuất số mới hoặc upload chồng.');throw e;});
    }
    // R78: local exports remain exclusive and serial. Upload receipts own an
    // exact, never-overwritten filename/hash and commit with a fresh short lock.
    // No network callback retains a mutable canonical state object.
    function queueEvent(type,identity,p,extra){var event={type:type,sku:identity.sku,designer:identity.designer,name:p&&p.name||'',jobId:p&&p.jobId||'',pending:p&&p.status||''};if(extra)Object.keys(extra).forEach(function(k){event[k]=extra[k];});try{if(typeof options.queueEvent==='function')options.queueEvent(event);}catch(_){}return event;}
    function shortState(identity,work){var started=Date.now();function attempt(){return Promise.resolve().then(function(){return locked(identity,work);}).catch(function(error){if(error.code!=='BUSY'||Date.now()-started>120000)throw error;return new Promise(function(resolve){setTimeout(resolve,25);}).then(attempt);});}return attempt();}
    function jobTransaction(identity,id,change){return shortState(identity,function(ctx,s){var p=(s.jobs||[]).find(function(j){return j.jobId===id;});if(!p)fail('QUEUE_CHANGED','Biên nhận upload không còn khớp; chưa tự xử lý.');var result=change(ctx,s,p);write(ctx,s);return result;});}
    function sameDestination(p,result){if(!result||String(result.folderId)!==String(p.folderId)||result.link!==p.link||!Array.isArray(result.names)||!result.scope||['anchor','year','day'].some(function(k){return result.scope[k]!==p.scope[k];}))fail('REMOTE_CHANGED','Folder SKU khác biên nhận hàng đợi; không tự đổi đích upload.');return result;}
    function backgroundProgress(identity,p){return function(message){queueEvent('progress',identity,p,{message:message});try{if(typeof options.backgroundProgress==='function')options.backgroundProgress(message,{sku:identity.sku,designer:identity.designer,name:p.name,jobId:p.jobId});}catch(_){}};}
    function networkClaim(identity,jobId){var ctx=context(identity),file=plain(path.join(privateRoot,'network-'+key(ctx.sku)+'.json'),false),nonce=crypto.randomBytes(16).toString('hex'),proc=options.process||process,record={nonce:nonce,pid:proc.pid,sku:ctx.sku,jobId:jobId,children:[],released:false},body=JSON.stringify(record),removed=false;
      fs.mkdirSync(plain(privateRoot,false),{recursive:true});
      function exited(pid){if(pid===proc.pid)return false;try{proc.kill(pid,0);}catch(error){return error.code==='ESRCH';}return false;}
      function valid(value){return value&&Object.keys(value).sort().join(',')==='children,jobId,nonce,pid,released,sku'&&/^[a-f0-9]{32}$/.test(value.nonce)&&/^[a-f0-9]{32}$/.test(value.jobId)&&Number.isSafeInteger(value.pid)&&value.pid>0&&value.sku===ctx.sku&&typeof value.released==='boolean'&&Array.isArray(value.children)&&value.children.length<=16&&value.children.every(function(child){return child&&Object.keys(child).sort().join(',')==='closed,pid'&&Number.isSafeInteger(child.pid)&&child.pid>0&&typeof child.closed==='boolean';});}
      function quiescent(value){return value.children.every(function(child){return child.closed||exited(child.pid);});}
      function readOwned(){if(removed)return false;plain(file,true);var info=fs.lstatSync(file);if(!info.isFile()||info.size>8192||fs.readFileSync(file,'utf8')!==body)fail('LOCK','Khóa upload đã đổi; không sửa hoặc xóa khóa của panel khác.');return info;}
      function update(){var before=readOwned();if(!before)return;var next=JSON.stringify(record),temp=plain(path.join(privateRoot,'network-update-'+nonce+'-'+crypto.randomBytes(8).toString('hex')+'.tmp'),false);fs.writeFileSync(temp,next,{flag:'wx',encoding:'utf8'});try{var now=readOwned();if(now.ino!==before.ino||now.dev!==before.dev)fail('LOCK','Danh tính khóa upload vừa đổi; giữ nguyên.');fs.renameSync(temp,file);body=next;}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}}
      function remove(){if(!readOwned())return;fs.unlinkSync(file);removed=true;}
      function reserve(attempt){try{fs.writeFileSync(file,body,{flag:'wx'});return;}catch(error){if(error.code!=='EEXIST')throw error;}
        if(attempt>=2)fail('NETWORK_BUSY','SKU đang upload ở panel khác; biên nhận được giữ nguyên.');plain(file,true);var before=fs.lstatSync(file);if(!before.isFile()||before.size>8192)fail('LOCK','Khóa upload không hợp lệ; giữ nguyên.');var raw=fs.readFileSync(file,'utf8'),old;try{old=JSON.parse(raw);}catch(_){fail('LOCK','Khóa upload không hợp lệ; giữ nguyên.');}
        if(!valid(old))fail('LOCK','Khóa upload cũ thiếu bằng chứng tiến trình con; giữ nguyên, không tự thử lại.');
        if(!old.released&&!exited(old.pid))fail('NETWORK_BUSY','Panel giữ quyền upload vẫn còn chạy; không gửi trùng.');if(!quiescent(old))fail('NETWORK_BUSY','Tiến trình upload trước vẫn chạy hoặc chưa xác minh đã thoát; chưa gửi lại.');
        plain(file,true);var after=fs.lstatSync(file);if(after.ino!==before.ino||after.dev!==before.dev||fs.readFileSync(file,'utf8')!==raw)fail('NETWORK_BUSY','Chủ khóa upload vừa đổi; chưa lấy khóa.');var recovery=plain(path.join(privateRoot,'recovery'),false);fs.mkdirSync(recovery,{recursive:true});fs.renameSync(file,path.join(recovery,'network-'+old.nonce+'-'+nonce+'.json'));reserve(attempt+1);
      }reserve(0);
      function release(){if(removed)return;record.released=true;update();if(quiescent(record))remove();}
      release.onSpawn=function(command,pid){if(removed||record.released||!['prepare','upload','reconcile','link'].includes(command)||!Number.isSafeInteger(pid)||pid<1||record.children.length>=16||record.children.some(function(child){return child.pid===pid&&!child.closed;}))fail('CHILD_TRACKING','Không thể ghi nhận tiến trình upload trước khi gửi yêu cầu.');record.children.push({pid:pid,closed:false});update();};
      release.onClose=function(command,pid){if(removed)return;if(!['prepare','upload','reconcile','link'].includes(command)||!Number.isSafeInteger(pid)||pid<1)fail('CHILD_TRACKING','Thông báo đóng tiến trình upload không hợp lệ.');var child=null;for(var i=record.children.length-1;i>=0;i--)if(record.children[i].pid===pid&&!record.children[i].closed){child=record.children[i];break;}if(!child)return;child.closed=true;update();if(record.released&&quiescent(record))remove();};
      return release;
    }
    async function runJob(identity,id,fresh){
      var p,ctx=context(identity),file,localChanged=false,missing=false,reconciled=false,releaseNetwork=null;
      try{
        releaseNetwork=networkClaim(identity,id);activeJobs[id]=true;
        p=await jobTransaction(identity,id,function(c,s,j){if(j.status==='complete')return null;j.status='uploading';j.uploadStartedAt=Date.now();return JSON.parse(JSON.stringify(j));});
        if(!p)return;queueEvent('uploading',identity,p);
        var progress=backgroundProgress(identity,p);progress.onSpawn=releaseNetwork.onSpawn;progress.onClose=releaseNetwork.onClose;var prepared=sameDestination(p,await remote.prepare({designer:identity.designer,sku:identity.sku,scope:p.scope,exportRoot:plain(output,false)},progress));
        file=assetPath(ctx,p.name);missing=!fs.existsSync(file);
        if(!missing){if(!fs.lstatSync(file).isFile()||fs.lstatSync(file).size!==p.size)localChanged=true;else{try{localChanged=(await fingerprint(file,'CHANGED','File hàng đợi đã thay đổi.')).sha256!==p.sha256;}catch(error){if(error.code==='ENOENT')missing=true;else if(error.code==='CHANGED')localChanged=true;else throw error;}}}
        var payload={name:path.basename(file),size:p.size,sha256:p.sha256};if(p.kind==='fonts')payload.subfolder='Fonts';
        var request={designer:identity.designer,sku:identity.sku,scope:p.scope,folderId:p.folderId,exportRoot:plain(output,false),uploadId:p.uploadId,files:[payload]},result;
        var listed=prepared.names.some(function(n){return n.toLowerCase()===p.name.toLowerCase();});
        if(!fresh||missing||localChanged||listed){
          if(typeof remote.reconcile!=='function')fail('UNCERTAIN','Cần đối chiếu đúng nội dung trước khi xử lý biên nhận này.');
          try{result=await remote.reconcile(request,progress);}catch(error){if(error.code!=='REMOTE_MISSING')throw error;if(missing)throw error;if(localChanged)fail('CHANGED','File local khác biên nhận và hệ thống chưa có bản cũ; không upload thay.');if(listed)fail('UNCERTAIN','Danh sách và đối chiếu hệ thống chưa thống nhất; chưa upload lại.');result=null;}
          if(result){var verified=result.verified;sameDestination(p,result);if(!Array.isArray(verified)||verified.length!==1||verified[0].name!==p.name||verified[0].size!==p.size||verified[0].sha256!==p.sha256||!/^[1-9][0-9]{0,19}$/.test(String(verified[0].fileId)))fail('UNCERTAIN','Chưa xác nhận đúng nội dung cũ; không gửi trùng.');reconciled=true;}
        }
        if(!reconciled){payload.path=file;result=await remote.upload(request,progress);if(!result||String(result.folderId)!==String(p.folderId)||!Array.isArray(result.uploaded)||result.uploaded.length!==1||result.uploaded[0]!==p.name)fail('REMOTE','Chưa nhận xác nhận đúng file trong hàng đợi.');}
        await jobTransaction(identity,id,function(c,s,j){if(['jobId','uploadId','name','kind','productType','sourcePath','size','sha256','folderId','link','jpegToken','jpegPhase','jpegStageLocation','jpegWebProfile','jpegNativeClosed','jpegClosedAt'].some(function(k){return j[k]!==p[k];})||['anchor','year','day'].some(function(k){return j.scope[k]!==p.scope[k];})||JSON.stringify(j.jpegSnapshot)!==JSON.stringify(p.jpegSnapshot))fail('QUEUE_CHANGED','Biên nhận hàng đợi đã đổi; không xác nhận thay.');j.status='complete';j.completedAt=Date.now();j.reconciled=reconciled;delete j.lastUploadError;var saved=s.files[j.name];if(!saved||saved.jobId!==id||saved.sha256!==j.sha256||saved.size!==j.size)fail('QUEUE_CHANGED','Biên nhận file local đã đổi; không ghi đè.');saved.uploaded=true;});
        cleanupJpeg(ctx,p);p.status='complete';queueEvent('uploaded',identity,p,{reconciled:reconciled,localMissing:missing,localChanged:localChanged});
      }catch(error){
        if(releaseNetwork)try{await jobTransaction(identity,id,function(c,s,j){if(j.status==='complete')return;j.status='uncertain';j.lastUploadError={at:Date.now(),code:/^[A-Z0-9_]{1,64}$/.test(error.code||'')?error.code:'REMOTE_FAILED'};});}catch(journalError){error=journalError;}
        if(p&&releaseNetwork)p.status='uncertain';queueEvent('failed',identity,p||{jobId:id},{error:error.message||String(error),code:error.code||'REMOTE_FAILED'});
      }finally{if(releaseNetwork)try{releaseNetwork();}catch(error){queueEvent('failed',identity,p||{jobId:id},{error:error.message||String(error),code:error.code||'LOCK'});}delete activeJobs[id];delete scheduled[id];queueEvent('settled',identity,p||{jobId:id});}
    }
    function scheduleJob(identity,id,fresh){if(scheduled[id])return;scheduled[id]=true;var frozen={sku:identity.sku,designer:identity.designer};networkTail=networkTail.then(function(){return new Promise(function(resolve){if(typeof setImmediate==='function')setImmediate(resolve);else setTimeout(resolve,0);});}).then(function(){return runJob(frozen,id,fresh);}).catch(function(error){delete scheduled[id];queueEvent('failed',frozen,{jobId:id},{error:error.message||String(error)});});}
    function enqueue(ctx,s,fresh,legacy){var p=s.pending;if(!p||p.status!=='ready'||!Number.isSafeInteger(p.size)||!/^[a-f0-9]{64}$/.test(p.sha256||''))fail('PENDING','Chưa có file xuất ổn định để đưa vào hàng đợi.');
      if((s.jobs||[]).length>=512)fail('QUEUE_LIMIT','SKU đã đạt giới hạn biên nhận; giữ nguyên file và kiểm tra hàng đợi.');
      var job=JSON.parse(JSON.stringify(p));job.jobId=crypto.randomBytes(16).toString('hex');job.uploadId=job.uploadId||uuid();job.status='ready';job.scope=JSON.parse(JSON.stringify(s.scope));job.folderId=s.folderId;job.link=s.link;job.createdAt=Date.now();
      if((s.jobs||[]).some(function(old){return old.jobId===job.jobId||old.name.toLowerCase()===job.name.toLowerCase()||old.uploadId===job.uploadId;}))fail('QUEUE_CONFLICT','Tên file hoặc mã upload đã thuộc biên nhận khác; giữ nguyên file và hàng đợi, không ghi đè.');
      if(legacy){job.needsReconcile=true;job.legacyPending=true;var archiveDir=plain(path.join(ctx.dir,'recovery'),false);fs.mkdirSync(archiveDir,{recursive:true});var archiveName='legacy-state-'+job.jobId+'.json';fs.writeFileSync(plain(path.join(archiveDir,archiveName),false),ctx.raw||JSON.stringify(s),{flag:'wx',encoding:'utf8'});job.legacyArchive=archiveName;}
      s.version=10;s.jobs=s.jobs||[];s.jobs.push(job);s.files[job.name]={kind:job.kind,size:job.size,sha256:job.sha256,sourcePath:job.sourcePath||'',uploaded:false,jobId:job.jobId};s.pending=null;write(ctx,s);knownContexts[key(ctx.sku)]={sku:ctx.sku,designer:ctx.designer};
      var result={file:assetPath(ctx,job.name),name:job.name,folder:ctx.folder,link:s.link,queued:true,uploaded:false,jobId:job.jobId,retried:!!legacy,jpegAdvisory:job.jpegAdvisory||''};scheduleJob(ctx,job.jobId,fresh!==false);queueEvent('queued',ctx,job);try{if(typeof options.queued==='function')options.queued(result);}catch(_){}return result;
    }
    function queueStats(args){var result={waiting:0,uploading:0,failed:0,complete:0,total:0};var identities=args?[args]:Object.keys(knownContexts).map(function(k){return knownContexts[k];});identities.forEach(function(identity){var s=load(context(identity));(s.jobs||[]).forEach(function(j){result.total++;if(j.status==='complete')result.complete++;else if(activeJobs[j.jobId])result.uploading++;else if(scheduled[j.jobId])result.waiting++;else result.failed++;});});result.queued=result.waiting;result.running=result.uploading;return result;}
    function retry(args){if(!background)fail('QUEUE_DISABLED','Hàng đợi nền chưa được bật.');return shortState(args,function(ctx,s){if(s.pending)fail('PENDING','Biên nhận Save cũ được giữ nguyên; bấm đúng nút Save cũ để đối chiếu.');var jobs=(s.jobs||[]).filter(function(j){return j.status!=='complete'&&!scheduled[j.jobId];});jobs.forEach(function(j){scheduleJob(ctx,j.jobId,false);queueEvent('queued',ctx,j,{retry:true});});return{queued:true,uploaded:false,count:jobs.length};});}
    async function migratePending(ctx,s){var p=s.pending;if(p.jpegPhase==='finalizing')await finalizeJpeg(ctx,s);
      if(!['ready','uploading','uncertain'].includes(p.status)||!Number.isSafeInteger(p.size)||!/^[a-f0-9]{64}$/.test(p.sha256||''))fail('PENDING','Lượt xuất cũ chưa có biên nhận ổn định; giữ nguyên file, không tự xuất hoặc upload lại.');
      if(!p.uploadId&&p.status!=='ready')fail('PENDING','Biên nhận cũ chưa có mã upload để đối chiếu an toàn; giữ nguyên, không tạo giao dịch mới.');
      if(!s.scope||s.scope.anchor!=='01_TASK'||!/^20\d{2}$/.test(s.scope.year)||!/^T(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$/.test(s.scope.day)||!/^\d+$/.test(String(s.folderId))||s.link!=='https://files.uoymedia.com/shared/'+s.folderId)fail('PENDING','Biên nhận cũ chưa xác nhận đủ thư mục đích; chưa chuyển sang hàng đợi.');
      if(p.jpegSnapshot&&(p.jpegSnapshot.size!==p.size||p.jpegSnapshot.sha256!==p.sha256))fail('PENDING','JPEG cũ cần kiểm tra bằng chứng metadata riêng; giữ nguyên biên nhận, không thay hash hoặc mã upload.');
      p.status='ready';return enqueue(ctx,s,false,true);
    }
    function save(args){return (background?shortState:locked)(args,async function(ctx,s){if(!['psd','mockup','fullprint'].includes(args.kind))fail('KIND','Loại Save không hợp lệ.');if(args.kind==='psd')product(args.productType);
      if(s.pending){if(s.pending.kind!==args.kind||(args.kind==='psd'&&s.pending.productType!==args.productType))fail('PENDING','SKU còn file chờ upload; bấm lại đúng nút Save trước để xử lý, không xuất thêm file trùng.');
        if(s.pending.status==='export_failed'&&!fs.existsSync(assetPath(ctx,s.pending.name))){s.pending=null;write(ctx,s);}else{if(background)return migratePending(ctx,s);var retry=resolved(ctx,s,await remote.prepare({designer:ctx.designer,sku:ctx.sku,scope:s.scope,exportRoot:plain(output,false)}));s.pending.retry=true;if(s.pending.jpegPhase==='finalizing')await finalizeJpeg(ctx,s);return uploadPending(ctx,s,retry);}}
      if(typeof options.progress==='function')options.progress('Đang xác định tài liệu Photoshop đang mở…');var capture=await options.native('capture');if(!capture||!/^\d+$/.test(String(capture.id)))fail('NATIVE','Photoshop chưa xác nhận tài liệu đang mở.');
      if(typeof options.progress==='function')options.progress('Đang kiểm tra folder '+ctx.designer+' / '+ctx.sku+' trên hệ thống…');
      var prepared=resolved(ctx,s,await remote.prepare({designer:ctx.designer,sku:ctx.sku,scope:s.scope,exportRoot:plain(output,false)})),name=nextName(ctx.sku,args.kind,localNames(ctx).concat(prepared.names,background?(s.jobs||[]).filter(function(j){return j.name.indexOf('/')<0;}).map(function(j){return j.name;}):[]),args.productType),file=assetPath(ctx,name);
      fs.mkdirSync(plain(ctx.folder,false),{recursive:true});if(fs.existsSync(file))fail('EXISTS','File đã tồn tại; không ghi đè.');
      s.pending={kind:args.kind,productType:args.productType||'',name:name,status:'exporting',sourcePath:capture.path||''};write(ctx,s);
      var request={kind:args.kind,sku:ctx.sku,productType:args.productType||'',documentId:String(capture.id),exportRoot:plain(output,false),target:file};
      try{if(args.kind==='mockup'){s.pending.jpegToken=crypto.randomBytes(16).toString('hex');s.pending.jpegPhase='exporting';if(capture.mockupExportProfile!==undefined||capture.jpegStageLocation!==undefined){if(capture.mockupExportProfile!=='web-jpeg-v1'||capture.jpegStageLocation!=='appdata-web-v1')fail('NATIVE','Photoshop chưa xác nhận đúng profile Save for Web.');s.pending.jpegStageLocation='appdata-web-v1';request.stagingLocation='appdata-web-v1';request.exportProfile='web-jpeg-v1';fs.mkdirSync(plain(jpegStageRoot,false),{recursive:true});plain(jpegStageRoot,true);}var stageDir=plain(s.pending.jpegStageLocation==='appdata-web-v1'?path.join(jpegStageRoot,s.pending.jpegToken):path.join(ctx.folder,'.uoy-save-task-'+s.pending.jpegToken),false);fs.mkdirSync(stageDir);request.stagingToken=s.pending.jpegToken;request.stagingPath=jpegStage(ctx,s.pending).raw;if(s.pending.jpegStageLocation==='appdata-web-v1')fs.writeFileSync(plain(path.join(stageDir,'owner.json'),false),JSON.stringify(stageOwner(ctx,s.pending)),{flag:'wx',encoding:'utf8'});write(ctx,s);}if(typeof options.progress==='function')options.progress('Đang chờ Photoshop lưu '+name+'…');var report=await options.native('exportAsset',request);
        if(!report||report.path.replace(/\\/g,'/').toLowerCase()!==file.replace(/\\/g,'/').toLowerCase()||report.kind!==args.kind||String(report.documentId)!==String(capture.id))fail('NATIVE','Kết quả Photoshop không khớp tài liệu/file đã chọn.');
        if(args.kind==='mockup'){if(report.stagingToken!==request.stagingToken||typeof report.stagedPath!=='string'||path.resolve(report.stagedPath).toLowerCase()!==path.resolve(request.stagingPath).toLowerCase()||report.workClosed!==true)fail('NATIVE','Photoshop chưa xác nhận đúng bản JPEG tạm đã đóng.');if(s.pending.jpegStageLocation==='appdata-web-v1'){if(report.exportProfile!=='web-jpeg-v1'||report.stagingLocation!=='appdata-web-v1'||report.jpegQuality!==75||report.maxLongEdge!==2000||report.optimized!==true||!Number.isSafeInteger(report.width)||!Number.isSafeInteger(report.height)||Math.min(report.width,report.height)<1||Math.max(report.width,report.height)>2000)fail('NATIVE','Kết quả Save for Web không đúng profile đã yêu cầu; chưa upload.');s.pending.jpegWebProfile='web-jpeg-v1';}s.pending.jpegPhase='finalizing';s.pending.jpegNativeClosed=true;s.pending.jpegClosedAt=jpegNow();write(ctx,s);await finalizeJpeg(ctx,s);}
        else{var proof=await fingerprint(file,'EXPORT_UNSTABLE','File xuất còn thay đổi trong lúc ghi biên nhận; chưa upload. Kiểm tra Photoshop đã ghi xong file trước khi xử lý lượt xuất này.');s.pending.size=proof.size;s.pending.sha256=proof.sha256;s.pending.status='ready';write(ctx,s);}
      }catch(e){if(s.pending.jpegPhase!=='finalizing')s.pending.status='export_failed';write(ctx,s);e.message+=' Không upload file xuất lỗi; giữ nguyên để kiểm tra: '+file;throw e;}
      return background?enqueue(ctx,s):uploadPending(ctx,s,prepared,true);
    });}
    function fonts(args){return (background?shortState:locked)(args,async function(ctx,s){if(s.pending){if(s.pending.kind!=='fonts')fail('PENDING','SKU còn file chờ upload; xử lý lượt Save trước rồi Xuất font.');if(background)return migratePending(ctx,s).then(function(r){return{folder:plain(path.join(ctx.folder,'Fonts'),false),link:r.link,count:0,uploaded:0,queued:true,queuedCount:1,warnings:[]};});var retry=resolved(ctx,s,await remote.prepare({designer:ctx.designer,sku:ctx.sku,scope:s.scope,exportRoot:plain(output,false)}));s.pending.retry=true;var recovered=await uploadPending(ctx,s,retry);if(recovered.localChanged)return{folder:plain(path.join(ctx.folder,'Fonts'),false),link:s.link,count:0,uploaded:0,warnings:['Đã xác nhận đúng font theo biên nhận cũ trên hệ thống. Bản font local đã thay đổi được giữ nguyên và chưa upload; không tự thay thế font đã có.'],reconciled:true,localChanged:true};}
      var files=localNames(ctx).filter(function(n){return n.toLowerCase().indexOf((ctx.sku+'__').toLowerCase())===0&&/\.psd$/i.test(n);}).map(function(n){return assetPath(ctx,n);});
      if(!files.length)fail('FONTS','Hãy Save PSD của SKU trước khi Xuất font.');if(files.length>32)fail('FONTS','SKU vượt giới hạn 32 PSD để gom font.');
      var prepared=resolved(ctx,s,await remote.prepare({designer:ctx.designer,sku:ctx.sku,scope:s.scope,exportRoot:plain(output,false)}));
      var aliases={};files.forEach(function(f){var r=s.files[path.basename(f)];if(r&&r.sourcePath&&/\.ps[db]$/i.test(r.sourcePath))aliases[f]=r.sourcePath;});
      if(typeof options.progress==='function')options.progress('Đang đọc font từ '+files.length+' PSD đã lưu của SKU…');var metadata=await options.psdFonts.readFiles(files,{sourceAliases:aliases}),work=plain(path.join(ctx.dir,'fonts-'+crypto.randomBytes(12).toString('hex')),false);fs.mkdirSync(work);
      var report=await options.fonts.collectFonts({fontNames:metadata.fontNames,outputDir:work}),fontFolder=plain(path.join(ctx.folder,'Fonts'),false),uploads=[];
      fs.mkdirSync(fontFolder,{recursive:true});
      for(var font of report.copied){var name=segment(font.fileName,'Tên font',240),sourceName=name;if(!/\.(?:otf|ttf|ttc|otc)$/i.test(name))fail('FONTS','Bộ font trả file không phải font.');var knownFontName=background?Object.keys(s.files).find(function(n){return n.toLowerCase()===('Fonts/'+name).toLowerCase();}):null;if(knownFontName)name=knownFontName.slice(6);var source=plain(path.join(work,sourceName),true),target=assetPath(ctx,'Fonts/'+name),hash=await digest(source),size=fs.statSync(source).size;
        if(fs.existsSync(target)){if(await digest(target)!==hash)fail('FONT_CONFLICT','Đã có font khác nội dung: '+name+'. Không ghi đè.');}else fs.copyFileSync(source,target,fs.constants.COPYFILE_EXCL);
        var old=s.files['Fonts/'+name];if(!old||old.sha256!==hash||!old.uploaded&&!(background&&old.jobId&&(s.jobs||[]).some(function(j){return j.jobId===old.jobId&&j.sha256===hash;})))uploads.push({path:target,name:name,size:size,sha256:hash,subfolder:'Fonts'});
      }
      for(var upload of uploads){s.pending={kind:'fonts',name:'Fonts/'+upload.name,status:'ready',size:upload.size,sha256:upload.sha256,sourcePath:''};write(ctx,s);if(background)enqueue(ctx,s);else await uploadPending(ctx,s,prepared);}
      var warnings=[];if(metadata.errors.length)warnings.push('Có PSD/Smart Object chưa đọc được font');if(metadata.warnings.length)warnings.push('Có cảnh báo đọc PSD');if(report.missing.length)warnings.push('Thiếu font (có thể là Adobe): '+report.missing.map(function(x){return x.postScriptName||String(x);}).join(', '));if(report.ambiguous.length)warnings.push('Có font nhiều phiên bản; không tự chọn');if(report.errors.length)warnings.push('Có font chưa gom được');
      return{folder:fontFolder,link:s.link,count:report.copied.length,uploaded:background?0:uploads.length,queued:background,queuedCount:background?uploads.length:0,warnings:warnings};
    });}
    function link(args){if(!background)return locked(args,async function(ctx,s){var value=await remote.link({designer:ctx.designer,sku:ctx.sku,scope:s.scope,exportRoot:plain(output,false)});resolved(ctx,s,value);return value.link;});
      var identity={sku:args.sku,designer:args.designer};return shortState(identity,function(ctx,s){return s.scope?JSON.parse(JSON.stringify(s.scope)):null;}).then(function(scope){return remote.link({designer:identity.designer,sku:identity.sku,scope:scope,exportRoot:plain(output,false)},function(){});}).then(function(value){return shortState(identity,function(ctx,s){resolved(ctx,s,value);return value.link;});});}
    function preview(args){var ctx=context(args),file=assetPath(ctx,ctx.sku+'__mockup1.jpg');plain(file,true);var st=fs.statSync(file);if(!st.isFile()||!st.size)fail('PREVIEW','Chưa có mockup1 của SKU; không lấy ảnh mockup khác thay thế.');return file;}
    return{save:save,fonts:fonts,link:link,whenIdle:function(){return networkTail;},queueStats:queueStats,retry:retry,preview:preview,digest:digest,loadTypes:function(args){try{return load(context(args)).types;}catch(_){return['','','',''];}},saveTypes:function(args,types){return (background?shortState:locked)(args,function(ctx,s){if(!Array.isArray(types)||types.length!==4)fail('STATE','Cần đúng 4 ô Product type.');s.types=types.map(function(x){return String(x).slice(0,80);});write(ctx,s);});}};
  }
  function nativeInvoker(options){return function(operation,request){return new Promise(function(resolve,reject){
    var cep=options.window.__adobe_cep__,file=options.path.join(options.panelRoot,'jsx','save-task-active.jsx').replace(/\\/g,'/');
    if(!cep||typeof cep.evalScript!=='function'){reject(new Error('Thiếu kết nối Photoshop CEP.'));return;}
    if(!['capture','exportAsset'].includes(operation)){reject(new Error('Native operation không hợp lệ.'));return;}
    var q=function(v){return JSON.stringify(v).replace(/[\u007f-\uffff]/g,function(ch){return '\\u'+('0000'+ch.charCodeAt(0).toString(16)).slice(-4);});};
    var script='(function(){try{var f=new File('+q(file)+');if(!f.exists)throw new Error("Thieu Save Task active module R12");var a=$.global.UOYTaskActive;if(!a||a.version!=="'+NATIVE_BUILD+'"){$.evalFile(f);a=$.global.UOYTaskActive;}if(!a||a.version!=="'+NATIVE_BUILD+'")throw new Error("Sai native module R12");return a.'+operation+'('+ (request?q(request):'')+');}catch(e){return "ERR: "+String(e);}}())';
    var done=false,warning=setTimeout(function(){if(!done&&typeof options.progress==='function')options.progress('Đang đợi Photoshop trả kết quả. Chưa tự chạy lại lệnh xuất; kiểm tra Photoshop có hộp thoại đang chờ hay không.');},20000);try{cep.evalScript(script,function(raw){if(done)return;done=true;clearTimeout(warning);try{raw=String(raw||'');if(raw.indexOf('OK:')!==0)throw new Error(raw||'Photoshop không trả kết quả; không tự thử xuất lại.');resolve(JSON.parse(raw.slice(3)));}catch(e){reject(e);}});}catch(e){if(!done){done=true;clearTimeout(warning);reject(e);}}
  });};}
  function clipboard(options,text,isImage){return new Promise(function(resolve,reject){
    var literal="'"+String(text).replace(/'/g,"''")+"'",script=isImage?'$ErrorActionPreference="Stop";Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing;$i=[System.Drawing.Image]::FromFile('+literal+');try{[System.Windows.Forms.Clipboard]::SetImage($i)}finally{$i.Dispose()}':'$ErrorActionPreference="Stop";Set-Clipboard -Value '+literal;
    var child=options.cp.spawn('powershell.exe',['-NoProfile','-NonInteractive','-STA','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{shell:false,windowsHide:true,stdio:['ignore','ignore','ignore']}),timer=setTimeout(function(){finish(new Error('Clipboard chưa trả kết quả đúng hạn.'));},15000),done=false;
    function finish(e){if(done)return;done=true;clearTimeout(timer);if(e)reject(e);else resolve();}child.once('error',function(){finish(new Error('Không mở được clipboard Windows.'));});child.once('exit',function(code){finish(code===0?null:new Error('Không copy được vào clipboard; thử lại khi clipboard rảnh.'));});
  });}
  // R78: local Photoshop production and the immutable upload queue have
  // separate lifetimes. Never release another job's production token.
  function mount(options){
    var doc=options.document,$=function(id){return doc.getElementById(id);},foregroundBusy=false,foregroundIdentity=null,lastIdentity='',service,utilityBusy={};
    var inputs=['sku','tenSku','skuType1','skuType2','skuType3','skuType4'];
    var productionButtons=['bSkuPsd1','bSkuPsd2','bSkuPsd3','bSkuPsd4','bSkuFullprint','bSkuMockup','bSkuFonts'];
    var previousQueueEvent=options.queueEvent,previousProgress=options.progress,lastQueueMessage={};
    var queueStatus=null,retryButton=null;
    function args(){return{sku:segment($('sku').value.trim(),'SKU'),designer:segment(($('tenSku').value||options.readName()).trim(),'Tên',100)};}
    function sameSelection(value){try{var now=args();return now.sku===value.sku&&now.designer===value.designer;}catch(_){return false;}}
    function current(value){if(!sameSelection(value))fail('UI_CHANGED','SKU/Tên đã đổi trong lúc xử lý. Không copy kết quả của SKU cũ sang SKU mới.');}
    function status(message,kind){$('skuTaskStatus').textContent=message;options.setStatus(message,kind||'info');}
    function queueControls(){
      // No HTML/main.js change is needed; keep the package scoped to Save Task.
      var anchor=$('skuTaskStatus');
      if(!doc.createElement||!anchor||!anchor.parentNode)return;
      var container=doc.createElement('div');container.id='skuUploadQueue';
      container.style.cssText='margin-top:7px;padding:7px 0;border-top:1px solid #555;';
      queueStatus=doc.createElement('div');queueStatus.id='skuUploadQueueStatus';queueStatus.style.cssText='font-size:11px;color:#9ecaff;line-height:1.5;';
      retryButton=doc.createElement('button');retryButton.id='bSkuRetryUpload';retryButton.type='button';
      retryButton.textContent='Tiếp tục upload đang chờ';retryButton.style.cssText='margin-top:5px;width:100%;display:none;';
      container.appendChild(queueStatus);container.appendChild(retryButton);anchor.parentNode.insertBefore(container,anchor.nextSibling);
      retryButton.addEventListener('click',function(){runUtility('retry','Tiếp tục upload đang chờ',async function(value){
        var result=await service.retry(value);updateQueue();
        if(sameSelection(value))status('Đã đưa '+(result&&result.count||0)+' file vào hàng đợi upload; không xuất lại Photoshop.','info');
      },retryButton);});
    }
    function updateQueue(){
      if(!service||typeof service.queueStats!=='function')return;
      var stats,value;try{value=args();stats=service.queueStats(value);}catch(_){stats={waiting:0,uploading:0,failed:0,total:0};}
      stats=stats||{};var waiting=stats.waiting||0,uploading=stats.uploading||0,failed=stats.failed||0;
      var text='Upload nền: '+uploading+' đang tải · '+waiting+' đang chờ'+(failed?' · '+failed+' cần tiếp tục':'')+'. Có thể lưu file khác.';
      if(!waiting&&!uploading&&!failed)text='Upload nền đã rảnh. File local luôn được giữ.';
      var detail=value&&lastQueueMessage[value.designer+'|'+value.sku];
      if(queueStatus)queueStatus.textContent=text+(waiting||uploading||failed?detail?' '+detail:'':'');
      if(retryButton)retryButton.style.display=failed||waiting&&!uploading?'':'none';
    }
    options.backgroundUploads=true;
    options.queueEvent=function(event){
      if(event&&event.sku&&event.designer){var key=event.designer+'|'+event.sku;
        if(event.type==='progress'&&typeof event.message==='string')lastQueueMessage[key]=event.name+': '+event.message;
        else if(event.type==='failed')lastQueueMessage[key]=(event.name||'File')+' chưa được xác nhận. Giữ file local; bấm Tiếp tục upload để đối chiếu, không xuất lại.';
        else if(event.type==='uploaded')lastQueueMessage[key]='Đã xác nhận '+event.name+'.';
      }
      updateQueue();if(typeof previousQueueEvent==='function')previousQueueEvent(event);
    };
    options.progress=function(message){
      // Only local production uses this callback. Network progress is rendered
      // in the dedicated queue area, never in a later SKU's foreground status.
      if(foregroundBusy&&foregroundIdentity&&sameSelection(foregroundIdentity))status(message,'info');
      if(typeof previousProgress==='function')previousProgress(message);
    };
    options.native=options.native||nativeInvoker(options);
    if(!options.remote)options.requireOwnedChildren=true;
    options.remote=options.remote||options.window.UOYTaskRemote.create(options);
    service=createService(options);
    function clearLink(){$('linkval').value='';$('linkbox').classList.remove('show');}
    function refresh(){var sku=$('sku').value.trim(),designer=($('tenSku').value||options.readName()||'').trim(),identity=designer+'|'+sku;
      $('skuDest').textContent=options.path.join(configuredExportRoot(options),sku||'{SKU}');
      if(identity!==lastIdentity){lastIdentity=identity;clearLink();var types=service.loadTypes({sku:sku,designer:designer});for(var i=0;i<4;i++)$('skuType'+(i+1)).value=types[i]||'';}
      updateQueue();
    }
    async function runProduction(label,extra,action){
      // This short gate is only capture/export/fingerprint, never upload. R12
      // cannot pin an uncaptured click while a different export is in flight.
      if(foregroundBusy)return;
      var value,types;try{value=args();Object.keys(extra||{}).forEach(function(key){value[key]=extra[key];});types=[1,2,3,4].map(function(i){return $('skuType'+i).value.trim();});if(value.kind==='psd')product(value.productType);}catch(e){status(e.message||String(e),'err');return;}
      var token=options.beginAction(label,null);if(!token)return;
      foregroundBusy=true;foregroundIdentity=value;productionButtons.forEach(function(id){$(id).disabled=true;});var released=false;
      function release(){if(!released){released=true;options.endAction(token);}}
      try{options.writeName(value.designer);status(label+'…');await action(value,types);}
      catch(e){if(sameSelection(value))status(e.message||String(e),'err');}
      finally{foregroundBusy=false;foregroundIdentity=null;productionButtons.forEach(function(id){$(id).disabled=false;});release();refresh();}
    }
    async function runUtility(key,label,action,button){
      if(utilityBusy[key])return;var value;try{value=args();}catch(e){status(e.message||String(e),'err');return;}
      utilityBusy[key]=true;if(button)button.disabled=true;
      try{if(!foregroundBusy)status(label+'…');await action(value);}
      catch(e){if(sameSelection(value))status(e.message||String(e),'err');}
      finally{utilityBusy[key]=false;if(button)button.disabled=false;updateQueue();}
    }
    function savedMessage(result){
      if(result.queued)return '✔ Đã lưu local '+result.name+'. Upload chạy nền; bạn có thể lưu file tiếp theo.';
      return '✔ '+(result.reconciled?'Đã đối chiếu bản đã upload: ':'Đã lưu và upload ')+result.name+'. File local được giữ.'+(result.jpegAdvisory?' Lưu ý: '+result.jpegAdvisory:'');
    }
    for(let index=1;index<=4;index++)$('bSkuPsd'+index).addEventListener('click',function(){
      var type=$('skuType'+index).value.trim();runProduction('Save PSD '+index,{kind:'psd',productType:type},async function(value,types){
        await service.saveTypes(value,types);var result=await service.save(value);if(sameSelection(value))status(savedMessage(result),'ok');
      });
    });
    [['bSkuFullprint','fullprint'],['bSkuMockup','mockup']].forEach(function(entry){$(entry[0]).addEventListener('click',function(){
      runProduction('Save '+entry[1],{kind:entry[1]},async function(value){var result=await service.save(value);if(sameSelection(value))status(savedMessage(result),'ok');});
    });});
    $('bSkuFonts').addEventListener('click',function(){runProduction('Gom font của SKU',{},async function(value){
      var result=await service.fonts(value);if(sameSelection(value))status('✔ Gom '+result.count+' font'+(result.queued?'; upload chạy nền.':', upload mới '+result.uploaded+' file.')+(result.warnings.length?' Cảnh báo: '+result.warnings.join('; '):''),result.warnings.length?'info':'ok');
    });});
    $('bSkuPreview').addEventListener('click',function(){runUtility('preview','Copy mockup1',async function(value){
      var file=service.preview(value);current(value);await clipboard(options,file,true);current(value);if(!foregroundBusy)status('✔ Đã copy đúng '+value.sku+'__mockup1.jpg — Ctrl+V vào Base.','ok');
    },$('bSkuPreview'));});
    $('bSkuLink').addEventListener('click',function(){runUtility('link','Lấy link folder SKU',async function(value){
      clearLink();var link=await service.link(value);current(value);$('linkval').value=link;$('linkbox').classList.add('show');await clipboard(options,link,false);current(value);if(!foregroundBusy)status('✔ Đã copy link folder '+value.designer+' / '+value.sku+'.','ok');
    },$('bSkuLink'));});
    inputs.slice(0,2).forEach(function(id){$(id).addEventListener('input',refresh);$(id).addEventListener('change',refresh);});
    if($('tabSku'))$('tabSku').addEventListener('click',refresh);
    queueControls();refresh();return{refresh:refresh,service:service,updateQueue:updateQueue};
  }
  return{build:BUILD,sourceRevision:'20261029-R78',segment:segment,product:product,nextName:nextName,createService:createService,mount:mount,nativeInvoker:nativeInvoker,clipboard:clipboard};
}));


