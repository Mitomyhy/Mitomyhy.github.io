@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-save-task.ps1" -CheckOnly
pause
