MITOM Save Task Pipeline R78 - deferred one-file update

HƯỚNG DẪN NHANH
1. Giải nén toàn bộ ZIP; không chạy trực tiếp trong file ZIP.
2. Chạy Check Save Task.cmd để kiểm tra; bước này không thay đổi file,
   không upload và không cần đóng Photoshop/OrderStudio.
3. Khi tiện, chờ upload cũ hoàn tất, lưu PSD và tự đóng Photoshop cùng
   OrderStudio. Chạy Update Save Task.cmd rồi mở lại panel.
4. Upload nền chỉ tiếp tục khi vẫn giữ panel mở. Sau khi mở lại panel,
   bấm “Tiếp tục upload đang chờ” để đối chiếu và tiếp tục các file chưa xong.
5. Bản vá chỉ thay Save Task; không đổi Order Custom, GPU hay Companion.
   Không tự đóng ứng dụng, quét Base, ghép nối lại hoặc xóa file của bạn.
Đây là ZIP để bạn cài sau, chưa phải xác nhận đã cài vào máy.

This ZIP is for installation later. Do not interrupt your current work.
1. Extract the whole ZIP to an ordinary local folder.
2. Check Save Task.cmd verifies package/dependencies without writing, uploading,
   scanning Base, or requiring Photoshop/OrderStudio to close.
3. When convenient, finish pending Save Task uploads, save your work, and close
   Photoshop and OrderStudio yourself. Run Update Save Task.cmd, then reopen.
   The installer never terminates applications. No Chrome reload or re-pairing.

Only js/save-task-flow.js changes. It requires the exact existing R76 flow,
R76 remote helper and R12 native exporter. Unknown local versions are preserved
and refused; use the matching full managed update if required. Existing main.js
(including R77 Save Fix / Night Light), CPU/GPU, Base/Companion, settings,
exports, fonts, credentials, receipts and installation records are not replaced.
Uses this PC user's APPDATA, not a fixed ADMIN account or drive path.

Save Task behavior and limits:
- Photoshop local exports are serialized; UI need not wait for upload ACK.
- Each accepted local export has its own immutable queued upload job.
- Uploads continue only while this Panel remains open; this is not a detached
  Windows/background service. Do not close it before required uploads finish.
- On reload, use the explicit Retry action for saved unfinished jobs.
- Uncertain server responses are reconciled before retry; no automatic repost
  or silent success. Do not delete receipts or queued files to bypass a warning.
- A retained uploader that is still running, or whose exit cannot be proved,
  blocks a retry safely. Do not delete upload locks to bypass that warning;
  keep the backup and seek recovery rather than risk a duplicate upload.
- No automatic Base scans or changes to Order Custom save flow are added.

A verified original backup is retained under the Panel's
.mitom-save-task-backups folder. To inspect/restore it before any R78 state has
been written, use the exact backup path printed after installation:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-save-task.ps1 -Rollback "exact backup path" -CheckOnly
powershell.exe -NoProfile -ExecutionPolicy Bypass -File install-save-task.ps1 -Rollback "exact backup path"
Rollback refuses when version 10/newer Save Task receipts exist: R76 cannot read
them, even if completed. There is no override. Keep all receipts, exports and
the backup; reinstall R78 and use Retry/reconciliation for recovery. This patch
does not downgrade, erase or migrate queue receipts during rollback.

No process termination, upload, network request, public publication or automatic
backup deletion is performed by these tools. Synthetic QA is not a measurement
of real server/network speed. Closing Photoshop is not needed for Check only.
