(function (root) {
  "use strict";
  const URL = "https://www.canva.com/features/background-remover/";
  // Actual loopback endpoint is resolved by local-transport.js. Retained only
  // as a compatibility constant; no request may bypass service discovery.
  const BRIDGE = "http://127.0.0.1:28767";
  const LIMIT = 60 * 1024 * 1024;
  // 2 MiB of base64 per message: comfortably below Chrome's 64 MiB limit,
  // with fewer authenticated roundtrips for full-resolution customer photos.
  const CHUNK = 1536 * 1024;
  function validPage(url) {
    try { const u = new globalThis.URL(url); return !u.username && !u.password && u.origin === "https://www.canva.com" && u.pathname.replace(/\/$/, "") === "/features/background-remover"; } catch (_) { return false; }
  }
  function validJob(job) {
    return !!job && /^[a-zA-Z0-9_-]{16,128}$/.test(job.id || "") && ["image/png", "image/jpeg", "image/webp"].includes(job.mime);
  }
  function scopedTab(tab) {
    if (!tab) return false;
    if (tab.pendingUrl && !validPage(tab.pendingUrl)) return false;
    return validPage(tab.url) || ((!tab.url || tab.url === "about:blank") && validPage(tab.pendingUrl));
  }
  function validToken(value) { return typeof value === "string" && /^[a-f0-9]{64}$/.test(value); }
  // Only the actual media host/path seen in the public result dialog. Never
  // treat arbitrary page messages or arbitrary HTTPS URLs as fetch authority.
  function validResultUrl(value) {
    try { const u = new globalThis.URL(value); return !u.username && !u.password && u.origin === "https://media.canva.com" && u.pathname.startsWith("/v2/files/"); } catch (_) { return false; }
  }
  function pngData(value) {
    if (typeof value !== "string" || !value.startsWith("data:image/png;base64,")) throw new Error("Web chưa cung cấp PNG trong suốt; không dùng ảnh nguồn thay thế.");
    const payload = value.slice(22);
    if (!payload || payload.length > Math.ceil(LIMIT / 3) * 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(payload) || payload.length % 4) throw new Error("PNG từ web quá lớn hoặc không hợp lệ.");
    return payload;
  }
  function base64(bytes) {
    let str = ""; for (let i = 0; i < bytes.length; i += 8192) str += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return btoa(str);
  }
  function unbase64(value) { const str = atob(value); const bytes = new Uint8Array(str.length); for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i); return bytes; }
  const api = { URL, BRIDGE, LIMIT, CHUNK, validPage, scopedTab, validJob, validToken, validResultUrl, pngData, base64, unbase64 };
  if (typeof module === "object" && module.exports) module.exports = api;
  root.UOYCanvaCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
