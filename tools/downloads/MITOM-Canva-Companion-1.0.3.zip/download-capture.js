/* MAIN-world hook, injected only into the fresh tab owned by one panel job.
 * Armed only around the observed Download action. No browser-wide downloads
 * listener and no interception of user tabs, cookies, fetch or page internals. */
(function(){
  "use strict";
  if(globalThis.__uoyCanvaDownload)return;
  const oldClick=HTMLAnchorElement.prototype.click;
  let armed=null, disposed=false;
  const validPage=()=>location.origin==="https://www.canva.com"&&location.pathname.replace(/\/$/,"")==="/features/background-remover";
  const emit=(type,detail)=>document.dispatchEvent(new CustomEvent(type,{detail}));
  function allowed(url){try{const u=new URL(url);return !u.username&&!u.password&&((u.protocol==="blob:"&&u.origin==="https://www.canva.com")||(u.protocol==="data:"&&/^data:image\/png;base64,/.test(url))||(u.origin==="https://media.canva.com"&&u.pathname.startsWith("/v2/files/")));}catch(_){return false;}}
  function clear(){if(armed)clearTimeout(armed.timer);armed=null;}
  function capture(anchor,event){
    if(disposed||!validPage()||!armed||Date.now()>armed.expires||!(anchor instanceof HTMLAnchorElement)||!anchor.hasAttribute("download"))return false;
    const href=anchor.href;
    if(!allowed(href))return false;
    const nonce=armed.nonce; clear();
    if(event){event.preventDefault();event.stopImmediatePropagation();}
    emit("uoy-canva-download-captured",{nonce,url:href});
    return true;
  }
  function onArm(event){const d=event.detail;if(!validPage()||disposed||!d||!/^[a-f0-9]{32}$/.test(d.nonce||""))return;clear();armed={nonce:d.nonce,expires:Date.now()+25000};armed.timer=setTimeout(clear,25000);emit("uoy-canva-download-armed",{nonce:d.nonce});}
  function onCancel(event){if(armed&&event.detail&&event.detail.nonce===armed.nonce)clear();}
  function onClick(event){const a=event.target&&event.target.closest&&event.target.closest("a[download]");if(a)capture(a,event);}
  function wrapped(){if(!capture(this,null))return oldClick.apply(this,arguments);}
  function restore(){if(disposed)return;disposed=true;clear();if(HTMLAnchorElement.prototype.click===wrapped)HTMLAnchorElement.prototype.click=oldClick;document.removeEventListener("click",onClick,true);document.removeEventListener("uoy-canva-download-arm",onArm);document.removeEventListener("uoy-canva-download-cancel",onCancel);delete globalThis.__uoyCanvaDownload;}
  HTMLAnchorElement.prototype.click=wrapped;
  document.addEventListener("click",onClick,true);
  document.addEventListener("uoy-canva-download-arm",onArm);
  document.addEventListener("uoy-canva-download-cancel",onCancel);
  globalThis.__uoyCanvaDownload={restore};
  addEventListener("pagehide",restore,{once:true});
})();
