"use strict";
importScripts("core.js", "warm-tab.js", "local-transport.js");
const C = UOYCanvaCore;
const localTransport = UOYCanvaTransport.create();
let running = false, active = null, timer = null, epoch = 0, pendingPoll = null;
let warmLease = null;
const warmTabs = typeof UOYCanvaWarm === "object" ? UOYCanvaWarm.createWarmTabs({
  chrome, scopedTab:C.scopedTab,
  isLive:async id => {
    const lease = warmLease;
    if (!lease || lease.id !== id || lease.epoch !== epoch) return false;
    const response = await request(lease.token, "/v1/warm/" + id, {}, 2500);
    const state = await response.json();
    return warmLease === lease && lease.epoch === epoch && !!state.active;
  }
}) : null;
// Content scripts may use only transient image messages, never stored pairing.
const trustedStorage = chrome.storage.local.setAccessLevel({accessLevel:"TRUSTED_CONTEXTS"});
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function request(token, route, options = {}, timeout = 8000, outerSignal = null) {
  return localTransport.request(token, route, options, timeout, outerSignal);
}
async function json(token, route, body) { return request(token, route, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)}); }
async function connectedToken() { const config = await chrome.storage.local.get("pairingToken"); return C.validToken(config.pairingToken) ? config.pairingToken : ""; }
async function closeOwned(job) {
  if (!job || !job.tabId) return;
  try {
    const tab = await chrome.tabs.get(job.tabId);
    // Never close a user's tab navigated away from our scoped tool.
    if (C.scopedTab(tab)) {
      try { await chrome.tabs.sendMessage(job.tabId, {type:"clear", id:job.id}); } catch (_) {}
      try { await chrome.scripting.executeScript({target:{tabId:job.tabId},world:"MAIN",func:() => { globalThis.__uoyCanvaDownload?.restore(); }}); } catch (_) {}
      await chrome.tabs.remove(job.tabId);
    }
  } catch (_) {}
  const stored = (await chrome.storage.session.get("ownedTab")).ownedTab;
  if ((!active || active === job) && stored && stored.id === job.id && stored.tabId === job.tabId) await chrome.storage.session.remove("ownedTab");
}
async function recover() {
  const {ownedTab} = await chrome.storage.session.get("ownedTab");
  if (ownedTab && Number.isInteger(ownedTab.tabId) && /^[a-zA-Z0-9_-]{16,128}$/.test(ownedTab.id || "")) {
    const token = await connectedToken();
    if (token) try { await json(token, "/v1/jobs/" + ownedTab.id + "/error", {message:"Chrome đã khởi động lại companion giữa phiên. Ảnh không được tự gửi lại; hãy bấm Tách nền khi sẵn sàng."}); } catch (_) {}
    await closeOwned(ownedTab);
  }
}
async function check(job) {
  if (active !== job || job.cancelled || job.epoch !== epoch) throw new Error("Đã hủy phiên ảnh.");
  // Independent read-only checks can run together. Keep both guards before
  // every transfer, and recheck local cancellation after either read waited.
  const values = await Promise.all([
    request(job.token, "/v1/jobs/" + job.id + "/state", {}, 5000).then(response => response.json()),
    job.tabId ? chrome.tabs.get(job.tabId) : Promise.resolve(null)
  ]);
  if (active !== job || job.cancelled || job.epoch !== epoch) throw new Error("Đã hủy phiên ảnh.");
  if (!values[0].active) throw new Error("Panel đã hủy hoặc đóng phiên ảnh.");
  if (job.tabId && !C.scopedTab(values[1])) throw new Error("Tab Canva đã đổi trang. Không tiếp tục gửi ảnh.");
  return values[1];
}
async function send(job, message) {
  if (job.cancelled) throw new Error("Đã hủy phiên ảnh.");
  const response = await chrome.tabs.sendMessage(job.tabId, {...message, id:job.id});
  if (!response || response.error) throw new Error(response?.error || "Trang Canva không phản hồi.");
  return response;
}
async function readBounded(response, signal = null) {
  const reader = response.body.getReader(), parts = []; let size = 0;
  let cancelled = false, readerCancelled = false, rejectAbort;
  const interrupted = new Promise((_, reject) => { rejectAbort = reject; });
  // A streaming response may already have returned headers when the panel
  // cancels. Abort the body too; do not retain a pending preload in that case.
  const cancelReader = () => {
    if (readerCancelled) return; readerCancelled = true;
    try { Promise.resolve(reader.cancel()).catch(() => {}); } catch (_) {}
  };
  const abort = () => { cancelled = true; cancelReader(); rejectAbort(new Error("Đã hủy đọc ảnh của panel.")); };
  const readTimer = setTimeout(abort, 8000);
  if (signal) { if (signal.aborted) abort(); else signal.addEventListener("abort", abort, {once:true}); }
  try {
    for (;;) {
      const reading = reader.read().then(item => {
        // A non-conforming/late stream callback must not retain image bytes
        // after cancellation has already released the owning preload.
        if (cancelled && item.value) item.value.fill(0);
        return item;
      });
      const item = await Promise.race([reading, interrupted]);
      if (cancelled) throw new Error("Đã hủy đọc ảnh của panel.");
      if (item.done) break;
      size += item.value.length;
      if (size > C.LIMIT) { item.value.fill(0); throw new Error("Ảnh vượt 60 MB."); }
      parts.push(item.value);
    }
    if (!size) throw new Error("Ảnh trống.");
    const output = new Uint8Array(size); let offset = 0;
    for (const part of parts) { output.set(part, offset); offset += part.length; }
    return output;
  } finally {
    clearTimeout(readTimer); if (signal) signal.removeEventListener("abort", abort);
    for (const part of parts) part.fill(0); cancelReader();
  }
}
async function execute(spec, token, expectedEpoch = epoch) {
  if (!C.validJob(spec)) throw new Error("Panel trả phiên ảnh không hợp lệ.");
  const job = {id:spec.id, token, epoch:expectedEpoch, cancelled:false, tabId:null}; active = job;
  localTransport.lock();
  let source = null, output = null, inputLoad = null, monitor = null, monitoring = false, monitorTask = null, processing = false, lastStage = "";
  const inputControl = new AbortController();
  try {
    await check(job);
    // Read only from the authenticated local broker while the fresh page
    // loads. No photo reaches the website until its normal readiness gate.
    inputLoad = (async () => readBounded(await request(token, "/v1/jobs/" + job.id + "/input", {}, 8000, inputControl.signal), inputControl.signal))();
    inputLoad.catch(() => {}); // Readiness failures must not leave a rejected preload unobserved.
    await json(token, "/v1/jobs/" + job.id + "/progress", {progress:10, message:"Đang mở Canva trong tab nền…"});
    // A prepared page has never received a photo. Adopt it once, recording
    // job ownership before clearing its warm lease so restart cleanup is safe.
    let tab = warmTabs && spec.warmId ? await warmTabs.take(spec.warmId, async candidate => {
      await check(job);
      job.tabId = candidate.id;
      await chrome.storage.session.set({ownedTab:{id:job.id, tabId:job.tabId}});
    }) : null;
    warmLease = null;
    if (!tab) {
      // take() can fail after its adoption callback persisted job ownership
      // (for example clear/expiry during handoff). Release that provisional
      // owner before deciding whether this still-live job needs a fresh page.
      if (job.tabId) { await closeOwned(job); job.tabId = null; }
      if (warmTabs) await warmTabs.clear();
      await check(job);
      tab = await chrome.tabs.create({url:C.URL, active:false}); job.tabId = tab.id;
      await chrome.storage.session.set({ownedTab:{id:job.id, tabId:job.tabId}});
    }
    await check(job);
    // Scoped to the temporary tab we own; never change the user's Chrome
    // settings, selected tab, or window focus while Photoshop is being used.
    await chrome.tabs.update(job.tabId, {autoDiscardable:false});
    const deadline = Date.now() + 25000;
    for (;;) {
      const loaded = await check(job);
      if (loaded.status === "complete") break;
      if (Date.now() > deadline) throw new Error("Canva tải trang quá lâu. Kiểm tra Chrome và mạng.");
      await sleep(250);
    }
    await chrome.scripting.executeScript({target:{tabId:job.tabId},world:"MAIN",files:["download-capture.js"]});
    await check(job);
    await chrome.scripting.executeScript({target:{tabId:job.tabId}, files:["core.js", "page-adapter.js", "content.js"]});
    await check(job);
    source = await inputLoad; inputLoad = null;
    await check(job);
    await send(job, {type:"prepare", mime:spec.mime, size:source.length});
    for (let offset = 0, index = 0; offset < source.length; offset += C.CHUNK, index++) {
      await check(job);
      await send(job, {type:"chunk", index, data:C.base64(source.subarray(offset, offset + C.CHUNK))});
    }
    source.fill(0); source = null;
    await check(job);
    await json(token, "/v1/jobs/" + job.id + "/progress", {progress:40, message:"Đã gửi ảnh qua Chrome. Đang đợi Canva tách nền…"});
    // Long content-script work is monitored with authenticated local reads.
    // Cancellation closes only this newly created tab, not any user's tabs.
    monitor = setInterval(() => {
      if (monitoring || job.cancelled) return; monitoring = true;
      monitorTask = (async () => {
        try {
          await check(job);
          if (processing) {
            // Stage reporting is advisory. A late/failed diagnostic must not
            // cancel valid output; processImage enforces website blockers.
            const status = await send(job, {type:"stage"}).catch(() => ({}));
            if (processing && status.stage && status.stage !== lastStage) {
              lastStage = status.stage;
              const message = status.stage === "reading-input" ? "Canva đang đọc ảnh đầu vào…" : status.stage === "processing" ? "Canva đã đọc ảnh. Đang xử lý tách nền…" : "Canva đã có kết quả. Đang nhận PNG…";
              await json(token, "/v1/jobs/" + job.id + "/progress", {progress:status.stage === "reading-input" ? 42 : status.stage === "processing" ? 55 : 80, message});
            }
          }
        }
        catch (_) { job.cancelled = true; await closeOwned(job); }
        finally { monitoring = false; }
      })();
    }, 1000);
    await check(job);
    processing = true;
    const result = await send(job, {type:"process"});
    processing = false;
    clearInterval(monitor);
    if (monitorTask) await monitorTask.catch(() => {});
    await check(job);
    if (!result.ready || (result.url ? !C.validResultUrl(result.url) : (!Number.isInteger(result.length) || result.length < 4 || result.length > C.LIMIT * 4 / 3 || result.length % 4))) throw new Error("Web chưa trả PNG hợp lệ.");
    await json(token, "/v1/jobs/" + job.id + "/progress", {progress:85, message:"Đang nhận PNG trong suốt về panel (không lưu Downloads)…"});
    if (result.url) {
      // This URL was produced by the site's Download action in the exact
      // owned tab. Not a preview URL, cookie, private API or guessed route.
      await check(job);
      const control = new AbortController(), downloadTimer = setTimeout(() => control.abort(), 15000);
      let checkingDownload = false, downloadCheck = null;
      const downloadMonitor = setInterval(() => {
        if (checkingDownload || control.signal.aborted) return;
        checkingDownload = true;
        downloadCheck = check(job).catch(() => control.abort()).finally(() => { checkingDownload = false; });
      }, 500);
      try {
        const response = await fetch(result.url, {signal:control.signal,credentials:"omit",redirect:"error",cache:"no-store"});
        if (!response.ok || !/^image\/png(?:;|$)/i.test(response.headers.get("content-type") || "")) throw new Error("Canva tải về không phải PNG hợp lệ.");
        output = await readBounded(response, control.signal);
        await check(job);
      } finally { clearTimeout(downloadTimer); clearInterval(downloadMonitor); control.abort(); if (downloadCheck) await downloadCheck.catch(() => {}); }
    } else {
    const parts = []; let size = 0;
    try {
      for (let offset = 0; offset < result.length; offset += C.CHUNK * 4 / 3) {
        await check(job);
        const chunk = await send(job, {type:"result-chunk", offset});
        if (typeof chunk.data !== "string" || chunk.data.length !== Math.min(C.CHUNK * 4 / 3, result.length - offset)) throw new Error("Kết quả bị thiếu một phần.");
        const bytes = C.unbase64(chunk.data); parts.push(bytes); size += bytes.length;
        if (size > C.LIMIT) throw new Error("PNG kết quả vượt 60 MB.");
      }
      output = new Uint8Array(size); let offset = 0;
      for (const part of parts) { output.set(part, offset); offset += part.length; }
    } finally { for (const part of parts) part.fill(0); }
    }
    await check(job);
    // Broker decodes and validates actual alpha, PNG CRCs and dimensions.
    await request(token, "/v1/jobs/" + job.id + "/result", {method:"POST", headers:{"Content-Type":"image/png"}, body:output}, 15000);
  } catch (error) {
    inputControl.abort();
    try { await json(token, "/v1/jobs/" + job.id + "/error", {message:String(error.message || error).slice(0,400)}); } catch (_) {}
  } finally {
    processing = false; clearInterval(monitor); job.cancelled = true;
    inputControl.abort();
    if (inputLoad) { try { (await inputLoad).fill(0); } catch (_) {} inputLoad = null; }
    if (monitorTask) await monitorTask.catch(() => {});
    if (source) source.fill(0); if (output) output.fill(0);
    try { await closeOwned(job); }
    finally { if (active === job) active = null; localTransport.unlock(); localTransport.invalidate(); }
  }
}
async function poll() {
  if (running) return; running = true; clearTimeout(timer);
  let retry = 50;
  try {
    const token = await connectedToken();
    if (!token) { retry = 10000; return; }
    const pollEpoch = epoch;
    pendingPoll = new AbortController();
    const response = await request(token, "/v1/next", {headers:{Accept:"application/vnd.uoy.canva.warm+json"}}, 24000, pendingPoll.signal);
    pendingPoll = null;
    if (response.status !== 204) {
      const spec = await response.json();
      const latestToken = await connectedToken();
      if (epoch !== pollEpoch || token !== latestToken) {
        if (C.validJob(spec)) try { await json(token, "/v1/jobs/" + spec.id + "/error", {message:"Kết nối đã đổi hoặc ngắt. Không gửi ảnh của phiên cũ."}); } catch (_) {}
        return;
      }
      if (spec && spec.type === "warm" && /^[a-f0-9]{32}$/.test(spec.id || "")) {
        if (warmTabs) {
          warmLease = {id:spec.id, token, epoch:pollEpoch};
          // Preparation is image-free and does not block the real job poll.
          warmTabs.prepare({id:spec.id}).catch(() => {});
        }
        return;
      }
      await execute(spec, token, pollEpoch);
    }
  } catch (_) { retry = 3000; } // No image, token, or customer path in logs.
  finally { pendingPoll = null; running = false; timer = setTimeout(poll, retry); }
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  // Only our own popup may alter pairing. Web content never receives the token.
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html")) return false;
  (async () => {
    await trustedStorage;
    if (message.type === "pair") {
      if (!C.validToken(message.token)) throw new Error("Mã ghép không hợp lệ.");
      if (active) throw new Error("Chờ phiên đang chạy xong trước khi đổi kết nối.");
      localTransport.invalidate();
      const health = await (await request(message.token, "/v1/health", {}, 4000)).json();
      if (health.service !== "uoy-canva-ram") throw new Error("Cổng này không phải Canva bridge. Mở đúng tab Canva rồi ghép lại.");
      epoch++; if (pendingPoll) pendingPoll.abort();
      warmLease = null; if (warmTabs) await warmTabs.clear();
      await chrome.storage.local.set({pairingToken:message.token}); poll();
      return {ok:true, message:"Đã ghép. Quay lại panel, chọn ảnh và bấm Tách nền Canva."};
    }
    if (message.type === "forget") {
      epoch++; if (pendingPoll) pendingPoll.abort();
      warmLease = null; if (warmTabs) await warmTabs.clear();
      if (active) { active.cancelled = true; try { await json(active.token, "/v1/jobs/" + active.id + "/error", {message:"Bạn đã ngắt kết nối companion."}); } catch (_) {} await closeOwned(active); }
      await chrome.storage.local.remove("pairingToken"); localTransport.invalidate(); return {ok:true, message:"Đã ngắt kết nối và bỏ mã ghép khỏi extension."};
    }
    if (message.type === "connection-status") {
      const token = await connectedToken(); if (!token) return {ok:false,message:"Chưa ghép với panel."};
      const health = await (await request(token, "/v1/health", {}, 4000)).json();
      if (health.service !== "uoy-canva-ram") throw new Error("Cổng này không phải Canva bridge."); return {ok:true,message:active ? "Đang xử lý ảnh của panel." : "Đã kết nối với panel."};
    }
    throw new Error("Lệnh không hỗ trợ.");
  })().then(reply, error => reply({ok:false,message:String(error.message || error).slice(0,300)}));
  return true;
});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === "canva-health") poll(); });
chrome.runtime.onStartup.addListener(() => { chrome.alarms.create("canva-health", {periodInMinutes:0.5}); });
chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create("canva-health", {periodInMinutes:0.5}); });
trustedStorage.then(recover).then(() => warmTabs && warmTabs.recover()).then(poll).catch(() => {});
