(function(){
  "use strict";
  if(globalThis.__uoyCanvaContent)return;
  globalThis.__uoyCanvaContent=true;
  const C=UOYCanvaCore,P=UOYCanvaPage;
  let state=null;
  function ensure(id){if(!C.validPage(location.href)||!state||state.id!==id||state.cancelled)throw new Error("Phiên Canva đã hủy hoặc trang đã thay đổi.");return state;}
  function clean(){if(state){state.cancelled=true;for(const part of state.parts)part.fill(0);state.parts.length=0;state.result="";if(state.input)state.input.value="";if(state.abort)state.abort.abort();if(state.cancelDownload)state.cancelDownload();}state=null;}
  function pause(){return new Promise(resolve=>{const observer=new MutationObserver(done),timer=setTimeout(done,300);function done(){clearTimeout(timer);observer.disconnect();resolve();}observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:["src","disabled","aria-disabled","aria-label"]});});}
  function captureDownload(id,button){
    const s=ensure(id),nonce=Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b=>b.toString(16).padStart(2,"0")).join("");
    return new Promise((resolve,reject)=>{
      let armed=false,done=false;
      const finish=(error,value)=>{if(done)return;done=true;clearInterval(monitor);clearTimeout(timeout);document.removeEventListener("uoy-canva-download-armed",onArmed);document.removeEventListener("uoy-canva-download-captured",onCaptured);document.dispatchEvent(new CustomEvent("uoy-canva-download-cancel",{detail:{nonce}}));s.cancelDownload=null;error?reject(error):resolve(value);};
      const onArmed=e=>{if(e.detail&&e.detail.nonce===nonce)armed=true;};
      const onCaptured=e=>{if(!armed||!e.detail||e.detail.nonce!==nonce)return;try{ensure(id);const problem=P.blocker(document);if(problem)throw new Error(problem);const url=e.detail.url;if(typeof url!=="string"||(!C.validResultUrl(url)&&!url.startsWith("blob:https://www.canva.com/")&&!url.startsWith("data:image/png;base64,")))throw new Error("Canva chưa trả liên kết PNG hợp lệ.");
        // Start reading a blob immediately in this event stack: the website
        // can revoke its object URL as soon as anchor.click() returns. Never
        // override URL.revokeObjectURL or retain a page-wide blob registry.
        const captured=C.validResultUrl(url)?url:readLocalDownload(id,url);
        finish(null,captured);
      }catch(error){finish(error);}};
      const monitor=setInterval(()=>{try{ensure(id);const problem=P.blocker(document);if(problem)throw new Error(problem);}catch(error){finish(error);}},250);
      const timeout=setTimeout(()=>finish(new Error("Canva chưa cho tải PNG. Kiểm tra đăng nhập/gói hoặc giao diện web; không sử dụng ảnh xem trước làm kết quả.")),25000);
      s.cancelDownload=()=>finish(new Error("Đã hủy nhận PNG Canva."));
      document.addEventListener("uoy-canva-download-armed",onArmed);document.addEventListener("uoy-canva-download-captured",onCaptured);
      document.dispatchEvent(new CustomEvent("uoy-canva-download-arm",{detail:{nonce}}));
      if(!armed){finish(new Error("Canva companion chưa sẵn sàng nhận PNG. Reload extension rồi thử lại."));return;}
      try{ensure(id);button.click();}catch(error){finish(error);}
    });
  }
  async function readLocalDownload(id,url){
    const s=ensure(id);if(url.startsWith("data:image/png;base64,")){s.result=C.pngData(url);return {ready:true,length:s.result.length};}
    s.abort=new AbortController();const timer=setTimeout(()=>s.abort.abort(),15000);let reader=null;const parts=[];let size=0;
    try{
      const response=await fetch(url,{signal:s.abort.signal,credentials:"omit",redirect:"error",cache:"no-store"});
      if(!response.ok||!/^image\/png(?:;|$)/i.test(response.headers.get("content-type")||""))throw new Error("Canva tải về không phải PNG. Không dùng ảnh nguồn thay thế.");
      reader=response.body.getReader();
      for(;;){ensure(id);const item=await reader.read();ensure(id);if(item.done)break;size+=item.value.length;if(size>C.LIMIT){item.value.fill(0);throw new Error("PNG Canva vượt 60 MB.");}parts.push(item.value);}
      if(!size)throw new Error("Canva trả ảnh trống.");const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}try{s.result=C.base64(bytes);}finally{bytes.fill(0);}return {ready:true,length:s.result.length};
    }finally{clearTimeout(timer);for(const part of parts)part.fill(0);if(reader)try{await reader.cancel();}catch(_){}s.abort=null;}
  }
  async function processImage(id){
    const s=ensure(id);if(s.processing||s.received!==s.size)throw new Error("Ảnh truyền chưa đủ hoặc đang xử lý.");
    const deadline=Date.now()+105000;
    const own=()=>{if(ensure(id)!==s)throw new Error("Phiên Canva đã thay đổi; không gửi ảnh của phiên cũ.");return s;};
    const problem=P.blocker(document);if(problem)throw new Error(problem);
    if(Array.from(document.querySelectorAll('[role="dialog"]')).some(e=>P.visible(e)&&e.querySelector("img")))throw new Error("Canva còn ảnh cũ. Chỉ dùng tab trống của phiên này.");
    // Lock this process before waiting for late hydration. A page-load event
    // does not prove Canva's responsive upload controls are already ready.
    s.processing=true;s.stage="reading-input";
    const stillReady=()=>{own();const blocked=P.blocker(document);if(blocked)throw new Error(blocked);if(Array.from(document.querySelectorAll('[role="dialog"]')).some(e=>P.visible(e)&&e.querySelector("img")))throw new Error("Canva còn ảnh cũ. Chỉ dùng tab trống của phiên này.");};
    s.input=typeof P.waitForUpload==="function"?await P.waitForUpload(document,{mime:s.mime,ensure:stillReady,pause,timeoutMs:12000}):P.uploadInput(document,s.mime);
    stillReady();
    if(s.input.isConnected===false)throw new Error("Canva vừa thay ô nhận ảnh. Chọn lại ảnh để thử; ảnh chưa được gửi.");
    if(P.uploadInput(document,s.mime)!==s.input)throw new Error("Canva vừa đổi ô tải ảnh. Chưa gửi ảnh; chọn lại ảnh để thử.");
    s.filename="uoy-canva-"+id+"."+(s.mime==="image/jpeg"?"jpg":s.mime==="image/webp"?"webp":"png");
    const file=new File(s.parts,s.filename,{type:s.mime});for(const part of s.parts)part.fill(0);s.parts.length=0;
    const transfer=new DataTransfer();transfer.items.add(file);own();s.input.files=transfer.files;s.input.dispatchEvent(new Event("change",{bubbles:true}));
    while(Date.now()<deadline){own();const blocked=P.blocker(document);if(blocked)throw new Error(blocked);s.stage="processing";const result=P.result(document,s.filename);if(result){s.stage="result";const captured=await captureDownload(id,result.button);own();s.input.value="";if(typeof captured==="string"&&C.validResultUrl(captured))return {ready:true,url:captured};return captured;}await pause();}
    throw new Error("Canva chưa trả kết quả sau 105 giây. Kiểm tra mạng, đăng nhập hoặc giới hạn web rồi chọn lại ảnh.");
  }
  chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
    if(sender.id!==chrome.runtime.id||!C.validPage(location.href))return false;
    const owner=state;
    (async()=>{
      if(msg.type==="prepare"){if(state)throw new Error("Trang đang có phiên ảnh.");if(!C.validJob(msg)||!Number.isInteger(msg.size)||msg.size<1||msg.size>C.LIMIT)throw new Error("Thông tin ảnh không hợp lệ.");state={id:msg.id,mime:msg.mime,size:msg.size,parts:[],received:0,result:"",processing:false,stage:"reading-input"};return {ok:true};}
      const s=ensure(msg.id);
      if(msg.type==="stage")return {stage:s.stage};
      if(msg.type==="chunk"){if(s.processing||msg.index!==s.parts.length||typeof msg.data!=="string"||msg.data.length>C.CHUNK*4/3)throw new Error("Khối ảnh không đúng phiên/thứ tự.");const bytes=C.unbase64(msg.data);if(!bytes.length||s.received+bytes.length>s.size){bytes.fill(0);throw new Error("Khối ảnh vượt kích thước.");}s.parts.push(bytes);s.received+=bytes.length;return {ok:true};}
      if(msg.type==="process")return await processImage(msg.id);
      if(msg.type==="result-chunk"){if(!s.result||!Number.isInteger(msg.offset)||msg.offset<0||msg.offset%(C.CHUNK*4/3))throw new Error("Khối kết quả không hợp lệ.");return {data:s.result.slice(msg.offset,msg.offset+C.CHUNK*4/3)};}
      if(msg.type==="clear"){clean();return {ok:true};}
      throw new Error("Lệnh không hỗ trợ.");
    })().then(reply,error=>{if(msg.type!=="stage"&&state&&state===owner&&state.id===msg.id)clean();reply({error:String(error.message||error).slice(0,400)});});return true;
  });
  addEventListener("pagehide",clean,{once:true});
})();
