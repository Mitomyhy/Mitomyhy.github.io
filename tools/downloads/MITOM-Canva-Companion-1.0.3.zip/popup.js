"use strict";
const status = document.getElementById("status"), field = document.getElementById("token");
async function act(type, token) {
  try { const result = await chrome.runtime.sendMessage({type, token}); status.textContent = result.message || (result.ok ? "Đã kết nối." : "Chưa kết nối."); if (result.ok) field.value = ""; }
  catch (_) { status.textContent = "Không liên hệ được companion. Reload extension rồi thử lại."; }
}
document.getElementById("connect").onclick = () => {
  const token = field.value.trim();
  if (!UOYCanvaCore.validToken(token)) { status.textContent = "Hãy sao chép đầy đủ mã ghép trong file canva_pairing_token.txt."; return; }
  act("pair", token);
};
document.getElementById("forget").onclick = () => act("forget");
act("connection-status");
