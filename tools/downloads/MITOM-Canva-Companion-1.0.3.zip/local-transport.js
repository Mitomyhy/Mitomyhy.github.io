/* Fixed-loopback Canva discovery. Never send pairing credentials to a port
 * until its unauthenticated, image-free Canva protocol marker is verified.
 * A running image job remains pinned: no automatic resend to another panel. */
(function (root) {
  "use strict";
  const PORTS = [28767, 28768, 28769, 28770, 28771, 8767];
  function failure(code, message) { const value = new Error(message); value.code = code; return value; }
  function create(options = {}) {
    const fetcher = options.fetch || root.fetch.bind(root);
    const Controller = options.AbortController || root.AbortController;
    const cryptography = options.crypto || root.crypto;
    const setTimer = options.setTimeout || root.setTimeout.bind(root), clearTimer = options.clearTimeout || root.clearTimeout.bind(root);
    let selected = null, pending = null, pendingToken = "", locked = false;
    function endpoint(port) { if (!PORTS.includes(port)) throw failure("PORT_DENIED", "Cổng Canva local không hợp lệ."); return "http://127.0.0.1:" + port; }
    async function boundedJson(response) {
      const declared = response.headers?.get("content-length");
      if (declared && (!/^\d+$/.test(declared) || Number(declared) > 4096)) throw failure("DISCOVERY_INVALID", "Thông tin kết nối local không hợp lệ.");
      const reader = response.body?.getReader?.();
      if (!reader) { const value = await response.text(); if (value.length > 4096) throw failure("DISCOVERY_INVALID", "Thông tin kết nối local quá dài."); return JSON.parse(value); }
      let total = 0; const parts = [];
      try {
        for (;;) { const item = await reader.read(); if (item.done) break; total += item.value.length; if (total > 4096) throw failure("DISCOVERY_INVALID", "Thông tin kết nối local quá dài."); parts.push(item.value); }
        const bytes = new Uint8Array(total); let offset = 0; for (const part of parts) { bytes.set(part, offset); offset += part.length; }
        return JSON.parse(new TextDecoder().decode(bytes));
      } finally { try { Promise.resolve(reader.cancel()).catch(() => {}); } catch (_) {} }
    }
    async function raw(base, route, options = {}, timeout = 8000, outerSignal = null, decode = false) {
      const control = new Controller(), timer = setTimer(() => control.abort(), timeout), abort = () => control.abort();
      if (outerSignal) { if (outerSignal.aborted) abort(); else outerSignal.addEventListener("abort", abort, {once:true}); }
      try {
        const response = await fetcher(base + route, {...options, cache:"no-store", credentials:"omit", redirect:"error", signal:control.signal});
        return decode ? {ok:response.ok, status:response.status, data:response.ok ? await boundedJson(response) : null} : response;
      } finally { clearTimer(timer); if (outerSignal) outerSignal.removeEventListener("abort", abort); }
    }
    async function probe(port, token) {
      const base = endpoint(port);
      const nonceBytes = new Uint8Array(16); cryptography.getRandomValues(nonceBytes);
      const challenge = Array.from(nonceBytes, value => value.toString(16).padStart(2,"0")).join("");
      let identity;
      try { const response = await raw(base, "/v1/discovery?challenge=" + challenge, {}, 900, null, true); if (!response.ok) return null; identity = response.data; }
      catch (_) { return null; }
      if (!identity || identity.service !== "uoy-canva-ram" || identity.protocol !== "canva-local-v2" || identity.port !== port || identity.challenge !== challenge || !/^[a-f0-9]{64}$/.test(identity.proof || "") || Object.keys(identity).length !== 5) return null;
      const encoder = new TextEncoder(), key = await cryptography.subtle.importKey("raw", encoder.encode(token), {name:"HMAC",hash:"SHA-256"}, false, ["sign"]);
      const signature = new Uint8Array(await cryptography.subtle.sign("HMAC", key, encoder.encode("uoy-canva-discovery-v2|" + port + "|" + challenge)));
      const expected = Array.from(signature, value => value.toString(16).padStart(2,"0")).join("");
      let different = 0; for (let at = 0; at < expected.length; at++) different |= expected.charCodeAt(at) ^ identity.proof.charCodeAt(at);
      if (different) return {unauthorized:true};
      const response = await raw(base, "/v1/health", {headers:{Authorization:"Bearer " + token}}, 1500, null, true);
      if (response.status === 401) return {unauthorized:true};
      if (!response.ok) return null;
      const health = response.data;
      if (!health || health.ok !== true || health.service !== "uoy-canva-ram" || health.version !== 2 || health.port !== port) return null;
      return {base, port, token};
    }
    async function connect(token) {
      if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token)) throw failure("TOKEN_INVALID", "Sao chép đầy đủ mã ghép Canva của máy này.");
      if (selected && selected.token === token) return selected;
      if (locked) throw failure("LOCAL_SESSION_CHANGED", "Phiên ảnh đang chạy; không đổi kết nối sang Panel khác.");
      if (pending && pendingToken === token) return pending;
      if (pending) throw failure("CONNECTION_BUSY", "Đang kiểm tra kết nối Canva; thử lại sau một chút.");
      pendingToken = token;
      const task = (async () => {
        const values = await Promise.all(PORTS.map(port => probe(port, token).catch(() => null)));
        const matches = values.filter(value => value?.base);
        if (matches.length > 1) throw failure("PANEL_AMBIGUOUS", "Có nhiều Panel Canva cùng mở. Giữ một Panel Canva để ghép đúng phiên; không cần tắt OrderStudio.");
        if (!matches.length) {
          if (values.some(value => value?.unauthorized)) throw failure("UNAUTHORIZED", "Mã ghép không đúng. Sao chép lại từ file canva_pairing_token.txt của máy này.");
          throw failure("PANEL_UNAVAILABLE", "Chưa tìm thấy Canva Panel mới. Cập nhật cả Panel và UOY Canva Companion, rồi bấm Kết nối lại trong tab Canva.");
        }
        selected = matches[0]; return selected;
      })();
      pending = task;
      try { return await task; } finally { if (pending === task) { pending = null; pendingToken = ""; } }
    }
    async function request(token, route, options = {}, timeout = 8000, outerSignal = null) {
      if (!/^\/v1\/(?:health|next|warm\/[a-f0-9]{32}|jobs\/[a-f0-9]{32}\/(?:input|state|progress|result|error))$/.test(route)) throw failure("ROUTE_DENIED", "Đường dẫn Canva local không hợp lệ.");
      const target = await connect(token);
      let response;
      try { response = await raw(target.base, route, {...options, headers:{...options.headers, Authorization:"Bearer " + token}}, timeout, outerSignal); }
      catch (error) { if (!locked && selected === target) selected = null; throw error; }
      if (!response.ok && response.status !== 204) {
        if (!locked && selected === target && [401,403,404].includes(response.status)) selected = null;
        throw failure(response.status === 401 ? "UNAUTHORIZED" : "LOCAL_REQUEST_FAILED", response.status === 401 ? "Mã ghép không đúng. Sao chép lại từ file canva_pairing_token.txt của máy này." : "Panel không nhận được phiên ảnh (" + response.status + "). Bấm Kết nối lại để kiểm tra phiên local.");
      }
      return response;
    }
    return {connect, request, lock:() => { locked = true; }, unlock:() => { locked = false; }, invalidate:() => { if (!locked) selected = null; }, status:() => ({port:selected?.port || null, locked})};
  }
  const api = {PORTS:PORTS.slice(), create};
  if (typeof module === "object" && module.exports) module.exports = api;
  root.UOYCanvaTransport = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
