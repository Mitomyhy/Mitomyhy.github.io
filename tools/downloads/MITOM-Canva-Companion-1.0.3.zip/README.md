# UOY Canva Companion — 1.0.3

## Sửa xung đột cổng local — 2026-10-07

- OrderStudio dùng cổng 8767 cho Lark. Canva Panel mới dùng riêng 28767–28771 và tự chọn cổng còn trống; không dừng OrderStudio hay tiến trình khác.
- Cập nhật cả Canva Panel và Companion này. Extension cũ 1.0.2 chỉ gọi cổng 8767 nên không dùng được với Panel mới. Giữ nguyên mã ghép TXT và pairing đã lưu; không xóa dữ liệu Chrome.
- Companion tìm đúng Canva bridge bằng challenge HMAC trước khi gửi mã ghép. Không gửi mã ghép hoặc ảnh tới dịch vụ khác đang giữ cổng 8767.
- Sau cập nhật, Reload UOY Canva Companion ở `chrome://extensions`, mở tab Canva trong Panel rồi bấm Kết nối lại. Nếu phải Load unpacked thư mục mới, dùng mã trong `canva_pairing_token.txt` của chính máy đó để ghép lại một lần.
- Khi idle và Photoshop đổi cổng sau mở lại, companion tự dò lại. Phiên ảnh đã bắt đầu không được tự chuyển Panel hoặc gửi lại ảnh khi mất kết nối. Nếu có nhiều Canva Panel cùng mở, giữ một Panel để tránh ghép nhầm phiên.
- Đã kiểm thử ngoài Photoshop: fallback cổng, challenge/token, restart, warm-tab/job/hủy và kiểm tra PNG thực tế. Chưa xác minh toàn tuyến Canva website thật → Photoshop trên máy đang làm việc.

Companion Chrome riêng cho tab Canva trong panel UOY. Photoroom và mã ghép Photoroom không thay đổi. Không cần Canva API key; sử dụng trang web Canva bằng quyền truy cập tài khoản hiện có.

## Sửa lỗi nhận kết quả — 1.0.2

- Tách địa chỉ ảnh xem trước khỏi địa chỉ PNG tải về. Ảnh xem trước có thể đang tải, dùng đường dẫn tương đối, srcset, JPEG hoặc CDN khác; companion không đọc/tải địa chỉ này và không dùng nó làm kết quả.
- Chỉ bấm Download khi hộp thoại tách nền có đúng một ảnh mang tên ngẫu nhiên của phiên hiện tại và đúng một nút Download khả dụng; hộp thoại đang bận thì tiếp tục chờ. Ảnh cũ, nhiều kết quả hoặc nút mơ hồ vẫn bị từ chối.
- Giữ nguyên giới hạn địa chỉ tải thực tế, quyền extension, kiểm tra PNG, kích thước và độ trong suốt. Không lấy ảnh gốc hoặc preview thay thế khi web không xuất PNG hợp lệ; không vượt đăng nhập/Canva Pro.
- Đã quan sát lại trang Canva thật bằng ảnh cốc tổng hợp ngày 2026-09-12: preview ở `media.canva.com/v2/image-resize`, đúng tên ảnh của phiên và nút Download khả dụng. Bộ đọc cũ áp nhầm danh sách đường dẫn tải `/v2/files/` lên preview này; bản vá không thêm `/v2/image-resize` vào quyền tải.
- Kiểm thử companion dùng DOM/Chrome mô phỏng; chưa xác minh toàn tuyến extension Chrome thật → Photoshop sau bản 1.0.2. Không lưu URL đầy đủ chứa chữ ký hoặc dữ liệu ảnh khách hàng trong chẩn đoán.
- Cập nhật đúng thư mục extension đang nạp, rồi bấm Reload UOY Canva Companion tại chrome://extensions. Giữ mã ghép hiện có.

## Sửa lỗi nhận ô Upload — 1.0.1

- Không yêu cầu nút Upload phải nằm trong khung nhìn có kích thước dương: Chrome thu nhỏ hoặc tab nền có thể trả viewport bằng 0. Xác định vùng tải ảnh chính theo tiêu đề trang và đúng phần tử input liên kết với nút, loại các bản responsive bị CSS ẩn.
- Nhận thêm nhãn Upload your image và các cách viết tiếng Việt, accept dạng image/* hoặc đuôi PNG/JPG/WebP. Input cho phép nhiều file vẫn chỉ nhận đúng một ảnh đang chọn của phiên.
- Chờ Canva khởi tạo ô tải ảnh tối đa 12 giây, kiểm tra hủy/đổi phiên ở mỗi lần chờ. Không chọn đại input đầu tiên trên trang; nếu có nhiều ô thực sự khác nhau trong vùng chính thì dừng. Mã lỗi kèm số lượng h1/input/match, không ghi nội dung ảnh hay dữ liệu khách.
- Giữ mã ghép đã lưu. Sau khi cập nhật đúng thư mục extension đang nạp, bấm Reload UOY Canva Companion tại chrome://extensions để Chrome dùng mã mới.
- Các thay đổi này đã kiểm tra hồi quy bằng DOM/Chrome mô phỏng. Chưa xác minh lại toàn tuyến Chrome thật chạy nền → Photoshop sau bản vá; không cam kết thành công mọi biến thể giao diện Canva.

## Cài một lần

1. Giải nén gói vào thư mục cố định; không di chuyển sau khi nạp extension.
2. Google Chrome → `chrome://extensions` → Developer mode → Load unpacked → chọn `canva-extension` (thư mục có `manifest.json`). Giữ extension Photoroom đang dùng.
3. Mở Photoshop → UOY → Canva. Mở file `%LOCALAPPDATA%\UOY\Canva\settings\canva_pairing_token.txt`, copy mã vào popup UOY Canva Companion → Ghép kết nối. Đây là mã kết nối nội bộ máy, không phải mật khẩu Canva. Không chia sẻ mã; mỗi máy ghép riêng.
4. Trong tab Canva, chủ động chọn/kéo ảnh, lấy từ Photoshop hoặc Clipboard. Thao tác nhận ảnh sẽ bắt đầu một lần upload → Canva tách nền → nhận PNG → thêm Photoshop. Không khôi phục ảnh cũ hoặc tự gửi lại khi lỗi.
5. Nếu cần đăng nhập/hết lượt/Canva Pro/CAPTCHA, mở Canva bằng đúng profile Chrome, xử lý thủ công, rồi chọn lại ảnh. Companion không mua gói, chấp nhận dùng thử, nhập tài khoản hoặc vượt giới hạn.

## Phạm vi bảo vệ

- Cổng riêng trong danh sách cố định `127.0.0.1:28767–28771`, Bearer token chỉ nằm ở popup/service worker, không gửi mã cho Canva. Token bền trong storage; ảnh chỉ ở RAM. Cổng 8767 chỉ được dò challenge không chứa token để tương thích định tuyến cũ; không dùng làm mặc định.
- Chỉ thao tác trang remover công khai `https://www.canva.com/features/background-remover/` trong tab mới do job sở hữu. Không chọn hoặc đóng tab Canva của người dùng, không duyệt design đã lưu.
- Đối chiếu tên file ngẫu nhiên do job tạo với ảnh trong đúng hộp thoại kết quả. Chỉ nhận download sau nút Download khả dụng; không lấy ảnh nguồn/ảnh minh họa/preview làm kết quả thay thế.
- Hook download chỉ được kích hoạt quanh thao tác Download của job, tối đa 25 giây, chỉ bắt thẻ tải PNG ở tab đó. Không có quyền `downloads`, `cookies`, `webRequest` hoặc `<all_urls>`; không quét lịch sử Downloads. Hết phiên sẽ hoàn tác hook và đóng đúng tab thuộc phiên.
- Bản hiện tại hỗ trợ liên kết download PNG `data:`, `blob:` của origin Canva hoặc host media.canva.com theo URL xuất hiện ở kết quả web. Các máy/tài khoản dùng luồng xuất khác sẽ báo lỗi, không tự đoán đường dẫn/API.
- Không gọi API riêng Canva, không lấy cookie/token đăng nhập, không giảm bảo vệ Chrome. Tài khoản Canva, mạng và điều khoản Canva vẫn áp dụng. Canva/Chrome có thể lưu cache hoặc dữ liệu phía dịch vụ; companion không xóa dữ liệu tài khoản hoặc lịch sử web.
- Không mở Canva editor hoặc tự lưu design vào tài khoản. Luồng ở đây là remover công khai. Không cam kết tốc độ, lượt miễn phí hoặc độ phân giải luôn bằng nguồn.
- Giữ bản PNG trong RAM khi nhập Photoshop thất bại; có thể bấm Thêm vào Photoshop hoặc lưu PNG trong panel. Không cần upload/tách nền lại.

## Kiểm tra đã thực hiện ngày 2026-09-12

- Thử trang Canva thật bằng ảnh cốc tổng hợp, không có dữ liệu khách hàng: Upload image → hộp thoại Remove background from image → Download trả PNG 384 × 384, RGBA, alpha 0–255. Lượt thử này không gặp đăng nhập/Pro. Đây không phải cam kết các lượt/tài khoản khác đều miễn phí.
- Kiểm thử mô phỏng companion: giới hạn URL/quyền, nhận đúng tên ảnh, từ chối ảnh cũ/ảnh mơ hồ, phiên/chunk/hủy, lỗi đăng nhập, download hook giới hạn phiên. Không coi unit test là thử toàn bộ Chrome/Photoshop thật.
- Chưa xác minh toàn tuyến extension Chrome chạy nền → broker → Photoshop trên máy này. Website đổi DOM/cách download có thể cần cập nhật adapter. Nếu chạy lỗi, giữ nguyên nguồn và báo lỗi hiển thị; không tắt firewall hay đổi DNS để xử lý.

Nguồn chính thức: [Canva Background Remover](https://www.canva.com/features/background-remover/).
