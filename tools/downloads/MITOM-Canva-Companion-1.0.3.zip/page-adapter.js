/* Public Canva remover DOM observed 2026-09-12 with a synthetic image.
 * No app internals, guessed API endpoints, generated editor routes, or source-image fallback. */
(function(root){
  "use strict";
  function label(e){return String(e.getAttribute("aria-label")||e.textContent||"").trim();}
  function visible(e){return !!e&&e.getClientRects().length>0&&e.getAttribute("aria-hidden")!=="true";}
  function buttons(scope, pattern){return Array.from(scope.querySelectorAll('button,[role="button"]')).filter(e=>visible(e)&&!e.disabled&&e.getAttribute("aria-disabled")!=="true"&&pattern.test(label(e)));}
  const UPLOAD_NAME=/^(?:upload(?: your)? (?:image|photo)|choose (?:an? )?(?:image|photo)|tải (?:hình )?ảnh(?: của bạn)? lên|tải lên (?:hình )?ảnh|chọn (?:hình )?ảnh)$/i;
  function displayed(e,doc){
    if(!e)return false;
    const view=doc&&doc.defaultView;let current=e;
    while(current&&current!==doc){
      if(current.hidden||(current.getAttribute&&(current.getAttribute("hidden")!==null||current.getAttribute("aria-hidden")==="true")))return false;
      if(view&&typeof view.getComputedStyle==="function"){
        const style=view.getComputedStyle(current);if(style&&(style.display==="none"||style.visibility==="hidden"||style.visibility==="collapse"))return false;
      }
      current=current.parentElement;
    }
    // Minimized/background tabs can have a zero viewport. Geometry is not a
    // readiness/authorization signal: use CSS visibility, not viewport bounds.
    if(view&&typeof view.getComputedStyle==="function")return true;
    return visible(e);
  }
  function accepts(input,mime){
    const accept=String(input.getAttribute("accept")||"").toLowerCase().split(",").map(x=>x.trim());
    const extension=mime==="image/jpeg"?[".jpg",".jpeg"]:mime==="image/webp"?[".webp"]:[".png"];
    return !input.disabled&&(accept.includes("image/*")||accept.includes(mime)||extension.some(x=>accept.includes(x)));
  }
  function imageInputs(scope,mime){return Array.from(scope.querySelectorAll('input[type="file"]')).filter(e=>accepts(e,mime));}
  function localOwner(input,doc,mime,limit){
    let parent=input.parentElement;
    for(let depth=0;parent&&depth<12;depth++,parent=parent.parentElement){
      const inputs=imageInputs(parent,mime);if(inputs.length>1)return null;
      if(inputs.length!==1||inputs[0]!==input)continue;
      const displayedControls=Array.from(parent.querySelectorAll('button,[role="button"],label')).filter(e=>displayed(e,doc));
      const controls=displayedControls.filter(e=>!e.disabled&&e.getAttribute("aria-disabled")!=="true");
      const named=controls.filter(e=>UPLOAD_NAME.test(label(e).replace(/\s+/g," ")));
      if(named.length)return {input,owner:parent,controls:named};
      // A unique image input next to its one visible control in the primary
      // hero remains unambiguous in other site locales; do not infer handlers.
      if(controls.length===1)return {input,owner:parent,controls,structural:true};
      // A recognized local owner whose controls are disabled/ambiguous is
      // still loading. Never climb outward to borrow an unrelated CTA.
      if(displayedControls.length)return null;
      if(parent===limit)return null;
    }
    return null;
  }
  function after(a,b){return !!(a&&typeof a.compareDocumentPosition==="function"&&(a.compareDocumentPosition(b)&4));}
  function inspectUpload(doc,mime="image/png"){
    const all=imageInputs(doc,mime),headings=Array.from(doc.querySelectorAll('h1,[role="heading"][aria-level="1"]')).filter(e=>displayed(e,doc));
    if(headings.length!==1)return {status:headings.length>1?"ambiguous":"waiting",diagnostic:"h1="+headings.length+", input="+all.length+", region=unproven, match=0"};
    let candidates=[],scoped=false,scopeLimit=null,withinRegion=null;
    if(headings.length===1){
      const heading=headings[0];let scope=heading.parentElement;
      for(let depth=0;scope&&depth<12;depth++,scope=scope.parentElement){
        const secondary=Array.from(scope.querySelectorAll('h2,[role="heading"][aria-level="2"]')).filter(e=>displayed(e,doc));
        if(secondary.length)break;
        const inputs=imageInputs(scope,mime);
        if(inputs.length){candidates=inputs;scoped=true;scopeLimit=scope;break;}
      }
      if(!scoped&&typeof heading.compareDocumentPosition==="function"){
        const boundaries=Array.from(doc.querySelectorAll('h1,h2,[role="heading"][aria-level="1"],[role="heading"][aria-level="2"]')).filter(e=>e!==heading&&displayed(e,doc)&&after(heading,e));
        let boundary=null;for(const item of boundaries)if(!boundary||after(item,boundary))boundary=item;
        candidates=all.filter(e=>after(heading,e)&&(!boundary||after(e,boundary)));scoped=true;
        withinRegion=e=>after(heading,e)&&(!boundary||after(e,boundary));
      }
    }
    const owners=(scoped?candidates:[]).map(e=>localOwner(e,doc,mime,scopeLimit)).filter(Boolean).filter(x=>!withinRegion||x.controls.every(withinRegion));
    const unique=[...new Set(owners.map(x=>x.input))];
    // Numeric diagnostics only: no customer text, filenames, URL tokens or DOM dump.
    const diagnostic="h1="+headings.length+", input="+all.length+", region="+(scoped?"hero":"unproven")+", match="+unique.length;
    if(unique.length===1)return {status:"ready",input:unique[0],diagnostic};
    return {status:unique.length>1?"ambiguous":"waiting",diagnostic};
  }
  function uploadInput(doc,mime){
    const found=inspectUpload(doc,mime);
    if(found.status==="ready")return found.input;
    const error=new Error(found.status==="ambiguous"?"Canva đang có nhiều ô tải ảnh trong cùng vùng chính. Không chọn ô mơ hồ.":"Canva chưa hiển thị ô tải ảnh sẵn sàng.");
    error.code=found.status==="ambiguous"?"CANVA_UPLOAD_AMBIGUOUS":"CANVA_UPLOAD_NOT_READY";error.diagnostic=found.diagnostic;throw error;
  }
  async function waitForUpload(doc,options={}){
    const now=options.now||Date.now,pause=options.pause||(()=>new Promise(resolve=>setTimeout(resolve,250)));
    const until=now()+Math.min(12000,Math.max(1,Number(options.timeoutMs)||12000));let found;
    do{
      if(options.ensure)options.ensure();
      found=inspectUpload(doc,options.mime||"image/png");
      if(found.status==="ready")return found.input;
      if(now()>=until)break;
      await pause();
    }while(true);
    const detail=found.status==="ambiguous"?"có nhiều ô tải ảnh trong vùng chính":"chưa tải xong ô nhận ảnh";
    throw new Error("Canva "+detail+" sau khi chờ sẵn sàng ("+found.diagnostic+"). Mở trang Canva kiểm tra, rồi chọn lại ảnh. Chưa gửi ảnh lên web.");
  }
  function blocker(doc){
    const dialogs=Array.from(doc.querySelectorAll('[role="dialog"],dialog,[role="alert"]')).filter(visible);
    const text=dialogs.map(e=>label(e)+" "+(e.textContent||"")).join(" ");
    if(/captcha|verify.{0,20}human|security check|xác minh|verification/i.test(text)||Array.from(doc.querySelectorAll('iframe[src*="captcha"],iframe[title*="challenge"]')).some(visible))return "Canva yêu cầu xác minh. Mở Canva và xử lý thủ công, sau đó chọn lại ảnh; companion không vượt CAPTCHA.";
    if(/sign in|log in|sign up|đăng nhập|đăng ký|upgrade|subscribe|payment|nâng cấp|start.{0,12}trial|try.{0,12}pro|dùng thử|limit reached|daily limit|too many|đạt giới hạn/i.test(text))return "Canva yêu cầu đăng nhập, Canva Pro hoặc đã hết lượt. Mở Canva bằng đúng tài khoản và xử lý thủ công rồi chọn lại ảnh. Không tự mua gói hay gửi lại.";
    if(/(?:error|failed|try again|lỗi|không thể)/i.test(dialogs.filter(e=>e.getAttribute("role")==="alert").map(e=>e.textContent||"").join(" ")))return "Canva báo xử lý thất bại. Kiểm tra ảnh/mạng hoặc thử trên web rồi chọn lại ảnh.";
    return "";
  }
  function result(doc,filename){
    const dialogs=Array.from(doc.querySelectorAll('[role="dialog"]')).filter(e=>visible(e)&&/Remove background from image|Xóa nền.*ảnh|Xoá nền.*ảnh/i.test(e.getAttribute("aria-label")||""));
    if(dialogs.length>1)throw new Error("Canva có nhiều kết quả. Dừng để tránh nhận nhầm ảnh.");
    if(!dialogs.length)return null;
    const dialog=dialogs[0], images=Array.from(dialog.querySelectorAll('img')).filter(e=>e.getAttribute("alt")===filename), downloads=buttons(dialog,/^(Download|Tải xuống)$/i);
    if(images.length>1||downloads.length>1)throw new Error("Canva có nhiều ảnh/nút tải; không nhận kết quả mơ hồ.");
    if(images.length!==1||downloads.length!==1||dialog.getAttribute("aria-busy")==="true")return null;
    // The exact job filename identifies the result dialog; an enabled Download
    // control signals export readiness. Its preview can be loading, relative,
    // srcset-only, JPEG, or served from a different preview CDN. Never read,
    // return, fetch, or treat that preview URL as download authority.
    // content.js captures only the actual Download action; its URL allowlist,
    // PNG MIME/size checks and the broker's full PNG/alpha validation still apply.
    return {button:downloads[0]};
  }
  const api={label,visible,buttons,displayed,accepts,localOwner,inspectUpload,uploadInput,waitForUpload,blocker,result};
  if(typeof module==="object"&&module.exports)module.exports=api;
  root.UOYCanvaPage=api;
})(typeof globalThis!=="undefined"?globalThis:this);
