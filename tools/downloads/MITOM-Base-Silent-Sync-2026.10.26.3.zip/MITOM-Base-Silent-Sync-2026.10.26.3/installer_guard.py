"""Per-user UOY CEP installer. No elevation, process termination or profile copying.

Only explicitly listed, hash-verified release files are installed. ``base_root``
is an isolated test fixture layout (Roaming/ and Local/), never a production
override. The caller must obtain explicit Install/Update consent, including the
per-user unsigned CEP setting. HTTPS/signature verification of downloaded
releases belongs to the launcher; this module validates the embedded payload.
"""
from __future__ import annotations

import base64
import contextlib
import ctypes
import functools
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET

MANIFEST = "payload-manifest.json"
MAX_MANIFEST = 16 * 1024 * 1024
MAX_FILE = 1536 * 1024 * 1024
MAX_PAYLOAD = 5 * 1024 * 1024 * 1024
DEPTH_MODELS = {"moge-2-vitl-normal.pt": (1323815904, "280741fd09bc3f403ccff9967784c2a391b52d2c0742ae3efdb21d9f90cc1a01"),
                "depth-anything-v2-vits.pth": (99218434, "715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378")}
SPACE_RESERVE = 32 * 1024 * 1024
PRIVATE_PARTS = {".git", ".huong_tool", "app_data", "profiles", "logs", "__pycache__"}
PRIVATE_NAMES = {"local-config.json", "depth-runtime.json", "active-v1.json",
                 "application-key.dat", "tool_dir.txt", "pythonw-path.txt",
                 "install-receipt.json", "pending-transaction.json"}
DEVICE = re.compile(r"^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)", re.I)


class InstallError(RuntimeError):
    """A safe, actionable installation failure; never contains credentials."""


class _FileSource:
    """A regular file plus its already authorized content digest."""
    def __init__(self, path, sha256):
        self.path, self.sha256 = Path(path), sha256


def _json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _pairs(items):
    out = {}
    for key, value in items:
        if key in out:
            raise InstallError("Duplicate JSON field in package or receipt.")
        out[key] = value
    return out


def _read_json(file, limit=MAX_MANIFEST):
    _plain(file)
    if not file.is_file() or file.stat().st_size > limit:
        raise InstallError("Missing or oversized package metadata.")
    try:
        value = json.loads(file.read_text(encoding="utf-8-sig"), object_pairs_hook=_pairs)
    except (ValueError, UnicodeError) as exc:
        raise InstallError("Invalid JSON package metadata.") from exc
    if not isinstance(value, dict):
        raise InstallError("Package metadata must be an object.")
    return value


def _plain(path):
    """Check every existing ancestor without resolving away links/junctions."""
    path = Path(os.path.abspath(path))
    for item in (path, *path.parents):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise InstallError("Linked paths and Windows junctions are not supported.")
        if item != path and not stat.S_ISDIR(info.st_mode):
            raise InstallError("An installation ancestor is not a directory.")
    return path


def _relative(value):
    if (not isinstance(value, str) or not value or len(value) > 600 or
            "\\" in value or re.search(r'[:<>"|?*\x00-\x1f\x7f]', value)):
        raise InstallError("Unsafe package-relative path.")
    parts = value.split("/")
    if any(not p or p in (".", "..") or p.endswith((".", " ")) or
           DEVICE.match(p) for p in parts) or PurePosixPath(value).is_absolute():
        raise InstallError("Unsafe package-relative path.")
    return parts


def _child(root, relative):
    parts = _relative(relative)
    path = _plain(root.joinpath(*parts))
    if root not in path.parents:
        raise InstallError("Path escaped its installation root.")
    return path


def _hash(file):
    file = _plain(file)
    try:
        info = file.stat()
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(info.st_mode):
        raise InstallError("Expected a regular installation file.")
    digest = hashlib.sha256()
    with file.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _roots(base_root):
    sandbox = base_root is not None
    if sandbox:
        base = _plain(Path(base_root))
        if base == Path(base.anchor):
            raise InstallError("A drive root cannot be a fixture directory.")
        roaming, local = base / "Roaming", base / "Local"
    else:
        if os.name != "nt":
            raise InstallError("Production installation requires Windows x64 with Photoshop CEP support.")
        if not os.environ.get("APPDATA") or not os.environ.get("LOCALAPPDATA"):
            raise InstallError("Windows per-user application directories are unavailable.")
        roaming, local = Path(os.environ["APPDATA"]), Path(os.environ["LOCALAPPDATA"])
        if any(not p.is_absolute() or str(p).startswith("\\\\") or p == Path(p.anchor)
               for p in (roaming, local)):
            raise InstallError("Use local, absolute Windows per-user application directories.")
    roaming, local = _plain(roaming), _plain(local)
    roots = {"panel": roaming / "Adobe/CEP/extensions/com.uoy.orderpanel",
             "coexist": local / "UOY/BaseCoexist",
             "companion": local / "UOY/Companion",
             "core": local / "UOY/Launcher/current",
             "launcher": local / "UOY/Launcher"}
    for key in roots:
        roots[key] = _plain(roots[key])
    if sandbox and os.name == "nt":
        real = [Path(os.environ.get("APPDATA", "C:/invalid")) / "Adobe/CEP/extensions/com.uoy.orderpanel",
                Path(os.environ.get("LOCALAPPDATA", "C:/invalid")) / "UOY"]
        for test in roots.values():
            for target in real:
                if test == target or test in target.parents or target in test.parents:
                    raise InstallError("A fixture cannot overlap a live installation.")
    return roots, local, sandbox


def _identity(roots):
    data = "|".join(str(roots[k]).lower() for k in sorted(roots))
    data += "|" + os.environ.get("COMPUTERNAME", "fixture") + "|" + os.environ.get("USERNAME", "fixture")
    actual_panel = Path(os.environ.get("APPDATA", "non-production-fixture")) / "Adobe/CEP/extensions/com.uoy.orderpanel"
    actual_core = Path(os.environ.get("LOCALAPPDATA", "non-production-fixture")) / "UOY/Launcher/current"
    if (os.name == "nt" and str(roots["panel"]).lower() == str(actual_panel).lower() and
            str(roots["core"]).lower() == str(actual_core).lower()):
        # Same PC/user names are not a Windows identity. Do not accept a copied
        # backup from another machine/account with matching display names.
        data += "|" + _windows_identity()
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


@functools.lru_cache(maxsize=1)
def _windows_identity():
    """Read-only current-user SID + machine GUID; only their hash is persisted."""
    import winreg
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    advapi.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                          wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    advapi.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.LPWSTR)]
    token, size, sid_text = wintypes.HANDLE(), wintypes.DWORD(), wintypes.LPWSTR()
    try:
        if not advapi.OpenProcessToken(kernel.GetCurrentProcess(), 8, ctypes.byref(token)):
            raise InstallError("Cannot verify the current Windows account. No files changed.")
        advapi.GetTokenInformation(token, 1, None, 0, ctypes.byref(size))
        if not 1 <= size.value <= 65536:
            raise InstallError("Cannot verify the current Windows account.")
        buffer = ctypes.create_string_buffer(size.value)
        if not advapi.GetTokenInformation(token, 1, buffer, size.value, ctypes.byref(size)):
            raise InstallError("Cannot verify the current Windows account.")
        # TOKEN_USER begins with SID_AND_ATTRIBUTES; its first field is PSID.
        sid = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_void_p)).contents.value
        if not advapi.ConvertSidToStringSidW(sid, ctypes.byref(sid_text)):
            raise InstallError("Cannot verify the current Windows account SID.")
        sid_value = sid_text.value
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            machine_guid, _ = winreg.QueryValueEx(key, "MachineGuid")
        if not isinstance(machine_guid, str) or not 1 <= len(machine_guid) <= 256 or not sid_value:
            raise InstallError("Cannot verify this Windows machine identity.")
        return machine_guid.upper() + "|" + sid_value
    except OSError as exc:
        raise InstallError("Cannot verify this Windows machine/account. No files changed.") from exc
    finally:
        if sid_text:
            kernel.LocalFree(ctypes.cast(sid_text, ctypes.c_void_p))
        if token:
            kernel.CloseHandle(token)


@contextlib.contextmanager
def _lock(roots, sandbox):
    """Kernel-owned per-profile mutex; it disappears automatically after a crash."""
    if not sandbox:
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
        kernel.CreateMutexW.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.ReleaseMutex.argtypes = [wintypes.HANDLE]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.CreateMutexW(None, False, "Global\\UOYLauncherInstall-" + _identity(roots))
        if not handle:
            raise InstallError("Cannot acquire the per-user installer lock.")
        acquired = False
        try:
            acquired = kernel.WaitForSingleObject(handle, 0) in (0, 0x80)
            if not acquired:
                raise InstallError("Another UOY install/update is already running for this user.")
            yield
        finally:
            if acquired:
                kernel.ReleaseMutex(handle)
            kernel.CloseHandle(handle)
    else:
        # Test-only lock; never used for a production installation.
        directory = roots["launcher"]
        _plain(directory).mkdir(parents=True, exist_ok=True)
        file = directory / ".fixture-install.lock"
        _plain(file)
        try:
            fd = os.open(file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise InstallError("Another UOY install/update is already running.") from exc
        try:
            os.close(fd)
            yield
        finally:
            _plain(file).unlink(missing_ok=True)


def _processes():
    """Actual current-session executable names; no shell search/PID guess or kill."""
    if os.name != "nt":
        return []
    from ctypes import wintypes
    class Entry(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
                    ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", wintypes.LONG),
                    ("dwFlags", wintypes.DWORD), ("szExeFile", wintypes.WCHAR * 260)]
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(Entry)]
    kernel.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(Entry)]
    kernel.ProcessIdToSessionId.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    session = wintypes.DWORD()
    if not kernel.ProcessIdToSessionId(os.getpid(), ctypes.byref(session)):
        raise InstallError("Cannot check Photoshop in the current Windows session.")
    handle = kernel.CreateToolhelp32Snapshot(2, 0)
    if handle in (None, ctypes.c_void_p(-1).value):
        raise InstallError("Cannot check running applications. No process was stopped.")
    rows = []
    try:
        item = Entry()
        item.dwSize = ctypes.sizeof(Entry)
        more = kernel.Process32FirstW(handle, ctypes.byref(item))
        while more:
            if item.szExeFile.lower() in {"photoshop.exe", "orderstudio.exe"}:
                owner_session = wintypes.DWORD()
                if kernel.ProcessIdToSessionId(item.th32ProcessID, ctypes.byref(owner_session)) and owner_session.value == session.value:
                    rows.append({"name": item.szExeFile, "pid": int(item.th32ProcessID)})
            more = kernel.Process32NextW(handle, ctypes.byref(item))
    finally:
        kernel.CloseHandle(handle)
    return rows


def _closed(sandbox):
    if sandbox:
        return
    rows = _processes()
    if rows:
        names = ", ".join(f"{row['name']} (PID {row['pid']})" for row in rows)
        raise InstallError("Save your work and close these applications: " + names +
                           ". Chrome may remain open. No process was stopped.")


def _space_location(path):
    """A local volume and an existing directory usable for disk_usage()."""
    candidate = _plain(path)
    if candidate.is_file():
        candidate = candidate.parent
    while not candidate.exists():
        parent = candidate.parent
        if parent == candidate:
            raise InstallError("Cannot locate the installation volume for a free-space check.")
        candidate = parent
    _plain(candidate)
    if not candidate.is_dir():
        raise InstallError("The installation volume is not a directory.")
    return str(candidate.anchor).lower(), candidate


def _space_preflight(changes, roots):
    """Conservative volume budget before a lock, key generation or any writes.

    Changed destination bytes, all originals retained on the backup volume,
    each volume's largest atomic staging file and metadata/recovery reserve are
    counted. Available space is checked at every existing destination ancestor;
    the minimum is used for a shared anchor (safe for unusual mount layouts).
    Other applications may still consume space later, so this is not a quota.
    """
    budgets = {}
    def add(path, new_bytes=0, backup_bytes=0, stage_bytes=0):
        volume, existing = _space_location(path)
        item = budgets.setdefault(volume, {"new": 0, "backup": 0, "stage": 0, "parents": set()})
        item["new"] += new_bytes
        item["backup"] += backup_bytes
        item["stage"] = max(item["stage"], stage_bytes)
        item["parents"].add(existing)
    add(roots["launcher"])
    # Absent local settings/credentials are small and covered by the metadata
    # reserve, but their destination volumes must also be checked.
    add(roots["panel"])
    add(roots["coexist"])
    for row in changes:
        size = row["entry"]["size"]
        add(row["target"], new_bytes=size, stage_bytes=size)
        if row["before"] is not None:
            info = _plain(row["target"]).stat()
            add(roots["launcher"], backup_bytes=info.st_size, stage_bytes=info.st_size)
    result = []
    for volume, item in sorted(budgets.items()):
        required = item["new"] + item["backup"] + item["stage"] + SPACE_RESERVE
        try:
            available = min(shutil.disk_usage(parent).free for parent in item["parents"])
        except OSError as exc:
            raise InstallError("Cannot check free space on the installation volume. No files changed.") from exc
        if available < required:
            raise InstallError("Not enough free disk space on " + volume + ": need at least " +
                               str((required + 1024 * 1024 - 1) // (1024 * 1024)) +
                               " MiB including backups/recovery reserve. Free space and retry; no files changed.")
        result.append({"volume": volume, "required_bytes": required, "available_bytes": available})
    return result


def _official_crt():
    """Trust-check the recipient's installed CRT; never redistribute that DLL."""
    from ctypes import wintypes
    if os.name != "nt":
        raise InstallError("Microsoft Visual C++ x64 runtime is required on Windows.")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    buffer = ctypes.create_unicode_buffer(32768)
    length = kernel.GetSystemDirectoryW(buffer, len(buffer))
    if not length or length >= len(buffer):
        raise InstallError("Cannot locate the official Windows system directory.")
    source = _plain(Path(buffer.value) / "msvcp140.dll")
    if not source.is_file():
        raise InstallError("Install the official Microsoft Visual C++ x64 runtime, then retry: https://aka.ms/vs/17/release/vc_redist.x64.exe . No Panel files changed.")
    class FileInfo(ctypes.Structure):
        _fields_ = [("cbStruct", wintypes.DWORD), ("pcwszFilePath", wintypes.LPCWSTR),
                    ("hFile", wintypes.HANDLE), ("pgKnownSubject", ctypes.c_void_p)]
    class TrustData(ctypes.Structure):
        _fields_ = [("cbStruct", wintypes.DWORD), ("pPolicyCallbackData", ctypes.c_void_p),
                    ("pSIPClientData", ctypes.c_void_p), ("dwUIChoice", wintypes.DWORD),
                    ("fdwRevocationChecks", wintypes.DWORD), ("dwUnionChoice", wintypes.DWORD),
                    ("pFile", ctypes.POINTER(FileInfo)), ("dwStateAction", wintypes.DWORD),
                    ("hWVTStateData", wintypes.HANDLE), ("pwszURLReference", wintypes.LPCWSTR),
                    ("dwProvFlags", wintypes.DWORD), ("dwUIContext", wintypes.DWORD),
                    ("pSignatureSettings", ctypes.c_void_p)]
    info = FileInfo(ctypes.sizeof(FileInfo), str(source), None, None)
    data = TrustData()
    data.cbStruct, data.dwUIChoice, data.dwUnionChoice = ctypes.sizeof(TrustData), 2, 1
    data.pFile, data.dwStateAction, data.dwProvFlags = ctypes.pointer(info), 1, 0x1010
    action = (ctypes.c_byte * 16).from_buffer_copy(uuid.UUID("00aac56b-cd44-11d0-8cc2-00c04fc295ee").bytes_le)
    trust = ctypes.WinDLL("wintrust", use_last_error=True).WinVerifyTrust
    trust.argtypes = [wintypes.HWND, ctypes.c_void_p, ctypes.c_void_p]
    trust.restype = wintypes.LONG
    try:
        if trust(wintypes.HWND(-1), ctypes.byref(action), ctypes.byref(data)) != 0:
            raise InstallError("The installed Microsoft Visual C++ x64 DLL did not pass Windows signature trust. Repair it from Microsoft, then retry; no Panel files changed.")
    finally:
        data.dwStateAction = 2
        trust(wintypes.HWND(-1), ctypes.byref(action), ctypes.byref(data))
    return source


def _runtime_prerequisite_plans(available, roots):
    numpy = "core/python/Lib/site-packages/numpy/_core/_multiarray_umath.cp312-win_amd64.pyd"
    if numpy not in available:
        return []
    relative = "python/Lib/site-packages/numpy.libs/msvcp140-263139962577ecda4cd9469ca360a746.dll"
    source = _official_crt()
    digest = _hash(source)
    target = _child(roots["core"], relative)
    before = _hash(target)
    if before == digest:
        return []
    return [{"entry": {"path": "core/" + relative, "size": source.stat().st_size, "sha256": digest},
             "target": target, "before": before, "source": source}]


def _manifest(payload_root):
    root = _plain(Path(payload_root))
    value = _read_json(_child(root, MANIFEST))
    if (set(value) != {"schema", "version", "files"} or value["schema"] != 1 or
            not isinstance(value["version"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", value["version"]) or
            not isinstance(value["files"], list) or not 2 <= len(value["files"]) <= 50000):
        raise InstallError("Unsupported payload manifest.")
    seen, entries, total = set(), [], 0
    for entry in value["files"]:
        if not isinstance(entry, dict) or set(entry) != {"path", "sha256", "size"}:
            raise InstallError("Invalid payload file entry.")
        parts = _relative(entry["path"])
        if len(parts) < 2 or parts[0] not in {"panel", "coexist", "companion", "core"}:
            raise InstallError("Unapproved payload component.")
        if (any(p.lower() in PRIVATE_PARTS for p in parts) or
                any(p.lower() in PRIVATE_NAMES for p in parts) or
                entry["path"].lower() in seen):
            raise InstallError("Private/generated or duplicate payload path.")
        seen.add(entry["path"].lower())
        if (not isinstance(entry["sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", entry["sha256"]) or
                type(entry["size"]) is not int or not 0 <= entry["size"] <= MAX_FILE):
            raise InstallError("Invalid payload checksum or file size.")
        total += entry["size"]
        if total > MAX_PAYLOAD:
            raise InstallError("Payload exceeds the supported core package size.")
        source = _child(root, entry["path"])
        if _hash(source) != entry["sha256"] or source.stat().st_size != entry["size"]:
            raise InstallError("Payload integrity check failed: " + entry["path"])
        entries.append(dict(entry))
    expected = {entry["path"] for entry in entries} | {MANIFEST}
    observed = set()
    for directory, children, files in os.walk(root, followlinks=False):
        _plain(Path(directory))
        for name in children:
            _plain(Path(directory) / name)
        for name in files:
            file = _plain(Path(directory) / name)
            relative = file.relative_to(root).as_posix()
            if relative not in expected:
                raise InstallError("Unlisted file in release payload: " + relative)
            observed.add(relative)
    if observed != expected:
        raise InstallError("Payload inventory differs from its manifest.")
    if not {"panel/csxs/manifest.xml", "panel/index.html"} <= seen:
        raise InstallError("The package is missing the Photoshop CEP panel entry points.")
    _panel_identity(_child(root, "panel/CSXS/manifest.xml"))
    return root, value["version"], entries


def _panel_identity(file):
    _plain(file)
    if not file.is_file() or file.stat().st_size > 128 * 1024:
        raise InstallError("Existing target is not an identifiable UOY CEP panel.")
    source = file.read_bytes()
    if b"<!DOCTYPE" in source.upper() or b"<!ENTITY" in source.upper():
        raise InstallError("Unsupported CEP manifest XML declaration.")
    try:
        tree = ET.fromstring(source)
    except ET.ParseError as exc:
        raise InstallError("Invalid CEP manifest.") from exc
    if tree.tag != "ExtensionManifest" or tree.attrib.get("ExtensionBundleId") != "com.uoy.orderpanel":
        raise InstallError("Existing target belongs to another extension. No files replaced.")



def _panel_destination_identity(panel):
    """Adopt no existing extension: only an absent or directory-only skeleton.

    Rollback intentionally preserves directories. Inspect every descendant of
    this exact configured destination without deleting anything or following
    links. The caller repeats this read-only check under the installer lock.
    A regular file of any name, even zero bytes, requires a valid UOY manifest.
    """
    panel = _plain(panel)
    if not panel.exists():
        return
    if not panel.is_dir():
        raise InstallError("Existing target is not an identifiable UOY CEP panel.")
    manifest = _child(panel, "CSXS/manifest.xml")
    if manifest.exists():
        _panel_identity(manifest)
        return
    stack = [panel]
    visited = 0
    while stack:
        directory = stack.pop()
        for child in directory.iterdir():
            child = _plain(child)
            visited += 1
            if visited > 4096 or not child.is_dir():
                raise InstallError("Existing target is not an identifiable UOY CEP panel.")
            stack.append(child)


def _dpapi_key():
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]
    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    crypt.CryptProtectData.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.POINTER(Blob),
                                      ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    raw = (ctypes.c_ubyte * 32).from_buffer_copy(secrets.token_bytes(32))
    entropy_bytes = b"UOY.BaseCoexist.Application.v1"
    entropy = (ctypes.c_ubyte * len(entropy_bytes)).from_buffer_copy(entropy_bytes)
    plain, salt, result = Blob(32, raw), Blob(len(entropy_bytes), entropy), Blob()
    try:
        if not crypt.CryptProtectData(ctypes.byref(plain), "UOY local application key", ctypes.byref(salt),
                                      None, None, 1, ctypes.byref(result)):
            raise InstallError("Windows cannot protect the new local application key. Existing pairing unchanged.")
        return ctypes.string_at(result.data, result.size)
    finally:
        ctypes.memset(raw, 0, 32)
        if result.data:
            kernel.LocalFree(result.data)


def _depth_shape(value):
    keys = {"python", "worker", "modelsRoot", "dataRoot"}
    return (set(value) == keys and all(isinstance(value[key], str) and
            Path(value[key]).is_absolute() and not value[key].startswith("\\\\") and
            Path(value[key]) != Path(Path(value[key]).anchor) for key in keys))


def _valid_depth(value, managed_data=None):
    """Preserve only an existing exact, local runtime with the pinned models."""
    if not _depth_shape(value):
        return False
    try:
        python, worker = _plain(value["python"]), _plain(value["worker"])
        if (python.name.lower() != "python.exe" or worker.name.lower() != "engine.py" or
                not python.is_file() or not worker.is_file()):
            return False
        models = _plain(value["modelsRoot"])
        data = _plain(value["dataRoot"])
        new_managed_data = managed_data is not None and data == managed_data and not data.exists()
        if not models.is_dir() or (not data.is_dir() and not new_managed_data):
            return False
        for name, (size, digest) in DEPTH_MODELS.items():
            file = _child(models, name)
            if not file.is_file() or file.stat().st_size != size or _hash(file) != digest:
                return False
        return True
    except (OSError, InstallError):
        return False


def _generated(roots, local, sandbox, available):
    """Generate absent settings; rebind only validated same-user Base runtime paths."""
    plans, warnings = [], []
    config = roots["panel"] / "local-config.json"
    if _hash(config) is None:
        plans.append((config, _json_bytes({"exportRoot": str(local / "UOY/Export"),
                                          "uploadToolDir": str(roots["core"] / "upload-tool")}), "generated/local-config.json", None))
    depth = roots["panel"] / "depth-runtime.json"
    depth_required = {"core/python/python.exe", "core/depth-engine/engine.py",
                      "core/depth-models/moge-2-vitl-normal.pt",
                      "core/depth-models/depth-anything-v2-vits.pth"}
    if depth_required <= available:
        before = _hash(depth)
        try:
            old = _read_json(depth, 65536) if before is not None else None
        except InstallError:
            old = {}  # Unrecognized settings remain byte-preserved and blocked.
        if old is not None and _valid_depth(old, local / "UOY/Depth3D/data"):
            warnings.append("Existing valid machine-local Depth configuration and data paths were preserved; no caches or models were moved.")
        elif old is not None and not _depth_shape(old):
            warnings.append("DEPTH_CONFIGURATION_REVIEW_REQUIRED: unknown Depth configuration schema was preserved. 3D remains blocked until it is reviewed; no user data was moved.")
        else:
            data_root = local / "UOY/Depth3D/data"
            if old is not None:
                try:
                    candidate = _plain(old["dataRoot"])
                    managed = local / "UOY"
                    known_migrated = "uoy-3d" in {part.lower() for part in candidate.parts} and candidate.name.lower() == "data"
                    if candidate.is_dir() and (managed in candidate.parents or known_migrated):
                        data_root = candidate
                except (OSError, InstallError):
                    pass
            config_bytes = _json_bytes({"python": str(roots["core"] / "python/python.exe"),
                         "worker": str(roots["core"] / "depth-engine/engine.py"),
                         "modelsRoot": str(roots["core"] / "depth-models"),
                         "dataRoot": str(data_root)})
            if hashlib.sha256(config_bytes).hexdigest() != before:
                plans.append((depth, config_bytes, "generated/depth-runtime.json", before))
            if old is not None:
                warnings.append("Stale local Depth runtime paths were rebound to the managed installation; prior configuration is in the rollback backup. No old data was deleted.")
    node = roots["core"] / "node.exe"
    active, key = roots["coexist"] / "active-v1.json", roots["coexist"] / "application-key.dat"
    active_exists, key_exists = _hash(active) is not None, _hash(key) is not None
    required = {"core/node.exe", "coexist/coexist-host.js", "coexist/coexist-common.js",
                "coexist/coexist-client.js", "panel/js/lark-base-bridge.js", "panel/js/lark-pairing-store.js"}
    if active_exists != key_exists:
        warnings.append("Existing Base bridge configuration is incomplete; it was preserved. Use Repair Base/pairing after installation.")
    elif active_exists:
        try:
            active_hash = _hash(active)
            old = _read_json(active, 4096)
            allowed = {"version", "enabled", "machine", "profile", "pipeId", "nodePath",
                       "hostPath", "bridgePath", "pairStorePath", "staticRoot"}
            local_profile = Path(str(old.get("profile", ".")))
            if (set(old) != allowed or type(old.get("version")) is not int or old["version"] != 1 or
                    type(old.get("enabled")) is not bool or
                    str(old.get("machine", "")).lower() != os.environ.get("COMPUTERNAME", "FIXTURE").lower() or
                    str(local_profile).lower() != str(local).lower() or
                    not isinstance(old.get("pipeId"), str) or not re.fullmatch(r"[a-f0-9]{32}", old["pipeId"]) or
                    not required <= available):
                raise InstallError("Existing Base configuration identity differs.")
            updated = dict(old)
            for field, expected in (("nodePath", node),
                                    ("hostPath", roots["coexist"] / "coexist-host.js"),
                                    ("bridgePath", roots["panel"] / "js/lark-base-bridge.js"),
                                    ("pairStorePath", roots["panel"] / "js/lark-pairing-store.js"),
                                    ("staticRoot", roots["panel"] / "lark-base-extension")):
                if not isinstance(old[field], str) or not Path(old[field]).is_absolute():
                    raise InstallError("Existing Base paths are not absolute.")
                updated[field] = str(expected)
            if any(old[field].lower() != updated[field].lower() for field in
                   ("nodePath", "hostPath", "bridgePath", "pairStorePath", "staticRoot")):
                plans.append((active, _json_bytes(updated), "generated/active-v1.json", active_hash))
                warnings.append("Existing Base runtime paths were moved to the stable managed installation. Pairing, pipe ID, enablement and application key were preserved.")
        except Exception:
            warnings.append("Existing Base bridge configuration has old/unavailable paths or a different machine identity. It and its key were preserved; review Base setup after installation.")
    elif not active_exists and required <= available:
        if sandbox:
            # Fixture only, not a usable credential and never sent to a live root.
            protected = b"UOY-TEST-NOT-A-DPAPI-KEY"
        else:
            protected = _dpapi_key()
        plans.append((key, protected, "generated/application-key.dat", None))
        config_value = {"version": 1, "enabled": True,
                        "machine": os.environ.get("COMPUTERNAME", "FIXTURE"), "profile": str(local),
                        "pipeId": uuid.uuid4().hex, "nodePath": str(node),
                        "hostPath": str(roots["coexist"] / "coexist-host.js"),
                        "bridgePath": str(roots["panel"] / "js/lark-base-bridge.js"),
                        "pairStorePath": str(roots["panel"] / "js/lark-pairing-store.js"),
                        "staticRoot": str(roots["panel"] / "lark-base-extension")}
        plans.append((active, _json_bytes(config_value), "generated/active-v1.json", None))
    elif not active_exists:
        warnings.append("This payload has no complete Base bridge runtime; existing Base state was not changed.")
    return plans, warnings


def _atomic(file, data, expected):
    """Same-directory CAS replacement, streaming file sources without RAM copies.

    Bytes are reserved for bounded generated metadata; public payload/backup data
    is represented by a pinned _FileSource. No hardlink connects an installed
    file to staging.
    """
    file = _plain(file)
    if _hash(file) != expected:
        raise InstallError("A local file changed during installation: " + file.name)
    parent = _plain(file.parent)
    parent.mkdir(parents=True, exist_ok=True)
    _plain(parent)
    source_hash = data.sha256 if isinstance(data, _FileSource) else hashlib.sha256(data).hexdigest()
    fd, temporary = tempfile.mkstemp(prefix=".uoy-stage-", dir=parent)
    stage = Path(temporary)
    try:
        with os.fdopen(fd, "wb") as stream:
            if isinstance(data, _FileSource):
                with _plain(data.path).open("rb") as source:
                    shutil.copyfileobj(source, stream, 1024 * 1024)
            else:
                stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if _hash(stage) != source_hash:
            raise InstallError("Staged file integrity changed or checksum failed.")
        _plain(file)
        if _hash(file) != expected:
            raise InstallError("A local file changed before replacement: " + file.name)
        os.replace(stage, file)
    finally:
        _plain(stage).unlink(missing_ok=True)


def _reg_read(version):
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, f"Software\\Adobe\\CSXS.{version}") as key:
            value, kind = winreg.QueryValueEx(key, "PlayerDebugMode")
        if isinstance(value, bytes):
            value = {"binary": base64.b64encode(value).decode("ascii")}
        return {"exists": True, "value": value, "kind": kind}
    except FileNotFoundError:
        return {"exists": False}


def _reg_set(version, state):
    import winreg
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, f"Software\\Adobe\\CSXS.{version}", 0,
                            winreg.KEY_SET_VALUE) as key:
        if state["exists"]:
            value = state["value"]
            if isinstance(value, dict):
                value = base64.b64decode(value["binary"], validate=True)
            winreg.SetValueEx(key, "PlayerDebugMode", 0, state["kind"], value)
        else:
            try:
                winreg.DeleteValue(key, "PlayerDebugMode")
            except FileNotFoundError:
                pass


def _registry_plan(sandbox):
    return [] if sandbox else [{"version": n, "before": _reg_read(n),
                               "after": {"exists": True, "value": "1", "kind": 1}}
                              for n in range(9, 15)]


def _write_journal(path, journal):
    _atomic(path, _json_bytes(journal), _hash(path))


def _restore(journal, backup, roots, sandbox):
    retained = []
    for row in reversed(journal["registry"]):
        if not row.get("applied"):
            continue
        try:
            _closed(sandbox)
            actual = _reg_read(row["version"])
            if actual == row["before"]:
                continue
            if actual != row["after"]:
                raise InstallError("Later registry edit retained.")
            _reg_set(row["version"], row["before"])
        except Exception:
            retained.append("CEP setting CSXS." + str(row["version"]))
    for row in reversed(journal["files"]):
        if not row.get("applied"):
            continue
        try:
            _closed(sandbox)
            target = _journal_target(row, roots)
            actual = _hash(target)
            if actual == row["before"]:
                continue
            if actual != row["after"]:
                raise InstallError("Later file edit retained.")
            if row["before"] is None:
                _plain(target).unlink()
            else:
                source = _child(backup, row["backup"])
                if _hash(source) != row["before"]:
                    raise InstallError("Backup integrity changed.")
                _atomic(target, _FileSource(source, row["before"]), row["after"])
        except Exception:
            retained.append(row["path"])
    return retained


def _journal_target(row, roots):
    path = row["path"]
    parts = _relative(path)
    if parts[0] not in {"panel", "coexist", "companion", "core", "launcher"} or len(parts) < 2:
        raise InstallError("Invalid rollback target.")
    return _child(roots[parts[0]], "/".join(parts[1:]))


def _target_key(target, roots):
    for key in ("panel", "coexist", "companion", "core", "launcher"):
        if roots[key] in target.parents:
            return key + "/" + target.relative_to(roots[key]).as_posix()
    raise InstallError("Unapproved generated target.")


def install(payload_root: Path, base_root: Path | None = None, dry_run=False) -> dict:
    """Validate and install current release into this user's CEP/runtime roots.

    Dry run never creates a directory, credentials, lock, registry value, or file.
    Production installer must be called only after the user clicks Install/Update.
    """
    root, version, entries = _manifest(payload_root)
    roots, local, sandbox = _roots(base_root)
    for destination in roots.values():
        if root == destination or root in destination.parents or destination in root.parents:
            raise InstallError("Payload and installed directories must be separate.")
    panel = roots["panel"]
    _panel_destination_identity(panel)
    initial = []
    for entry in entries:
        component, relative = entry["path"].split("/", 1)
        target = _child(roots[component], relative)
        before = _hash(target)
        if before != entry["sha256"]:
            initial.append({"entry": entry, "target": target, "before": before})
    # Destination-only alias for the recipient's trusted installed Microsoft
    # runtime. It is neither in the public manifest nor downloaded from UOY.
    initial.extend(_runtime_prerequisite_plans({entry["path"] for entry in entries}, roots))
    warnings = ["Photoshop must support CEP/Extensions (Legacy). UXP-only hosts are not supported.",
                "Chrome Companion is installed to a stable folder; first installation still requires Chrome Load unpacked and Base pairing."]
    result = {"status": "validated" if dry_run else "installed", "version": version,
              "changed": len(initial), "roots": {k: str(v) for k, v in roots.items()},
              "warnings": warnings, "cep_debug_versions": list(range(9, 15))}
    result["disk_space"] = _space_preflight(initial, roots)
    if dry_run:
        result["files"] = [row["entry"]["path"] for row in initial]
        return result
    _closed(sandbox)
    with _lock(roots, sandbox):
        pending = roots["launcher"] / "pending-transaction.json"
        if _hash(pending) is not None:
            raise InstallError("An unfinished UOY update was preserved. In this Launcher, open Photoshop Panel -> ... -> Restore previous version, then retry Install / repair panel. Save work and close Photoshop/OrderStudio before recovery; no files changed.")
        _panel_destination_identity(panel)
        generated, extra_warnings = _generated(roots, local, sandbox, {e["path"] for e in entries})
        warnings.extend(extra_warnings)
        plans = []
        for row in initial:
            entry = row["entry"]
            source = row.get("source") or _child(root, entry["path"])
            if _hash(source) != entry["sha256"]:
                raise InstallError("Payload changed after preflight: " + entry["path"])
            plans.append((row["target"], _FileSource(source, entry["sha256"]), entry["path"], row["before"]))
        for target, data, label, before in generated:
            plans.append((target, data, _target_key(target, roots), before))
        receipt = roots["launcher"] / "install-receipt.json"
        receipt_before = _hash(receipt)
        if receipt_before is not None:
            old = _read_json(receipt)
            if old.get("schema") != 1 or old.get("identity") != _identity(roots):
                raise InstallError("Existing launcher receipt belongs to another location/user. It was preserved.")
        receipt_data = _json_bytes({"schema": 1, "version": version, "identity": _identity(roots),
                                    "files": entries, "installed_at": int(time.time())})
        plans.append((receipt, receipt_data, "launcher/install-receipt.json", receipt_before))
        registry = _registry_plan(sandbox)
        for row in registry:
            row["applied"] = True
        backup = _child(roots["launcher"], "backups/" + time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex)
        backup.mkdir(parents=True, exist_ok=False)
        journal = {"schema": 1, "identity": _identity(roots), "version": version, "status": "preparing",
                   "files": [], "registry": registry}
        journal_path = backup / "transaction.json"
        for index, (target, data, label, before) in enumerate(plans):
            if _hash(target) != before:
                raise InstallError("A destination changed during preflight: " + target.name)
            old_path = "files/" + str(index) + ".bin" if before else None
            if before:
                if _hash(target) != before:
                    raise InstallError("A destination changed during backup: " + target.name)
                _atomic(_child(backup, old_path), _FileSource(target, before), None)
            journal["files"].append({"path": label, "before": before,
                                     "after": data.sha256 if isinstance(data, _FileSource) else hashlib.sha256(data).hexdigest(), "backup": old_path,
                                     "applied": True})
        # One complete write-ahead intent covers every possible write. Recovery
        # compares actual before/after hashes, so not-yet-written rows are skipped
        # safely. Do not rewrite this large JSON once per runtime file (thousands
        # of fsyncs and a gigabyte of metadata on a first install).
        _write_journal(journal_path, journal)
        _atomic(pending, _json_bytes({"schema": 1, "identity": _identity(roots),
                                     "backup": backup.relative_to(roots["launcher"]).as_posix()}), None)
        try:
            for index, (target, data, label, before) in enumerate(plans):
                _closed(sandbox)
                _atomic(target, data, before)
            for row in registry:
                _closed(sandbox)
                if _reg_read(row["version"]) != row["before"]:
                    raise InstallError("CEP setting changed during installation.")
                _reg_set(row["version"], row["after"])
            journal["status"] = "installed"
            _write_journal(journal_path, journal)
            _plain(pending).unlink()
        except Exception as exc:
            retained = _restore(journal, backup, roots, sandbox)
            journal["status"] = "recovery_required" if retained else "rolled_back"
            journal["retained"] = retained
            _write_journal(journal_path, journal)
            if not retained:
                _plain(pending).unlink(missing_ok=True)
            raise InstallError("Installation stopped. " + ("Recovery retained later edits: " + ", ".join(retained) if retained else "Previous files restored.") +
                               " Backup: " + str(backup) + ". " + str(exc)) from exc
        result.update(changed=len(plans) - 1, backup=str(backup))
    return result


def rollback(backup_root: Path, base_root: Path | None = None) -> dict:
    """Restore one local transaction, only if its exact installed bytes still own targets."""
    roots, _, sandbox = _roots(base_root)
    backup = _plain(Path(backup_root))
    allowed = roots["launcher"] / "backups"
    if backup.parent != allowed:
        raise InstallError("Rollback must use this user's exact launcher backup directory.")
    journal = _read_json(backup / "transaction.json")
    if journal.get("schema") != 1 or journal.get("identity") != _identity(roots) or journal.get("status") not in {"installed", "recovery_required", "preparing"}:
        raise InstallError("This backup does not own the current local installation.")
    if not isinstance(journal.get("files"), list) or not isinstance(journal.get("registry"), list):
        raise InstallError("Invalid rollback inventory.")
    seen = set()
    for row in journal["files"]:
        if (not isinstance(row, dict) or set(row) != {"path", "before", "after", "backup", "applied"} or
                type(row["applied"]) is not bool or not isinstance(row["after"], str) or
                not re.fullmatch(r"[a-f0-9]{64}", row["after"]) or
                (row["before"] is not None and (not isinstance(row["before"], str) or not re.fullmatch(r"[a-f0-9]{64}", row["before"])) )):
            raise InstallError("Invalid rollback file ownership record.")
        target = _journal_target(row, roots)
        key = str(target).lower()
        if key in seen:
            raise InstallError("Duplicated rollback target.")
        seen.add(key)
        if row["before"] is not None:
            if not isinstance(row["backup"], str) or not re.fullmatch(r"files/[0-9]+\.bin", row["backup"]):
                raise InstallError("Invalid rollback backup path.")
            if _hash(_child(backup, row["backup"])) != row["before"]:
                raise InstallError("Rollback backup integrity check failed.")
        elif row["backup"] is not None:
            raise InstallError("Unexpected backup for a new file.")
    for row in journal["registry"]:
        if (not isinstance(row, dict) or row.get("version") not in range(9, 15) or
                row.get("after") != {"exists": True, "value": "1", "kind": 1} or
                (sandbox and row.get("applied"))):
            raise InstallError("Invalid CEP registry rollback ownership record.")
    with _lock(roots, sandbox):
        _closed(sandbox)
        retained = _restore(journal, backup, roots, sandbox)
        journal["status"] = "recovery_required" if retained else "rolled_back"
        journal["retained"] = retained
        _write_journal(backup / "transaction.json", journal)
        if not retained:
            pending = roots["launcher"] / "pending-transaction.json"
            if _hash(pending):
                meta = _read_json(pending)
                if meta.get("identity") == _identity(roots) and meta.get("backup") == backup.relative_to(roots["launcher"]).as_posix():
                    _plain(pending).unlink()
        return {"status": journal["status"], "retained": retained, "backup": str(backup)}


def get_installed_version(base_root: Path | None = None) -> str | None:
    roots, _, _ = _roots(base_root)
    file = roots["launcher"] / "install-receipt.json"
    if _hash(file) is None:
        return None
    value = _read_json(file)
    if value.get("schema") != 1 or value.get("identity") != _identity(roots):
        raise InstallError("The local installation receipt is not valid for this user.")
    version = value.get("version")
    if not isinstance(version, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", version):
        raise InstallError("The local installation version is invalid.")
    return version


def get_companion_path(base_root: Path | None = None) -> Path:
    return _roots(base_root)[0]["companion"]


def get_recovery_backup(base_root: Path | None = None) -> Path | None:
    """Read-only local recovery discovery; never follows a publisher-supplied path."""
    roots, _, _ = _roots(base_root)
    launcher = roots["launcher"]
    pending = launcher / "pending-transaction.json"
    if _hash(pending) is not None:
        value = _read_json(pending, 16384)
        relative = value.get("backup")
        if (set(value) != {"schema", "identity", "backup"} or value.get("schema") != 1 or
                value.get("identity") != _identity(roots) or not isinstance(relative, str) or
                not re.fullmatch(r"backups/[0-9]{8}-[0-9]{6}-[a-f0-9]{32}", relative)):
            raise InstallError("The unfinished update receipt is not valid for this user.")
        backup = _child(launcher, relative)
        journal = _read_json(backup / "transaction.json")
        if journal.get("schema") != 1 or journal.get("identity") != _identity(roots):
            raise InstallError("The recovery transaction belongs to another user/location.")
        return backup
    directory = _plain(launcher / "backups")
    if not directory.exists():
        return None
    for backup in sorted(directory.iterdir(), key=lambda p: p.name, reverse=True):
        if not re.fullmatch(r"[0-9]{8}-[0-9]{6}-[a-f0-9]{32}", backup.name):
            continue
        _plain(backup)
        if not backup.is_dir():
            continue
        try:
            journal = _read_json(backup / "transaction.json")
        except InstallError:
            continue
        if (journal.get("schema") == 1 and journal.get("identity") == _identity(roots) and
                journal.get("status") in {"installed", "preparing", "recovery_required"}):
            return backup
    return None


