/* Working Status + Design Link + view membership are one live read-only proof.
 * Save may use exact-bound last-known eligible data when verification is unavailable;
 * that advisory fallback never becomes a fresh proof. Explicit user saves have
 * a separate targeted verification policy; legacy eligibility remains strict.
 * No Base writes or uploads. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.UOYLarkLiveStatus=api;})(typeof window==='undefined'?null:window,function(){
  'use strict';
  var FALLBACK=2000,RETRY_BASE=5000,CATCH_UP=250,SLOW_YIELD=1000,MAX_PROOF_AGE=15000,MAX_BACKOFF=15000,VERIFY_DEADLINE=45000,POLL=250,DEBOUNCE=350,MAX_RECORDS=5000,CHUNK=200,privateProofs=new WeakMap();
  var VIEW_LEFT_WARNING='đã nhảy khỏi view hiện tại, check AI hoặc trạng thái khác',VIEW_UNKNOWN_WARNING='chưa xác minh thuộc view hiện tại';
  function fail(code,message){var error=new Error(message);error.code=code;return error;}
  function recordId(value){return typeof value==='string'&&/^\w[\w-]{0,159}$/.test(value);}
  function normalize(value){return String(value||'').replace(/[\u200b-\u200d\u2060\ufeff]/g,'').replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim().toUpperCase().replace(/^TO DO$/,'TODO');}
  function canonicalSource(value){
    if(!value||!recordId(value.tableId)||!recordId(value.viewId)||typeof value.url!=='string'||value.url.length>4096)return null;
    var url;try{url=new URL(value.url);}catch(_){return null;}
    if(url.protocol!=='https:'||url.username||url.password||url.port||!/(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(url.hostname)||url.pathname==='/'||url.pathname.length>1024)return null;
    // Selection IDs, not arbitrary query text or query ordering, define scope.
    if(url.searchParams.has('table')&&(url.searchParams.getAll('table').length!==1||url.searchParams.get('table')!==value.tableId))return null;
    if(url.searchParams.has('view')&&(url.searchParams.getAll('view').length!==1||url.searchParams.get('view')!==value.viewId))return null;
    url.hash='';return {url:url.href,tableId:value.tableId,viewId:value.viewId};
  }
  function sourceKey(value){var source=canonicalSource(value);if(!source)return '';var url=new URL(source.url);return url.origin+url.pathname.replace(/\/$/,'')+'|'+source.tableId+'|'+source.viewId;}
  function sameSource(a,b){var key=sourceKey(a);return !!key&&key===sourceKey(b);}
  function binding(record){return record&&recordId(record.recordId)&&sourceKey(record.baseSource)?sourceKey(record.baseSource)+'|'+record.recordId:'';}
  function trustedProof(record){var proof=record&&privateProofs.get(record);if(proof){if(proof.valid())return proof;privateProofs.delete(record);}return null;}
  function state(record){var proof=trustedProof(record);if(proof)return {phase:!normalize(proof.workingStatus)?'missing':proof.viewMembership==='unknown'?'membership-unknown':'ready',verifiedAt:proof.receivedAt,viewMembership:proof.viewMembership,message:proof.viewMembership==='out'?VIEW_LEFT_WARNING:proof.viewMembership==='unknown'?VIEW_UNKNOWN_WARNING:!normalize(proof.workingStatus)?'Working Status đang trống; chưa cho phép gửi file.':''};var shown=record&&record._baseLive;if(shown&&shown.phase!=='ready'&&shown.phase!=='membership-unknown'&&!(shown.phase==='missing'&&shown.verifiedAt))return {phase:shown.phase,verifiedAt:shown.verifiedAt||0,message:shown.message||''};return {phase:'stale',verifiedAt:0,message:'Chưa xác minh Working Status từ Base.'};}
  function display(record){var value=state(record),raw=record&&record.workingStatus||'Working Status trống';if(value.viewMembership==='out')return raw+' · '+VIEW_LEFT_WARNING;if(value.viewMembership==='unknown')return raw+' · '+VIEW_UNKNOWN_WARNING;if(value.phase==='ready')return record.workingStatus||'Chưa xác minh';if(value.phase==='missing')return 'Không tìm thấy record · chưa xác minh';return 'Chưa xác minh'+(record&&record.workingStatus?' (lần trước: '+record.workingStatus+')':'');}
  function createController(options){
    options=options||{};var now=options.now||Date.now,clock=options.clock||{setInterval:setInterval,clearInterval:clearInterval,setTimeout:setTimeout,clearTimeout:clearTimeout};
    var records=null,boundRecords=[],saveEvidence=new WeakMap(),generation=0,invalidationEpoch=0,closed=false,interval=null,debounce=null,flight=null,foregroundChecks=0,nextPollAt=0,retryUntil=0,yieldUntil=0,due=false,waitingIdle=false,idleGraceUsed=false,lastSelected=null,failures=0,lastRevision=null,lastFailure='',rotation=0,proofOwner={},notify=options.onChange||function(){};
    var subscribedBridge=null,unsubscribe=null,proofExpiry=null,feedStatus=null,dirtyIds=Object.create(null),dirtyFull=false,busyRetries=0,explicitSavePolicy={};
    function bridge(){return typeof options.getBridge==='function'?options.getBridge():options.bridge;}
    function current(){var next=typeof options.getRecords==='function'?options.getRecords():records;if(next!==records)bind(next||[]);return records||[];}
    function selected(list){var record=typeof options.getCurrentRecord==='function'?options.getCurrentRecord():null;return record&&list.indexOf(record)>=0?record:null;}
    function emit(changed,durable){if(changed.length)notify({records:changed,durableChanged:!!durable});}
    function mark(list,phase,message){var changed=[];list.forEach(function(record){var previous=state(record),shown=record._baseLive;privateProofs.delete(record);if(previous.phase!==phase||previous.message!==message||shown&&shown.phase!==phase){record._baseLive={phase:phase,verifiedAt:previous.verifiedAt||0,message:message};changed.push(record);}});emit(changed,false);}
    function rememberSaveEvidence(record,missing){var prior=saveEvidence.get(record);saveEvidence.set(record,{generation:generation,binding:prior?prior.binding:binding(record),name:prior?prior.name:record.name,sku:prior?prior.sku:record.sku,workingStatus:record.workingStatus,designLink:record.designLink,viewMembership:record.baseViewMembership,missing:!!missing});}
    function bind(next,settings){
      settings=settings||{};if(records)records.forEach(function(record){privateProofs.delete(record);});records=Array.isArray(next)?next:[];generation++;invalidationEpoch++;nextPollAt=0;retryUntil=0;yieldUntil=0;due=true;waitingIdle=false;idleGraceUsed=false;lastSelected=null;failures=0;lastRevision=null;lastFailure='';rotation=0;
      boundRecords=records.slice();saveEvidence=new WeakMap();
      if(debounce!==null){clock.clearTimeout(debounce);debounce=null;}
      records.forEach(function(record){
        if(settings.source){var source=canonicalSource(settings.source);if(source)record.baseSource=source;}
        // Public/imported timestamps remain history. Only an accepted targeted
        // SDK response below can mint a controller-owned reusable proof.
        privateProofs.delete(record);record._baseLive={phase:'stale',verifiedAt:0,message:'Phiên đã nạp cần xác minh lại Working Status.'};
        rememberSaveEvidence(record,false);
      });
      dirtyIds=Object.create(null);dirtyFull=false;emit(records.slice(),!!settings.fresh);if(interval!==null&&records.length&&!options.externalViewFeed)schedule(0);return records;
    }
    function capture(settings){
      var list=current();if(!list.length)throw fail('BASE_LIVE_EMPTY','Chưa nạp đơn từ Base.');
      if(list.length>MAX_RECORDS)throw fail('BASE_LIVE_LIMIT','Đợt đơn vượt giới hạn xác minh Working Status.');
      var source=canonicalSource(list[0].baseSource),scope=sourceKey(source),ids=[],seen=Object.create(null),keys=[];
      if(!source)throw fail('BASE_LIVE_SOURCE','Đợt đơn cũ chưa có nguồn Base xác thực. Bấm Nạp từ Base để xác nhận nguồn; PSD và tiến độ vẫn giữ nguyên.');
      list.forEach(function(record){var key=binding(record);if(!key||sourceKey(record.baseSource)!==scope)throw fail('BASE_LIVE_SOURCE','Nguồn Base của đợt đơn không đồng nhất; chưa gửi file.');keys.push(key);});
      var targets;
      if(settings&&settings.record)targets=[settings.record];
      else if(settings&&Array.isArray(settings.recordIds)){var wanted=Object.create(null);settings.recordIds.forEach(function(id){wanted[id]=true;});targets=list.filter(function(record){return wanted[record.recordId];}).slice(0,CHUNK);if(!targets.length)throw fail('BASE_LIVE_EMPTY','Không có Record ID đang nạp cần kiểm tra.');}
      else if(list.length<=CHUNK)targets=list;
      else {
        // Keep the visible order first. A large queue rotates bounded slices;
        // never issue thousands of per-cell SDK reads in one request.
        targets=[];var selected=typeof options.getCurrentRecord==='function'?options.getCurrentRecord():null;
        if(selected&&list.indexOf(selected)>=0)targets.push(selected);
        var visited=0;while(targets.length<CHUNK&&visited<list.length){var candidate=list[(rotation+visited)%list.length];if(targets.indexOf(candidate)<0)targets.push(candidate);visited++;}
        rotation=(rotation+visited)%list.length;
      }
      targets.forEach(function(record){if(list.indexOf(record)<0)throw fail('BASE_LIVE_CHANGED','Đơn cần xác minh không còn trong đợt đang làm.');if(!seen[record.recordId]){seen[record.recordId]=true;ids.push(record.recordId);}});
      return {list:list,targets:targets,generation:generation,epoch:invalidationEpoch,source:source,ids:ids,keys:keys,startedAt:now()};
    }
    function unchanged(captured){var list=current();return !closed&&captured.generation===generation&&captured.epoch===invalidationEpoch&&captured.list===list&&captured.keys.length===list.length&&list.every(function(record,index){return binding(record)===captured.keys[index];});}
    function observeRevision(info,list,initial){
      var revision=info&&Number.isSafeInteger(info.liveRevision)&&info.liveRevision>=0?info.liveRevision:null;
      // Capture a baseline before dispatch. A previously unobserved event while
      // a request is in flight must not later restore a stale proof to READY.
      if(lastRevision===null&&initial){lastRevision=revision===null?0:revision;return;}
      if(revision===null)return;
      var changed=lastRevision!==null&&revision!==lastRevision;lastRevision=revision;
      // liveSource identifies the LAST authenticated dirty event, not selected
      // Chrome UI. Another application's Base must not freeze this batch.
      if(changed&&list.length&&sameSource(info.liveSource,list[0].baseSource)){
        invalidationEpoch++;mark(list,'stale','Base vừa thay đổi; đang xác minh Working Status…');if(!options.externalViewFeed)schedule();
      }
    }
    function readRevision(backend,list,initial){
      var info,statusFailure='';try{info=backend&&typeof backend.status==='function'?backend.status():null;}catch(_){statusFailure='BASE_LOCAL_DISCONNECTED';}
      if(info)feedStatus=info;
      observeRevision(info,list,initial);
      if(info){if(info.clientCompatible===false)statusFailure='CLIENT_VERSION';else if(info.launcherCompatible===false)statusFailure='LAUNCHER_VERSION';else if(info.started===false||info.connected===false)statusFailure='BASE_DISCONNECTED';else if(info.launcherState==='error')statusFailure='BASE_LAUNCHER';else if(options.externalViewFeed&&info.readerEventReady===false)statusFailure='BASE_EVENT_UNAVAILABLE';}
      if(statusFailure){if(lastFailure!==statusFailure){invalidationEpoch++;mark(list,'stale','Cầu nối Base chưa sẵn sàng; đang chờ xác minh lại trạng thái.');}else list.forEach(function(record){privateProofs.delete(record);});}
      lastFailure=statusFailure;
    }
    function feedHealthy(source){var info=feedStatus;return !!(options.externalViewFeed&&unsubscribe&&info&&info.eventCapable===true&&info.readerEventReady===true&&info.connected===true&&info.clientCompatible!==false&&info.launcherCompatible!==false&&info.launcherState!=='error'&&sameSource(info.readerSource,source));}
    function expireProofs(){proofExpiry=null;if(closed)return;var list=current();mark(list.filter(function(record){return record._baseLive&&/^(?:ready|membership-unknown)$/.test(record._baseLive.phase)&&!trustedProof(record);}),'stale','Kết nối sự kiện Base chưa xác nhận dữ liệu hiện tại; dữ liệu lần trước vẫn được giữ.');}
    function armProofExpiry(){if(proofExpiry!==null)clock.clearTimeout(proofExpiry);proofExpiry=null;if(interval!==null&&!closed&&!feedHealthy(records&&records[0]&&records[0].baseSource))proofExpiry=clock.setTimeout(expireProofs,MAX_PROOF_AGE+1);}
    function handleEvent(event){
      if(closed||!event||typeof event!=='object')return;var list=current();
      if(event.status&&typeof event.status==='object')feedStatus=event.status;
      if(event.type==='dirty'){
        if(!list.length||!sameSource(event.source,list[0].baseSource))return;
        if(Number.isSafeInteger(event.revision))lastRevision=event.revision;
        invalidationEpoch++;mark(list,'stale','Base vừa thay đổi; đang cập nhật view hiện tại…');
        var dirty=event.dirty||{};dirtyFull=dirtyFull||dirty.full===true||!Array.isArray(dirty.recordIds);if(Array.isArray(dirty.recordIds))dirty.recordIds.forEach(function(id){if(recordId(id))dirtyIds[id]=true;});if(Object.keys(dirtyIds).length>MAX_RECORDS){dirtyIds=Object.create(null);dirtyFull=true;}
        if(!options.externalViewFeed)schedule();return;
      }
      if(event.type==='state'){
        readRevision(bridge(),list,false);
        if(event.reason==='ready'&&feedStatus&&feedStatus.readerEventReady===false){invalidationEpoch++;mark(list,'stale','SDK Base chưa xác nhận bộ theo dõi sự kiện; dữ liệu lần trước vẫn được giữ.');armProofExpiry();return;}
        if(event.reason==='disconnected'||event.reason==='closed'){invalidationEpoch++;mark(list,'stale','Cầu nối Base đã ngắt; dữ liệu lần trước vẫn được giữ.');armProofExpiry();return;}
        if(event.reason==='connected'){if(!options.externalViewFeed&&list.length)schedule(DEBOUNCE);}
        else if(event.reason==='idle'&&due&&!options.externalViewFeed){busyRetries=0;schedule(DEBOUNCE);}
      }
    }
    function attach(){var backend=bridge();if(backend===subscribedBridge&&unsubscribe)return;if(unsubscribe)unsubscribe();unsubscribe=null;subscribedBridge=backend;feedStatus=null;if(backend&&typeof backend.subscribe==='function'){unsubscribe=backend.subscribe(handleEvent);try{feedStatus=backend.status();}catch(_){}}}
    function mintProof(record,captured,stamp,targeted){
      var proof={owner:proofOwner,binding:binding(record),generation:generation,epoch:invalidationEpoch,receivedAt:stamp,workingStatus:record.workingStatus,designLink:record.designLink,viewMembership:record.baseViewMembership,name:record.name,sku:record.sku,targeted:targeted===true};
      proof.valid=function(){var active;try{active=typeof options.getRecords==='function'?options.getRecords():records;}catch(_){return false;}return !closed&&!lastFailure&&active===records&&captured.list===records&&records.indexOf(record)>=0&&generation===proof.generation&&invalidationEpoch===proof.epoch&&binding(record)===proof.binding&&record.name===proof.name&&record.sku===proof.sku&&record.workingStatus===proof.workingStatus&&record.designLink===proof.designLink&&record.baseViewMembership===proof.viewMembership&&now()>=proof.receivedAt&&(now()-proof.receivedAt<=MAX_PROOF_AGE||feedHealthy(captured.source));};
      privateProofs.set(record,proof);
    }
    function eligibleKnown(proof,mode,policy){
      var explicit=policy===explicitSavePolicy;
      if(!explicit&&proof.viewMembership==='out')throw fail('BASE_VIEW_LEFT',VIEW_LEFT_WARNING+'. Working Status hiện tại: '+(proof.workingStatus||'(trống)')+'. PSD và file local vẫn được giữ.');
      // Membership is advisory when its exact view list is unavailable. The
      // accepted table-level status/link proof keeps R37 eligibility; only a
      // confirmed departure adds a new production rejection.
      if(!normalize(proof.workingStatus))throw fail('BASE_LIVE_UNKNOWN','Working Status đang trống; chưa cho phép gửi file.');
      var status=normalize(proof.workingStatus),fixed=/^(?:fix|fix_mockup|cmykfix)$/.test(mode||''),allowed=mode==='revision'?status==='TODO'||status==='FIX FILE':fixed?status==='FIX FILE':status==='TODO';
      if(!explicit&&!allowed)throw fail('BASE_WORKING_CHANGED','Working Status hiện tại: '+proof.workingStatus+'. '+(status==='FIX FILE'&&!fixed?'Hãy dùng Save Fix.':status==='TODO'&&fixed?'Hãy dùng Save Folder.':'Đơn không còn thuộc Todo/FIX FILE; không gửi trùng.')+' PSD và file local vẫn được giữ.');
      return {binding:proof.binding,verifiedAt:proof.receivedAt,workingStatus:proof.workingStatus,designLink:proof.designLink,viewMembership:proof.viewMembership};
    }
    function eligibleProof(record,mode,policy){var proof=trustedProof(record);if(!proof||proof.owner!==proofOwner)return null;if(policy===explicitSavePolicy&&(!proof.targeted||record.baseDesignLinkStale===true||now()-proof.receivedAt>MAX_PROOF_AGE))return null;return eligibleKnown(proof,mode,policy);}
    function validate(result,captured){
      if(!result||Object.keys(result).sort().join(',')!=='kind,records,source,version'||result.version!==3||result.kind!=='record-statuses'||!result.source||Object.keys(result.source).sort().join(',')!=='tableId,url,viewId'||!sameSource(result.source,captured.source)||!Array.isArray(result.records)||result.records.length>captured.ids.length)throw fail('BASE_LIVE_RESULT','Kết quả Working Status/Design Link/view không khớp đúng Base/bảng/view; chưa gửi file.');
      var allowed=Object.create(null),found=Object.create(null);captured.ids.forEach(function(id){allowed[id]=true;});
      result.records.forEach(function(row){if(!row||Object.keys(row).sort().join(',')!=='designLink,recordId,viewMembership,workingStatus'||!recordId(row.recordId)||!allowed[row.recordId]||Object.prototype.hasOwnProperty.call(found,row.recordId)||typeof row.workingStatus!=='string'||row.workingStatus.length>256||/[\x00-\x1f\x7f]/.test(row.workingStatus)||typeof row.designLink!=='string'||row.designLink.length>8192||/[\x00-\x1f\x7f]/.test(row.designLink)||!['in','out','unknown'].includes(row.viewMembership))throw fail('BASE_LIVE_RESULT','Working Status/Design Link/view thiếu, trùng ID hoặc sai định dạng; chưa gửi file.');found[row.recordId]={workingStatus:row.workingStatus.trim(),designLink:row.designLink.trim(),viewMembership:row.viewMembership};});
      return found;
    }
    function failedRead(error){
      var transient=error&&/BUSY|CANCELLED|LIVE_CHANGED|VIEW_CHANGED|RECONNECTED/.test(error.code||'');
      if(!transient)failures=Math.min(3,failures+1);
      var wait=transient?1000:Math.min(MAX_BACKOFF,RETRY_BASE*Math.pow(2,failures-1));
      retryUntil=now()+wait;nextPollAt=retryUntil;
    }
    function refresh(settings){
      settings=settings||{};if(closed)return Promise.reject(fail('BASE_LIVE_CLOSED','Theo dõi Working Status đã dừng.'));
      if(flight){if(settings.verificationOwner)return Promise.reject(fail('BASE_BUSY','Đang chờ lượt đọc Base hiện tại kết thúc.'));if(settings.force)return flight.promise.catch(function(){}).then(function(){return refresh(settings);});return flight.promise;}
      var captured,backend;try{backend=bridge();readRevision(backend,current(),true);captured=capture(settings);if(!backend||typeof backend.fetchRecordStatuses!=='function')throw fail('BASE_LIVE_VERSION','Cần cài đủ bản cập nhật để xác minh Working Status.');}catch(error){mark(current(),'stale',error.message);failedRead(error);return Promise.reject(error);}
      var owned={captured:captured,promise:null};flight=owned;waitingIdle=false;idleGraceUsed=false;lastSelected=selected(captured.list);nextPollAt=captured.startedAt+FALLBACK;
      owned.promise=Promise.resolve().then(function(){if(settings.verificationOwner&&typeof settings.verificationOwner.isCurrent==='function'&&!settings.verificationOwner.isCurrent())throw fail('BASE_LIVE_CANCELLED','Thao tác xác minh đã dừng; chưa gửi yêu cầu đọc mới.');if(!unchanged(captured))throw fail('BASE_LIVE_CHANGED','Đợt đơn đã thay đổi; không dùng kết quả cũ.');return backend.fetchRecordStatuses({source:captured.source,recordIds:captured.ids.slice()});}).then(function(result){
        readRevision(backend,captured.list,false);
        if(!unchanged(captured))throw fail('BASE_LIVE_CHANGED','Đợt đơn đã thay đổi; không dùng kết quả cũ.');
        if(settings.verificationOwner&&settings.verificationOwner.explicitSavePolicy===explicitSavePolicy&&!settings.verificationOwner.isCurrent())throw fail('BASE_LIVE_CANCELLED','Danh tính hoặc thao tác lưu đã thay đổi; không nhận kết quả của lượt cũ.');
        if(lastFailure)throw fail(lastFailure,'Cầu nối Base chưa xác nhận trạng thái kết nối hiện tại; chưa cho phép gửi file.');
        var found=validate(result,captured),stamp=now(),changed=[],durable=false;
        captured.targets.forEach(function(record){var row=found[record.recordId],before=state(record),present=!!row&&!!normalize(row.workingStatus),statusChanged=!!row&&record.workingStatus!==row.workingStatus,linkChanged=!!row&&record.designLink!==row.designLink,membershipChanged=!!row&&record.baseViewMembership!==row.viewMembership;
          if(row){
            // Both values come from one validated current-record read. Empty
            // links intentionally clear old destinations; never retain them.
            if(statusChanged||linkChanged||membershipChanged||record.baseDesignLinkStale===true||!record.baseStatusAt)durable=true;
            record.workingStatus=row.workingStatus;record.designLink=row.designLink;record.baseViewMembership=row.viewMembership;record.baseViewMembershipAt=row.viewMembership==='unknown'?0:stamp;record.baseDesignLinkStale=false;record.baseStatusAt=stamp;
            record._baseLive={phase:present?(row.viewMembership==='unknown'?'membership-unknown':'ready'):'missing',verifiedAt:stamp,message:row.viewMembership==='out'?VIEW_LEFT_WARNING:row.viewMembership==='unknown'?VIEW_UNKNOWN_WARNING:present?'':'Working Status đang trống; chưa cho phép gửi file.'};
            rememberSaveEvidence(record,false);
            // Only an actual returned row from a one-record SDK request can
            // be reused by the explicit Save policy. A view snapshot may also
            // describe absence and must never stand in for this row proof.
            mintProof(record,captured,stamp,captured.targets.length===1&&captured.ids.length===1);
          }
          else {privateProofs.delete(record);rememberSaveEvidence(record,true);record._baseLive={phase:'missing',verifiedAt:0,message:'Record không đọc được hoặc không còn quyền truy cập; không suy đoán trạng thái.'};}
          if(statusChanged||linkChanged||membershipChanged||before.phase!==record._baseLive.phase||before.message!==record._baseLive.message||row)changed.push(record);
        });failures=0;retryUntil=0;emit(changed,durable);armProofExpiry();return result;
      }).catch(function(error){if(unchanged(captured)){var busy=error&&/^(?:BASE_BUSY|BASE_LAUNCHER_BUSY)$/.test(error.code||'');if(busy)mark(captured.targets.filter(function(record){return !trustedProof(record);}), 'stale',String(error.message||'Đang chờ lượt đọc Base.').slice(0,700));else {invalidationEpoch++;mark(captured.list,'stale',String(error&&error.message||'Chưa xác minh được Working Status.').slice(0,700));}}if(captured.generation===generation&&captured.list===records)failedRead(error);throw error;});
      function finish(){
        if(flight!==owned)return;flight=null;
        // A slow SDK read cannot meet a two-second cadence. Leave the full
        // view watch's one-second due retry a real turn instead of saturating
        // the shared bridge with immediate catch-up reads forever.
        yieldUntil=now()+CATCH_UP;
        if(!closed&&interval!==null&&current().length&&due&&!foregroundChecks&&!options.externalViewFeed)schedule(0);
      }owned.promise.then(finish,finish);return owned.promise;
    }
    function checkForSave(record,mode,verificationOptions){
      verificationOptions=verificationOptions||{};
      var captured,key,capturedGeneration;
      function assertCurrent(){
        var valid=true;try{if(typeof verificationOptions.isCurrent==='function')valid=verificationOptions.isCurrent()===true;}catch(_){valid=false;}
        if(closed||!valid||generation!==capturedGeneration||binding(record)!==key||current()!==captured.list||captured.list.indexOf(record)<0)throw fail('BASE_LIVE_CANCELLED','Đơn hoặc thao tác đã thay đổi; đã dừng, chưa xuất hay gửi file.');
        if(boundRecords.length!==captured.list.length||captured.list.some(function(item,index){var known=saveEvidence.get(item);return item!==boundRecords[index]||!known||known.generation!==generation||binding(item)!==known.binding||item.name!==known.name||item.sku!==known.sku||item.workingStatus!==known.workingStatus||item.designLink!==known.designLink||item.baseViewMembership!==known.viewMembership;}))throw fail('BASE_LIVE_CHANGED','Danh tính, nguồn hoặc dữ liệu đích của đợt đơn đã thay đổi; chưa xuất hay gửi file.');
      }
      try{captured=capture({record:record});key=binding(record);capturedGeneration=generation;assertCurrent();}catch(error){return Promise.reject(error);}
      // No foreground SDK request, drain, retry or deadline timer belongs to
      // Save. The independent two-second reader remains the only live work.
      return Promise.resolve().then(function(){
        assertCurrent();
        try{readRevision(bridge(),captured.list,true);}catch(_){invalidationEpoch++;mark(captured.list,'stale','Chưa xác minh được Working Status; dữ liệu lần trước vẫn được giữ.');}
        assertCurrent();
        var known=saveEvidence.get(record);
        if(known.missing)throw fail('BASE_LIVE_UNKNOWN','Lần đọc Base đã xác nhận không đọc được record; chưa cho phép gửi file.');
        if(record.baseDesignLinkStale===true&&/^(?:fix|fix_mockup|cmykfix|revision)$/.test(mode||''))throw fail('BASE_LIVE_DESTINATION','Design Link của bản Fix chưa xác nhận được đích hiện tại; chưa gửi vào thư mục cũ.');
        var fresh=eligibleProof(record,mode);
        if(fresh){fresh.verification='verified';return fresh;}
        // Only bind()/an accepted scoped row can update this private evidence.
        // Failed, malformed or wrong-source replies cannot replace known facts
        // (including missing/blank/noneligible status and confirmed view out).
        var fallback=eligibleKnown(known,mode);fallback.verifiedAt=0;fallback.verification='unverified';return fallback;
      });
    }
    function verifyFresh(record,mode,verificationOptions,policy){
      verificationOptions=verificationOptions||{};
      var key=binding(record),list=current(),capturedGeneration=generation;if(!key||list.indexOf(record)<0)return Promise.reject(fail('BASE_LIVE_SOURCE','Đơn chưa có nguồn Base xác thực. Bấm Nạp từ Base; chưa gửi file.'));
      var explicit=policy===explicitSavePolicy,capturedName=record.name,capturedSku=record.sku;
      var started=now(),deadline=started+VERIFY_DEADLINE,owner={},attempts=0,lastWait='',finished=false;
      function assertCurrent(){
        var valid=true;try{if(typeof verificationOptions.isCurrent==='function')valid=verificationOptions.isCurrent()===true;}catch(_){valid=false;}
        if(closed||!valid||generation!==capturedGeneration||binding(record)!==key||current().indexOf(record)<0)throw fail('BASE_LIVE_CANCELLED','Đơn hoặc thao tác đã thay đổi; đã dừng xác minh, chưa xuất hay gửi file.');
        if(explicit){var known=saveEvidence.get(record);if(current()!==list||boundRecords.indexOf(record)<0||!known||known.generation!==capturedGeneration||known.binding!==key||known.name!==capturedName||known.sku!==capturedSku||record.name!==capturedName||record.sku!==capturedSku)throw fail('BASE_LIVE_CHANGED','Danh tính hoặc nguồn của đơn đang lưu đã thay đổi; chưa xuất hay gửi file.');}
        if(now()>=deadline)throw fail('BASE_LIVE_VERIFY_TIMEOUT','Chưa xác minh được Base trong 45 giây. Đã mở khóa thao tác và giữ file local; không tự xuất hoặc gửi lại.');
      }
      function waiting(reason,code){var label=reason+'|'+(code||'');if(label===lastWait)return;lastWait=label;if(typeof verificationOptions.onWait==='function')try{verificationOptions.onWait({reason:reason,code:code||'',elapsedMs:Math.max(0,now()-started),attempt:attempts});}catch(_){} }
      // Bound both an older read's drain and this intent's own SDK read. A
      // timed-out read may still finish as status-only work, never as Save.
      function bounded(promise){return new Promise(function(resolve,reject){var timer=null,settled=false;function finish(error,value){if(settled)return;settled=true;if(timer!==null)clock.clearTimeout(timer);if(error)reject(error);else resolve(value);}function watch(){try{assertCurrent();}catch(error){finish(error);return;}timer=clock.setTimeout(watch,Math.min(250,Math.max(1,deadline-now())));}watch();Promise.resolve(promise).then(function(value){try{assertCurrent();finish(null,value);}catch(error){finish(error);}},function(error){try{assertCurrent();finish(error);}catch(cancelled){finish(cancelled);}});});}
      function pause(ms){var timer;var sleeping=new Promise(function(resolve){timer=clock.setTimeout(resolve,ms);});return bounded(sleeping).then(function(value){clock.clearTimeout(timer);return value;},function(error){clock.clearTimeout(timer);throw error;});}
      function ownRead(){
        try{assertCurrent();}catch(error){return Promise.reject(error);}
        try{readRevision(bridge(),current(),true);var cached=eligibleProof(record,mode,policy);if(cached)return Promise.resolve(cached);}catch(error){return Promise.reject(error);}
        if(flight){var observed=flight,matching=unchanged(observed.captured)&&observed.captured.targets.indexOf(record)>=0&&(!explicit||observed.captured.targets.length===1&&observed.captured.ids.length===1);waiting('drain');return bounded(observed.promise).then(function(){if(matching){readRevision(bridge(),current(),true);var accepted=eligibleProof(record,mode,policy);if(accepted)return accepted;throw fail('BASE_LIVE_UNKNOWN','Lần đọc hiện tại chưa xác minh được đúng đơn; chưa xuất hay gửi file.');}return ownRead();},function(error){if(error&&/^(?:BASE_BUSY|BASE_LAUNCHER_BUSY|BASE_CANCELLED|BASE_LIVE_CHANGED)$/.test(error.code||'')){assertCurrent();return ownRead();}throw error;});}
        attempts++;waiting('read');
        return bounded(refresh({record:record,verificationOwner:owner})).catch(function(error){
          if(error&&/^(?:BASE_BUSY|BASE_LAUNCHER_BUSY)$/.test(error.code||'')){
            assertCurrent();waiting('busy',error.code);return pause(Math.min(1500,attempts*500)).then(ownRead);
          }
          throw error;
        });
      }
      owner.isCurrent=function(){try{assertCurrent();return true;}catch(_){return false;}};if(explicit)owner.explicitSavePolicy=explicitSavePolicy;
      function finishVerification(){if(finished)return;finished=true;foregroundChecks=Math.max(0,foregroundChecks-1);if(!closed&&interval!==null&&!foregroundChecks&&current().length&&!flight&&due&&!options.externalViewFeed)schedule(0);}
      try{assertCurrent();readRevision(bridge(),current(),true);var immediate=eligibleProof(record,mode,policy);if(immediate)return explicit?Promise.resolve().then(function(){assertCurrent();var accepted=eligibleProof(record,mode,policy);if(!accepted)throw fail('BASE_LIVE_UNKNOWN','Lần xác nhận đơn đã thay đổi; chưa xuất hay gửi file.');return accepted;}):Promise.resolve(immediate);}catch(error){return Promise.reject(error);}
      foregroundChecks++;if(debounce!==null){clock.clearTimeout(debounce);debounce=null;}
      var result=ownRead().then(function(){
        assertCurrent();
        var proof=eligibleProof(record,mode,policy);if(!proof)throw fail('BASE_LIVE_UNKNOWN','Chưa xác minh được Working Status của đúng Record ID; đã giữ file local, chưa gửi lên hệ thống.');return proof;
      });
      return result.then(function(value){finishVerification();return value;},function(error){finishVerification();throw error;});
    }
    function verifyExplicitSave(record,mode,verificationOptions){
      // User intent permits an existing row's status/view transition, not an
      // unknown row, destination guess or last-known fallback. The private
      // policy cannot be opted into through legacy verification options.
      return verifyFresh(record,mode,verificationOptions,explicitSavePolicy).then(function(proof){proof.verification='verified';return proof;});
    }
    function quietly(){
      if(options.externalViewFeed){due=false;return;}
      // One pending intent survives a slow read, focus or record navigation.
      // Autonomous work reads only the visible record; explicit refresh()
      // keeps the original bounded batch sweep when no record is requested.
      due=true;if(foregroundChecks||flight)return;var list=current();if(!list.length)return;
      // The SDK promise can finish before Companion's close ACK. Reserving
      // another broker read during that close would hide every idle window
      // from the full-view watcher. Observe the complete shared lifecycle,
      // then leave its one-second due retry a real idle turn. This scheduler
      // gate never delays or invalidates a ready Save proof/manual read. Use
      // that grace only once until our next dispatch: repeatedly yielding to
      // a long full read would otherwise starve Working Status in return.
      var backend=bridge(),info;try{info=backend&&typeof backend.status==='function'?backend.status():null;}catch(_){}
      if(info&&info.busy===true){waitingIdle=true;busyRetries=Math.min(5,busyRetries+1);schedule(Math.min(MAX_BACKOFF,500*Math.pow(2,busyRetries)));return;}
      if(waitingIdle){waitingIdle=false;if(!idleGraceUsed){idleGraceUsed=true;yieldUntil=Math.max(yieldUntil,now()+SLOW_YIELD);schedule(0);return;}}
      var visible=selected(list),ids=Object.keys(dirtyIds),settings=dirtyFull?{}:ids.length?{recordIds:ids}:visible?{record:visible}:{};lastSelected=visible;due=false;dirtyIds=Object.create(null);dirtyFull=false;busyRetries=0;void refresh(settings).catch(function(){if(!closed&&interval!==null){due=true;schedule(0);}});
    }
    function schedule(delay){if(closed)return;due=true;if(debounce!==null)return;var wait=Math.max(delay===undefined?DEBOUNCE:delay,retryUntil-now(),yieldUntil-now(),0);debounce=clock.setTimeout(function(){debounce=null;if(now()<retryUntil||now()<yieldUntil){schedule(0);return;}quietly();},wait);}
    function receiveSnapshot(snapshot,receipt){
      function receiptCurrent(){try{return !receipt||typeof receipt.isCurrent==='function'&&receipt.isCurrent()===true;}catch(_){return false;}}
      if(closed||!receiptCurrent())return false;var captured,byId=Object.create(null),headers=['Order Number','SKU','Record ID','Product Type','Design Link','Personalized/File','Note','Personalized/Options','Variation','Quantity','Personalized','Name fullprint','Working Status','Listing URL'];
      try{
        captured=capture({});if(!snapshot||snapshot.version!==1||!sameSource(snapshot.source,captured.source)||!Number.isInteger(snapshot.count)||snapshot.count<0||snapshot.count>MAX_RECORDS||!Array.isArray(snapshot.rows)||snapshot.rows.length!==snapshot.count+1||JSON.stringify(snapshot.rows[0])!==JSON.stringify(headers))throw fail('BASE_LIVE_RESULT','Snapshot không khớp view đang nạp.');
        snapshot.rows.slice(1).forEach(function(row){if(!Array.isArray(row)||row.length!==14||row.some(function(cell){return typeof cell!=='string'||cell.length>100000||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(cell);})||!recordId(row[2])||byId[row[2]]||row[12].length>256||row[4].length>8192||/[\x00-\x1f\x7f]/.test(row[12]+row[4]))throw fail('BASE_LIVE_RESULT','Snapshot có dữ liệu record không hợp lệ.');byId[row[2]]=row;});
        captured.list.forEach(function(record){var row=byId[record.recordId];if(row&&(row[1].trim()!==record.sku||row[11].trim()!==record.name))throw fail('BASE_LIVE_CHANGED','SKU hoặc Name fullprint đã thay đổi; giữ danh tính đơn đang chỉnh.');});
        var encoded=JSON.stringify(snapshot);if((typeof Buffer!=='undefined'?Buffer.byteLength(encoded,'utf8'):encoded.length)>8*1024*1024)throw fail('BASE_LIVE_RESULT','Snapshot vượt giới hạn.');
      }catch(error){if(records){invalidationEpoch++;mark(records,'stale',String(error.message||'Chưa nhận được snapshot đúng view.').slice(0,700));}return false;}
      // Only the authenticated view pipeline calls this hook. A lifecycle
      // heartbeat never enters here and never changes the SDK receipt time.
      if(!receiptCurrent())return false;readRevision(bridge(),captured.list,true);invalidationEpoch++;captured.epoch=invalidationEpoch;var stamp=now(),changed=[],durable=false;
      captured.list.forEach(function(record){var row=byId[record.recordId],status=row?row[12].trim():record.workingStatus,link=row?row[4].trim():record.designLink,membership=row?'in':'out';
        if(record.workingStatus!==status||record.designLink!==link||record.baseViewMembership!==membership||record.baseDesignLinkStale===true)durable=true;
        record.workingStatus=status;record.designLink=link;record.baseViewMembership=membership;record.baseViewMembershipAt=stamp;record.baseStatusAt=stamp;if(row)record.baseDesignLinkStale=false;
        record._baseLive={phase:normalize(status)?'ready':'missing',verifiedAt:stamp,message:membership==='out'?VIEW_LEFT_WARNING:normalize(status)?'':'Working Status đang trống; chưa cho phép gửi file.'};rememberSaveEvidence(record,false);mintProof(record,captured,stamp);changed.push(record);
      });due=false;dirtyIds=Object.create(null);dirtyFull=false;retryUntil=0;failures=0;emit(changed,durable);armProofExpiry();return true;
    }
    function tick(){
      if(closed)return;var list=current();if(!list.length)return;var backend=bridge();
      mark(list.filter(function(record){return record._baseLive&&/^(?:ready|membership-unknown)$/.test(record._baseLive.phase)&&!trustedProof(record);}),'stale','Lần xác nhận Working Status đã cũ; chờ xác minh lại trước khi gửi.');
      readRevision(backend,list,false);
      var visible=selected(list);if(visible!==lastSelected){lastSelected=visible;if(!options.externalViewFeed)schedule(0);}
      if(due&&now()>=retryUntil&&now()>=yieldUntil&&!flight&&!foregroundChecks&&debounce===null&&!options.externalViewFeed)quietly();
    }
    return {bind:bind,refresh:refresh,receiveSnapshot:receiveSnapshot,acceptSnapshot:receiveSnapshot,ensureFresh:checkForSave,checkForSave:checkForSave,verifyFresh:verifyFresh,verifyExplicitSave:verifyExplicitSave,tick:tick,start:function(){if(closed)return;attach();if(interval===null){current();interval=true;if(records.length&&!options.externalViewFeed)schedule(0);}},focus:function(){if(!closed){attach();if(current().length){var visible=selected(current()),changed=visible!==lastSelected;lastSelected=visible;if(!options.externalViewFeed)schedule(changed?0:DEBOUNCE);else expireProofs();}}},close:function(){closed=true;generation++;due=false;waitingIdle=false;lastSelected=null;if(records)records.forEach(function(record){privateProofs.delete(record);});if(unsubscribe)unsubscribe();unsubscribe=null;subscribedBridge=null;if(proofExpiry!==null)clock.clearTimeout(proofExpiry);if(debounce!==null)clock.clearTimeout(debounce);proofExpiry=interval=debounce=null;}};
  }
  return {FALLBACK_MS:FALLBACK,MAX_PROOF_AGE_MS:MAX_PROOF_AGE,MAX_BACKOFF_MS:MAX_BACKOFF,VERIFY_DEADLINE_MS:VERIFY_DEADLINE,POLL_MS:POLL,CHUNK_SIZE:CHUNK,VIEW_LEFT_WARNING:VIEW_LEFT_WARNING,canonicalSource:canonicalSource,sourceKey:sourceKey,sameSource:sameSource,binding:binding,normalize:normalize,state:state,display:display,createController:createController};
});
