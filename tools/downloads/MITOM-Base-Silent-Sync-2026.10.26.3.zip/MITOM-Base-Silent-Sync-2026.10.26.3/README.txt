MITOM Base silent-sync repair 2026.10.26.3

Save your work and close Photoshop and OrderStudio yourself before running Update Base Silent Sync.cmd.
Requires managed Panel2026.10.25.1,2026.10.26.1 or2026.10.26.2 with exact known Base code. Changes at most three owned JS files.
No models, CPU/GPU routing code or runtimes, local settings, pairing or full-install receipt are changed.
This Base-only repair does not upgrade an older CPU/GPU route. Use Launcher update for the full newest Panel. No package download, CUDA setup or generation starts.
A full backup is recorded under your own LOCALAPPDATA/UOY/Launcher/backups.
Use Launcher > Photoshop Panel > ... > Restore previous version if an update was interrupted.
Unknown/newer/custom files are preserved and require the cumulative release instead.
