@echo off
setlocal
"%~dp0Install.exe" --check %*
set "MITOM_CHECK_RESULT=%ERRORLEVEL%"
pause
exit /b %MITOM_CHECK_RESULT%
