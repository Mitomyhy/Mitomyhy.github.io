MITOM GPT/Codex → Web 3D R82 — sửa bộ cài Windows

Bản này chỉ thay bộ cài PowerShell bằng Install.exe (.NET Framework).
Cả sáu file chức năng R82 giữ nguyên byte như bản đã phát hành.
Không cần bật PowerShell, đổi Execution Policy hoặc chạy quyền Administrator.
Nếu chính sách công ty/Windows chặn EXE, nhờ IT duyệt; không tắt bảo vệ.

1. Giải nén ZIP mới vào một thư mục mới, không chạy từ bên trong ZIP.
2. Check.cmd chỉ kiểm tra; có thể chạy khi Photoshop đang mở.
3. Để cài: lưu công việc rồi tự đóng GPT/Codex MITOM (UOYChatGPTWorkspace),
   Photoshop và OrderStudio. Chạy Install.cmd trong thư mục mới.
   Nếu thấy yêu cầu đóng ứng dụng thì chưa cài, không tự đóng ứng dụng nào.
4. Chờ trạng thái Installed hoặc AlreadyInstalled rồi mở lại Panel/GPT/Codex.
   Nút Generate 3D: chọn ảnh output, template Acrylic / Circle / Heart Ceramic
   và CPU / GPU. Web nhận artwork, chạy flow 3D hiện tại.

Không phải đóng ứng dụng Codex desktop đang trò chuyện với trợ lý này.
Không đổi tài khoản, cookie, lịch sử chat, PSD, cấu hình máy, mô hình 3D,
Companion, Save Task hay bản R81. Không tự tách nền artwork.
Ảnh chuyển qua cầu nối nội bộ trên máy, không upload lên máy chủ AI.
Internet vẫn cần để tải trang/mô hình khi chưa có cache.

Đường cài dựa vào APPDATA của người dùng hiện tại, không cố định ADMIN.
Bộ cài chỉ ghi sáu file đúng phiên bản đã xác minh; file lạ được giữ nguyên.
Bản gốc và receipt.json được giữ tại .mitom-gpt-web3d-r82-backups của Panel.
Để hoàn tác, đóng ba ứng dụng trên, mở CMD tại thư mục bộ cài rồi chạy:
Install.exe --rollback "đường dẫn receipt.json được in khi cài"

Đây là ZIP riêng, chưa gộp vào Launcher. Không cài lại toàn bộ Panel.
