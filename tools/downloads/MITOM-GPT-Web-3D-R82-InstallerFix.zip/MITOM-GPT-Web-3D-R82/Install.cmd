@echo off
setlocal
"%~dp0Install.exe" %*
set "MITOM_INSTALL_RESULT=%ERRORLEVEL%"
if not "%MITOM_INSTALL_RESULT%"=="0" echo Installation did not complete. Read the message above; no app was closed.
pause
exit /b %MITOM_INSTALL_RESULT%
