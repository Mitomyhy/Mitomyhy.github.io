[CmdletBinding()]
param([switch]$CheckOnly,[switch]$Rollback,[string]$TargetRoot,[string]$ReceiptPath)
$ErrorActionPreference = 'Stop'
$Owner = 'MITOM.3D.MemoryGuard.R80'
$Before = 'b08954f02da3716c0afc0c9482066d7d806afe0d64e4812a95c0d0d8f091a1e9'
$Pins = [ordered]@{
    'js/depth-map.js' = 'e8689660edc3d98b4ae64b6a854b1cd9f29bbf4d6f6ccbdd8724cf63fa68c0f4'
    'js/depth-memory-probe.py' = '7693ba2056bd4c9b3fa1773bc0edbd3298c243049ad900c1264debb4e294a924'
}
function Full([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value) -or -not [IO.Path]::IsPathRooted($Value) -or $Value.StartsWith('\\') -or $Value.IndexOf([char]0) -ge 0) { throw 'An absolute local path is required.' }
    return [IO.Path]::GetFullPath($Value).TrimEnd('\','/')
}
function Safe([string]$Value) {
    $resolved = Full $Value
    $cursor = $resolved
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Redirected path refused: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if (-not $parent -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
    return $resolved
}
function Inside([string]$Base,[string]$Child) {
    $baseFull = Full $Base; $childFull = Safe $Child
    if (-not $childFull.StartsWith($baseFull + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Patch path escaped its verified Panel root.' }
    return $childFull
}
function Hash([string]$File) {
    if (-not (Test-Path -LiteralPath $File)) { return $null }
    [void](Safe $File)
    if (-not (Get-Item -LiteralPath $File -Force).PSIsContainer) { return (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant() }
    throw "Expected a regular file: $File"
}
function Closed {
    $apps = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -eq 'Photoshop' -or $_.ProcessName -like '*OrderStudio*'})
    if ($apps.Count) { throw 'Save your work and close Photoshop and OrderStudio first. No application was stopped.' }
}
function WriteJson([string]$File,$Value) { [IO.File]::WriteAllText($File,($Value | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false)) }
if (-not $TargetRoot) {
    if (-not $env:APPDATA) { throw 'APPDATA is unavailable. Supply -TargetRoot for the installed Panel.' }
    $TargetRoot = Join-Path $env:APPDATA 'Adobe/CEP/extensions/com.uoy.orderpanel'
}
$TargetRoot = Safe $TargetRoot
if (-not (Test-Path -LiteralPath (Join-Path $TargetRoot 'js') -PathType Container)) { throw 'Installed Panel/js folder was not found. No files changed.' }
$backupParent = Inside $TargetRoot (Join-Path $TargetRoot '.mitom-3d-memory-r80-backups')
if ($Rollback) {
    $receiptFile = Inside $backupParent $ReceiptPath
    $receipt = Get-Content -Raw -LiteralPath $receiptFile | ConvertFrom-Json
    if ($receipt.owner -ne $Owner -or $receipt.schema -ne 1 -or $receipt.target -ne $TargetRoot -or @($receipt.files).Count -lt 1 -or @($receipt.files).Count -gt 2) { throw 'Unrecognized rollback receipt.' }
    $backup = Split-Path -Parent $receiptFile
    $seen = @{}
    foreach ($row in $receipt.files) {
        if (-not $Pins.Contains($row.relative) -or $seen.ContainsKey($row.relative) -or $row.after -ne $Pins[$row.relative]) { throw 'Unrecognized rollback file.' }
        $seen[$row.relative] = $true
        $target = Inside $TargetRoot (Join-Path $TargetRoot $row.relative)
        $now = Hash $target
        if ($row.relative -eq 'js/depth-map.js' -and $row.before -ne $Before) { throw 'Unknown original Panel hash in receipt.' }
        if ($row.relative -eq 'js/depth-memory-probe.py' -and $null -ne $row.before) { throw 'Unknown original helper in receipt.' }
        if ($now -ne $row.after -and $now -ne $row.before) { throw 'A patched file changed after installation. Rollback refused to overwrite it.' }
        if ($row.before) {
            $original = Inside $backup (Join-Path $backup (($row.relative -replace '[/\\]','_') + '.before'))
            if ((Hash $original) -ne $row.before) { throw 'Rollback backup hash mismatch.' }
        }
    }
    if ($CheckOnly) { [pscustomobject]@{Status='RollbackReady';Changed=0;Target=$TargetRoot;Receipt=$receiptFile}; return }
    Closed
    foreach ($row in $receipt.files) {
        $target = Inside $TargetRoot (Join-Path $TargetRoot $row.relative)
        if ((Hash $target) -eq $row.before) { continue }
        if ($row.before) { Copy-Item -LiteralPath (Join-Path $backup (($row.relative -replace '[/\\]','_') + '.before')) -Destination $target -Force }
        else { Remove-Item -LiteralPath $target -Force }
    }
    $receipt.status='RolledBack'; WriteJson $receiptFile $receipt
    [pscustomobject]@{Status='RolledBack';Target=$TargetRoot;Receipt=$receiptFile}; return
}
$changes = @()
foreach ($relative in $Pins.Keys) {
    $source = Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/' + $relative))
    if ((Hash $source) -ne $Pins[$relative]) { throw "Package hash mismatch: $relative. No files changed." }
    $target = Inside $TargetRoot (Join-Path $TargetRoot $relative)
    $existing = Hash $target
    if ($existing -eq $Pins[$relative]) { continue }
    if ($relative -eq 'js/depth-map.js' -and $existing -ne $Before) { throw 'Unknown Panel depth-map.js. This patch supports only the verified current release; no files changed.' }
    if ($relative -eq 'js/depth-memory-probe.py' -and $null -ne $existing) { throw 'An unknown helper already exists. No files changed.' }
    $changes += [pscustomobject]@{relative=$relative;before=$existing;after=$Pins[$relative]}
}
if (-not $changes.Count) { [pscustomobject]@{Status='AlreadyInstalled';Changed=0;Target=$TargetRoot}; return }
if ($CheckOnly) { [pscustomobject]@{Status='Ready';WouldChange=$changes.Count;Changed=0;Target=$TargetRoot}; return }
Closed
if (Test-Path -LiteralPath $backupParent) {
    if (-not (Test-Path -LiteralPath (Join-Path $backupParent '.owner.json') -PathType Leaf) -or (Get-Content -Raw -LiteralPath (Join-Path $backupParent '.owner.json') | ConvertFrom-Json).owner -ne $Owner) { throw 'Unknown backup folder. No files changed.' }
} else {
    New-Item -ItemType Directory -Path $backupParent | Out-Null
    WriteJson (Join-Path $backupParent '.owner.json') @{owner=$Owner;schema=1}
}
$backup = Inside $backupParent (Join-Path $backupParent ('run-' + [guid]::NewGuid().ToString('N')))
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($row in $changes) {
    if ($row.before) {
        $target = Inside $TargetRoot (Join-Path $TargetRoot $row.relative)
        if ((Hash $target) -ne $row.before) { throw 'Panel changed during preflight; nothing was overwritten.' }
        $original = Inside $backup (Join-Path $backup (($row.relative -replace '[/\\]','_') + '.before'))
        Copy-Item -LiteralPath $target -Destination $original
        if ((Hash $original) -ne $row.before) { throw 'Backup verification failed.' }
    }
}
$receiptFile = Join-Path $backup 'receipt.json'
$receipt = [ordered]@{owner=$Owner;schema=1;status='Prepared';target=$TargetRoot;files=$changes;createdAt=[DateTime]::UtcNow.ToString('o')}
WriteJson $receiptFile $receipt
foreach ($row in $changes) {
    $target = Inside $TargetRoot (Join-Path $TargetRoot $row.relative)
    if ((Hash $target) -ne $row.before) { throw "Panel changed during installation. Verified backup and receipt remain at $receiptFile" }
    $source = Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/' + $row.relative))
    if ((Hash $source) -ne $row.after) { throw 'Package changed during installation; no unverified source was copied.' }
    Copy-Item -LiteralPath $source -Destination $target -Force
    if ((Hash $target) -ne $row.after) { throw "Write verification failed. Use rollback receipt $receiptFile" }
}
$receipt.status='Complete'; WriteJson $receiptFile $receipt
[pscustomobject]@{Status='Installed';Changed=$changes.Count;Target=$TargetRoot;Receipt=$receiptFile}
