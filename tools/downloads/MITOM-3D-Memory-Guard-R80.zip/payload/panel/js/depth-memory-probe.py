"""R80 conservative Windows commit-pressure preflight; standard library only.

This guard is a low-memory floor, not a promise that a particular UHD model
fits. It never closes apps, changes paging settings, or lowers model quality.
No process enumeration, customer data, credentials, network, or file writes.
"""
from __future__ import annotations

import ctypes
import json
import sys

GIB = 1024 ** 3
MIN_AVAILABLE_COMMIT = 2 * GIB
GUARD = "low-commit-floor-v1"
STAGES = frozenset(("generate", "moge-load", "moge-inference", "da2-load", "da2-inference"))


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_uint32), ("dwMemoryLoad", ctypes.c_uint32),
        ("ullTotalPhys", ctypes.c_uint64), ("ullAvailPhys", ctypes.c_uint64),
        ("ullTotalPageFile", ctypes.c_uint64), ("ullAvailPageFile", ctypes.c_uint64),
        ("ullTotalVirtual", ctypes.c_uint64), ("ullAvailVirtual", ctypes.c_uint64),
        ("ullAvailExtendedVirtual", ctypes.c_uint64),
    ]


class MemoryBudgetError(RuntimeError):
    code = "DEPTH_MEMORY_PRESSURE"

    def __init__(self, stage, available_commit):
        self.stage = stage
        self.available_commit = available_commit
        super().__init__(
            "[DEPTH_MEMORY_PRESSURE] Windows chỉ còn "
            f"{available_commit / GIB:.2f} GiB dung lượng commit (RAM + pagefile), "
            "dưới ngưỡng bảo vệ 2 GiB; chưa chạy bước AI tiếp theo. "
            "Hãy lưu công việc, đóng bớt tài liệu hoặc tab AI đang chạy rồi Generate lại. "
            "Không đổi model/chất lượng; PSD gốc và kết quả trước được giữ nguyên."
        )


def windows_memory_status(*, platform=None, windows_api=None):
    """Return aggregate bytes only, or None if this read-only API is unavailable.

    ullAvailPageFile is the process's available commit allowance. Windows can
    exhaust this before all physical RAM is used, so physical RAM alone is not
    a suitable safety floor. Unsupported platforms/probe failures do not invent
    a zero-memory reading or block an otherwise working custom runtime.
    """
    if (sys.platform if platform is None else platform) != "win32":
        return None
    try:
        api = windows_api
        if api is None:
            api = ctypes.WinDLL("kernel32", use_last_error=True)
            api.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MEMORYSTATUSEX)]
            api.GlobalMemoryStatusEx.restype = ctypes.c_int
        snapshot = MEMORYSTATUSEX()
        snapshot.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if not api.GlobalMemoryStatusEx(ctypes.byref(snapshot)):
            return None
        values = {
            "total_physical": int(snapshot.ullTotalPhys),
            "available_physical": int(snapshot.ullAvailPhys),
            "total_commit": int(snapshot.ullTotalPageFile),
            "available_commit": int(snapshot.ullAvailPageFile),
        }
        if (values["total_physical"] <= 0 or values["total_commit"] <= 0
                or values["available_physical"] > values["total_physical"]
                or values["available_commit"] > values["total_commit"]):
            return None
        return values
    except (AttributeError, OSError, TypeError, ValueError):
        return None


def preflight(stage, *, probe=windows_memory_status):
    if stage not in STAGES:
        raise ValueError("Unknown depth memory preflight stage.")
    snapshot = probe()
    if snapshot is None:
        return {"guard": GUARD, "stage": stage, "supported": False}
    available = snapshot.get("available_commit")
    if type(available) is not int or available < 0:
        raise ValueError("Invalid available commit reading.")
    if available < MIN_AVAILABLE_COMMIT:
        raise MemoryBudgetError(stage, available)
    return {"guard": GUARD, "stage": stage, "supported": True,
            "minimum_available_commit": MIN_AVAILABLE_COMMIT, **snapshot}


def main():
    snapshot = windows_memory_status()
    if snapshot is None:
        result = {"schema": 1, "probe": "mitom-depth-memory-r80", "supported": False,
                  "reason": "unsupported-platform" if sys.platform != "win32" else "windows-probe-unavailable"}
    else:
        result = {"schema": 1, "probe": "mitom-depth-memory-r80", "supported": True,
                  "availableCommitBytes": snapshot["available_commit"], "totalCommitBytes": snapshot["total_commit"],
                  "availablePhysicalBytes": snapshot["available_physical"], "totalPhysicalBytes": snapshot["total_physical"]}
    print(json.dumps(result, ensure_ascii=True, allow_nan=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
