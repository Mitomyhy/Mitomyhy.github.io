@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Install.ps1"
if errorlevel 1 echo Installation did not complete. Read the message above; no app was closed.
pause
