MITOM 3D Memory Guard R80 - ban va nho cho Photoshop Panel

1. Luu PSD, dong Photoshop va OrderStudio. Khong can go cai dat hay ghep Base lai.
2. Giai nen toan bo ZIP, chay Install.cmd. Mo lai Photoshop sau khi bao Installed.

Ban va chi thay js/depth-map.js va them js/depth-memory-probe.py.
Khong sua engine, Python/venv, model, cau hinh ca nhan, du lieu Base hay PSD.
Tu tim Panel theo APPDATA cua tung may; khong co duong dan F: cua may tac gia.
Chi chap nhan depth-map.js da xac minh cua ban Panel hien hanh. Neu file khac,
cong cu dung lai, khong ghi de. Chay lai khi da cai thi bao AlreadyInstalled.

Guard chi chan khi Windows con duoi 2 GiB dung luong commit (RAM + pagefile).
Day la nguong bao ve cuc thap, KHONG cam ket UHD du bo nho khi vuot nguong.
Khong ha chat luong, khong tu doi CPU/GPU, khong dong app hay sua paging settings.
Khi loi native, ghi them buoc cuoi va stderr co gioi han trong chan doan cuc bo.

Kiem tra ma khong thay doi file:
  powershell.exe -NoProfile -File .\Install.ps1 -CheckOnly

Neu Panel o noi khac, them -TargetRoot "duong dan day du den com.uoy.orderpanel".
Khi cai xong, chuong trinh in duong dan receipt.json. Chi cac file da thay doi
duoc backup trong .mitom-3d-memory-r80-backups ben trong Panel.

Rollback (dong Photoshop va OrderStudio truoc; giu dung receipt cua lan cai):
  powershell.exe -NoProfile -File .\Install.ps1 -Rollback -ReceiptPath "duong dan receipt.json"
Co the them -CheckOnly de kiem tra rollback, khong thay doi file.
Rollback tu choi ghi de neu file Panel hoac ban backup da bi thay doi ngoai ban va.

Neu Windows chan script theo chinh sach cong ty, khong tu tat chinh sach bao mat;
nho quan tri vien chay Install.ps1 bang cach duoc cong ty cho phep.
