MITOM Night Light Flow R81 — bản vá riêng cho Order Custom

1. Giải nén ZIP vào một thư mục bình thường trên máy.
2. Có thể chạy Check.cmd khi Photoshop đang mở: chỉ kiểm tra, không sửa file.
3. Để cài: lưu PSD rồi tự đóng Photoshop và OrderStudio. Đợi khoảng 20 giây
   để reader host cũ thoát, rồi chạy Install.cmd. Gói không tự đóng ứng dụng.
4. Sau khi báo Installed, mở lại Photoshop và Panel. Tải lại trang Base một
   lần, kiểm tra Reader R81 rồi bấm Nạp từ Base để đọc cột Suppliers.
   Không cần tải lại Companion hoặc ghép Base lại.

Night Light 4-inch Warm Light hoặc 7 Color Light:
- Suppliers Printway: lưu Ball trước, Base sau; chưa upload/chuyển đơn khi
  chỉ mới lưu Ball.
- Suppliers Printtbelle/Printbelle: vẫn một fullprint.
- Thiếu/không nhận diện được Suppliers của đơn 4-inch: dừng trước khi xuất,
  yêu cầu kiểm tra cột Suppliers; không tự đoán xưởng.
Night Light 2.4-inch và 3.2-inch vẫn một fullprint như trước.

Gói chỉ thay sáu file mã đã xác minh của Panel R77/R78: js/main.js,
js/lark-base-bridge.js, lark-base-extension/extension.js và
lark-base-extension/index.html, js/lark-base-ui.js, js/lark-import-adapter.js.
Không đổi engine CPU/GPU, mô hình AI, cấu hình, PSD, Base pairing, Save Task
hoặc dữ liệu upload.
Đường dẫn cài theo APPDATA của người đang dùng, không cố định ADMIN/ổ đĩa.
Bản cũ được giữ trong .mitom-nightlight-r81-backups dưới thư mục Panel.
Installer in đường dẫn receipt.json chính xác để hoàn tác khi cần.

Hoàn tác (đóng Photoshop/OrderStudio trước):
powershell.exe -NoProfile -File Install.ps1 -Rollback -ReceiptPath "đường dẫn receipt.json đã in"

Không tự đóng ứng dụng, không gọi Base/upload và không xóa bản sao lưu.
Nếu PowerShell bị chính sách công ty chặn, nhờ IT cho phép/chạy mã đã duyệt;
gói này không tắt hoặc vượt qua execution policy.
Gói này là ZIP riêng; không tự đổi phiên bản Launcher hoặc cài đặt gói đầy đủ.
