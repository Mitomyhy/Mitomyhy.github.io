@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Install.ps1" -CheckOnly
pause
