/* Base connection controls and read-only SDK import boundary. The existing Order Custom parser and
 * production-state guards remain authoritative for any Photoshop work. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root){root.UOYLarkBaseUI=api;if(root.document)api.autoInit(root);}})(typeof window==='undefined'?null:window,function(){
  'use strict';
  var currentWindow=null,dialog=null;
  function escapeHtml(value){return String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/\r\n?/g,'\n').replace(/\n/g,'<br>');}
  function snapshotToClip(snapshot){
    if(!snapshot||snapshot.version!==1||!snapshot.source||!Array.isArray(snapshot.rows)||snapshot.rows.length!==snapshot.count+1)throw new Error('Base chưa trả JSON view đầy đủ.');
    var columns=Array.isArray(snapshot.rows[0])?snapshot.rows[0].length:0;if(columns!==14&&columns!==15)throw new Error('JSON Base thiếu cột.');
    var html='<table><tbody>'+snapshot.rows.map(function(row,i){if(!Array.isArray(row)||row.length!==columns)throw new Error('JSON Base thiếu cột.');return '<tr>'+row.map(function(cell){if(typeof cell!=='string')throw new Error('JSON Base có ô không đúng định dạng.');var tag=i===0?'th':'td';return '<'+tag+'>'+escapeHtml(cell)+'</'+tag+'>';}).join('')+'</tr>';}).join('')+'</tbody></table>';
    return {text:'',html:html,source:'lark-base-sdk',sourceInfo:{tableId:String(snapshot.source.tableId||''),viewId:String(snapshot.source.viewId||''),viewName:String(snapshot.source.viewName||''),url:String(snapshot.source.url||'')},count:snapshot.count};
  }
  function importStatus(value){return value.replace(/^\s+|\s+$/g,'').toLowerCase().replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g,'a').replace(/[èéẹẻẽêềếệểễ]/g,'e').replace(/[ìíịỉĩ]/g,'i').replace(/[òóọỏõôồốộổỗơờớợởỡ]/g,'o').replace(/[ùúụủũưừứựửữ]/g,'u').replace(/[ỳýỵỷỹ]/g,'y').replace(/đ/g,'d').replace(/[\u200b-\u200d\u2060\ufeff]/g,'').replace(/[_\-]+/g,' ').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'');}
  function importEligible(value){return /^(?:todo|to do|fix file)$/.test(importStatus(value));}
  function preflightSnapshot(snapshot){
    // Diagnose the immutable full SDK read before making a separate ordered
    // Todo/Fix projection. Never repair fields or skip an invalid eligible row.
    var headers=['Order Number','SKU','Record ID','Product Type','Design Link','Personalized/File','Note','Personalized/Options','Variation','Quantity','Personalized','Name fullprint','Working Status','Listing URL'];
    function schema(){var error=new Error('Base đã trả dữ liệu nhưng cấu trúc cột chưa hợp lệ. Đợt đơn cũ vẫn được giữ. Kiểm tra dữ liệu/ánh xạ trong Base; không cần ghép lại.');error.code='BASE_DATA_SCHEMA';throw error;}
    if(!snapshot||snapshot.version!==1||!snapshot.source||!Number.isInteger(snapshot.count)||snapshot.count<0||snapshot.count>5000||!Array.isArray(snapshot.rows)||snapshot.rows.length!==snapshot.count+1)schema();
    if(Array.isArray(snapshot.rows[0])&&snapshot.rows[0].length===15)headers.push('Suppliers');
    // Validate the complete rectangle and exact canonical header BEFORE any
    // field index is used, including malformed rows late in a large view.
    for(var i=0;i<snapshot.rows.length;i++){
      var cells=snapshot.rows[i];if(!Array.isArray(cells)||cells.length!==headers.length)schema();
      for(var c=0;c<cells.length;c++)if(typeof cells[c]!=='string'||cells[c].length>100000||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(cells[c]))schema();
    }
    for(var h=0;h<headers.length;h++)if(snapshot.rows[0][h]!==headers[h])schema();
    var seen=Object.create(null);
    for(var rid=1;rid<snapshot.rows.length;rid++){var rawId=snapshot.rows[rid][2];if(!/^\w[\w-]{0,159}$/.test(rawId)||seen[rawId])schema();seen[rawId]=true;}
    function trim(value){return value.replace(/^\s+|\s+$/g,'');}
    function skuFromName(name){var base=name.split(/-fullprint-/i)[0],match=base.match(/^(.*)-(\d{6,})$/);return match?match[1]:base;}
    function orderFromName(name){var match=name.match(/-(\d{8,18})-fullprint-/i);return match?match[1]:'';}
    function recordFromName(name){var parts=name.split('-'),anchor=-1,found='';for(var a=0;a<parts.length;a++)if(/^fullprint$/i.test(parts[a])){anchor=a;break;}if(anchor<0)return '';for(var p=anchor+1;p<parts.length;p++){var token=trim(parts[p]);if(/^rec[a-z0-9]{3,96}$/i.test(token)){if(found&&found!==token)return null;found=token;}}return found;}
    var labels={quantityEmpty:'Quantity trống',quantityInvalid:'Quantity không hợp lệ',nameInvalid:'Name fullprint trống hoặc không hợp lệ',statusEmpty:'Working/Working Status trống',statusMultiline:'Working/Working Status nhiều dòng hoặc ô',skuEmpty:'SKU trống',skuMismatch:'SKU không khớp Name fullprint',orderMismatch:'Order Number không khớp Name fullprint',recordMismatch:'Record ID không khớp Name fullprint',recordInvalid:'Record ID không hợp lệ'};
    var eligible=0,excluded=0,invalidEligible=0,invalidStatus=0,samples=[];
    for(var r=1;r<snapshot.rows.length;r++){
      var row=snapshot.rows[r],working=trim(row[12]),order=trim(row[0]),record=trim(row[2]),reasons=[];
      if(!importStatus(working))reasons.push('statusEmpty');if(/[\r\n\t]/.test(working))reasons.push('statusMultiline');
      if(reasons.length)invalidStatus++;
      else if(!importEligible(working)){excluded++;continue;}
      else {
        eligible++;
        var name=trim(row[11]),sku=trim(row[1]),quantity=trim(row[9]);
        if(!name||!/\S-fullprint-\S/i.test(name)||/[\r\n\t]/.test(name))reasons.push('nameInvalid');
        if(!sku)reasons.push('skuEmpty');
        if(!quantity)reasons.push('quantityEmpty');else if(!/^\d+(?:\.\d+)?$/.test(quantity))reasons.push('quantityInvalid');
        if(name&&sku&&sku!==skuFromName(name))reasons.push('skuMismatch');
        var nameOrder=orderFromName(name),nameRecord=recordFromName(name);
        if(nameRecord===null)reasons.push('recordInvalid');
        if(order&&(!/^\d{8,18}$/.test(order)||(nameOrder&&order!==nameOrder)))reasons.push('orderMismatch');
        if(record&&!/^[A-Za-z0-9_-]{1,160}$/.test(record))reasons.push('recordInvalid');
        if(record&&nameRecord&&record!==nameRecord)reasons.push('recordMismatch');
        if(reasons.length)invalidEligible++;
      }
      if(reasons.length&&samples.length<3){var sample={row:r,reasons:reasons};if(/^\d{8,18}$/.test(order))sample.orderNumber=order;if(/^rec[a-z0-9]{3,96}$/i.test(record))sample.recordId=record;samples.push(sample);}
    }
    var diagnostics={readTotal:snapshot.count,eligible:eligible,excluded:excluded,invalidEligible:invalidEligible,invalidStatus:invalidStatus,samples:samples};
    if(invalidEligible||invalidStatus){
      var details=samples.map(function(sample){return 'dòng '+sample.row+(sample.orderNumber?' (Order '+sample.orderNumber+')':'')+(sample.recordId?' ['+sample.recordId+']':'')+': '+sample.reasons.map(function(reason){return labels[reason];}).join(', ');}).join('; ');
      var issue=new Error('Base đã đọc '+snapshot.count+' dòng; '+eligible+' dòng Todo/Fix File, '+excluded+' dòng khác trạng thái. '+invalidEligible+' dòng Todo/Fix File chưa hợp lệ'+(invalidStatus?', '+invalidStatus+' dòng chưa đọc được Working':'')+'. '+details+'. Đợt đơn cũ vẫn được giữ. Kiểm tra dữ liệu/ánh xạ trong Base, không tự sửa hoặc bỏ qua dòng Todo/Fix File; không cần ghép lại.');issue.code='BASE_DATA_INVALID';issue.diagnostics=diagnostics;throw issue;
    }
    if(!eligible){var empty=new Error('Base đã đọc '+snapshot.count+' dòng; không có dòng Todo/Fix File để nạp, '+excluded+' dòng khác trạng thái. Đợt đơn cũ vẫn được giữ. Kiểm tra dữ liệu/ánh xạ hoặc Working trong Base; không cần ghép lại.');empty.code='BASE_NO_ELIGIBLE';empty.diagnostics=diagnostics;throw empty;}
    return diagnostics;
  }
  function prepareImportSnapshot(snapshot){
    var summary=preflightSnapshot(snapshot),rows=[snapshot.rows[0].slice()];
    for(var r=1;r<snapshot.rows.length;r++)if(importEligible(snapshot.rows[r][12]))rows.push(snapshot.rows[r].slice());
    return {snapshot:{version:snapshot.version,source:Object.assign({},snapshot.source),count:summary.eligible,rows:rows},summary:summary};
  }
  function importSourceLabel(clip){
    var summary=clip&&clip.readSummary;
    if(!clip||clip.source!=='lark-base-sdk'||clip.importProjection!==true||!summary)return '';
    for(var i=0,keys=['readTotal','eligible','excluded','invalidEligible','invalidStatus'];i<keys.length;i++)if(!Number.isInteger(summary[keys[i]])||summary[keys[i]]<0||summary[keys[i]]>5000)return '';
    if(!summary.eligible||summary.invalidEligible||summary.invalidStatus||summary.eligible+summary.excluded!==summary.readTotal||clip.count!==summary.eligible)return '';
    return 'Base SDK · đọc '+summary.readTotal+' dòng · nạp '+summary.eligible+' Todo/Fix File · loại '+summary.excluded+' khác trạng thái';
  }
  function bridge(win){var api=win&&win.UOYLarkBaseBridge;if(!api)throw new Error('Thiếu cầu nối Base. Cài lại bản panel mới và mở lại Photoshop.');if(typeof api.autoInit==='function')api.autoInit(win);return api;}
  function make(doc,tag,text){var node=doc.createElement(tag);if(text!==undefined)node.textContent=text;return node;}
  function buildLabel(value){return typeof value==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(value)?value:'';}
  function launcherBuildText(info){
    var has=Object.prototype.hasOwnProperty,actual=buildLabel(info&&(has.call(info,'launcherClientBuild')?info.launcherClientBuild:info.clientBuild)),required=buildLabel(info&&(has.call(info,'requiredLauncherBuild')?info.requiredLauncherBuild:info.requiredClientBuild));
    return 'Companion: '+(actual||'chưa xác định')+' · cần: '+(required||'bản đi kèm gói cài');
  }
  function buildText(info){
    var server=buildLabel(info&&info.serverBuild),required=buildLabel(info&&info.requiredClientBuild),client=buildLabel(info&&info.clientBuild);
    if(!server&&!required&&!client&&(!info||info.clientCompatible===undefined))return '';
    var state=info&&info.clientCompatible===false?'cần tải lại extension':info&&info.clientCompatible===true?'đúng bản':'chưa kết nối';
    return 'Panel: '+(server||required||'chưa xác định')+' · Extension Order: '+(client||'chưa xác định')+' ('+state+')'+(required&&required!==server?' · Bản cần dùng: '+required:'');
  }
  function connectionText(info){
    var remembered=Number(info&&info.rememberedBases)>0;
    if(info&&info.clientCompatible===false)return 'Extension Order đang chạy bản cũ. Chỉ cho lần cập nhật này: bấm X ngay ở tiêu đề Order rồi mở lại UOY Order để tải bản mới; quay về danh sách rồi ẩn danh sách sẽ giữ bản cũ. Không đóng trang Base. '+(remembered?'Ghép nối đã lưu vẫn được giữ; không cần ghép mã lại.':'Không cần bấm Quên ghép nối.');
    if(info&&info.launcherCompatible===false)return 'Chrome Companion chưa đúng phiên bản. '+launcherBuildText(info)+'. Cập nhật bằng gói mới rồi tải lại UOY Base Companion trong chrome://extensions. Nếu tab Base vẫn giữ mã cũ, lưu công việc rồi tải lại riêng tab đó một lần. Không cần xóa ghép nối hoặc dạy lại nút.';
    if(info&&info.launcherState==='needsSetup')return 'Companion đã ghép nhưng chưa dạy đủ nút trên máy này. Hoàn tất trong popup Chrome; cấu hình nút không được mang sang máy khác theo ZIP. Có thể mở UOY Order bằng tay rồi Nạp qua SDK. Không cần xóa ghép nối.';
    if(info&&info.launcherState==='paused')return 'Chrome đang tạm dừng tự mở/đóng Order. Có thể giữ Order mở để chỉnh ánh xạ và Nạp bằng SDK như cũ. Nếu Order đã đóng, bật lại tự mở/đóng trong UOY Base Companion hoặc mở Order bằng tay. Ghép nối vẫn được giữ.';
    if(info&&info.launcherConnected)return 'Chrome đã kết nối để tự mở/đóng Order. Chọn view trên tab Base rồi bấm Nạp từ Base trong Photoshop; Order mở chốc lát để đọc và tự đóng. '+(remembered?'Ghép nối Base đã lưu vẫn được giữ; không cần dán mã lại khi mở Photoshop. ':'')+'Giữ tab Base mở và đăng nhập. Không cần API key.';
    if(info&&Number(info.launcherRememberedBases)>0)return 'Tiện ích Chrome đã được ghi nhớ và sẽ tự nối lại khi Photoshop mở. Giữ tab Base đã ghép mở và đăng nhập, chọn view rồi bấm Nạp từ Base; panel chờ xác nhận view mới tối đa 45 giây ở lần nối đầu. Không cần mở popup Companion hay mở/đóng Order bằng tay. Nếu hết thời gian, kiểm tra tiện ích đã bật, đúng bản và đã dạy đủ bốn nút trên máy này. Không cần ghép mã lại.';
    if(info&&info.connected)return 'Extension đã kết nối. '+(remembered?'Máy này có ghép nối Base đã lưu; Base đã ghép không cần dán mã lại khi mở Photoshop. ':'')+'Chọn view rồi bấm Nạp từ Base. Có thể đóng hộp thoại này; giữ extension Base hoạt động.';
    if(remembered)return 'Đã lưu ghép nối trên máy này. Base đã ghép không cần dán mã lại khi mở Photoshop. Mở extension trong Base để tự kết nối, rồi bấm Nạp. Với Base mới, mở Thiết lập ghép nối bên dưới và xác nhận một lần. Đóng extension ở Lark sẽ dừng đọc view.';
    return 'Ghép một lần đầu cho Base này: mở extension trong Base, dán mã và xác nhận quyền đọc. '+(info&&info.rememberAvailable===false?'Máy này chưa lưu được ghép nối; chỉ dùng phiên hiện tại.':'Bật Ghi nhớ để tự nối những lần mở Photoshop sau, khi extension Base hoạt động.');
  }
  function launcherText(info){
    var states={unpaired:'chưa ghép',waiting:'đợi tab Base',ready:'sẵn sàng',opening:'đang mở Order',reading:'đang đọc bằng SDK',closing:'đang đóng Order',paused:'đã tạm dừng',needsSetup:'chưa dạy đủ nút trên máy này',error:'cần kiểm tra tiện ích'};
    var state=states[info&&info.launcherState]||(info&&info.launcherConnected?'sẵn sàng':'chưa ghép'),saved=Number(info&&info.launcherRememberedBases)>0;
    return 'Chrome tự mở/đóng Order: '+state+(saved?' · đã ghi nhớ trên máy này':'')+(info&&info.launcherRememberAvailable===false?' · chưa lưu được, chỉ dùng phiên hiện tại':'')+' · '+launcherBuildText(info);
  }
  function launcherProblem(error){
    var messages={BASE_LAUNCHER_BUSY:'Đang có một lần Nạp mở/đọc Order. Đợi lần đó hoàn tất rồi thử lại.',BASE_LAUNCHER_NOT_READY:'Chrome chưa sẵn sàng tự mở Order. Giữ tab Base đã ghép mở, bật UOY Base Companion và chọn một view. Bấm Kết nối Base để kiểm tra tiện ích; không cần ghép mã đọc Base lại.',BASE_LAUNCHER_TIMEOUT:'Tiện ích Chrome chưa mở được Order hoặc SDK chưa kết nối kịp. Kiểm tra tab Base còn mở và các nút mở/đóng Order đã được thiết lập trong tiện ích, rồi bấm Nạp lại. Chưa nạp dữ liệu cũ.',BASE_LAUNCHER_CHANGED:'Tab hoặc view Base đã đổi trong lúc tự mở Order. Chọn đúng view rồi bấm Nạp lại; chưa đưa dữ liệu nào vào Photoshop.',BASE_LAUNCHER_REVOKED:'Ghép nối tiện ích Chrome đã được quên. Bấm Kết nối Base → Chrome để ghép lại riêng tiện ích. Mã đọc Base không bị thay đổi.',BASE_LAUNCHER:'Chrome chưa hoàn tất mở/đóng Order. Kiểm tra UOY Base Companion và các nút đã thiết lập rồi thử lại; chưa nạp dữ liệu cũ.',BASE_VIEW_CHANGED:'View đã đổi trong lúc mở hoặc đọc Order. Chọn đúng view trên Base rồi bấm Nạp lại; chưa đưa dữ liệu nào vào Photoshop.',BASE_METADATA:'Không xác định chắc Base/bảng/view đang chọn từ Chrome. Chọn một view trong tab Base đã ghép rồi bấm Nạp lại; tool không đoán view hoặc đọc dữ liệu cũ.'};
    messages.BASE_LAUNCHER_PAUSED='Chrome đang tạm dừng tự mở/đóng Order. Bật lại trong UOY Base Companion để Nạp khi Order đã đóng, hoặc mở Order bằng tay để Nạp qua SDK. Không cần ghép mã lại.';
    messages.BASE_METADATA_TIMEOUT='Chưa nhận được view hiện tại từ Chrome Companion đúng hạn. Giữ tab Base đã ghép mở và đăng nhập, kiểm tra tiện ích đã bật, đúng bản và đã dạy đủ nút trên máy này rồi Nạp lại. Không cần ghép mã lại; đợt đơn cũ vẫn được giữ.';
    messages.BASE_READER_TIMEOUT='Chrome đã mở Order nhưng bộ đọc chưa kết nối kịp. Kiểm tra tab Base và dùng bộ đọc đi kèm gói mới rồi Nạp lại. Không cần xóa ghép nối.';
    messages.BASE_READ_TIMEOUT='Bộ đọc Base ngừng phản hồi trong lúc lấy view. Kiểm tra mạng và tab Base, rồi Nạp lại; chưa nạp dữ liệu thiếu.';
    messages.BASE_READ_DEADLINE='Base trả view quá chậm. Chọn view ít dòng hơn rồi Nạp lại; tool chưa nạp một phần hoặc dùng dữ liệu cũ.';
    messages.BASE_COMPANION_CALIBRATION='Companion đã kết nối nhưng chưa dạy đủ nút mở/thu gọn Order trên máy này. Mở popup UOY Base Companion để hoàn tất, hoặc mở UOY Order bằng tay rồi Nạp.';
    messages.LAUNCHER_VERSION='Chrome Companion chưa đúng phiên bản. '+launcherBuildText(error)+'. Companion chỉ nhận đúng phiên bản, không dùng mã cũ để đọc Base. Cập nhật bằng gói mới rồi tải lại UOY Base Companion trong chrome://extensions; ghép nối và nút đã dạy vẫn được giữ.';
    messages.BASE_CHROME_CONTENT_VERSION='Mã Companion trong tab Base chưa đúng phiên bản. Lưu công việc rồi tải lại riêng tab Base một lần để nạp mã mới; tool không tự tải lại tab hoặc bấm lại lệnh. Ghép nối và nút đã dạy vẫn được giữ.';
    if(!error||!Object.prototype.hasOwnProperty.call(messages,error.code))return error;
    var friendly=new Error(messages[error.code]);friendly.code=error.code;
    for(var i=0,keys=['clientBuild','requiredClientBuild','launcherClientBuild','requiredLauncherBuild'];i<keys.length;i++){var label=buildLabel(error[keys[i]]);if(label)friendly[keys[i]]=label;}
    return friendly;
  }
  function progressText(info){
    var stages={metadata:'Đang xác nhận tab và view Base',waitingMetadata:'Đang xác nhận tab và view Base',opening:'Đang mở Order trong Base',connecting:'Đang kết nối bộ đọc Base',waitingReader:'Đang kết nối bộ đọc Base',reading:'Đang đọc view Base',validating:'Đang kiểm tra dữ liệu view'};
    var stage=info&&stages[info.readStage]||'Đang kết nối Base';
    if(info&&info.readStage==='waitingMetadata'&&info.readDetail==='coldStart')stage='Đang chờ Chrome tự nối lại và xác nhận view Base (tối đa 45 giây)';
    if(info&&info.readStage==='reading'&&info.readDetail==='validating')stage=stages.validating;
    var count=Number(info&&info.readRecords),elapsed=Number(info&&info.readElapsedMs);
    if(Number.isInteger(count)&&count>=0&&count<=5000&&info.readStage==='reading')stage+=' · '+count+' dòng';
    if(Number.isFinite(elapsed)&&elapsed>=0&&elapsed<=180000)stage+=' · '+Math.floor(elapsed/1000)+' giây';
    return stage+'…';
  }
  function showPairing(win){
    win=win||currentWindow;if(!win||!win.document)return Promise.reject(new Error('Chưa có giao diện panel.'));var api;try{api=bridge(win);}catch(e){return Promise.reject(e);}
    return api.getPairingInfo().then(function(info){
      if(dialog){dialog.focus();return info;}
      var doc=win.document,previous=doc.activeElement,closed=false,overlay=make(doc,'div'),box=make(doc,'section'),title=make(doc,'h3','Kết nối Lark Base'),status=make(doc,'p',connectionText(info));status.setAttribute('role','status');status.setAttribute('aria-live','polite');
      overlay.id='uoyLarkPairing';overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:100000;display:flex;align-items:center;justify-content:center;padding:10px;box-sizing:border-box';
      box.tabIndex=-1;box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-labelledby','uoyLarkPairingTitle');box.style.cssText='background:#282e32;color:#eef2f4;border:1px solid #62737c;border-radius:10px;padding:16px;width:100%;max-width:540px;max-height:95%;overflow:auto;box-sizing:border-box;font:13px/1.5 system-ui,sans-serif';title.id='uoyLarkPairingTitle';title.style.margin='0 0 10px';box.appendChild(title);box.appendChild(status);
      var versions=make(doc,'p',buildText(info));versions.id='uoyLarkBuildStatus';versions.style.cssText='font-size:12px;color:#b9c6ce;overflow-wrap:anywhere';versions.hidden=!versions.textContent;box.appendChild(versions);
      var launcherStatus=make(doc,'p',launcherText(info));launcherStatus.id='uoyLarkLauncherStatus';launcherStatus.setAttribute('aria-live','polite');launcherStatus.style.cssText='font-size:12px;color:#b9c6ce';box.appendChild(launcherStatus);
      var setup=make(doc,'details'),setupSummary=make(doc,'summary','Thiết lập ghép nối — lần đầu hoặc Base mới');setup.id='uoyLarkPairSetup';setup.open=!(Number(info.rememberedBases)>0);setupSummary.style.cssText='cursor:pointer;margin:8px 0 12px;color:#d8e8dd';setup.appendChild(setupSummary);box.appendChild(setup);
      function field(label,value,multi,parent){var wrapper=make(doc,'label',label),input=make(doc,multi?'textarea':'input');input.readOnly=true;input.value=value;input.setAttribute('aria-label',label);input.style.cssText='display:block;width:100%;box-sizing:border-box;margin:5px 0 9px;padding:8px;background:#1b2125;color:#eef2f4;border:1px solid #596a73;border-radius:6px';if(multi)input.rows=4;wrapper.appendChild(input);(parent||setup).appendChild(wrapper);return input;}
      var urlInput=field('URL extension',setup.open?String(info.url||''):'',false),codeInput=field('Mã ghép nối lần đầu',setup.open?String(info.code||''):'',true),setupActions=make(doc,'div'),actions=make(doc,'div');setupActions.style.cssText=actions.style.cssText='display:flex;gap:6px;flex-wrap:wrap;margin:8px 0';setup.appendChild(setupActions);
      function syncSetup(){urlInput.value=setup.open?String(info.url||''):'';codeInput.value=setup.open?String(info.code||''):'';}
      setup.addEventListener('toggle',syncSetup);
      function button(label,handler,parent){var button=make(doc,'button',label);button.type='button';button.style.cssText='padding:7px 10px;border:1px solid #697b85;border-radius:5px;background:#36594a;color:white;cursor:pointer';button.addEventListener('click',handler);(parent||actions).appendChild(button);return button;}
      function copyInput(input,destination){input.focus();input.select();var copied=false;try{copied=doc.execCommand('copy');}catch(_){}status.textContent=copied?'Đã copy. Dán vào '+(destination||'phần mở rộng Base')+'.':'Đã chọn nội dung. Bấm Ctrl+C để copy, rồi dán vào '+(destination||'Base')+'.';}
      button('Copy URL',function(){syncSetup();copyInput(urlInput);},setupActions);button('Copy mã',function(){syncSetup();copyInput(codeInput);},setupActions);
      var launcherSetup=make(doc,'details'),launcherSummary=make(doc,'summary','Chrome — tự mở/đóng Order (thiết lập một lần)');launcherSetup.id='uoyLarkLauncherSetup';launcherSetup.open=false;launcherSummary.style.cssText='cursor:pointer;margin:8px 0 12px;color:#d8e8dd';launcherSetup.appendChild(launcherSummary);box.appendChild(launcherSetup);
      var launcherNote=make(doc,'p','Thêm tiện ích UOY Base Companion vào Chrome bằng bộ cài đi kèm, rồi dán mã riêng bên dưới vào tiện ích và ghép từng Base. Mã Chrome không phải mã đọc Base ở phần trên. Tiện ích chỉ nhận biết Base/bảng/view đang chọn và mở/đóng Order; các dòng đơn vẫn do SDK Order đọc. Dùng Tạm dừng tự mở/đóng trong tiện ích khi cần chỉnh ánh xạ Order. Bạn tự duyệt quyền Chrome hoặc mạng local nếu trình duyệt hỏi, không tắt bảo vệ trình duyệt.');launcherSetup.appendChild(launcherNote);
      var launcherCodeInput=field('Mã riêng cho UOY Base Companion (Chrome)','',true,launcherSetup),launcherId=make(doc,'p');launcherId.style.cssText='font-size:12px;color:#b9c6ce;overflow-wrap:anywhere';launcherSetup.appendChild(launcherId);
      function syncLauncher(){launcherCodeInput.value=launcherSetup.open?String(info.launcherCode||''):'';launcherId.textContent=typeof info.launcherExtensionId==='string'&&/^[a-p]{32}$/.test(info.launcherExtensionId)?'Tiện ích đã ghép: '+info.launcherExtensionId:'';launcherId.hidden=!launcherId.textContent;}
      launcherSetup.addEventListener('toggle',syncLauncher);syncLauncher();
      var launcherActions=make(doc,'div');launcherActions.style.cssText='display:flex;gap:6px;flex-wrap:wrap;margin:8px 0';launcherSetup.appendChild(launcherActions);
      var copyLauncher=button('Copy mã Chrome',function(){syncLauncher();if(!launcherCodeInput.value){status.textContent='Cầu nối chưa có mã Chrome. Bấm Kiểm tra kết nối rồi thử lại.';return;}copyInput(launcherCodeInput,'tiện ích UOY Base Companion trong Chrome');},launcherActions);
      var forgettingLauncher=false,forgetLauncher=button('Quên tiện ích Chrome',function(){
        if(forgettingLauncher||forgetLauncher.disabled)return;
        var approved=false;try{approved=win.confirm('Quên ghép nối UOY Base Companion trên máy này? Tiện ích Chrome sẽ cần ghép lại. Không quên mã đọc Base và không sửa dữ liệu Base.');}catch(_){}
        if(!approved)return;forgettingLauncher=true;forgetLauncher.disabled=true;copyLauncher.disabled=true;
        Promise.resolve().then(function(){return api.forgetLauncherPairings();}).then(function(){return api.getPairingInfo();}).then(updateInfo).catch(function(e){status.textContent=String(e.message||'Không quên được tiện ích Chrome.');}).then(function(){forgettingLauncher=false;copyLauncher.disabled=false;forgetLauncher.disabled=typeof api.forgetLauncherPairings!=='function'||!(Number(info.launcherRememberedBases)>0);});
      },launcherActions);
      forgetLauncher.disabled=typeof api.forgetLauncherPairings!=='function'||!(Number(info.launcherRememberedBases)>0);
      function updateInfo(next){if(closed)return;info=next;status.textContent=connectionText(next);versions.textContent=buildText(next);versions.hidden=!versions.textContent;launcherStatus.textContent=launcherText(next);if(!(Number(next.rememberedBases)>0))setup.open=true;syncSetup();syncLauncher();forget.disabled=typeof api.forgetRememberedPairings!=='function'||!(Number(next.rememberedBases)>0);forgetLauncher.disabled=typeof api.forgetLauncherPairings!=='function'||!(Number(next.launcherRememberedBases)>0);}
      var refresh=button('Kiểm tra kết nối',function(){api.getPairingInfo().then(updateInfo).catch(function(e){status.textContent=String(e.message||e);});});
      var forgetting=false,forget=button('Quên ghép nối',function(){
        if(forgetting||forget.disabled)return;
        var approved=false;try{approved=win.confirm('Quên tất cả ghép nối Base đã lưu trên máy này? Các Base sẽ cần ghép mã lại. Không sửa hoặc xóa dữ liệu Base.');}catch(_){}
        if(!approved)return;
        forgetting=true;forget.disabled=true;refresh.disabled=true;
        Promise.resolve().then(function(){return api.forgetRememberedPairings();}).then(function(){return api.getPairingInfo();}).then(updateInfo).catch(function(e){status.textContent=String(e.message||'Không quên được ghép nối.');forget.disabled=!(Number(info.rememberedBases)>0);}).then(function(){forgetting=false;refresh.disabled=false;});
      });
      forget.disabled=typeof api.forgetRememberedPairings!=='function'||!(Number(info.rememberedBases)>0);
      function close(){closed=true;doc.removeEventListener('keydown',onKey,true);urlInput.value='';codeInput.value='';launcherCodeInput.value='';if(overlay.parentNode)overlay.parentNode.removeChild(overlay);dialog=null;try{if(previous&&previous.focus)previous.focus();}catch(_){}}
      var closeButton=button('Đóng',close);box.appendChild(actions);
      var note=make(doc,'p','Ghép nối được lưu riêng cho từng Base trên máy và trình duyệt này; không lưu tài khoản, cookie hoặc nội dung đơn. Đóng hộp thoại này không ngắt ghép nối. Đã ghép UOY Base Companion: khung Order tự đóng sau kết nối và Nạp; bấm Nạp ở Photoshop để mở lại chốc lát, đọc đúng view đang chọn rồi đóng. Giữ tab Base mở và đăng nhập. Chưa ghép tiện ích Chrome: vẫn cần giữ Order mở. Không dùng API key và không sửa Base. Nếu không lưu được ghép nối, giao diện báo rõ chỉ dùng phiên hiện tại.');note.style.cssText='font-size:12px;color:#b9c6ce';box.appendChild(note);
      function onKey(event){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();return;}if(event.key==='Tab'){var controls=Array.prototype.slice.call(box.querySelectorAll('summary,input,textarea,button')).filter(function(node){return !node.disabled&&(!node.getClientRects||node.getClientRects().length>0);}),first=controls[0],last=controls[controls.length-1];if(event.shiftKey&&(doc.activeElement===first||doc.activeElement===box)){event.preventDefault();last.focus();}else if(!event.shiftKey&&doc.activeElement===last){event.preventDefault();first.focus();}}}
      doc.addEventListener('keydown',onKey,true);overlay.appendChild(box);doc.body.appendChild(overlay);dialog=box;box.focus();return info;
    });
  }
  function readCurrentClip(callback,onError,onProgress){var win=currentWindow||(typeof window!=='undefined'?window:null),api,ticker=null;function fail(e){if(typeof onError==='function')onError(e);}
    try{api=bridge(win);}catch(e){fail(e);return Promise.resolve(null);}
    function notifyProgress(){if(typeof onProgress!=='function'||typeof api.status!=='function')return;try{onProgress(api.status());}catch(_){}}
    function stopProgress(){if(ticker!==null){clearInterval(ticker);ticker=null;}}
    if(typeof onProgress==='function'){notifyProgress();ticker=setInterval(notifyProgress,400);}
    var result=api.fetchCurrentView().then(function(snapshot){try{if(win&&win.UOYLarkBaseWatch)win.UOYLarkBaseWatch.observeSnapshot(snapshot);}catch(_){}var prepared=prepareImportSnapshot(snapshot),clip=snapshotToClip(prepared.snapshot);clip.importProjection=true;clip.readSummary=prepared.summary;callback(clip);return clip;}).catch(function(e){
      e=launcherProblem(e);
      if(e&&e.code==='BASE_NOT_CONNECTED')return Promise.resolve().then(function(){return api.getPairingInfo();}).then(function(info){
        if(Number(info&&info.rememberedBases)>0){var savedError=new Error(info&&info.clientCompatible===false||Number(info&&info.launcherRememberedBases)>0?connectionText(info):'Ghép nối Order đã lưu vẫn được giữ; Base đã ghép không cần dán mã lại. Chrome Companion chưa sẵn sàng: kiểm tra popup Chrome. Nếu popup báo chưa có cấu hình, ghép mã Chrome RIÊNG ở Kết nối Base > Chrome một lần, rồi dạy bốn nút. Có thể Mở UOY Order Custom bằng tay để đọc trong lúc thiết lập. Thu gọn bằng quay về danh sách rồi X danh sách; không dùng X ngay trên Order.');savedError.code=info&&info.clientCompatible===false?'CLIENT_VERSION':'BASE_NOT_CONNECTED';fail(savedError);return null;}
        return showPairing(win).then(function(){fail(e);return null;},function(pairError){fail(pairError);return null;});
      },function(pairError){fail(pairError);return null;});
      fail(e);return null;
    });
    return result.then(function(value){stopProgress();return value;},function(error){stopProgress();throw error;});
  }
  function autoInit(win){currentWindow=win;function mount(){var doc=win.document,load=doc.getElementById('aLoadClip');if(!load||!load.parentNode||doc.getElementById('uoyLarkPairButton'))return;var button=make(doc,'button','Kết nối Base');button.id='uoyLarkPairButton';button.type='button';button.className=load.className;button.title='Thêm phần mở rộng Base và kết nối view đến Photoshop';button.style.cssText='margin-left:4px;min-height:25px;flex:0 0 auto;padding-left:6px;padding-right:6px';button.addEventListener('click',function(){showPairing(win).catch(function(e){try{win.alert(String(e.message||e));}catch(_){}});});load.parentNode.insertBefore(button,load.nextSibling);
      // Listen once when the panel mounts so remembered Base clients can reconnect
      // without requiring a modal or a first Nạp click. Explicit actions can retry.
      function startupFailed(){button.title='Cầu nối Base chưa khởi động. Bấm Kết nối Base để thử lại.';}
      try{var backend=bridge(win);Promise.resolve(typeof backend.start==='function'?backend.start():backend.getPairingInfo()).catch(startupFailed);}catch(_){startupFailed();}
    }
    if(win.document.readyState==='loading')win.document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();return api;
  }
  var api={escapeHtml:escapeHtml,snapshotToClip:snapshotToClip,preflightSnapshot:preflightSnapshot,prepareImportSnapshot:prepareImportSnapshot,importSourceLabel:importSourceLabel,buildText:buildText,launcherBuildText:launcherBuildText,connectionText:connectionText,launcherText:launcherText,launcherProblem:launcherProblem,progressText:progressText,showPairing:showPairing,readCurrentClip:readCurrentClip,autoInit:autoInit};return api;
});
