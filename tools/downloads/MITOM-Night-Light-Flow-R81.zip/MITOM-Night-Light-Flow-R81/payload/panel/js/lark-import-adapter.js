/* Base-only bridge for classic Order loaders. Accepts ONLY the validated,
 * projected SDK clip, not arbitrary clipboard HTML or guessed row layouts.
 * Empty canonical fields remain empty; no legacy offset reconstruction. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.UOYLarkImportAdapter=api;})(typeof window==='undefined'?null:window,function(){
  'use strict';
  var HEADERS=['Order Number','SKU','Record ID','Product Type','Design Link','Personalized/File','Note','Personalized/Options','Variation','Quantity','Personalized','Name fullprint','Working Status','Listing URL'];
  function fail(){var issue=new Error('Dữ liệu Base SDK không khớp cấu trúc nhập an toàn. Đợt đơn cũ vẫn được giữ; kiểm tra view/ánh xạ, không ghép lại.');issue.code='BASE_IMPORT_SCHEMA';throw issue;}
  function decodeCell(encoded){
    if(typeof encoded!=='string'||encoded.length>600000)fail();
    var plain=encoded.replace(/<br>/g,'\n');
    if(/[<>]/.test(plain)||/&(?!(?:amp|lt|gt|quot|#39);)/.test(plain))fail();
    return plain.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
  }
  function canonicalRows(clip){
    if(!clip||clip.source!=='lark-base-sdk'||clip.importProjection!==true||clip.text!==''||!Number.isInteger(clip.count)||clip.count<1||clip.count>5000||typeof clip.html!=='string'||clip.html.length>48*1024*1024)fail();
    var html=clip.html,prefix='<table><tbody>',suffix='</tbody></table>';
    if(html.slice(0,prefix.length)!==prefix||html.slice(-suffix.length)!==suffix)fail();
    var body=html.slice(prefix.length,-suffix.length),rowPattern=/<tr>([\s\S]*?)<\/tr>/g,rawRows=[],rows=[],row,headers=HEADERS.slice();
    while((row=rowPattern.exec(body))){
      rawRows.push(row[0]);var cells=[],rawCells=[],cellPattern=/<(th|td)>([\s\S]*?)<\/\1>/g,cell;
      while((cell=cellPattern.exec(row[1]))){if(cell[1]!==(!rows.length?'th':'td'))fail();rawCells.push(cell[0]);cells.push(decodeCell(cell[2]));}
      if(!rows.length&&cells.length===15)headers.push('Suppliers');
      if(rawCells.join('')!==row[1]||cells.length!==headers.length)fail();rows.push(cells);
    }
    if(rawRows.join('')!==body||rows.length!==clip.count+1||JSON.stringify(rows[0])!==JSON.stringify(headers))fail();
    var source=clip.sourceInfo;if(!source||!/^\w[\w-]{0,159}$/.test(source.tableId||'')||!/^\w[\w-]{0,159}$/.test(source.viewId||''))fail();
    var url;try{url=new URL(source.url);}catch(_){fail();}
    if(url.protocol!=='https:'||url.username||url.password||url.port||!/(?:\.larksuite\.com|\.feishu\.cn|\.larkoffice\.com)$/i.test(url.hostname)||url.pathname==='/')fail();
    return rows;
  }
  function toRecords(clip,options){
    options=options||{};var provider=options.provider;
    if(!provider||typeof provider.preflightSnapshot!=='function'||typeof provider.importSourceLabel!=='function'||!provider.importSourceLabel(clip)||typeof options.deriveFolder!=='function'||typeof options.pngNameOf!=='function')fail();
    var rows=canonicalRows(clip),snapshot={version:1,source:Object.assign({},clip.sourceInfo),count:clip.count,rows:rows};
    var diagnostics=provider.preflightSnapshot(snapshot);
    if(diagnostics.eligible!==clip.count||diagnostics.excluded!==0||diagnostics.invalidEligible||diagnostics.invalidStatus)fail();
    function trim(value){return value.replace(/^\s+|\s+$/g,'');}
    function classicWorking(value){
      // The provider already accepts only the semantic Todo/Fix states. Keep
      // normal labels exact; canonicalize aliases solely for the classic
      // loader's narrower status filter, retaining the raw SDK label below.
      if(/^(?:to\s*do|fix\s*file)$/i.test(value))return value;
      var folded=value.toLowerCase().replace(/[ìíịỉĩ]/g,'i').replace(/[òóọỏõôồốộổỗơờớợởỡ]/g,'o').replace(/[èéẹẻẽêềếệểễ]/g,'e').replace(/[\u200b-\u200d\u2060\ufeff]/g,'').replace(/[_\-\s]+/g,'');
      if(folded==='todo')return 'Todo';if(folded==='fixfile')return 'Fix File';fail();
    }
    return rows.slice(1).map(function(row){
      var name=trim(row[11]),listing=trim(row[13]),listingId='',match=listing.match(/https?:\/\/(?:www\.)?etsy\.com\/(?:[a-z]{2}\/)?listing\/(\d+)/i);if(match)listingId=match[1];
      return {orderNumber:trim(row[0]),sku:trim(row[1]),recordId:trim(row[2]),productType:trim(row[3]),suppliers:rows[0].length===15?trim(row[14]):'',designLink:trim(row[4]),persFile:trim(row[5]),note:trim(row[6]),persOptions:trim(row[7]),variation:trim(row[8]),quantity:trim(row[9]),personalized:trim(row[10]),name:name,workingStatus:classicWorking(trim(row[12])),_baseSDKWorkingStatus:row[12],listingUrl:listing,listingId:listingId,folder:options.deriveFolder(name),file:options.pngNameOf(name)};
    });
  }
  return {HEADERS:HEADERS.slice(),canonicalRows:canonicalRows,toRecords:toRecords};
});
