#requires -Version 5.1
[CmdletBinding()]
param([switch]$CheckOnly,[switch]$Rollback,[string]$TargetRoot,[string]$ReceiptPath)
$ErrorActionPreference = 'Stop'
$Owner = 'MITOM.Order.NightLight.R81'
$Pins = @(
    [pscustomobject]@{relative='js/main.js';before='3ff8723b323cd1ee1d9d2290d44559ffefbef43a6b445bb3c62ef816964a1ccb';after='18461766f9cd7491d812f9af5b707c9ba383d712cbd34264428bec8515f55f1f'}
    [pscustomobject]@{relative='js/lark-base-bridge.js';before='6c787fcd4f04af78954d40a487fafd0fbba297470989666087d676daff0c5d74';after='585c3d34cc35110d9806a05087163e21817acd1772e0ce74c24033db9fc1f503'}
    [pscustomobject]@{relative='lark-base-extension/extension.js';before='f533f2197df17a6d509ca818d0dd3a0f99f5fc96af9bf9fbb8ddbec6d7bf9e56';after='34f8647c1c1604505ba814a6501109147ca7892bd729ee837c8a7ed5c7d8c2b5'}
    [pscustomobject]@{relative='lark-base-extension/index.html';before='7db527d8f05fb7008d25892d460e26846bda6bda7d62b66d1ffe7da087f368b6';after='c9d1992e88e888a3a02cfaab1eba4202663274e3e762d189e282bc2296d3bc01'}
    [pscustomobject]@{relative='js/lark-base-ui.js';before='b9f1bb5a469521370ad86ef9e07524f7a92d34f2d3656fbc0c33ca442458a565';after='e0ad91ae65ece0add381d7a6d8f0d05ed4f1ce838f6f89439b6df978e06016a7'}
    [pscustomobject]@{relative='js/lark-import-adapter.js';before='6dcc7609d744f693850592dd3ab9cce632352504e8d1ca1a0899e4b252a33b83';after='3a6b8decd7edc7754c1cf1882a780dae772bf6ad29272d8a11ee8ae109a2c961'}
)
function Full([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value) -or -not [IO.Path]::IsPathRooted($Value) -or $Value.StartsWith('\\') -or $Value.IndexOf([char]0) -ge 0) { throw 'An absolute local path is required.' }
    $result = [IO.Path]::GetFullPath($Value).TrimEnd('\','/')
    if ($result -eq [IO.Path]::GetPathRoot($result).TrimEnd('\','/')) { throw 'A drive root is not a Panel folder.' }
    return $result
}
function Safe([string]$Value) {
    $resolved = Full $Value
    for ($cursor = $resolved; $cursor; $cursor = [IO.Path]::GetDirectoryName($cursor)) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Redirected path refused: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if (-not $parent -or $parent -eq $cursor) { break }
    }
    return $resolved
}
function Inside([string]$Base,[string]$Child) {
    $baseFull = Full $Base; $childFull = Safe $Child
    if (-not $childFull.StartsWith($baseFull + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Patch path escaped its verified root.' }
    return $childFull
}
function Hash([string]$File) {
    [void](Safe $File)
    if (-not (Test-Path -LiteralPath $File)) { return $null }
    if ((Get-Item -LiteralPath $File -Force).PSIsContainer) { throw "Expected a regular file: $File" }
    return (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Closed {
    $apps = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {$_.ProcessName -eq 'Photoshop' -or $_.ProcessName -like '*OrderStudio*'})
    if ($apps.Count) { throw 'Save your work and close Photoshop and OrderStudio first. No application was stopped.' }
}
function WriteJson([string]$File,$Value) { [IO.File]::WriteAllText($File,($Value | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false)) }
function BackupName([string]$Relative) { return (($Relative -replace '[/\\]','_') + '.before') }
function AtomicCopy([string]$Source,[string]$Destination,[string]$ExpectedSource,[string]$ExpectedTarget,[string]$BackupFolder) {
    if ((Hash $Source) -cne $ExpectedSource -or (Hash $Destination) -cne $ExpectedTarget) { throw 'Source or target changed during the operation; no unverified data was copied.' }
    $stage = Inside $TargetRoot (Join-Path (Split-Path -Parent $Destination) ('.mitom-nightlight-r81-' + [guid]::NewGuid().ToString('N') + '.tmp'))
    $replaced = Inside $BackupFolder (Join-Path $BackupFolder ('atomic-replaced-' + [guid]::NewGuid().ToString('N') + '.before'))
    try {
        [IO.File]::Copy($Source,$stage,$false)
        if ((Hash $stage) -cne $ExpectedSource -or (Hash $Destination) -cne $ExpectedTarget) { throw 'Source or target changed before commit.' }
        Closed
        # An explicit unique backup path works in Windows PowerShell 5.1 and 7.
        [IO.File]::Replace($stage,$Destination,$replaced)
        if ((Hash $Destination) -cne $ExpectedSource -or (Hash $replaced) -cne $ExpectedTarget) { throw 'Atomic write verification failed. Keep all backups and the receipt for repair.' }
    } finally {
        if ((Test-Path -LiteralPath $stage) -and (Hash $stage) -ceq $ExpectedSource) { Remove-Item -LiteralPath $stage -Force }
    }
}
if (-not $TargetRoot) {
    if (-not $env:APPDATA) { throw 'APPDATA is unavailable. Supply -TargetRoot for the installed Panel.' }
    $TargetRoot = Join-Path $env:APPDATA 'Adobe/CEP/extensions/com.uoy.orderpanel'
}
$TargetRoot = Safe $TargetRoot
if (-not (Test-Path -LiteralPath (Join-Path $TargetRoot 'js/main.js') -PathType Leaf)) { throw 'Installed Panel/js/main.js was not found. No files changed.' }
$pinMap=@{}
foreach($pin in $Pins) {
    if ($pin.relative -cnotmatch '^(js/main\.js|js/lark-base-bridge\.js|lark-base-extension/extension\.js|lark-base-extension/index\.html|js/lark-base-ui\.js|js/lark-import-adapter\.js)$' -or $pinMap.ContainsKey($pin.relative) -or $pin.before -cnotmatch '^[a-f0-9]{64}$' -or $pin.after -cnotmatch '^[a-f0-9]{64}$') { throw 'Invalid sealed package pins.' }
    $pinMap[$pin.relative]=$pin
}
if($pinMap.Count -ne 6) { throw 'Expected exactly six sealed runtime files.' }
$backupParent = Inside $TargetRoot (Join-Path $TargetRoot '.mitom-nightlight-r81-backups')
$marker = Join-Path $backupParent '.owner.json'
function ValidateBackupParent {
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'Unrecognized backup folder.' }
    [void](Safe $marker);$value=Get-Content -Raw -LiteralPath $marker | ConvertFrom-Json
    if ($value.owner -cne $Owner -or $value.schema -ne 1) { throw 'Unrecognized backup folder.' }
}
if ($Rollback) {
    ValidateBackupParent
    $receiptFile = Inside $backupParent $ReceiptPath;$backup=Split-Path -Parent $receiptFile
    if ([IO.Path]::GetFileName($receiptFile) -cne 'receipt.json' -or [IO.Path]::GetFileName($backup) -cnotmatch '^run-[a-f0-9]{32}$' -or (Split-Path -Parent $backup) -cne $backupParent) { throw 'Unrecognized rollback receipt path.' }
    $receipt=Get-Content -Raw -LiteralPath $receiptFile | ConvertFrom-Json
    if ($receipt.owner -cne $Owner -or $receipt.schema -ne 1 -or $receipt.target -cne $TargetRoot -or @($receipt.files).Count -lt 1 -or @($receipt.files).Count -gt 6 -or $receipt.status -cnotmatch '^(Prepared|Complete|RolledBack|RolledBackOnError|RepairRequired)$') { throw 'Unrecognized rollback receipt.' }
    $seen=@{}
    foreach($row in $receipt.files) {
        $pin=$pinMap[$row.relative]
        if (-not $pin -or $seen.ContainsKey($row.relative) -or $row.before -cne $pin.before -or $row.after -cne $pin.after) { throw 'Unrecognized rollback file or hashes.' }
        $seen[$row.relative]=$true
        $original=Inside $backup (Join-Path $backup (BackupName $row.relative));$target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative)
        if((Hash $original) -cne $row.before) { throw 'Rollback backup hash mismatch.' }
        $now=Hash $target
        if($now -cne $row.before -and $now -cne $row.after) { throw 'Patched code changed after installation. Rollback refused to overwrite it.' }
    }
    if($CheckOnly) { [pscustomobject]@{Status='RollbackReady';Changed=0;Target=$TargetRoot;Receipt=$receiptFile};return }
    Closed
    $lockPath=Inside $TargetRoot (Join-Path $TargetRoot '.mitom-nightlight-r81.lock');$lock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try {
        foreach($row in $receipt.files) {
            $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$original=Inside $backup (Join-Path $backup (BackupName $row.relative));$now=Hash $target
            if($now -ceq $row.after) { AtomicCopy $original $target $row.before $row.after $backup }
            elseif($now -cne $row.before) { throw 'Target changed during rollback.' }
        }
        $receipt.status='RolledBack';WriteJson $receiptFile $receipt
    } finally { $lock.Dispose() }
    [pscustomobject]@{Status='RolledBack';Target=$TargetRoot;Receipt=$receiptFile};return
}
$changes=@()
foreach($pin in $Pins) {
    $source=Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/'+$pin.relative));$target=Inside $TargetRoot (Join-Path $TargetRoot $pin.relative)
    if((Hash $source) -cne $pin.after) { throw "Package hash mismatch: $($pin.relative). No files changed." }
    $existing=Hash $target
    if($existing -ceq $pin.after) { continue }
    if($existing -cne $pin.before) { throw "Unknown Panel code: $($pin.relative). This patch requires the verified R77/R78 release; no files changed." }
    $changes+=[pscustomobject]@{relative=$pin.relative;before=$existing;after=$pin.after}
}
if(-not $changes.Count) { [pscustomobject]@{Status='AlreadyInstalled';Changed=0;Target=$TargetRoot};return }
if($CheckOnly) { [pscustomobject]@{Status='Ready';WouldChange=$changes.Count;Changed=0;Target=$TargetRoot};return }
Closed
if(Test-Path -LiteralPath $backupParent) { ValidateBackupParent }
$lockPath=Inside $TargetRoot (Join-Path $TargetRoot '.mitom-nightlight-r81.lock');$lock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {
    foreach($row in $changes) {
        if((Hash (Inside $TargetRoot (Join-Path $TargetRoot $row.relative))) -cne $row.before -or (Hash (Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/'+$row.relative)))) -cne $row.after) { throw 'Panel or package changed during preflight; no code was overwritten.' }
    }
    if(Test-Path -LiteralPath $backupParent) { ValidateBackupParent }
    else { New-Item -ItemType Directory -Path $backupParent | Out-Null;WriteJson $marker @{owner=$Owner;schema=1} }
    $backup=Inside $backupParent (Join-Path $backupParent ('run-'+[guid]::NewGuid().ToString('N')));New-Item -ItemType Directory -Path $backup | Out-Null
    foreach($row in $changes) {
        $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$original=Inside $backup (Join-Path $backup (BackupName $row.relative))
        if((Hash $target) -cne $row.before) { throw 'Panel changed while preparing backups; no code was overwritten.' }
        [IO.File]::Copy($target,$original,$false)
        if((Hash $original) -cne $row.before) { throw 'Backup verification failed. No code was overwritten.' }
    }
    $receiptFile=Join-Path $backup 'receipt.json';$receipt=[ordered]@{owner=$Owner;schema=1;status='Prepared';target=$TargetRoot;files=$changes;createdAt=[DateTime]::UtcNow.ToString('o')};WriteJson $receiptFile $receipt
    try {
        foreach($row in $changes) {
            $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$source=Inside $PSScriptRoot (Join-Path $PSScriptRoot ('payload/panel/'+$row.relative))
            AtomicCopy $source $target $row.after $row.before $backup
        }
        $receipt.status='Complete';WriteJson $receiptFile $receipt
    } catch {
        $failure=$_.Exception.Message;$repair=$false
        foreach($row in $changes) {
            $target=Inside $TargetRoot (Join-Path $TargetRoot $row.relative);$now=Hash $target
            if($now -ceq $row.after) {
                try { $original=Inside $backup (Join-Path $backup (BackupName $row.relative));AtomicCopy $original $target $row.before $row.after $backup } catch { $repair=$true }
            } elseif($now -cne $row.before) { $repair=$true }
        }
        $receipt.status=if($repair){'RepairRequired'}else{'RolledBackOnError'};WriteJson $receiptFile $receipt
        throw "Installation stopped: $failure. Receipt and verified originals retained at $receiptFile"
    }
} finally { $lock.Dispose() }
[pscustomobject]@{Status='Installed';Changed=$changes.Count;Target=$TargetRoot;Receipt=$receiptFile}
