(function () {
  'use strict';
  if (typeof window === 'undefined' || window.top !== window || globalThis.__uoyCompanionInstalled) return;
  globalThis.__uoyCompanionInstalled = true;
  const C = globalThis.UoyCompanion;
  // One isolated top-document identity, retained on reinjection and changed
  // only by a real page load. No account, cookie, order or reader data.
  const PAGE_ID = Array.from(crypto.getRandomValues(new Uint8Array(16)), n => n.toString(16).padStart(2,'0')).join('');
  // A live isolated document is never hot-replaced. Reinjection keeps this
  // identity and any in-flight DOM command; the worker verifies this version
  // before binding/dispatch, rather than trusting the old boolean guard.
  globalThis.__uoyCompanionInstalled = Object.freeze({build:C.BUILD,revision:C.CONTENT_REVISION,protocol:C.CONTENT_PROTOCOL,pageId:PAGE_ID});
  const CONTROLS='button,[role="button"],[role="menuitem"],a[href="#"],div[tabindex],span[tabindex]';
  const ORDER_TITLES='div.'+C.ORDER_TITLE_CLASS;
  let learning = null;
  let cancelVersion = 0;
  const jobs = new Map();
  const commandWaiters = new Set();
  let lastContext = '';
  function announceContext(force) {
    // Lark changes views with history.replaceState/pushState; these do not
    // necessarily fire a Chrome tab-complete event. Inspect only the public
    // URL, never table rows or the application's internal data store.
    try {
      // Extension reload/disable can invalidate this isolated world while
      // the URL stays unchanged. This local check sends no worker request.
      if(!chrome.runtime||chrome.runtime.id!==C.EXTENSION_ID){mountedReaderHold().release();lastContext='';return;}
      const current=fresh();
      const key=current.url;
      mountedReaderHold().inspect();
      if(!force && key===lastContext) return;
      lastContext=key;
      chrome.runtime.sendMessage({type:'viewContext',context:current}).then(reply=>{
        // A resolved RPC is not an acknowledgement when its handler rejected
        // the wake hint. Retry the same public URL on the next bounded tick.
        if((!reply||reply.ok!==true)&&lastContext===key) lastContext='';
      }).catch(()=>{
        // Extension reload/disable can invalidate the isolated context without
        // pagehide. Fail visible on lost worker transport; never strand a
        // hidden host behind a dead Companion restore control.
        mountedReaderHold().release();
        // A worker can restart during tab/session restoration. Do not mark an
        // undelivered public-URL wake hint as acknowledged forever. The next
        // bounded watcher tick rechecks the real URL, never a cached view.
        if(lastContext===key) lastContext='';
      });
    } catch (_) {mountedReaderHold().release();lastContext='';}
  }
  function fresh(expected) {
    const current = {...C.context(location.href),pageId:PAGE_ID,documentVisible:document.visibilityState==='visible'};
    if (expected && !C.sameContext(expected, current)) C.fail('Bạn đã đổi Base/table/view. Bấm Nạp lại.', 'VIEW_CHANGED');
    return current;
  }
  function visible(el) {
    if (!el || !el.isConnected || el.closest('[hidden],[aria-hidden="true"]')) return false;
    const r = el.getBoundingClientRect(); const style = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth && style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) !== 0;
  }
  function unoccluded(el) {
    if(!visible(el)) C.fail('Nút/khung Order đang bị ẩn.', 'OCCLUDED');
    const r=el.getBoundingClientRect();const x=r.left+r.width/2;const y=r.top+r.height/2;
    if(x<0||y<0||x>=innerWidth||y>=innerHeight) C.fail('Nút không nằm đầy đủ trong khung nhìn. Không đoán vị trí bấm.', 'OCCLUDED');
    const hit=document.elementFromPoint(x,y);
    if(!hit || !(hit===el||el.contains(hit))) C.fail('Nút/khung Order bị hộp thoại khác che. Bạn tự xử lý đăng nhập/xác minh/quyền rồi bấm Nạp lại.', 'OCCLUDED');
  }
  function activate(el,expected) { fresh(expected);unoccluded(el);el.click(); }
  function hasPublicClass(el,name){return !!el&&typeof el.className==='string'&&el.className.split(/\s+/).includes(name);}
  function publicAncestor(el,name){for(let parent=el&&el.parentElement,depth=0;parent&&depth<20;parent=parent.parentElement,depth++)if(hasPublicClass(parent,name))return parent;return null;}
  function orderEntry(el) {
    if(!el || el.tagName!=='DIV' || !hasPublicClass(el,C.ORDER_TITLE_CLASS) || el.getAttribute('role') || !visible(el) || el.closest('form,table,[role="grid"],[role="row"],[role="tablist"],[contenteditable="true"],input,textarea'))return false;
    // This special nonsemantic title cannot inherit authority after becoming
    // a tab, disabled control or a protected action disguised as Order.
    const publicClasses=el.className.trim().split(/\s+/);if(publicClasses.length!==1 || publicClasses[0]!==C.ORDER_TITLE_CLASS || el.querySelectorAll('svg[data-icon]').length)return false;
    for(const [name,max] of [['aria-label',120],['title',120],['data-testid',100],['id',100]]){const publicName=(name==='id'?el.id:el.getAttribute(name))||'';if(publicName.length>max || C.FORBIDDEN.test(publicName))return false;}
    let ancestor=el;
    for(let depth=0;ancestor&&depth<40;depth++,ancestor=ancestor.parentElement){if(ancestor.disabled || ancestor.getAttribute('disabled')!==null || ancestor.getAttribute('aria-disabled')==='true')return false;if(ancestor===document.body || ancestor===document.documentElement)break;}
    if(ancestor!==document.body && ancestor!==document.documentElement)return false;
    // This is the public extension title the human selected, never a generic
    // DIV or a data row. Require its observed title/content/item/list chain.
    const content=el.parentElement,item=content&&content.parentElement;
    if(!hasPublicClass(content,'extension-market-grid-list-flex-container-v4-item-content') || !hasPublicClass(item,'extension-market-grid-list-flex-container-v4-item-v4'))return false;
    const titles=Array.from(item.querySelectorAll(ORDER_TITLES));if(titles.length!==1||titles[0]!==el)return false;
    let scope=item;
    for(const name of ['extension-myextension-v4-ui-list-flex-container','extension-myextension-v4-ui-list-container','extension-myextension-v4-ui-content','extension-myextension-v4-ui-container','extension-market-v4-main','extension-market-v4-spread']){scope=publicAncestor(scope,name);if(!scope)return false;}
    if(!hasPublicClass(scope,'extension-market-v4') || !visible(scope) || scope===document.body || scope===document.documentElement || scope.getBoundingClientRect().width>=innerWidth*.9)return false;
    const publicText=el.innerText||el.textContent||'';
    return publicText.length<=100 && /^(?:Order|UOY Order Custom)$/i.test(publicText.trim().replace(/\s+/g,' '));
  }
  function control(el,allowOrderTitle) {
    if (!el || !el.closest) return null;
    if(allowOrderTitle){const title=el.closest(ORDER_TITLES);if(title)return orderEntry(title)?title:null;}
    const b = el.closest(CONTROLS);
    if (!b || b.disabled || b.getAttribute('aria-disabled') === 'true' || b.getAttribute('role')==='tab' || b.closest('form,table,[role="grid"],[role="row"],[role="tablist"],[contenteditable="true"],input,textarea') || !visible(b)) return null;
    if (b.tagName === 'A' && b.getAttribute('href') !== '#') return null;
    if(b.tagName!=='BUTTON' && !['button','menuitem'].includes(b.getAttribute('role')) && b.tagName!=='A') {
      const tabindex=b.getAttribute('tabindex'); if(tabindex===null || !/^\d{1,3}$/.test(tabindex) || getComputedStyle(b).cursor!=='pointer') return null;
    }
    return b;
  }
  function describe(el,allowOrderTitle) {
    if (control(el,allowOrderTitle) !== el) C.fail('Chỉ chọn nút giao diện, không chọn ô dữ liệu.');
    if(allowOrderTitle && hasPublicClass(el,C.ORDER_TITLE_CLASS))return C.fingerprint({tag:'DIV',text:C.text(el.innerText||el.textContent,100).replace(/\s+/g,' '),classNames:[C.ORDER_TITLE_CLASS],orderEntry:true});
    // Only bounded text of the explicitly selected control, never rows, forms or HTML.
    const names=typeof el.className==='string' ? el.className.split(/\s+/).filter(x=>/^[A-Za-z_][A-Za-z0-9_-]{1,80}$/.test(x)).slice(0,6) : [];
    const svgIcons=Array.from(el.querySelectorAll('svg[data-icon]'));
    if(svgIcons.length>4) C.fail('Nút có quá nhiều icon công khai; không đoán icon để bấm.');
    const icons=[...new Set(svgIcons.map(svg=>svg.getAttribute('data-icon')))];
    if(icons.length>1) C.fail('Nút có nhiều icon khác nhau; không đoán icon để bấm.');
    return C.fingerprint({tag:el.tagName,role:el.getAttribute('role'),label:el.getAttribute('aria-label'),title:el.getAttribute('title'),testId:el.getAttribute('data-testid'),id:el.id,text:C.text(el.innerText || el.textContent,100),classNames:names,...(icons.length?{icon:icons[0]}:{})});
  }
  function matches(el, fp) {
    if (control(el,fp.orderEntry===true)!==el || el.tagName !== fp.tag) return false;
    const actual = describe(el,fp.orderEntry===true);
    if(fp.orderEntry===true && actual.orderEntry!==true)return false;
    return ['role','label','title','testId','id','text','icon'].every(k => !fp[k] || actual[k] === fp[k]) && (!fp.classNames.length || JSON.stringify(actual.classNames)===JSON.stringify(fp.classNames));
  }
  function unique(fp, optional, scope) {
    const valid = C.fingerprint(fp);
    const matching = Array.from(document.querySelectorAll(valid.orderEntry===true?ORDER_TITLES:CONTROLS)).filter(el => {
      try { return matches(el, valid); } catch (_) { return false; }
    });
    const found=scope ? matching.filter(scope) : matching;
    if(scope && matching.length && !found.length) C.fail('Nút khớp không thuộc sidebar UOY Order đã xác minh; không bấm.', 'FOREIGN_SIDEBAR');
    if (!found.length && optional) return null;
    if (found.length !== 1) C.fail('Nút đã dạy không còn duy nhất. Mở popup và dạy lại nút này.', 'CALIBRATION');
    return found[0];
  }
  function extensionSurface(el) {
    // A semantic fallback is confined to the observed Base extension market,
    // never a similarly named action in a table, form or unrelated dialog.
    for(let parent=el&&el.parentElement,depth=0;parent&&depth<30;parent=parent.parentElement,depth++) {
      if(parent===document.body || parent===document.documentElement) return null;
      if(hasPublicClass(parent,'extension-market-v4')) {
        const rect=parent.getBoundingClientRect();
        return visible(parent) && rect.width>0 && rect.width<innerWidth*.9 ? parent : null;
      }
    }
    return null;
  }
  function semanticName(el,step) {
    const expected=step==='toolbar' ? /^(?:extensions?|base extensions?|phan mo rong(?: base)?|tien ich mo rong|扩展|擴充功能)$/ :
      step==='customize' ? /^(?:customize|customise|tuy chinh|自定义|自訂)$/ : /^(?:order|uoy order custom)$/;
    const names=[el.getAttribute('aria-label'),el.getAttribute('title'),el.innerText||el.textContent||''].filter(value=>typeof value==='string'&&value.trim());
    return names.length>0 && names.every(value=>value.length<=120 && expected.test(value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim()));
  }
  function semanticUnique(step,optional) {
    const all=Array.from(document.querySelectorAll(step==='order'?CONTROLS+','+ORDER_TITLES:CONTROLS));
    const found=all.filter(el=>{
      try {
        if(control(el,step==='order')!==el || !semanticName(el,step)) return false;
        let ancestor=el,depth=0;
        for(;ancestor&&depth<40;ancestor=ancestor.parentElement,depth++) {
          if(ancestor.disabled || ancestor.getAttribute('disabled')!==null || ancestor.getAttribute('aria-disabled')==='true') return false;
          if(ancestor===document.body || ancestor===document.documentElement) break;
        }
        if(ancestor!==document.body && ancestor!==document.documentElement) return false;
        describe(el,step==='order'); // Reject forbidden names/ambiguous icons.
        if(step==='toolbar') return !!el.closest('[role="toolbar"],[role="banner"],header') && !extensionSurface(el);
        return !!extensionSurface(el);
      } catch(_) { return false; }
    });
    if(found.length>1) C.fail('Có nhiều nút '+step+' phù hợp trong giao diện Base. Không tự chọn hay bấm.', 'UI_AMBIGUOUS');
    if(!found.length && !optional) C.fail('Chưa xác định được nút '+step+' trong đúng giao diện Base. Chưa bấm nút.', 'CALIBRATION');
    return found[0]||null;
  }
  function hasStrongToolbarHint(fp){return !!fp&&['label','title','testId','id','icon'].some(key=>typeof fp[key]==='string'&&fp[key].length>0);}
  function toolbarHintCandidates(fp,stateOnly) {
    if(!fp||!stateOnly&&!hasStrongToolbarHint(fp))return [];
    const valid=C.fingerprint(fp);if(valid.orderEntry)return [];
    const transient=new Set(['active','hover','focus','focused','selected','open','is-active','is-hover','is-focused','is-selected','is-open']);
    const baseClasses=valid.classNames.filter(name=>!transient.has(name));
    if(stateOnly&&!baseClasses.length)return [];
    return Array.from(document.querySelectorAll(CONTROLS)).filter(el=>{
      try{
        if(control(el)!==el||el.tagName!==valid.tag||!el.closest('[role="toolbar"],[role="banner"],header')||extensionSurface(el))return false;
        let ancestor=el,depth=0;for(;ancestor&&depth<40;ancestor=ancestor.parentElement,depth++){if(ancestor.disabled||ancestor.getAttribute('disabled')!==null||ancestor.getAttribute('aria-disabled')==='true')return false;if(ancestor===document.body||ancestor===document.documentElement)break;}
        if(ancestor!==document.body&&ancestor!==document.documentElement)return false;
        const actual=describe(el);
        if(!['role','label','title','testId','id','text','icon'].every(key=>!valid[key]||actual[key]===valid[key]))return false;
        // State-normalized counts are diagnostic only. They never authorize a
        // class-only fingerprint. Strong recovery requires the human-taught
        // exact public identity, independently unique in the existing header.
        return !stateOnly||JSON.stringify(actual.classNames.filter(name=>!transient.has(name)))===JSON.stringify(baseClasses);
      }catch(_){return false;}
    });
  }
  function strongToolbarHint(fp){const found=toolbarHintCandidates(fp,false);return found.length===1?found[0]:null;}
  function observedToolbarCandidates() {
    // Grounded in the actual R60-D1 positive public-anchor diagnostic, not a
    // generic unnamed puzzle/SVG or an assumed semantic header ancestor.
    const stable=['ud__button','ud__button--circle','ud__button--icon','ud__button--icon-default','ud__button--icon-size-md'].sort();
    return Array.from(document.querySelectorAll('button')).filter(el=>{
      try{
        if(el.tagName!=='BUTTON'||control(el)!==el||el.getAttribute('role')||extensionSurface(el)||el.querySelectorAll('form,table,[role="grid"],[role="row"],input,textarea,[contenteditable="true"]').length)return false;
        const classes=typeof el.className==='string'?el.className.trim().split(/\s+/):[];
        if(classes.filter(name=>name==='ud__tooltip-open').length>1||JSON.stringify(classes.filter(name=>name!=='ud__tooltip-open').sort())!==JSON.stringify(stable))return false;
        const icons=Array.from(el.querySelectorAll('svg[data-icon]'));
        if(icons.length!==1||icons[0].getAttribute('data-icon')!=='BasePlugInOutlined'||el.querySelectorAll('svg').length!==1)return false;
        let reachedRoot=false;for(let p=el,depth=0;p&&depth<40;p=p.parentElement,depth++){if(p.disabled||p.getAttribute('disabled')!==null||p.getAttribute('aria-disabled')==='true')return false;if(p===document.body||p===document.documentElement){reachedRoot=true;break;}}if(!reachedRoot)return false;
        const actual=describe(el),r=el.getBoundingClientRect();
        // No extra action/accessibility names were present in the real
        // observed control. Such a changed shape requires new evidence.
        return !actual.label&&!actual.title&&!actual.testId&&!actual.id&&!actual.text&&!actual.role&&r.width<innerWidth*.9&&r.height<innerHeight*.75;
      }catch(_){return false;}
    });
  }
  function observedToolbarUnique(optional){const found=observedToolbarCandidates();if(found.length>1)C.fail('Có nhiều nút BasePlugInOutlined đúng cấu trúc; chưa tự chọn.','UI_AMBIGUOUS');if(!found.length&&!optional)C.fail('Chưa có nút mở phần mở rộng đúng cấu trúc đã xác minh.','CALIBRATION');return found[0]||null;}
  function routeEvidence(step,fp,phase) {
    let hintMatches=0,semanticMatches=0;
    if(fp)try{const valid=C.fingerprint(fp);for(const el of document.querySelectorAll(valid.orderEntry===true?ORDER_TITLES:CONTROLS)){try{if(matches(el,valid))hintMatches++;}catch(_){}if(hintMatches>=2)break;}}catch(_){}
    try{semanticMatches=semanticUnique(step,true)?1:0;}catch(error){if(error&&error.code==='UI_AMBIGUOUS')semanticMatches=2;}
    let strongMatches=0,stateNormalizedMatches=0;if(step==='toolbar')try{strongMatches=Math.min(2,toolbarHintCandidates(fp,false).length);stateNormalizedMatches=Math.min(2,toolbarHintCandidates(fp,true).length);}catch(_){}
    return C.routeDiagnostic({version:1,contentRevision:C.CONTENT_REVISION,step,phase,hintMatches:Math.min(2,hintMatches),semanticMatches,strongMatches,stateNormalizedMatches,hasHint:!!fp,hasStrongHint:hasStrongToolbarHint(fp),documentVisible:document.visibilityState!=='hidden'});
  }
  function attachRouteEvidence(error,step,fp,phase){if(error&&['CALIBRATION','UI_AMBIGUOUS'].includes(error.code)){try{error.uoyRouteDiagnostic=routeEvidence(step,fp,phase);}catch(_){}}return error;}
  function routeTarget(step,fp,optional) {
    try {
    if(step==='toolbar'){
      const observed=observedToolbarUnique(true);
      if(observed)return {el:observed,fp:describe(observed),step,semantic:false,observed:true};
    }
    // A remembered fingerprint is only an exact-match hint. Lark can reuse
    // its generic header classes/icons for another public control after a UI
    // update, making that old hint ambiguous while the correctly named,
    // bounded semantic opener is still unique. Do not let the stale hint
    // prevent that independently verified route, or ever choose its first
    // match. Every non-ambiguity validation error remains a hard failure.
    let taught=null,ambiguousHint=null;
    if(fp && !(step==='toolbar'&&fp.icon==='BasePlugInOutlined')) {
      try {taught=unique(fp,true);}
      catch(error) {if(!error || error.code!=='CALIBRATION')throw error;ambiguousHint=error;}
    }
    if(taught) return {el:taught,fp,step,semantic:false};
    if(step==='toolbar'&&hasStrongToolbarHint(fp)&&fp.icon!=='BasePlugInOutlined'){
      const recovered=strongToolbarHint(fp);
      if(recovered)return {el:recovered,fp:describe(recovered),savedFp:fp,step,semantic:false,strong:true};
    }
    const semantic=semanticUnique(step,optional);
    if(!semantic && ambiguousHint)throw ambiguousHint;
    return semantic ? {el:semantic,fp:describe(semantic,step==='order'),step,semantic:true} : null;
    }catch(error){throw attachRouteEvidence(error,step,fp,'resolve');}
  }
  function safeCommandError(error) {
    const aliases={PAGE_CHANGED:'VIEW_CHANGED',EXPIRED:'VIEW_CHANGED',COMMAND_PURPOSE:'VIEW_CHANGED'};
    const messages={VIEW_CHANGED:'Base, bảng, view hoặc phiên trang đã đổi; chưa bấm tiếp.',CALIBRATION:'Chưa xác định duy nhất đường mở Order trong giao diện Base; chưa bấm tiếp.',CONTENT_UNAVAILABLE:'Giao diện Base chưa phản hồi đúng hạn; không tự bấm lại.',UI_AMBIGUOUS:'Giao diện có nhiều mục phù hợp; không tự chọn.',AMBIGUOUS:'Có nhiều reader Order phù hợp; không tự chọn.',FOREIGN_SIDEBAR:'Một khung khác đang mở hoặc nút không thuộc reader Order; không tự đóng khung khác.',OCCLUDED:'Nút hoặc reader Order đang bị ẩn hay che; chưa bấm tiếp.',DOM_TIMEOUT:'Giao diện Base chưa hoàn tất thao tác đúng hạn; không tự bấm lại.',READER_REMOVED:'Base đã dừng reader khi thu gọn; không tự đóng khung khác.',READER_OWNERSHIP:'Chưa xác minh được reader Order thuộc đúng phiên; không thu gọn khung khác.',READER_BINDING:'Reader chưa xác nhận đúng phiên trang và nguồn SDK; chưa nhận dữ liệu.',STANDBY_HIDDEN:'Tab Base đang ẩn; chưa tự khởi động reader dự phòng.',CANCELLED:'Thao tác Companion đã dừng; chưa bấm tiếp.'};
    const supplied=error&&typeof error.code==='string'?error.code:'', mapped=Object.prototype.hasOwnProperty.call(aliases,supplied)?aliases[supplied]:supplied;
    const code=Object.prototype.hasOwnProperty.call(messages,mapped)?mapped:'CONTENT_UNAVAILABLE';
    const diagnostic=['CALIBRATION','UI_AMBIGUOUS'].includes(code)?C.routeDiagnostic(error&&error.uoyRouteDiagnostic):null;
    return {code,message:messages[code],...(error&&error.uoyNoAction===true?{noAction:true}:{}),...(diagnostic?{routeDiagnostic:diagnostic}:{})};
  }
  function frames(ep) {
    return Array.from(document.querySelectorAll('iframe')).filter(el => visible(el) && C.ownedFrame(el.getAttribute('src') || '', ep));
  }
  function ownedFrames(ep) {
    return Array.from(document.querySelectorAll('iframe')).filter(el => el.isConnected && C.ownedFrame(el.getAttribute('src') || '', ep));
  }
  function foreignFrames(ep) {
    return Array.from(document.querySelectorAll('iframe')).filter(el => visible(el) && !C.ownedFrame(el.getAttribute('src') || '', ep));
  }
  function closeScope(button, iframe, ep, retained) {
    // Both header controls must share a bounded sidebar ancestor with OUR
    // iframe. The list X additionally requires the original iframe retained
    // but hidden, never a deleted reader or an unrelated extension panel.
    // A whole-page ancestor (body/html or >90% of viewport width) is not a sidebar.
    if(retained && visible(iframe)) return false;
    for (let p = button.parentElement, depth = 0; p && depth < 10; p = p.parentElement, depth++) {
      if (p === document.body || p === document.documentElement) return false;
      if (!p.contains(iframe)) continue;
      const r = p.getBoundingClientRect();
      if (r.width >= innerWidth * 0.9 || !visible(p)) return false;
      const contained = Array.from(p.querySelectorAll('iframe')).filter(el => retained ? el.isConnected : visible(el));
      return contained.length === 1 && contained[0] === iframe && C.ownedFrame(iframe.getAttribute('src') || '', ep);
    }
    return false;
  }
  function mountedReaderHold() {
    if(mountedReaderHold.manager)return mountedReaderHold.manager;
    let held=null;
    const marker='data-uoy-mounted-reader';
    const ownerMarker='data-uoy-reader-hold-owner';
    const controlMarker='data-uoy-reader-control';
    const styleMarker='data-uoy-reader-style';
    const widthMarker='data-uoy-reader-table-width';
    const switcherMarker='data-uoy-reader-switcher-width';
    const controlLabel='UOY: mở hoặc thu gọn reader Order, giữ chạy nền';
    function exclusiveWrapper(parent,branch,reader,endpoint) {
      if(!parent||parent===document.body||parent===document.documentElement||!['DIV','ASIDE','SECTION'].includes(parent.tagName)||branch.parentElement!==parent)return false;
      // A slot can belong to Order only while its entire non-Order content is
      // empty presentation decoration. In particular a Comments heading,
      // control, foreign iframe, named region or data surface ends the chain.
      const name=[parent.getAttribute('aria-label'),parent.getAttribute('title')].filter(Boolean).join(' ').trim();
      if(name&&!/^(?:extensions?|base extensions?|order|uoy order custom)$/i.test(name))return false;
      const role=parent.getAttribute('role');if(role&&!['none','presentation','complementary'].includes(role))return false;
      const frames=Array.from(parent.querySelectorAll('iframe'));
      if(frames.length!==1||frames[0]!==reader||!C.ownedFrame(reader.getAttribute('src')||'',endpoint))return false;
      const unsafe='iframe,form,table,[role="grid"],[role="row"],[role="tablist"],[role="tree"],[role="dialog"],[role="region"],[role="complementary"],button,input,textarea,select,a[href],[contenteditable="true"],[aria-label],[title],[tabindex]';
      if(parent.childNodes.length>32)return false;
      for(const node of parent.childNodes) {
        if(node===branch||node.nodeType===8)continue;
        if(node.nodeType===3){if((node.nodeValue||'').trim())return false;continue;}
        if(node.nodeType!==1||node.matches(unsafe)||node.querySelector(unsafe)||(node.textContent||'').trim())return false;
      }
      return true;
    }
    function layoutChain(container,reader,endpoint) {
      const chain=[container];let branch=container;
      for(let depth=0;depth<8;depth++) {
        const parent=branch.parentElement;
        if(!exclusiveWrapper(parent,branch,reader,endpoint))break;
        const r=parent.getBoundingClientRect();
        if(!visible(parent)||r.width<=0||r.width>=innerWidth*.9)break;
        chain.push(parent);branch=parent;
      }
      return chain;
    }
    function ownStyleText(token){return '['+marker+'="'+token+'"]{display:none!important}['+widthMarker+'="'+token+'"]{width:auto!important;right:0!important}['+switcherMarker+'="'+token+'"]{right:0!important}';}
    function priorStyleText(token){return '['+marker+'="'+token+'"]{display:none!important}['+widthMarker+'="'+token+'"]{width:100%!important;right:0!important}['+switcherMarker+'="'+token+'"]{right:0!important}';}
    function legacyStyleText(token){return '['+marker+'="'+token+'"]{display:none!important}';}
    function reservationFor(container) {
      // Grounded in the verified Base layout: hiding the market does not
      // update its table sibling's explicit calc(100% - 400px)/right:400px.
      // Relinquish only that exact Order reservation, never a Comments pane
      // inside the table or an arbitrary parent/sibling's authored layout.
      const parent=container.parentElement;
      if(!hasPublicClass(parent,'bitable-main-container')||!/^0(?:px)?$/.test(parent.style.right))return null;
      const widthMatch=container.style.width.match(/^([0-9]+(?:\.[0-9]+)?)px$/),width=widthMatch?Number(widthMatch[1]):0;
      if(width<=0||width>=innerWidth*.9)return null;
      const children=Array.from(parent.children),markets=children.filter(node=>hasPublicClass(node,'extension-market-v4'));
      const tables=children.filter(node=>node.tagName==='DIV'&&node.id==='bitable-main-content-container'&&hasPublicClass(node,'bitable-table-container'));
      const switchers=children.filter(node=>node.tagName==='DIV'&&hasPublicClass(node,'bitable-block-switcher')&&hasPublicClass(node,'bitable-block-switcher-new-ui'));
      if(markets.length!==1||markets[0]!==container||tables.length!==1||switchers.length>1)return null;
      const table=tables[0],switcher=switchers[0]||null;
      // Base's native view navigation is a separate direct sibling, not part
      // of the right-hand Order reservation. Its observed public roots may
      // contain ordinary navigation controls/text. Leave those roots and
      // every descendant completely untouched; do not mistake them for an
      // unknown competing pane or infer ownership of their contents.
      function nativeNavigation(node) {
        if(node.tagName!=='DIV'||typeof node.className!=='string')return '';
        const classes=node.className.trim().split(/\s+/);
        const opener=['bitable-sidebar-opener','bitable-new-sidebar-opener','bitable-sidebar-opener-new-ui-bitable_table'];
        const sidebar=['bitable-sidebar-container','bitable-sidebar-container_new_ui'];
        if(opener.every(name=>classes.includes(name))&&classes.every(name=>opener.includes(name)||name==='visible'||name==='invisible')&&!(classes.includes('visible')&&classes.includes('invisible')))return 'opener';
        if(sidebar.every(name=>classes.includes(name))&&classes.every(name=>sidebar.includes(name)))return 'sidebar';
        return '';
      }
      const navigation=children.filter(node=>nativeNavigation(node));
      if(navigation.filter(node=>nativeNavigation(node)==='opener').length>1||navigation.filter(node=>nativeNavigation(node)==='sidebar').length>1)return null;
      // Two observed native layouts: navigation closed at left:0; or the
      // 240px native navigation retained at left:240. Reclaim only Order's
      // right-hand width, never the left navigation's authored reservation.
      const left=/^0(?:px)?$/.test(table.style.left)?0:table.style.left==='240px'?240:-1;
      if(left<0||table.style.position!=='absolute')return null;
      const opener=navigation.find(node=>nativeNavigation(node)==='opener');
      const sidebar=navigation.find(node=>nativeNavigation(node)==='sidebar');
      if(left===240&&(!opener||!sidebar||!hasPublicClass(opener,'invisible')||opener.style.left!=='240px'||sidebar.style.width!=='240px'))return null;
      if(left===0&&opener&&hasPublicClass(opener,'invisible'))return null;
      const calc=table.style.width.replace(/\s+/g,'').match(/^calc\(100%-([0-9]+(?:\.[0-9]+)?)px\)$/);
      if(!calc||Number(calc[1])!==width+left||table.style.right!==widthMatch[0])return null;
      if(switcher&&(switcher.style.right!==widthMatch[0]||switcher.style.visibility!=='hidden'||(left===0?!/^0(?:px)?$/.test(switcher.style.left):switcher.style.left!=='240px')))return null;
      for(const node of parent.childNodes) {
        if(node===container||node===table||node===switcher||navigation.includes(node)||node.nodeType===8)continue;
        if(node.nodeType===3){if((node.nodeValue||'').trim())return null;continue;}
        if(node.nodeType!==1||node.querySelector('iframe,button,input,textarea,select,form,table,[role="grid"],[role="dialog"]')||(node.textContent||'').trim())return null;
      }
      return {parent,table,switcher,width,left};
    }
    function sameReservation(a,b){return !a&&!b||!!a&&!!b&&a.parent===b.parent&&a.table===b.table&&a.switcher===b.switcher&&a.width===b.width;}
    function rootControls() {return Array.from(document.documentElement.children).filter(node=>node.tagName==='BUTTON'&&node.getAttribute('aria-label')===controlLabel);}
    function legacyControl(node) {
      return node.getAttribute('type')==='button'&&['true','false'].includes(node.getAttribute('aria-expanded'))&&
        ['Order chạy nền · Mở','Order · Thu gọn, giữ chạy nền'].includes(node.textContent)&&
        node.style.position==='fixed'&&node.style.right==='18px'&&node.style.bottom==='18px'&&node.style.zIndex==='2147483646'&&node.style.fontSize==='13px';
    }
    function clearStalePresentation(container,reader,endpoint) {
      // Reload replaces the isolated JS world, but leaves its DOM controls.
      // Migrate only the exact known root-level Companion footprint. Never
      // remove a similarly named Base control or close a host-owned sidebar.
      const controls=rootControls().filter(node=>node.getAttribute(controlMarker)===C.EXTENSION_ID||legacyControl(node));
      const styles=Array.from(document.documentElement.children).filter(node=>node.tagName==='STYLE');
      let branch=container;
      for(let depth=0;branch&&depth<9;depth++) {
        const token=branch.getAttribute(marker);
        if(token&&/^[a-f0-9]{32}$/.test(token)) {
          const matching=styles.filter(node=>node.textContent===ownStyleText(token)||node.textContent===priorStyleText(token)||node.textContent===legacyStyleText(token));
          if(matching.length&&controls.length){
            branch.removeAttribute(marker);
            const reservation=reservationFor(container);
            if(reservation){if(reservation.table.getAttribute(widthMarker)===token)reservation.table.removeAttribute(widthMarker);if(reservation.switcher&&reservation.switcher.getAttribute(switcherMarker)===token)reservation.switcher.removeAttribute(switcherMarker);}
            for(const node of matching)node.remove();
          }
        }
        const parent=branch.parentElement;
        if(!exclusiveWrapper(parent,branch,reader,endpoint))break;
        branch=parent;
      }
      for(const node of controls)node.remove();
    }
    function containerFor(reader,endpoint) {
      for(let p=reader&&reader.parentElement,depth=0;p&&depth<30;p=p.parentElement,depth++) {
        if(p===document.body||p===document.documentElement)return null;
        if(!hasPublicClass(p,'extension-market-v4'))continue;
        const frames=Array.from(p.querySelectorAll('iframe'));
        if(frames.length!==1||frames[0]!==reader||!C.ownedFrame(reader.getAttribute('src')||'',endpoint)||reader.getAttribute('srcdoc')!==null)return null;
        // This is only presentation chrome, never a table, form or unrelated
        // extension. If its public structure changes we leave it visible.
        if(p.querySelectorAll('form,table,[role="grid"],[role="row"],input,textarea,[contenteditable="true"]').length)return null;
        return p;
      }
      return null;
    }
    function valid(h) {
      if(document.documentElement.getAttribute(ownerMarker)!==h.token)return false;
      const current=fresh();
      if(current.pageId!==h.context.pageId||current.baseIdentity!==h.context.baseIdentity)return false;
      // A selected view can change while the original host iframe remains
      // mounted. Preserve presentation, but no old-source interception is
      // authorised until the normal SDK binding acknowledges the new source.
      h.sourceCurrent=C.sameContext(h.context,current);
      const owned=ownedFrames(h.endpoint);
      if(!h.reader.isConnected||h.reader.contentWindow!==h.window||!h.container.isConnected||containerFor(h.reader,h.endpoint)!==h.container||owned.length!==1||owned[0]!==h.reader||h.layout.parentElement!==h.layoutParent)return false;
      for(let i=1;i<h.chain.length;i++)if(!exclusiveWrapper(h.chain[i],h.chain[i-1],h.reader,h.endpoint))return false;
      if(!sameReservation(h.reservation,reservationFor(h.container)))return false;
      return true;
    }
    function release() {
      const h=held;if(!h)return;held=null;
      h.observer.disconnect();
      for(const name of h.events)removeEventListener(name,h.capture,true);
      removeEventListener('popstate',h.inspect);removeEventListener('hashchange',h.inspect);
      // Restore only our own exact marker. Never overwrite a host's style,
      // classes, hidden state, geometry or another extension's attribute.
      if(h.layout.getAttribute(marker)===h.token)h.layout.removeAttribute(marker);
      if(h.reservation){if(h.reservation.table.getAttribute(widthMarker)===h.token)h.reservation.table.removeAttribute(widthMarker);if(h.reservation.switcher&&h.reservation.switcher.getAttribute(switcherMarker)===h.token)h.reservation.switcher.removeAttribute(switcherMarker);}
      if(document.documentElement.getAttribute(ownerMarker)===h.token)document.documentElement.removeAttribute(ownerMarker);
      h.style.remove();h.chip.remove();
    }
    function inspect() {if(!held)return;try{if(!valid(held))release();}catch(_){release();}}
    function collapse() {
      if(!held)return false;
      try {
        const h=held;if(!valid(h)){release();return false;}
        if(!h.collapsed) {
          const r=h.layout.getBoundingClientRect();
          if(!visible(h.container)||!visible(h.layout)||r.width>=innerWidth*.9||r.width<=0)return false;
          h.collapsed=true;h.layout.setAttribute(marker,h.token);
          if(h.reservation){h.reservation.table.setAttribute(widthMarker,h.token);if(h.reservation.switcher)h.reservation.switcher.setAttribute(switcherMarker,h.token);}
        }
        if(h.layout.getAttribute(marker)!==h.token||getComputedStyle(h.layout).display!=='none'||!valid(h)||!h.style.isConnected||!h.chip.isConnected||!visible(h.chip)){release();return false;}
        h.chip.textContent='Order';h.chip.title='Mở Order — reader đang chạy nền';h.chip.setAttribute('aria-expanded','false');return true;
      }catch(_){release();return false;}
    }
    function restore() {
      if(!held)return false;
      try{const h=held;if(!valid(h)){release();return false;}if(h.layout.getAttribute(marker)===h.token)h.layout.removeAttribute(marker);if(h.reservation){if(h.reservation.table.getAttribute(widthMarker)===h.token)h.reservation.table.removeAttribute(widthMarker);if(h.reservation.switcher&&h.reservation.switcher.getAttribute(switcherMarker)===h.token)h.reservation.switcher.removeAttribute(switcherMarker);}h.collapsed=false;h.chip.textContent='Order';h.chip.title='Thu gọn Order, giữ reader chạy nền';h.chip.setAttribute('aria-expanded','true');return true;}catch(_){release();return false;}
    }
    function arm(reader,endpoint,context,calibration,backgroundDefault) {
      if(typeof document.createElement!=='function'||typeof MutationObserver!=='function')return false;
      if(held) {
        try{if(held.reader===reader&&held.endpoint===endpoint&&held.context.pageId===context.pageId&&held.context.baseIdentity===context.baseIdentity&&valid(held)){held.context=context;held.sourceCurrent=true;held.calibration=calibration;return true;}}catch(_){}
        release();
      }
      const container=containerFor(reader,endpoint);
      if(!container)return false;
      clearStalePresentation(container,reader,endpoint);
      const r=container.getBoundingClientRect();
      if(!container||!visible(container)||!r||r.width<=0||r.width>=innerWidth*.9||container.getAttribute(marker)!==null)return false;
      const chain=layoutChain(container,reader,endpoint),layout=chain[chain.length-1];
      if(layout.getAttribute(marker)!==null)return false;
      const reservation=reservationFor(container);
      if(hasPublicClass(container.parentElement,'bitable-main-container')&&!reservation)return false;
      const token=PAGE_ID;
      const style=document.createElement('style');style.textContent=ownStyleText(token);style.setAttribute(styleMarker,C.EXTENSION_ID);
      const chip=document.createElement('button');chip.type='button';chip.textContent='Order';chip.title='Thu gọn Order, giữ reader chạy nền';chip.setAttribute(controlMarker,C.EXTENSION_ID);chip.setAttribute('aria-label',controlLabel);chip.setAttribute('aria-expanded','true');chip.style.cssText='position:fixed;right:18px;bottom:18px;z-index:2147483646;background:#28594a;color:white;border:1px solid #8ab7a8;border-radius:6px;padding:6px 9px;font:13px sans-serif;cursor:pointer';
      const h={reader,window:reader.contentWindow,endpoint,context,calibration,container,chain,layout,layoutParent:layout.parentElement,reservation,token,style,chip,collapsed:false,sourceCurrent:true,suppressed:null,events:['pointerdown','pointerup','mousedown','mouseup','click','keydown','keyup']};
      function ownedDismissal(target) {
        const button=control(target);if(!button)return null;
        // Revalidate the exact previously taught identity and bounded scope.
        // No generic X/SVG, coordinates, whole-page Escape or first match.
        for(const step of ['back','listClose']) {
          const fp=h.calibration[step];if(!fp)continue;
          try{if(unique(fp,true,candidate=>closeScope(candidate,h.reader,h.endpoint))===button)return button;}catch(_){}
        }
        try{const route=routeTarget('toolbar',h.calibration.toolbar,true);if(route&&route.el===button)return button;}catch(_){}
        if(!h.container.contains(button))return null;
        const named=Array.from(h.container.querySelectorAll(CONTROLS)).filter(candidate=>{
          try{if(control(candidate)!==candidate||!closeScope(candidate,h.reader,h.endpoint))return false;describe(candidate);const names=[candidate.getAttribute('aria-label'),candidate.getAttribute('title'),candidate.innerText||candidate.textContent||''].filter(value=>typeof value==='string'&&value.trim());return names.length>0&&names.every(value=>/^(?:close(?: extensions?)?|dong(?: phan mo rong)?|关闭)$/i.test(value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim()));}catch(_){return false;}
        });
        return named.length===1&&named[0]===button?button:null;
      }
      h.capture=event=>{
        if(held!==h||event.isTrusted!==true||chip.contains(event.target)||learning)return;
        if(['pointerdown','pointerup','mousedown','mouseup','click'].includes(event.type)&&typeof event.button==='number'&&event.button!==0)return;
        try{
          if(!valid(h)){release();return;}
          if(!h.sourceCurrent)return;
          const remembered=h.suppressed&&Date.now()<h.suppressed.until&&(h.suppressed.button===event.target||h.suppressed.button.contains(event.target));
          if(remembered&&['pointerup','mousedown','mouseup','click','keyup'].includes(event.type)){event.preventDefault();event.stopImmediatePropagation();return;}
          if(!['pointerdown','mousedown','click','keydown'].includes(event.type)||event.type==='keydown'&&!['Enter',' '].includes(event.key))return;
          if(event.type==='keydown'&&event.repeat===true)return;
          const button=ownedDismissal(event.target);if(!button)return;
          const changed=h.collapsed?restore():collapse();if(!changed)return;
          h.suppressed={button,until:Date.now()+2000};event.preventDefault();event.stopImmediatePropagation();
        }catch(_){release();}
      };
      h.inspect=inspect;h.observer=new MutationObserver(inspect);
      held=h;document.documentElement.setAttribute(ownerMarker,token);document.documentElement.append(style,chip);
      chip.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();if(held===h)(h.collapsed?restore:collapse)();});
      // A prior extension world can leave document-level legacy listeners.
      // Window capture gives the current verified owner priority, without
      // reparenting/reloading the authenticated SDK iframe.
      for(const name of h.events)addEventListener(name,h.capture,true);
      addEventListener('popstate',inspect);addEventListener('hashchange',inspect);
      h.observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['src','srcdoc','class','style','aria-label','title','role',marker,ownerMarker,widthMarker,switcherMarker]});
      // Only a newly source-bound hold starts in background. Rebinding the
      // same live hold above preserves an explicit user restore via Order.
      return backgroundDefault===true?collapse():true;
    }
    mountedReaderHold.manager={arm,collapse,restore,release,inspect};return mountedReaderHold.manager;
  }
  function teardown() {
    if (!learning) return;
    clearTimeout(learning.timer); document.removeEventListener('click', learning.handler, true); learning.overlay.remove(); learning = null;
  }
  function teach(message) {
    if (!C.TEACH_STEPS.includes(message.step)) C.fail('Bước dạy nút không hợp lệ.');
    const expected = fresh(message.context); C.endpoint(message.endpoint); teardown();
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483647;background:#213536;color:white;padding:14px;border:1px solid #81b7a0;border-radius:8px;max-width:440px;font:14px sans-serif;box-shadow:0 3px 15px #0005';
    const label = document.createElement('div');
    label.textContent = message.step === 'toolbar' ? 'UOY: bấm nút Phần mở rộng của Base để ghi nhớ nút.' : message.step === 'customize' ? 'UOY: bấm nút Tùy chỉnh/Customize trong danh sách phần mở rộng để ghi nhớ đường mở Order. Không bấm tạo, thêm hoặc sửa extension.' : message.step === 'order' ? 'UOY: bấm mục Order/UOY Order Custom trong danh sách phần mở rộng.' : message.step === 'back' ? 'UOY: bấm nút quay về danh sách ở bên trái tiêu đề Order. KHÔNG bấm X của Order.' : 'UOY: bấm X của danh sách Phần mở rộng sau khi quay lại. KHÔNG bấm X của Order.';
    const cancel = document.createElement('button'); cancel.textContent = 'Hủy dạy nút'; cancel.style.cssText='margin-top:10px;padding:6px';
    cancel.addEventListener('click', e => { e.stopPropagation(); teardown(); }); overlay.append(label,cancel); document.documentElement.append(overlay);
    const handler = async e => {
      if (!e.isTrusted || overlay.contains(e.target) || !learning || learning.processing) return;
      const attempt=learning,version=cancelVersion;
      try {
        fresh(expected); const button = control(e.target,message.step==='order'); if (!button) C.fail('Chọn một nút, không chọn dữ liệu.');
        const fp = describe(button,message.step==='order');
        if (message.step === 'order' && !/(?:^|\W)(?:order|uoy)(?:\W|$)/i.test([fp.label,fp.title,fp.text].join(' '))) C.fail('Mục Order cần có tên Order hoặc UOY.');
        if (message.step === 'customize') C.customizeFingerprint(fp);
        let reader=null;
        if (message.step === 'back') { const owned = frames(message.endpoint); if (owned.length !== 1 || !closeScope(button,owned[0],message.endpoint)) C.fail('Nút quay lại không thuộc duy nhất khung UOY Order local.');reader=owned[0];unique(fp,false,candidate=>closeScope(candidate,reader,message.endpoint)); }
        else if (message.step === 'listClose') { const owned = ownedFrames(message.endpoint); if (owned.length !== 1 || visible(owned[0]) || !closeScope(button,owned[0],message.endpoint,true)) C.fail('Cần quay về danh sách và giữ reader Order trước khi dạy X của danh sách.');reader=owned[0];unique(fp,false,candidate=>closeScope(candidate,reader,message.endpoint,true)); }
        else unique(fp);
        if(reader) {
          // Let this trusted human click perform its normal action first. Do
          // not persist an accidentally selected destructive Order X as Back.
          attempt.processing=true;
          await waitFor(()=>{
            if(learning!==attempt) C.fail('Đã hủy dạy nút.','CANCELLED');
            if(!reader.isConnected || !C.ownedFrame(reader.getAttribute('src')||'',message.endpoint)) C.fail('Nút vừa bấm đã dừng reader Order; không ghi nhớ. Mở lại Order và chọn đúng nút quay về danh sách.','READER_REMOVED');
            return !visible(reader) && (message.step==='back' || !visible(button));
          },expected,Date.now()+4000,version);
        }
        if(learning!==attempt || version!==cancelVersion) C.fail('Đã hủy dạy nút.','CANCELLED');
        // The trusted click still performs the user's normal open/close action.
        chrome.runtime.sendMessage({type:'learned',step:message.step,fingerprint:fp,context:expected}).catch(() => {}); teardown();
      } catch (err) { label.textContent = C.text(err.message,300) + ' Bấm lại đúng nút hoặc Hủy.'; }
      finally { if(learning===attempt) attempt.processing=false; }
    };
    learning = {overlay,handler,timer:setTimeout(teardown,60000)}; document.addEventListener('click',handler,true);
    return {ok:true,learning:message.step};
  }
  async function waitFor(test, expected, deadline, version) {
    while (Date.now() < deadline) { if(version!==cancelVersion) C.fail('Đã dừng Companion.', 'CANCELLED'); fresh(expected); const found = test(); if (found) return found; await new Promise(resolve => setTimeout(resolve,150)); }
    C.fail('Giao diện Base không phản hồi kịp. Mở Order bằng tay, dạy lại nút hoặc bấm Nạp lại.', 'DOM_TIMEOUT');
  }
  function commandVisible(command) {
    // R32: an authenticated explicit read/watch may operate its exact paired
    // document while another tab is active. Visibility never changes identity.
    // Unsolicited standby still needs a visible document, as the broker does.
    if(command && command.purpose==='standby' && document.visibilityState==='hidden') C.fail('Tab Base đang ẩn; chưa tự khởi động reader dự phòng.', 'STANDBY_HIDDEN');
  }
  function cancelCommands() {
    cancelVersion++;
    mountedReaderHold().release();
    for(const wake of Array.from(commandWaiters)) wake();
  }
  function waitForCommand(test, expected, deadline, version, command) {
    // Background tabs can clamp chained timer polling to a minute. DOM
    // observation reacts to the actual menu/frame change without requiring
    // browser focus or throttling flags. A single watchdog only rejects.
    return new Promise((resolve,reject)=>{
      let settled=false,observer=null,timer=null;
      const events=['visibilitychange','load','transitionend','animationend'];
      function cleanup() {
        if(observer) observer.disconnect();
        if(timer!==null) clearTimeout(timer);
        commandWaiters.delete(inspect);
        for(const name of events) document.removeEventListener(name,inspect,true);
        removeEventListener('popstate',inspect);removeEventListener('hashchange',inspect);
      }
      function finish(error,value) { if(settled)return;settled=true;cleanup();if(error)reject(error);else resolve(value); }
      function check() {
        if(version!==cancelVersion) C.fail('Đã dừng Companion.', 'CANCELLED');
        fresh(expected);commandVisible(command);
        if(!Number.isSafeInteger(deadline)||Date.now()>=deadline) C.fail('Giao diện Base chưa phản hồi đúng hạn; không tự bấm lại.', 'DOM_TIMEOUT');
      }
      function inspect() {
        if(settled)return;
        try { check();const found=test();check();if(found)finish(null,found); }
        catch(error) { finish(error); }
      }
      try {
        check();
        if(typeof MutationObserver!=='function') C.fail('Chưa theo dõi được giao diện Base.', 'CONTENT_UNAVAILABLE');
        observer=new MutationObserver(inspect);
        observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','style','hidden','aria-hidden','disabled','aria-disabled','src','aria-label','title','role','data-testid','id','tabindex','href']});
        for(const name of events) document.addEventListener(name,inspect,true);
        addEventListener('popstate',inspect);addEventListener('hashchange',inspect);
        commandWaiters.add(inspect);
        timer=setTimeout(()=>{if(settled)return;try{check();C.fail('Giao diện Base chưa phản hồi đúng hạn; không tự bấm lại.', 'DOM_TIMEOUT');}catch(error){finish(error);}},Math.max(1,deadline-Date.now()));
        inspect();
      } catch(error) { finish(error); }
    });
  }
  function bindOwnedReader(reader,endpoint,command,expected,version) {
    // The DOM ACK is transport confirmation only. The broker separately
    // requires authenticated Reader hello proof before delivering any read.
    const target=reader&&reader.contentWindow;
    const readerCodes=new Set(['READER_BINDING_INVALID','READER_BINDING_EXPIRED','READER_SOURCE_CHANGED','READER_NOT_TRUSTED','READER_PAUSED','READER_BINDING_REJECTED','READER_BUSY','READER_UNAVAILABLE','READER_CANCELLED']);
    return new Promise((resolve,reject)=>{
      let settled=false,bindSent=false,observer=null,probes=0;
      const timers=new Set();
      function exactKeys(value,keys) {return !!value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.prototype.hasOwnProperty.call(value,key));}
      function cleanup() {
        if(observer)observer.disconnect();
        for(const timer of timers)clearTimeout(timer);timers.clear();
        commandWaiters.delete(inspect);
        removeEventListener('message',receive);removeEventListener('popstate',inspect);removeEventListener('hashchange',inspect);
        document.removeEventListener('load',loaded,true);
      }
      function finish(error,value) {if(settled)return;settled=true;cleanup();if(error)reject(error);else resolve(value);}
      function check() {
        if(version!==cancelVersion)C.fail('Đã dừng Companion.','CANCELLED');
        const current=fresh(expected);
        if(!command.readerBinding||Date.now()>=command.deadline||Date.now()>=command.readerBinding.expiresAt)C.fail('Phiên xác nhận reader đã hết hạn.','READER_BINDING');
        C.validateCommand(command,current);commandVisible(command);
        const owned=ownedFrames(endpoint);
        if(owned.length!==1||owned[0]!==reader||!reader.isConnected||reader.contentWindow!==target||!target||typeof target.postMessage!=='function'||reader.getAttribute('srcdoc')!==null||!C.ownedFrame(reader.getAttribute('src')||'',endpoint))C.fail('Reader không còn thuộc đúng khung nguồn.','READER_BINDING');
      }
      function inspect() {if(settled)return;try{check();}catch(error){finish(error);}}
      function probe() {
        if(settled||bindSent||probes>=8)return;
        try{check();probes++;target.postMessage({type:'uoy-reader-bind-probe',version:1,commandId:command.commandId},endpoint);}
        catch(error){finish(error);}
      }
      function loaded(event) {if(event&&event.target===reader){inspect();probe();}}
      function receive(event) {
        if(settled||!event||event.source!==target||event.origin!==endpoint)return;
        const value=event.data;
        if(!value||!['uoy-reader-bind-ready','uoy-reader-bind-result'].includes(value.type)||value.commandId!==command.commandId)return;
        try {
          check();
          if(value.type==='uoy-reader-bind-ready') {
            if(!exactKeys(value,['type','version','commandId'])||value.version!==1)C.fail('Phản hồi reader không hợp lệ.','READER_BINDING');
            if(bindSent)return;
            bindSent=true;
            target.postMessage({type:'uoy-reader-bind',version:1,commandId:command.commandId,readerBinding:command.readerBinding},endpoint);
            return;
          }
          const keys=Object.prototype.hasOwnProperty.call(value,'code')?['type','version','commandId','ok','code']:['type','version','commandId','ok'];
          if(!bindSent||!exactKeys(value,keys)||value.version!==1||typeof value.ok!=='boolean'||Object.prototype.hasOwnProperty.call(value,'code')&&(!readerCodes.has(value.code)||value.ok))C.fail('Kết quả reader không hợp lệ.','READER_BINDING');
          if(!value.ok)C.fail('Reader chưa xác nhận nguồn SDK của trang này.','READER_BINDING');
          finish(null,{ok:true,bound:true});
        } catch(error) {finish(error);}
      }
      function later(callback,delay) {const timer=setTimeout(()=>{timers.delete(timer);callback();},delay);timers.add(timer);}
      try {
        check();
        if(typeof MutationObserver!=='function')C.fail('Chưa theo dõi được reader.','READER_BINDING');
        observer=new MutationObserver(inspect);observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src','srcdoc']});
        addEventListener('message',receive);addEventListener('popstate',inspect);addEventListener('hashchange',inspect);
        document.addEventListener('load',loaded,true);commandWaiters.add(inspect);
        // Register before probing. A load event covers newly created iframes;
        // the bounded, idempotent probes also cover a late message listener.
        later(()=>{try{check();C.fail('Reader chưa xác nhận đúng hạn.','READER_BINDING');}catch(error){finish(error);}},Math.max(1,Math.min(command.deadline,command.readerBinding.expiresAt)-Date.now()));
        for(const delay of [250,1000,2000])if(Date.now()+delay<Math.min(command.deadline,command.readerBinding.expiresAt))later(probe,delay);
        probe();
      } catch(error) {finish(error);}
    });
  }
  async function execute(message) {
    const version=cancelVersion;
    let actionStarted=false;
    try {
    const current = fresh(message.context); const cmd = C.validateCommand(message.command,current); const ep = C.endpoint(message.endpoint); const cal = C.cleanCalibration(message.calibration);
    commandVisible(cmd);
    const hiddenCold=cmd.op==='openOrder'&&document.visibilityState==='hidden'&&ownedFrames(ep).length===0;
    function guardedActivate(el,fp,scope) {
      if(version!==cancelVersion) C.fail('Đã dừng Companion.', 'CANCELLED');
      commandVisible(cmd);
      C.validateCommand(cmd,fresh(current));
      if(foreignFrames(ep).length) C.fail('Một khung web khác đang mở; không bấm nút trong khung đó.', 'FOREIGN_SIDEBAR');
      if(unique(fp,false,scope)!==el) C.fail('Nút giao diện vừa đổi; không bấm. Dạy lại nút nếu cần.', 'CALIBRATION');
      commandVisible(cmd); actionStarted=true;activate(el,current);
    }
    function guardedRoute(target) {
      try {
      if(hiddenCold&&['order','customize'].includes(target.step)&&!extensionSurface(target.el))C.fail('Nút không còn thuộc đúng danh sách phần mở rộng đã xác minh.','FOREIGN_SIDEBAR');
      if(target.observed&&observedToolbarUnique(false)!==target.el)C.fail('Nút BasePlugInOutlined vừa đổi hoặc không còn duy nhất.','CALIBRATION');
      if(target.strong&&strongToolbarHint(target.savedFp)!==target.el)C.fail('Định danh nút đã dạy không còn duy nhất trong toolbar.','CALIBRATION');
      if(target.semantic && semanticUnique(target.step,false)!==target.el) C.fail('Nút giao diện vừa đổi; chưa bấm.', 'CALIBRATION');
      // The semantic verifier deliberately excludes controls outside its
      // public toolbar/extension scope. Rechecking the new fingerprint over
      // the entire page must not reintroduce those unrelated matches. The
      // predicate revalidates semantic uniqueness immediately before click.
      const scope=target.observed ? candidate=>observedToolbarUnique(false)===candidate : target.strong ? candidate=>strongToolbarHint(target.savedFp)===candidate : target.semantic ? candidate=>semanticUnique(target.step,false)===candidate : undefined;
      guardedActivate(target.el,target.fp,scope);
      }catch(error){throw attachRouteEvidence(error,target.step,target.strong?target.savedFp:target.fp,'activate');}
    }
    function resolveOrder(){const target=routeTarget('order',cal.order,true);if(!hiddenCold||!target||extensionSurface(target.el))return target;const named=semanticUnique('order',true);return named?{el:named,fp:describe(named,true),step:'order',semantic:true}:null;}
    const found = frames(ep); if (found.length > 1) C.fail('Có nhiều khung UOY Order; không tự chọn khung.', 'AMBIGUOUS');
    if (cmd.op === 'openOrder') {
      if(cmd.readerBinding) {
        const retained=ownedFrames(ep);
        if(retained.length>1)C.fail('Có nhiều reader Order; chưa xác nhận nguồn.','AMBIGUOUS');
        if(retained.length===1){const result=await bindOwnedReader(retained[0],ep,cmd,current,version);mountedReaderHold().arm(retained[0],ep,current,cal,true);return result;}
      }
      // An already retained source-bound reader above is usable in a hidden
      // tab. A cold hidden page may virtualize its toolbar; wait for a visible
      // wake instead of misreporting missing controls as stale calibration.
      if(document.visibilityState==='hidden'&&ownedFrames(ep).length===0){
        // Only the existing authenticated, source/page/nonce-bound explicit
        // SDK read may bootstrap a hidden document. Unsolicited standby and
        // unbound legacy commands cannot acquire this exception.
        if(cmd.purpose!==undefined||!cmd.readerBinding)C.fail('Đang chờ tab Base hiện lên để khởi động reader; chưa bấm giao diện.','STANDBY_HIDDEN');
        const direct=resolveOrder(),observed=observedToolbarUnique(true);
        const available=direct&&extensionSurface(direct.el)?direct.el:observed;
        if(!available)C.fail('Tab Base đang ẩn và chưa có đường mở Order đã xác minh; chưa bấm giao diện.','STANDBY_HIDDEN');
        unoccluded(available);
      }
      if (found.length === 1) { unoccluded(found[0]);return {ok:true,already:true}; }
      // Rebinding the single exact retained reader above performs no UI
      // action and must not depend on toolbar or collapse calibration.
      // Missing teaching is not a missing route. Resolve only the unique,
      // scoped public opener below; it is revalidated immediately before
      // each click. Saved teaching remains an optional exact-match hint.
      if (foreignFrames(ep).length) C.fail('Một khung web khác đang mở. Đóng khung đó bằng tay trước; tool không đóng khung khác.', 'FOREIGN_SIDEBAR');
      let order = resolveOrder();
      if (!order) {
        // Direct Order wins. A cold page may only expose it after Customize;
        // discover that exact public route without persisting guessed teaching.
        const route = () => {
          if(foreignFrames(ep).length) C.fail('Một khung web khác đang mở; không điều khiển danh sách đó.', 'FOREIGN_SIDEBAR');
          const direct=resolveOrder();if(direct)return {order:direct};
          const customize=routeTarget('customize',cal.customize,true);
          return customize ? {customize} : null;
        };
        let next=route();
        if(!next){guardedRoute(routeTarget('toolbar',cal.toolbar,false));next=await waitForCommand(route,current,Math.min(cmd.deadline,Date.now()+5000),version,cmd);}
        if(next.customize){
          if(version!==cancelVersion) C.fail('Đã dừng Companion.', 'CANCELLED');
          if(foreignFrames(ep).length) C.fail('Một khung web khác đang mở; không bấm Tùy chỉnh.', 'FOREIGN_SIDEBAR');
          guardedRoute(next.customize);
          order=await waitForCommand(()=>{if(foreignFrames(ep).length) C.fail('Một khung web khác đang mở; không bấm Order.', 'FOREIGN_SIDEBAR');return resolveOrder();},current,Math.min(cmd.deadline,Date.now()+5000),version,cmd);
        }else order=next.order;
      }
      if(foreignFrames(ep).length) C.fail('Một khung web khác đang mở; không bấm Order.', 'FOREIGN_SIDEBAR');
      guardedRoute(order);
      await waitForCommand(() => { const own = frames(ep); if (own.length > 1) C.fail('Nhiều khung UOY Order.', 'AMBIGUOUS'); if(own.length===1)unoccluded(own[0]);return own.length === 1; },current,cmd.deadline,version,cmd);
      if(cmd.readerBinding) {
        const retained=ownedFrames(ep);
        if(retained.length!==1)C.fail('Chưa có duy nhất reader Order.','READER_BINDING');
        const result=await bindOwnedReader(retained[0],ep,cmd,current,version);mountedReaderHold().arm(retained[0],ep,current,cal,true);return result;
      }
      return {ok:true};
    }
    const retained=ownedFrames(ep);
    if(retained.length>1) C.fail('Có nhiều reader Order; không thu gọn.', 'AMBIGUOUS');
    if(!retained.length) return {ok:true,already:true};
    const reader=retained[0];
    // Native Back/X may unmount the iframe, destroying its SDK browsing
    // context. Keep the original authenticated reader mounted instead.
    // An unsafe/unrecognised container stays open; never guess or resurrect.
    const hold=mountedReaderHold();
    if(hold.arm(reader,ep,current,cal)&&hold.collapse())return {ok:true,retained:true,presentationHeld:true};
    return {ok:true,retained:true,leftOpen:true};
    } catch(error) {
      // Only this exact command's isolated closure can certify no UI action.
      // Once any click was attempted, later failures must remain fenced.
      if(error&&typeof error==='object'&&!actionStarted)error.uoyNoAction=true;
      throw error;
    }
  }
  chrome.runtime.onMessage.addListener((message,sender,respond) => {
    if (!sender || sender.id !== C.EXTENSION_ID || !message || typeof message.type !== 'string') return false;
    Promise.resolve().then(() => {
      if (message.type === 'context') return {ok:true,context:fresh(),contentBuild:C.BUILD,contentRevision:C.CONTENT_REVISION,contentProtocol:C.CONTENT_PROTOCOL,readerBindingVersion:1};
      if (message.type === 'readerAvailability') {const current=fresh(message.context),ep=C.endpoint(message.endpoint);return {ok:true,context:current,contentBuild:C.BUILD,contentRevision:C.CONTENT_REVISION,contentProtocol:C.CONTENT_PROTOCOL,readerBindingVersion:1,retainedReaderCount:Math.min(2,ownedFrames(ep).length)};}
      if (message.type === 'cancel') { cancelCommands(); teardown(); return {ok:true}; }
      if (message.type === 'teach') return teach(message);
      if (message.type !== 'command') C.fail('Lệnh không được phép.');
      const cmd = C.validateCommand(message.command,fresh(message.context));
      if (jobs.has(cmd.commandId)) return jobs.get(cmd.commandId);
      const operation = execute(message); jobs.set(cmd.commandId,operation); if (jobs.size > 64) jobs.delete(jobs.keys().next().value); return operation;
    }).then(respond,err => respond({ok:false,error:safeCommandError(err)})); return true;
  });
  let contextTimer=setInterval(()=>announceContext(false),2000);
  addEventListener('popstate',()=>announceContext(false));
  addEventListener('hashchange',()=>announceContext(false));
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible') announceContext(true);});
  addEventListener('pageshow',()=>{if(contextTimer===null)contextTimer=setInterval(()=>announceContext(false),2000);announceContext(true);});
  announceContext(true);
  addEventListener('pagehide',()=>{clearInterval(contextTimer);contextTimer=null;cancelCommands();teardown();});
})();
