'use strict';
importScripts('core.js');
const C = globalThis.UoyCompanion;
const ALARM = 'uoy-base-companion-poll';
const STANDBY_KEY = 'uoy.launcher.standby.v1';
// Public target metadata only. Session storage survives service-worker idle
// restarts, not a full browser restart. Never add this to pairing/local data.
const TARGET_KEY = 'uoy.launcher.target.v1';
const READER_OWNER_KEY = 'uoy.launcher.reader-owner.v1';
const SOURCE_LOCK_KEY = 'uoy.launcher.source-lock.v1';
const SOURCE_LOCK_TTL = 240000;
const STANDBY_LIMIT = 64;
let targetWrites = Promise.resolve();
let ownerWrites = Promise.resolve();
let sourceLockWrites = Promise.resolve();
const RESULT_CODES = new Set(['VIEW_CHANGED','CALIBRATION','CONTENT_UNAVAILABLE','UI_AMBIGUOUS','AMBIGUOUS','FOREIGN_SIDEBAR','OCCLUDED','DOM_TIMEOUT','READER_REMOVED','CANCELLED','STANDBY_HIDDEN','READER_OWNERSHIP','READER_BINDING']);
let running = null;
let resumeTimer = null;
let transportRetryAttempt = 0;
let ownerRecoveryUsed = false;
let commandRecoveryNotBefore = 0;
// A same-view duplicate is a different reader DOM. Only the tab on which
// this worker acknowledged an open may receive its subsequent close.
// Its nonsecret identity is retained in session storage across worker idle,
// never a full Chrome restart. Every use rechecks document + broker instance.
let readerOwner = null;
let generation = 0;
// One-use, short-lived selection hint after an authenticated idle broker has
// released a stale source/page lock. This is never a command or persisted trust.
let recoveryTargetHint = null;
let latestStatus = 'Chưa ghép Chrome Companion.';
let verifiedContentRevision = '';
let latestRouteDiagnostic = null;
let latestRouteDiagnosticCode = '';
const randomId = () => Array.from(crypto.getRandomValues(new Uint8Array(16)),n => n.toString(16).padStart(2,'0')).join('');
const status = value => { latestStatus = C.text(value,700); };
const CHROME_API_TIMEOUT_MS = 8000;
const DIAGNOSTICS = new Set(['CHROME_API_TIMEOUT','TAB_REQUIRED','MULTIPLE_TABS','VIEW_REQUIRED','PERMISSION','CONTENT_UNAVAILABLE','CONTENT_VERSION','VIEW_CHANGED']);
const RECOVERABLE_CHROME = new Set(['CHROME_API_TIMEOUT','TAB_REQUIRED','VIEW_REQUIRED','CONTENT_UNAVAILABLE','VIEW_CHANGED']);
const DIAGNOSTIC_TEXT = {
  CHROME_API_TIMEOUT:'Chrome chưa phản hồi bước nối Base đúng hạn. Companion sẽ xác nhận lại phiên đã lưu.',
  TAB_REQUIRED:'Chưa có tab Base đã ghép sẵn sàng. Mở đúng Base và chọn view.',
  MULTIPLE_TABS:'Chrome chưa xác nhận được tab hiện tại của Base đã ghép. Companion không chọn nhầm một tab khác.',
  VIEW_REQUIRED:'Tab Base chưa xác định duy nhất bảng/view. Chọn một view trên Base.',
  PERMISSION:'Chrome chưa được cấp quyền riêng cho Base đã ghép. Kiểm tra quyền trong popup Companion.',
  CONTENT_UNAVAILABLE:'Tab Base chưa phản hồi Companion. Tiện ích đang thử nối lại phiên đã lưu.',
  CONTENT_VERSION:'Mã Companion đang nằm trong tab Base chưa đúng phiên bản. Lưu công việc rồi tải lại riêng tab Base một lần. Tool không tự tải lại, đổi ghép nối hoặc bấm lại lệnh.',
  VIEW_CHANGED:'Base/view đang đổi. Companion sẽ xác nhận lại URL hiện tại trước khi đọc.'
};
function chromeFailure(code) {
  const err=new Error(DIAGNOSTIC_TEXT[code]||DIAGNOSTIC_TEXT.CHROME_API_TIMEOUT);err.code=code;err.uoyChromeDiagnostic=true;return err;
}
function chromeFail(code) { throw chromeFailure(code); }
function checkGuard(guard) {
  if(guard && (!guard.active || guard.generation!==generation)) C.fail('Thiết lập hoặc phiên Companion vừa đổi. Đã bỏ phản hồi cũ.','CONFIG_CHANGED');
}
function chromeCall(action,guard,errorCode='CHROME_API_TIMEOUT',timeoutMs=CHROME_API_TIMEOUT_MS) {
  checkGuard(guard);
  return new Promise((resolve,reject)=>{
    let settled=false;
    const timer=setTimeout(()=>{
      if(settled) return;
      settled=true;
      if(guard) guard.active=false;
      reject(chromeFailure('CHROME_API_TIMEOUT'));
    },Math.max(1,Math.min(20000,timeoutMs)));
    // Invoke only inside the guarded continuation. A late Chrome response
    // cannot resume a timed-out session, save a new binding, or dispatch DOM.
    Promise.resolve().then(()=>{checkGuard(guard);return action();}).then(value=>{
      if(settled) return;
      settled=true;clearTimeout(timer);
      try { checkGuard(guard);resolve(value); } catch(err) { reject(err); }
    },err=>{
      if(settled) return;
      settled=true;clearTimeout(timer);
      try { checkGuard(guard); } catch(changed) { reject(changed);return; }
      // Chrome exception strings can contain tab URLs and implementation
      // details. Only named diagnostics cross the local protocol boundary.
      if(err && err.code==='CONFIG_CHANGED') { reject(err);return; }
      reject(chromeFailure(errorCode));
    });
  });
}
function cancelResume(resetRetry=true) {
  if(resumeTimer!==null) { clearTimeout(resumeTimer); resumeTimer=null; }
  if(resetRetry) { transportRetryAttempt=0; ownerRecoveryUsed=false; }
}
function scheduleResume(delay,expectedGeneration) {
  cancelResume(false);
  resumeTimer=setTimeout(()=>{
    resumeTimer=null;
    if(expectedGeneration===generation) runSession();
  },delay);
}
async function load(guard) {
  const transient = await chromeCall(()=>chrome.storage.session.get(C.STORAGE_KEY),guard);
  const data = await chromeCall(()=>chrome.storage.local.get(C.STORAGE_KEY),guard); const saved = transient[C.STORAGE_KEY] || data[C.STORAGE_KEY]; if (!saved) return null;
  const p = C.pairing(saved,saved.baseIdentity);
  if (!p.baseIdentity || !/^[a-f0-9]{32}$/i.test(saved.clientId || '')) C.fail('Ghép Companion đã lưu không hợp lệ. Ghép lại từ Photoshop.');
  return {...p,clientId:saved.clientId,calibration:C.cleanCalibration(saved.calibration),remembered:saved.remembered === true,enabled:saved.enabled!==false};
}
function savedValue(config) {
  return {...C.pairing(config,config.baseIdentity),clientId:config.clientId,calibration:C.cleanCalibration(config.calibration),remembered:config.remembered === true,enabled:config.enabled!==false};
}
async function save(config,guard) {
  checkGuard(guard);
  const value = savedValue(config);
  // Only launcher trust + Base/control metadata. Never Order rows, cookies or account data.
  if(value.remembered) { await chromeCall(()=>chrome.storage.local.set({[C.STORAGE_KEY]:value}),guard); await chromeCall(()=>chrome.storage.session.remove(C.STORAGE_KEY),guard); }
  else { await chromeCall(()=>chrome.storage.session.set({[C.STORAGE_KEY]:value}),guard); await chromeCall(()=>chrome.storage.local.remove(C.STORAGE_KEY),guard); }
}
function standbyEntry(context) {
  const current = C.context(context && context.url || (context && context.baseIdentity)+'?table='+encodeURIComponent(context && context.tableId)+'&view='+encodeURIComponent(context && context.viewId));
  if(!C.sameContext(current,context) || !C.validPageId(context.pageId)) C.fail('Phiên trang khởi động reader không hợp lệ.','PAGE_CHANGED');
  return JSON.stringify({baseIdentity:current.baseIdentity,tableId:current.tableId,viewId:current.viewId,pageId:context.pageId});
}
async function claimStandby(command,current,guard) {
  C.validateCommand(command,current);
  if(current.documentVisible!==true) C.fail('Tab Base chưa hiển thị. Chưa ghi nhận hay tự bấm khởi động reader.','STANDBY_HIDDEN');
  const entry=standbyEntry(current);
  const saved=await chromeCall(()=>chrome.storage.session.get(STANDBY_KEY),guard);
  const entries=saved[STANDBY_KEY] === undefined ? [] : saved[STANDBY_KEY];
  if(!Array.isArray(entries) || entries.length>STANDBY_LIMIT || entries.some(value=>{
    if(typeof value!=='string' || value.length>900) return true;
    try { return standbyEntry(JSON.parse(value))!==value; } catch(_) { return true; }
  }) || new Set(entries).size!==entries.length) C.fail('Nhật ký khởi động reader không hợp lệ. Chưa tự bấm; Nạp bằng tay vẫn dùng được.','STANDBY_LEDGER');
  if(entries.includes(entry)) return false;
  // Do not evict an old live page and thereby give an unknown action authority
  // to replay. Session storage resets on a full Chrome restart; manual Nạp is
  // never blocked by this bounded, noncredential standby ledger.
  if(entries.length===STANDBY_LIMIT) C.fail('Đã đạt giới hạn khởi động reader trong phiên Chrome. Bấm Nạp trong Photoshop; không tự bấm lặp.','STANDBY_LIMIT');
  await chromeCall(()=>chrome.storage.session.set({[STANDBY_KEY]:entries.concat(entry)}),guard);
  checkGuard(guard);
  return true;
}
async function releaseUnusedStandby(command,current,guard) {
  // Called only after a claim owned by this command and definitive evidence
  // that it sent no UI action. Unknown/dispatched outcomes stay reserved.
  checkGuard(guard);
  const entry=standbyEntry(current);
  const saved=await chromeCall(()=>chrome.storage.session.get(STANDBY_KEY),guard);
  const entries=saved[STANDBY_KEY];
  if(!Array.isArray(entries)||entries.length>STANDBY_LIMIT||entries.some(value=>{
    if(typeof value!=='string'||value.length>900)return true;
    try{return standbyEntry(JSON.parse(value))!==value;}catch(_){return true;}
  })||new Set(entries).size!==entries.length)return;
  checkGuard(guard);
  if(entries.includes(entry))await chromeCall(()=>chrome.storage.session.set({[STANDBY_KEY]:entries.filter(value=>value!==entry)}),guard);
}
async function ensureAlarm() {
  if (!await chrome.alarms.get(ALARM)) await chrome.alarms.create(ALARM,{periodInMinutes:0.5});
}
function cleanTarget(value,config) {
  if(!value || Object.keys(value).sort().join(',')!=='baseIdentity,pageId,tabId,tableId,version,viewId' || value.version!==1 ||
    !Number.isInteger(value.tabId) || value.tabId<0 || value.baseIdentity!==config.baseIdentity ||
    !C.id(value.tableId) || !C.id(value.viewId) || !C.validPageId(value.pageId)) return null;
  return {version:1,baseIdentity:value.baseIdentity,tableId:value.tableId,viewId:value.viewId,pageId:value.pageId,tabId:value.tabId};
}
async function rememberedTarget(config,guard) {
  const saved=await chromeCall(()=>chrome.storage.session.get(TARGET_KEY),guard);
  return cleanTarget(saved[TARGET_KEY],config);
}
async function rememberTarget(tab,current,guard,expectedGeneration=generation) {
  if(tab.uoyTargetRemembered) return;
  const value={version:1,baseIdentity:current.baseIdentity,tableId:current.tableId,viewId:current.viewId,pageId:current.pageId,tabId:tab.id};
  // Serialize target-only writes. A later verified selection wins over an
  // earlier pending write; a cancelled generation never recreates a target.
  const write=targetWrites.catch(()=>{}).then(async()=>{
    checkGuard(guard);
    if(expectedGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Không lưu lại tab cũ.','CONFIG_CHANGED');
    await chromeCall(()=>chrome.storage.session.set({[TARGET_KEY]:value}),guard);
    checkGuard(guard);
    if(expectedGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Không sử dụng phản hồi tab cũ.','CONFIG_CHANGED');
  });
  targetWrites=write;await write;tab.uoyTargetRemembered=true;
}
async function rememberedSourceLock(config,guard) {
  const saved=await chromeCall(()=>chrome.storage.session.get(SOURCE_LOCK_KEY),guard),value=saved[SOURCE_LOCK_KEY];
  if(!value || Object.keys(value).sort().join(',')!=='baseIdentity,expiresAt,instance,pageId,tabId,tableId,version,viewId' ||
    typeof value.instance!=='string' || !/^[a-f0-9]{32}$/.test(value.instance) || value.instance!==config.brokerInstance ||
    !Number.isSafeInteger(value.expiresAt) || value.expiresAt<=Date.now() || value.expiresAt>Date.now()+SOURCE_LOCK_TTL) return null;
  return cleanTarget({version:value.version,baseIdentity:value.baseIdentity,tableId:value.tableId,viewId:value.viewId,pageId:value.pageId,tabId:value.tabId},config);
}
async function saveSourceLock(reply,tab,current,config,guard) {
  if(typeof reply.sourceLocked!=='boolean') return;
  if(typeof reply.instance!=='string' || !/^[a-f0-9]{32}$/.test(reply.instance) || reply.instance!==config.brokerInstance) C.fail('Cầu nối vừa đổi phiên. Xác nhận lại nguồn trước khi thao tác.','LOCAL_SESSION_RESTARTED');
  // Production's entire read budget is <=190s, application IPC <=240s.
  // Only a fresh authenticated locked reply renews this 240s recovery fence.
  const value=reply.sourceLocked?{version:1,instance:reply.instance,tabId:tab.id,baseIdentity:current.baseIdentity,tableId:current.tableId,viewId:current.viewId,pageId:current.pageId,expiresAt:Date.now()+SOURCE_LOCK_TTL}:null;
  const expectedGeneration=generation;
  const write=sourceLockWrites.catch(()=>{}).then(async()=>{
    checkGuard(guard);if(expectedGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Không lưu nguồn cũ.','CONFIG_CHANGED');
    if(value) await chromeCall(()=>chrome.storage.session.set({[SOURCE_LOCK_KEY]:value}),guard);
    else await chromeCall(()=>chrome.storage.session.remove(SOURCE_LOCK_KEY),guard);
    checkGuard(guard);if(expectedGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Không dùng nguồn cũ.','CONFIG_CHANGED');
  });
  sourceLockWrites=write;await write;
}
async function clearSourceLock() {
  await sourceLockWrites.catch(()=>{});await chrome.storage.session.remove(SOURCE_LOCK_KEY);
}
async function rememberedReaderOwner(config,guard) {
  const saved=await chromeCall(()=>chrome.storage.session.get(READER_OWNER_KEY),guard),value=saved[READER_OWNER_KEY];
  if(!value || Object.keys(value).sort().join(',')!=='baseIdentity,instance,pageId,tabId,tableId,version,viewId' ||
    typeof value.instance!=='string' || !/^[a-f0-9]{32}$/.test(value.instance)) return null;
  const target=cleanTarget({version:value.version,baseIdentity:value.baseIdentity,tableId:value.tableId,viewId:value.viewId,pageId:value.pageId,tabId:value.tabId},config);
  if(!target) return null;
  return {instance:value.instance,tabId:target.tabId,context:{...C.context(target.baseIdentity+'?table='+encodeURIComponent(target.tableId)+'&view='+encodeURIComponent(target.viewId)),pageId:target.pageId}};
}
async function saveReaderOwner(value,guard) {
  const write=ownerWrites.catch(()=>{}).then(async()=>{
    checkGuard(guard);
    if(value) {
      const data={version:1,instance:value.instance,tabId:value.tabId,baseIdentity:value.context.baseIdentity,tableId:value.context.tableId,viewId:value.context.viewId,pageId:value.context.pageId};
      await chromeCall(()=>chrome.storage.session.set({[READER_OWNER_KEY]:data}),guard);
    } else await chromeCall(()=>chrome.storage.session.remove(READER_OWNER_KEY),guard);
    checkGuard(guard);
  });
  ownerWrites=write;await write;readerOwner=value;
}
async function clearReaderOwner() {
  readerOwner=null;await ownerWrites.catch(()=>{});
  await chrome.storage.session.remove(READER_OWNER_KEY);
}
async function findTab(config,guard,lockedTarget,recoveryTarget) {
  const origin = new URL(config.baseIdentity).origin;
  if (!await chromeCall(()=>chrome.permissions.contains({origins:[origin+'/*']}),guard,'PERMISSION')) chromeFail('PERMISSION');
  const tabs = await chromeCall(()=>chrome.tabs.query({url:origin+'/base/*'}),guard,'TAB_REQUIRED');
  // The user may work on another Chrome tab while Panel reads this Base.
  // An active paired Base is an explicit new choice BETWEEN operations.
  // Otherwise retain only an exact, live, freshly checked session binding,
  // or the sole paired Base tab. Never choose a duplicate by query order.
  const matches = tabs.filter(tab => { try { const u=new URL(tab.url);return Number.isInteger(tab.id) && tab.id>=0 && u.origin+u.pathname.replace(/\/$/,'')===config.baseIdentity; } catch (_) { return false; } });
  if (!matches.length) chromeFail('TAB_REQUIRED');
  let selected=null,expectedTarget=null;
  if(lockedTarget) {
    const locked=matches.find(tab=>tab.id===lockedTarget.tabId);
    try { if(!locked || !C.sameContext(lockedTarget,C.context(locked.url))) chromeFail('VIEW_CHANGED'); }
    catch(err) { if(err && err.uoyChromeDiagnostic) throw err;chromeFail('VIEW_CHANGED'); }
    return {...locked,uoyExpectedTarget:lockedTarget};
  }
  const active=await chromeCall(()=>chrome.tabs.query({active:true,lastFocusedWindow:true,url:origin+'/base/*'}),guard,'TAB_REQUIRED');
  const activePaired=active.filter(tab=>matches.some(candidate=>candidate.id===tab.id));
  if(activePaired.length>1) chromeFail('MULTIPLE_TABS');
  if(activePaired.length===1) {
    selected=activePaired[0];
    // The active URL may have changed after the first query. Do not silently
    // substitute the stale URL from that earlier all-Base list.
    try { if(C.context(selected.url).baseIdentity!==config.baseIdentity) chromeFail('VIEW_CHANGED'); }
    catch(err) { if(err && err.uoyChromeDiagnostic) throw err;chromeFail('VIEW_CHANGED'); }
  } else if(matches.length===1) selected=matches[0];
  else {
    const bound=await rememberedTarget(config,guard);
    if(bound) {
      const candidate=matches.find(tab=>tab.id===bound.tabId);
      try {
        if(candidate) {
          if(C.sameContext(bound,C.context(candidate.url))) {selected=candidate;expectedTarget=bound;}
          else {
            // The previously selected tab still exists, but its view changed.
            // Do not guess another duplicate or silently replace this hint.
            // Only an authenticated idle ACK can authorize fresh selection.
            const changed=chromeFailure('VIEW_CHANGED');changed.uoyStaleTarget={...bound};throw changed;
          }
        }
      } catch(err) {if(err && err.uoyChromeDiagnostic) throw err;}
    }
    // Only the exact previously selected surviving tab may be recovered. A
    // newly active paired Base above still wins between operations.
    const recovered=cleanTarget(recoveryTarget,config);if(!selected && recovered) selected=matches.find(tab=>tab.id===recovered.tabId)||null;
    if(!selected) chromeFail('MULTIPLE_TABS');
  }
  try { C.context(selected.url); } catch(err) { chromeFail('VIEW_REQUIRED'); }
  return {...selected,...(expectedTarget?{uoyExpectedTarget:expectedTarget}:{})};
}
async function inject(tabId,guard) {
  await chromeCall(()=>chrome.scripting.executeScript({target:{tabId,frameIds:[0]},files:['core.js','content.js'],world:'ISOLATED'}),guard,'CONTENT_UNAVAILABLE');
}
async function tabContext(tab,config,guard) {
  // A session/command stays pinned to this document. Focus changes are not
  // authority to retarget an in-flight SDK/open/close request to another tab.
  const targetGeneration=generation,origin=new URL(config.baseIdentity).origin;
  if(!await chromeCall(()=>chrome.permissions.contains({origins:[origin+'/*']}),guard,'PERMISSION')) chromeFail('PERMISSION');
  const browserTab = await chromeCall(()=>chrome.tabs.get(tab.id),guard,'TAB_REQUIRED');
  let fromUrl;try { fromUrl=C.context(browserTab.url); } catch(err) { chromeFail('VIEW_REQUIRED'); }
  let pinned;try { pinned=C.context(tab.url); } catch(err) { chromeFail('VIEW_CHANGED'); }
  if (browserTab.id!==tab.id || fromUrl.baseIdentity !== config.baseIdentity || !C.sameContext(fromUrl,pinned)) chromeFail('VIEW_CHANGED');
  const reply = await chromeCall(()=>chrome.tabs.sendMessage(tab.id,{type:'context'},{frameId:0}),guard,'CONTENT_UNAVAILABLE');
  if (!reply || reply.ok!==true) chromeFail('CONTENT_UNAVAILABLE');
  try { C.validateContentReadiness(reply); }
  catch(err) { if(err && err.code==='CONTENT_VERSION') {err.uoyChromeDiagnostic=true;throw err;}throw chromeFailure('CONTENT_UNAVAILABLE'); }
  let current;try { current=C.context(reply.context && reply.context.url); } catch(err) { chromeFail('CONTENT_UNAVAILABLE'); }
  if (!C.sameContext(fromUrl,current)) chromeFail('VIEW_CHANGED');
  if(!C.validPageId(reply.context && reply.context.pageId)) chromeFail('CONTENT_UNAVAILABLE');
  if(typeof reply.context.documentVisible!=='boolean') chromeFail('CONTENT_UNAVAILABLE');
  const pageId=reply.context.pageId;
  if(tab.uoyPageId && tab.uoyPageId!==pageId || tab.uoyExpectedTarget && tab.uoyExpectedTarget.pageId!==pageId) chromeFail('VIEW_CHANGED');
  tab.uoyPageId=pageId;
  const verified={...current,pageId,documentVisible:reply.context.documentVisible};
  if(targetGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Không giữ lại tab cũ.','CONFIG_CHANGED');
  await rememberTarget(tab,verified,guard,targetGeneration);
  return verified;
}
function takeRecoveryTarget(config,guard) {
  checkGuard(guard);const hint=recoveryTargetHint;recoveryTargetHint=null;
  return hint && hint.generation===generation && hint.instance===config.brokerInstance && hint.expiresAt>Date.now() ? cleanTarget(hint.target,config) : null;
}
async function releaseStaleTarget(expected,config,guard) {
  if(!expected || !cleanTarget(expected,config)) return;
  const expectedGeneration=generation;
  const write=targetWrites.catch(()=>{}).then(async()=>{
    checkGuard(guard);if(expectedGeneration!==generation) C.fail('Phiên Companion vừa đổi. Không xóa nguồn mới.','CONFIG_CHANGED');
    const saved=await chromeCall(()=>chrome.storage.session.get(TARGET_KEY),guard),current=cleanTarget(saved[TARGET_KEY],config);
    // An intervening successful selection owns its newer hint. Never delete
    // or replace it because an older diagnostic acknowledgement arrived late.
    if(saved[TARGET_KEY]!==undefined && (!current || Object.keys(expected).some(key=>current[key]!==expected[key]))) return;
    if(current) await chromeCall(()=>chrome.storage.session.remove(TARGET_KEY),guard);
    checkGuard(guard);if(expectedGeneration!==generation) C.fail('Phiên Companion vừa đổi. Không giữ nguồn cũ.','CONFIG_CHANGED');
    recoveryTargetHint={generation:expectedGeneration,instance:config.brokerInstance,expiresAt:Date.now()+5000,target:{...expected}};
  });
  targetWrites=write;await write;
}
async function settledSelectionContext(tab,config,guard) {
  // Only a NEW unlocked metadata selection may settle snapshots. Once a
  // document/page/source is pinned, use the original strict path unchanged.
  if(tab.uoyExpectedTarget || tab.uoyPageId) return tabContext(tab,config,guard);
  const expectedGeneration=generation,origin=new URL(config.baseIdentity).origin,deadline=Date.now()+4000;
  const call=(action,code)=>chromeCall(action,guard,code,Math.max(1,deadline-Date.now()));
  function content(value){
    if(!value || value.ok!==true) chromeFail('CONTENT_UNAVAILABLE');
    try { C.validateContentReadiness(value); } catch(err) {if(err && err.code==='CONTENT_VERSION'){err.uoyChromeDiagnostic=true;throw err;}throw chromeFailure('CONTENT_UNAVAILABLE');}
    let current;try {current=C.context(value.context && value.context.url);} catch(_) {chromeFail('CONTENT_UNAVAILABLE');}
    if(!C.validPageId(value.context.pageId) || typeof value.context.documentVisible!=='boolean') chromeFail('CONTENT_UNAVAILABLE');
    return {...current,pageId:value.context.pageId,documentVisible:value.context.documentVisible};
  }
  function browser(value){
    let current;try {current=C.context(value && value.url);}catch(_){chromeFail('VIEW_REQUIRED');}
    if(!value || value.id!==tab.id || current.baseIdentity!==config.baseIdentity) chromeFail('VIEW_CHANGED');return current;
  }
  for(let attempt=0;attempt<3;attempt++) {
    try {
      if(!await call(()=>chrome.permissions.contains({origins:[origin+'/*']}),'PERMISSION')) chromeFail('PERMISSION');
      const first=browser(await call(()=>chrome.tabs.get(tab.id),'TAB_REQUIRED'));
      const a=content(await call(()=>chrome.tabs.sendMessage(tab.id,{type:'context'},{frameId:0}),'CONTENT_UNAVAILABLE'));
      const latest=await call(()=>chrome.tabs.get(tab.id),'TAB_REQUIRED'),last=browser(latest);
      const b=content(await call(()=>chrome.tabs.sendMessage(tab.id,{type:'context'},{frameId:0}),'CONTENT_UNAVAILABLE'));
      if(!C.sameContext(first,last) || !C.sameContext(last,a) || !C.sameContext(a,b)) chromeFail('VIEW_CHANGED');
      checkGuard(guard);if(expectedGeneration!==generation) C.fail('Phiên Companion vừa đổi. Không giữ nguồn cũ.','CONFIG_CHANGED');
      tab.url=latest.url;tab.uoyPageId=b.pageId;await rememberTarget(tab,b,guard,expectedGeneration);return b;
    } catch(err) {
      checkGuard(guard);
      if(!err.uoyChromeDiagnostic || !['VIEW_CHANGED','VIEW_REQUIRED'].includes(err.code) || attempt===2 || Date.now()>=deadline) throw err;
      await new Promise(resolve=>setTimeout(resolve,100));checkGuard(guard);
    }
  }
  chromeFail('VIEW_CHANGED');
}
async function register(config) {
  const origin = new URL(config.baseIdentity).origin;
  const old = await chrome.scripting.getRegisteredContentScripts({ids:['uoy-base-companion']});
  if (old.length) await chrome.scripting.unregisterContentScripts({ids:['uoy-base-companion']});
  await chrome.scripting.registerContentScripts([{id:'uoy-base-companion',js:['core.js','content.js'],matches:[origin+'/base/*'],allFrames:false,runAt:'document_idle',world:'ISOLATED',persistAcrossSessions:true}]);
}
async function hello(config,current,expectedGeneration=generation,preserveEnabled=true,guard) {
  checkGuard(guard);
  const reply = await C.request(fetch,config,'/launcher/v1/hello',{version:1,baseIdentity:current.baseIdentity,extensionId:C.EXTENSION_ID,clientBuild:C.BUILD,remember:true,companionRevision:C.CONTENT_REVISION,contentRevision:verifiedContentRevision});
  checkGuard(guard);
  if(typeof reply.instance!=='string' || !/^[a-f0-9]{32}$/.test(reply.instance)) C.fail('Cầu nối chưa xác nhận được định danh phiên. Chưa đổi ghép Companion.','TRUST_RESPONSE');
  // A late network response must not recreate a forgotten/changed connection,
  // undo Pause, or overwrite controls taught while that request was in flight.
  if(expectedGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Đã bỏ phản hồi kết nối cũ.','CONFIG_CHANGED');
  const latest=await load(guard);
  if(expectedGeneration!==generation) C.fail('Thiết lập Companion vừa đổi. Đã bỏ phản hồi kết nối cũ.','CONFIG_CHANGED');
  if(latest && latest.baseIdentity===config.baseIdentity && latest.clientId===config.clientId) {
    config={...config,calibration:latest.calibration,enabled:preserveEnabled ? latest.enabled : config.enabled};
  }
  if (reply.remembered===true && reply.trust) {
    const trust = C.pairing(reply.trust,current.baseIdentity); config = {...config,...trust,remembered:true};
  } else if (reply.remembered===false && !reply.trust) { config = {...config,remembered:false}; }
  else C.fail('Cầu nối chưa xác nhận được kiểu ghép đã lưu. Chưa đổi ghép Companion.','TRUST_RESPONSE');
  // A warm remembered hello normally returns the exact existing trust. Avoid
  // rewriting identical storage every burst, and avoid leaving an unnecessary
  // asynchronous storage write that could outlive a Pause/Forget operation.
  if(!latest || JSON.stringify(savedValue(latest))!==JSON.stringify(savedValue(config))) await save(config,guard);
  checkGuard(guard);
  return {...config,brokerInstance:reply.instance};
}
async function sendPause(config) {
  // Pause is launcher metadata only: no DOM action, URL inspection or Order data.
  // Re-hello restores the same authenticated owner after a worker/server restart.
  try {
    config=await hello(config,{baseIdentity:config.baseIdentity});
    await C.request(fetch,config,'/launcher/v1/poll',{baseIdentity:config.baseIdentity,paused:true,ready:false});
    return true;
  } catch(err) { status('Đã tạm dừng trên Chrome. Photoshop chưa nhận trạng thái: '+C.text(err.message,500));return false; }
}
async function runSession() {
  if (running) return running;
  // An interrupted dispatched command may still be running in the content
  // frame. Even an alarm/tab wake must not fetch and replay it before its
  // broker deadline has expired. This is a memory-only safety fence, not a
  // stored command, guessed success or new user action.
  if(Date.now()<commandRecoveryNotBefore) return null;
  cancelResume(false);
  const startedGeneration=generation;
  const guard={generation:startedGeneration,active:true};
  let continuePolling=false, retryTransport=false, rememberedPairing=false, commandInFlight=false,commandDispatched=false,activeCommandDeadline=0,config=null,staleTarget=null;
  running = (async () => {
    config = await load(guard); if (!config || !config.enabled) return;
    rememberedPairing=config.remembered===true;
    // The remembered credential already belongs to this exact Base. Establish
    // only its authenticated launcher session first, so Chrome restore errors
    // can reach Photoshop without granting a view or any DOM action. Fresh
    // popup/bootstrap connections still inspect the tab before their hello.
    if(rememberedPairing) config=await hello(config,{baseIdentity:config.baseIdentity},startedGeneration,true,guard);
    checkGuard(guard);if(!config.enabled) return;
    const retainedLock=await rememberedSourceLock(config,guard);
    staleTarget=retainedLock;
    let tab = await findTab(config,guard,retainedLock,retainedLock?null:takeRecoveryTarget(config,guard));staleTarget=tab.uoyExpectedTarget||staleTarget;await inject(tab.id,guard);
    let current = retainedLock ? await tabContext(tab,config,guard) : await settledSelectionContext(tab,config,guard);
    verifiedContentRevision=C.CONTENT_REVISION;
    readerOwner=await rememberedReaderOwner(config,guard);
    if(!rememberedPairing) config = await hello(config,current,startedGeneration,true,guard);
    rememberedPairing=config.remembered===true;
    // hello re-reads saved settings; a Pause during reconnect wins over the
    // earlier snapshot even if the Base itself is still reachable.
    if(!config.enabled) return;
    checkGuard(guard);
    continuePolling=true;
    const deadline = Date.now()+22000;
    // Old brokers omit this optional field: conservatively keep their target
    // pinned for the whole burst. R32 unlocks only between completed reads.
    let sourceLocked=!!retainedLock;
    const missing=C.OPEN_STEPS.filter(step=>!config.calibration[step]);
    const missingCollapse=['back','listClose'].filter(step=>!config.calibration[step]);
    if (missing.length) status('Đã ghép. Reader đang giữ vẫn có thể xác minh; chỉ cần dạy nút '+missing.join(', ')+' nếu phải mở Order mới.');
    else if(missingCollapse.length)status('Đã ghép. Vẫn đọc Base; giữ Order mở vì chưa dạy đủ nút thu gọn.');
    while (Date.now()<deadline && startedGeneration===generation) {
      let selectionFresh=false;
      if(!sourceLocked) {
        const selected=await findTab(config,guard,null,takeRecoveryTarget(config,guard));
        if(selected.id!==tab.id) await inject(selected.id,guard);
        tab=selected;
        staleTarget=selected.uoyExpectedTarget||null;
        selectionFresh=true;
      }
      current = sourceLocked ? await tabContext(tab,config,guard) : await settledSelectionContext(tab,config,guard);
      verifiedContentRevision=C.CONTENT_REVISION;
      // Readiness proves only exact page/source metadata. UI capability is
      // checked by content at the last safe boundary, so a retained reader
      // can bind without calibration and collapse controls never block reads.
      let reply;
      try { checkGuard(guard);reply=await C.request(fetch,config,'/launcher/v1/poll',{baseIdentity:current.baseIdentity,tableId:current.tableId,viewId:current.viewId,url:current.url,pageId:current.pageId,documentVisible:current.documentVisible,selectionFresh:selectionFresh,ready:true,contentRevision:verifiedContentRevision});checkGuard(guard); }
      catch(err) {
        // A broker can restart between two polls without a transport outage.
        // Missing launcher ownership is recovered by ONE new authenticated
        // hello; a repeated CLIENT refusal does not become a retry hammer.
        if(rememberedPairing && ['SESSION_RESTARTED','CLIENT'].includes(err.code) && !ownerRecoveryUsed) { ownerRecoveryUsed=true; C.fail('Photoshop vừa khởi động lại cầu nối. Companion đang xác nhận lại phiên đã ghép.','LOCAL_SESSION_RESTARTED'); }
        throw err;
      }
      transportRetryAttempt=0; ownerRecoveryUsed=false;
      sourceLocked=reply.sourceLocked!==false;
      await saveSourceLock(reply,tab,current,config,guard);
      if (reply.commandId) {
        sourceLocked=true;
        if(startedGeneration!==generation) return;
        // R33 validates the complete transient readerBinding in core, then
        // forwards this ORIGINAL command to content. Storage helpers below
        // deliberately serialize only public target/owner fields, not tickets.
        const cmd = C.validateCommand(reply,current);
        if(cmd.op==='closeOrder' && (!readerOwner || readerOwner.instance!==cmd.instance || readerOwner.tabId!==tab.id || !C.sameContext(readerOwner.context,current))) {
          await C.request(fetch,config,'/launcher/v1/result',{commandId:cmd.commandId,instance:cmd.instance,ok:false,error:{code:'READER_OWNERSHIP',message:'Chưa xác minh được tab đã mở reader Order. Không thu gọn reader ở tab khác.'}});
          status('Đã giữ reader Order; không chuyển lệnh thu gọn sang tab khác.');
          return;
        }
        // Re-read URL from both Chrome and isolated content before ANY DOM command.
        let before;
        try {
          before=await tabContext(tab,config,guard);
          if(!C.sameContext(current,before)) chromeFail('VIEW_CHANGED');
        } catch(err) {
          // The broker has issued this validated command, but no DOM action
          // was sent. Reject it explicitly before rebinding: otherwise the
          // old open/close command would block recovery until its deadline.
          // Never retarget it to a newly active same-view duplicate tab.
          if(startedGeneration===generation && err.uoyChromeDiagnostic===true) {
            await C.request(fetch,config,'/launcher/v1/result',{commandId:cmd.commandId,instance:cmd.instance,ok:false,error:{code:'VIEW_CHANGED',message:'Tab/view nguồn đã đổi trước thao tác Order. Chưa bấm nút trên Base.'}});
          }
          throw err;
        }
        checkGuard(guard);
        commandInFlight=true;
        activeCommandDeadline=cmd.deadline;
        let result,standbyClaimed=false,thisCommandDispatched=false;
        if(cmd.purpose==='standby') {
          try {
            if(!await claimStandby(cmd,before,guard)) result={ok:false,error:{message:'Reader đã được khởi động cho trang/view này. Không tự bấm lặp; Nạp trong Photoshop vẫn dùng được.'}};
            else {
              standbyClaimed=true;
              // A page reload, Pause or tab/view switch during the durable
              // claim must win before the first DOM command is sent.
              const claimedCurrent=await tabContext(tab,config,guard);
              if(!C.sameContext(before,claimedCurrent)) chromeFail('VIEW_CHANGED');
              if(claimedCurrent.documentVisible!==true) C.fail('Tab Base vừa bị ẩn. Không gửi lệnh khởi động reader.','STANDBY_HIDDEN');
              C.validateCommand(cmd,claimedCurrent);before=claimedCurrent;
            }
          } catch(err) {
            checkGuard(guard);
            result={ok:false,error:{...(err.code==='STANDBY_HIDDEN'?{code:'STANDBY_HIDDEN'}:{}),noAction:true,message:'Chưa xác minh được phiên khởi động reader. Không tự bấm; Nạp trong Photoshop vẫn dùng được.'}};
          }
        }
        try { if(!result) {
          if(cmd.op==='openOrder'&&before.documentVisible===false&&!(cmd.purpose===undefined&&cmd.readerBinding)){
            const availability=await chromeCall(()=>chrome.tabs.sendMessage(tab.id,{type:'readerAvailability',context:before,endpoint:config.endpoint},{frameId:0}),guard,'CONTENT_UNAVAILABLE');
            const retained=C.readerAvailability(availability,before);
            if(!retained.documentVisible&&retained.retainedReaderCount===0)result={ok:false,error:{code:'STANDBY_HIDDEN',noAction:true,message:'Đang chờ tab Base hiện lên để khởi động reader. Không có thao tác UI; reader đã giữ vẫn đọc nền bình thường.'}};
          }
          if(!result){
          // Cold toolbar -> Customize -> Order can legitimately exceed 8s.
          // Metadata calls remain 8s; DOM gets only its validated remaining
          // broker deadline plus a bounded response-delivery allowance.
          const commandWait=Math.max(1,Math.min(20000,cmd.deadline-Date.now()+500));
          result = await chromeCall(()=>{commandDispatched=true;thisCommandDispatched=true;return chrome.tabs.sendMessage(tab.id,{type:'command',command:cmd,context:before,endpoint:config.endpoint,calibration:config.calibration},{frameId:0});},guard,'CONTENT_UNAVAILABLE',commandWait);
          if(Date.now()>cmd.deadline) {guard.active=false;throw chromeFailure('CHROME_API_TIMEOUT');}
          }
        } }
        catch (err) {
          // A dispatched action with an unknown/late outcome is never replayed
          // by a timeout recovery. Let the broker expire that command safely.
          if(err.code==='CHROME_API_TIMEOUT'||err.code==='CONFIG_CHANGED') throw err;
          result = {ok:false,error:{code:'CONTENT_UNAVAILABLE',message:'Tab Base không phản hồi. Không thử bấm lặp lại; bấm Nạp lại.'}};
        }
        const resultCode=result && result.error && result.error.code;
        const leftOpen=!!(result&&result.ok===true&&cmd.op==='closeOrder'&&result.leftOpen===true);
        const routeDiagnostic=['CALIBRATION','UI_AMBIGUOUS'].includes(resultCode)?C.routeDiagnostic(result&&result.error&&result.error.routeDiagnostic):null;
        const safeResult = result && result.ok === true ? {ok:true,...(leftOpen?{leftOpen:true}:{})} : {ok:false,error:{...(RESULT_CODES.has(resultCode)?{code:resultCode}:{}),...(result&&result.error&&result.error.noAction===true?{noAction:true}:{}),...(routeDiagnostic?{routeDiagnostic}:{}),message:C.text(result && result.error && result.error.message || 'Không xác minh được thao tác mở/đóng Order.',700)}};
        if(routeDiagnostic){latestRouteDiagnostic=routeDiagnostic;latestRouteDiagnosticCode=resultCode;}
        else if(result&&result.ok===true&&cmd.op==='openOrder'){latestRouteDiagnostic=null;latestRouteDiagnosticCode='';}
        checkGuard(guard);
        if(standbyClaimed&&safeResult.ok===false&&(!thisCommandDispatched||safeResult.error.noAction===true))await releaseUnusedStandby(cmd,before,guard);
        // Persist a confirmed DOM result before acknowledging it to the
        // broker. Worker suspension immediately after ACK must not erase the
        // only evidence authorizing a later close of this exact reader.
        if(safeResult.ok) {
          if(cmd.op==='openOrder') await saveReaderOwner({instance:cmd.instance,tabId:tab.id,context:before},guard);
          else if(!leftOpen)await saveReaderOwner(null,guard);
        }
        await C.request(fetch,config,'/launcher/v1/result',{commandId:cmd.commandId,instance:cmd.instance,...safeResult});
        checkGuard(guard);
        commandInFlight=false;
        commandRecoveryNotBefore=0;
        status(safeResult.ok ? (cmd.op==='openOrder' ? 'Đã xác nhận nguồn SDK của Order để Photoshop đọc đúng view.' : leftOpen?'Đã giữ Order mở: chưa xác minh được sidebar an toàn để ẩn; không tháo reader.':'Đã thu gọn bằng Companion, giữ nguyên iframe Order gốc chạy nền.') : safeResult.error.message);
      } else if (reply.idle !== true) C.fail('Cầu nối trả lệnh không hợp lệ.');
      await new Promise(resolve => setTimeout(resolve,1200));
    }
  })().catch(async err => {
    if(['CONTENT_VERSION','CONTENT_UNAVAILABLE','TAB_REQUIRED','VIEW_REQUIRED','VIEW_CHANGED','PERMISSION'].includes(err.code))verifiedContentRevision='';
    continuePolling=false;
    // Reconnect only an existing remembered local pairing. Do not fast-retry
    // denied credentials/setup errors, and never replay a dispatched DOM job
    // just because its result acknowledgement was interrupted.
    retryTransport=rememberedPairing && (['LOCAL_TRANSPORT','LOCAL_SESSION_RESTARTED'].includes(err.code)||(err.uoyChromeDiagnostic===true && RECOVERABLE_CHROME.has(err.code))) && !commandDispatched;
    if(commandDispatched && commandInFlight) commandRecoveryNotBefore=Math.max(commandRecoveryNotBefore,activeCommandDeadline+1000);
    if(config && rememberedPairing && config.enabled && startedGeneration===generation && !commandDispatched && err.uoyChromeDiagnostic===true && DIAGNOSTICS.has(err.code)) {
      // Only a named pre-dispatch diagnostic travels through authenticated
      // launcher ownership. Never include Chrome exceptions, URLs or records.
      try {
        const ack=await C.request(fetch,config,'/launcher/v1/state',{baseIdentity:config.baseIdentity,ready:false,diagnosticCode:err.code});
        if(err.code==='VIEW_CHANGED' && ack && ack.idle===true && ack.sourceLocked===false && ack.instance===config.brokerInstance) {
          // Only the broker's explicit same-instance idle authority may retire
          // a stale source/page fence. Busy/legacy/foreign ACKs change nothing.
          checkGuard(guard);await saveSourceLock(ack,null,null,config,guard);await releaseStaleTarget(cleanTarget(err.uoyStaleTarget,config)||staleTarget,config,guard);
        }
      }
      catch(reportError) { if(!['LOCAL_TRANSPORT','SESSION_RESTARTED','CLIENT'].includes(reportError.code)) retryTransport=false; }
    }
    if(startedGeneration===generation) status(err.message);
  }).finally(() => {
    guard.active=false;
    running=null;
    if(startedGeneration!==generation) runSession();
    // Keep the authenticated metadata channel warm. Previously a 22 s burst
    // ended eight seconds before the 30 s Chrome alarm, delaying every read
    // landing in that gap. Remembered loopback outages now reconnect in
    // 1/2/4/5 seconds, not only at Chrome's 30-second alarm. Each attempt
    // revalidates permissions, Base, enabled state and authenticated hello.
    else if(continuePolling) scheduleResume(1000,startedGeneration);
    else if(retryTransport) {
      const delay=Math.min(5000,1000*Math.pow(2,Math.min(transportRetryAttempt++,3)));
      scheduleResume(delay,startedGeneration);
    }
    else transportRetryAttempt=0;
  });
  return running;
}
async function popupConnect(message) {
  if (!Number.isInteger(message.tabId)) C.fail('Chọn tab Base trước.');
  const tab = await chrome.tabs.get(message.tabId); const current = C.context(tab.url); const code = C.pairing(message.code,current.baseIdentity);
  const expected=C.context(message.context&&message.context.url);if(!C.sameContext(expected,current)) C.fail('Tab/view đã đổi sau khi mở popup. Mở popup lại trên Base đúng trước khi ghép.', 'VIEW_CHANGED');
  if (!await chrome.permissions.contains({origins:[current.origin+'/*']})) C.fail('Bạn cần tự duyệt quyền riêng cho Base này trong Chrome.');
  const previous = await load();
  generation++; cancelResume();
  const connectGeneration=generation,sameBase=previous && previous.baseIdentity===current.baseIdentity;
  // Reconnecting this stored Base is the same Companion owner, not a competing
  // client. Preserve its identity across popup close/reopen and browser restarts.
  let config = {...code,baseIdentity:current.baseIdentity,clientId:sameBase ? previous.clientId : randomId(),calibration:sameBase ? previous.calibration : {},remembered:false,enabled:true};
  await inject(tab.id); const verified = await tabContext(tab,config);if(!C.sameContext(verified,current)) C.fail('View đã đổi trong lúc ghép. Mở popup lại.','VIEW_CHANGED');config=await hello(config,verified,connectGeneration,false); await register(config); await ensureAlarm();
  status('Đã ghép Companion'+(config.remembered ? ' và ghi nhớ trên máy này.' : ' cho phiên này; Photoshop chưa lưu được ghép lâu dài.')+' Tự nhận nút mở Order; dạy nút chỉ khi giao diện không xác định được duy nhất.'); runSession();
  return {ok:true,baseIdentity:config.baseIdentity,remembered:config.remembered};
}
async function handle(message,sender) {
  if (!message || typeof message.type !== 'string') C.fail('Thông điệp không hợp lệ.');
  const popup = sender && sender.id === C.EXTENSION_ID && sender.url === chrome.runtime.getURL('popup.html') && !sender.tab;
  if(message.type==='viewContext') {
    const config=await load(); if(!config || !config.enabled) return {ok:true,ignored:true};
    // URL metadata is only accepted from the top frame of the paired Base.
    // Never consume a page's records, cookies or main-world objects.
    if(!sender || !sender.tab || !C.validSender(sender,{...config,tabId:sender.tab.id})) C.fail('Không nhận thay đổi view từ tab/frame khác.','VIEW_CHANGED');
    const expected=C.context(message.context&&message.context.url);
    if(message.context && message.context.pageId!==undefined) {
      if(!C.validPageId(message.context.pageId)) C.fail('Thông báo không có phiên trang hợp lệ.','PAGE_CHANGED');
      expected.pageId=message.context.pageId;
    }
    const tab=await findTab(config);
    // A valid but inactive same-Base tab is only an ignored wake hint. ACK it
    // so its URL watcher does not retry every second; activation announces
    // again, and polling always resolves the current tab independently.
    if(tab.id!==sender.tab.id) return {ok:true,ignored:true};
    const latest=await tabContext(tab,config);
    if(!C.sameContext(expected,latest)) C.fail('Thông báo view không khớp tab Base hiện tại.','VIEW_CHANGED');
    runSession(); return {ok:true};
  }
  if (message.type==='learned') {
    const config=await load(); if(!config) C.fail('Chưa ghép Companion.'); const tab=await findTab(config); config.tabId=tab.id;
    if(!C.validSender(sender,config) || !C.TEACH_STEPS.includes(message.step)) C.fail('Không nhận dạy nút từ tab/frame khác.');
    const latest=await tabContext(tab,config); if(!C.sameContext(latest,message.context)) C.fail('View đã đổi trong lúc dạy nút.');
    const fp=message.step==='customize'?C.customizeFingerprint(message.fingerprint):C.fingerprint(message.fingerprint); config.calibration[message.step]=fp; await save(config); generation++; cancelResume(); status('Đã ghi nhớ nút '+message.step+'.'); runSession(); return {ok:true};
  }
  if(!popup) C.fail('Chỉ popup Companion được phép cấu hình.');
  if(message.type==='connect') return popupConnect(message);
  if(message.type==='status') { const config=await load(); return {ok:true,status:config&&!config.enabled ? (latestStatus.startsWith('Đã tạm dừng trên Chrome.') ? latestStatus : 'Đã tạm dừng tự mở/đóng. Bạn có thể mở Order và chỉnh cài đặt bằng tay.') : latestStatus,baseIdentity:config&&config.baseIdentity,remembered:!!(config&&config.remembered),enabled:!!(config&&config.enabled),calibration:config ? C.TEACH_STEPS.filter(step=>config.calibration[step]) : [],contentRevision:C.CONTENT_REVISION,verifiedContentRevision,routeDiagnostic:latestRouteDiagnostic,routeDiagnosticCode:latestRouteDiagnosticCode}; }
  if(message.type==='enabled') {
    if(typeof message.enabled!=='boolean') C.fail('Trạng thái tự mở/đóng không hợp lệ.');
    generation++; cancelResume(); const config=await load(); if(!config) C.fail('Ghép Companion trước.'); config.enabled=message.enabled; await save(config);
    if(!config.enabled) { await clearReaderOwner();await clearSourceLock();await chrome.alarms.clear(ALARM); try { const tab=await findTab(config); await chrome.tabs.sendMessage(tab.id,{type:'cancel'},{frameId:0}); } catch(_){} if(await sendPause(config)) status('Đã tạm dừng tự mở/đóng. Bạn có thể mở Order và chỉnh cài đặt bằng tay.'); }
    else { await ensureAlarm(); status('Đã bật tự mở/đóng Order.'); runSession(); }
    return {ok:true};
  }
  if(message.type==='forget') {
    generation++; cancelResume(); readerOwner=null; const config=await load();
    if(config) { try { const tab=await findTab(config); await chrome.tabs.sendMessage(tab.id,{type:'cancel'},{frameId:0}); } catch(_){} }
    await clearReaderOwner();await clearSourceLock();await targetWrites.catch(()=>{});await chrome.storage.local.remove(C.STORAGE_KEY); await chrome.storage.session.remove(C.STORAGE_KEY); await chrome.storage.session.remove(TARGET_KEY); await chrome.alarms.clear(ALARM);
    await chrome.scripting.unregisterContentScripts({ids:['uoy-base-companion']}).catch(()=>{});
    if(config) await chrome.permissions.remove({origins:[new URL(config.baseIdentity).origin+'/*']}); status('Đã quên Companion và gỡ quyền Base khỏi Companion.'); return {ok:true};
  }
  if(message.type==='teach') {
    const config=await load(); if(!config) C.fail('Ghép Companion trước.');const expected=C.context(message.context&&message.context.url);if(expected.baseIdentity!==config.baseIdentity)C.fail('Popup đang ở Base khác Base đã ghép.','VIEW_CHANGED');const tab=await findTab(config);if(!C.sameContext(expected,C.context(tab.url)))C.fail('Tab/view đã đổi sau khi mở popup.','VIEW_CHANGED');await inject(tab.id); const current=await tabContext(tab,config);
    if(!C.sameContext(expected,current)) C.fail('Popup không ở đúng Base/view đang dạy. Mở popup lại trên Base đã ghép.','VIEW_CHANGED');
    return chrome.tabs.sendMessage(tab.id,{type:'teach',step:message.step,context:current,endpoint:config.endpoint},{frameId:0});
  }
  if(message.type==='check') { const config=await load();if(config){const expected=C.context(message.context&&message.context.url);if(expected.baseIdentity!==config.baseIdentity) C.fail('Kiểm tra ở tab Base đã ghép; popup hiện đang ở Base khác.','VIEW_CHANGED');}if(config&&!config.enabled) await sendPause(config);else runSession();return {ok:true}; }
  C.fail('Lệnh popup không được phép.');
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{handle(message,sender).then(respond,err=>respond({ok:false,error:{message:C.text(err.message,700),code:C.text(err.code,60)}}));return true;});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name===ALARM) runSession();});
async function restore() { const config=await load();if(config&&config.enabled)return ensureAlarm().then(runSession);if(config)return sendPause(config); }
chrome.runtime.onStartup.addListener(()=>{restore().catch(err=>status(err.message));});
chrome.runtime.onInstalled.addListener(()=>{restore().catch(err=>status(err.message));});
chrome.tabs.onUpdated.addListener((_id,change)=>{if(change.status==='complete'||change.url||change.discarded===false) runSession();});
// Activating a restored Base tab is another wake hint, not authority to act:
// runSession still validates stored trust, enabled state, permission, selected
// exact Base tab and fresh public table/view before any broker or DOM command.
if(chrome.tabs.onActivated) chrome.tabs.onActivated.addListener(()=>{runSession();});
chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).then(restore).catch(err=>status(err.message));
