MiFont 1.0.0
FontTools, Pillow, Python, the Inter UI font and the separate Potrace CLI are bundled.
See packages.json and each package license. Potrace complete unmodified source is included.
PyInstaller bootloader redistribution exception: https://pyinstaller.org/en/stable/license.html
Complete app source: MiFont-source-1.0.0.zip
Rebuild with Python3.12 x64: create .work/mifont-env, install both pinned requirements files, then run mifont/build.ps1.
No customer project, specimen or downloaded reference font is bundled. User-chosen OFL derivative notices travel with their exported projects/fonts.
