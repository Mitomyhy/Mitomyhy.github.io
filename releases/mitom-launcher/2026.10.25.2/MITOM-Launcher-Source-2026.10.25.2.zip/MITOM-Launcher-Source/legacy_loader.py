"""Owner's unchanged original transactional-code integrity loader."""
from frozen_payload import populate as _recover
_recover("legacy_loader", globals())
