"""All writes use TemporaryDirectory fixture roots, never a real installation."""
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

SPEC = importlib.util.spec_from_file_location("uoy_test_installer", Path(__file__).parents[1] / "installer.py")
installer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(installer)

XML = b'<ExtensionManifest ExtensionBundleId="com.uoy.orderpanel"><Host Name="PHXS"/></ExtensionManifest>'


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="uoy-installer-test-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.payload = self.root / "payload"
        self.fixture = self.root / "pc"
        self.payload.mkdir()
        self.files = {"panel/CSXS/manifest.xml": XML,
                      "panel/index.html": b"current panel",
                      "panel/js/main.js": b"current JavaScript",
                      "core/node.exe": b"fixture-not-executable-node",
                      "core/python/python.exe": b"fixture-not-executable-python",
                      "core/upload-tool/upload_he_thong.py": b"# clean default",
                      "coexist/coexist-host.js": b"host",
                      "coexist/coexist-client.js": b"client",
                      "coexist/coexist-common.js": b"common",
                      "panel/js/lark-base-bridge.js": b"bridge",
                      "panel/js/lark-pairing-store.js": b"store module",
                      "companion/manifest.json": b'{"manifest_version":3}'}
        self.write_payload()

    def write_payload(self, version="2026.10.20.1"):
        entries = []
        for name, data in self.files.items():
            target = self.payload / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            entries.append({"path": name, "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)})
        self.manifest = {"schema": 1, "version": version, "files": entries}
        self.save_manifest()

    def save_manifest(self):
        (self.payload / installer.MANIFEST).write_text(json.dumps(self.manifest), encoding="utf-8")

    def roots(self):
        return installer._roots(self.fixture)[0]

    def legacy_base(self, **overrides):
        roots, local, _ = installer._roots(self.fixture)
        co = roots["coexist"]
        co.mkdir(parents=True, exist_ok=True)
        old_root = self.root / "old-unzipped-folder-no-longer-present"
        value = {"version": 1, "enabled": True, "machine": os.environ.get("COMPUTERNAME", "FIXTURE"),
                 "profile": str(local), "pipeId": "a" * 32, "nodePath": str(old_root / "node.exe"),
                 "hostPath": str(old_root / "coexist-host.js"), "bridgePath": str(old_root / "bridge.js"),
                 "pairStorePath": str(old_root / "lark-pairing-store.js"), "staticRoot": str(old_root / "lark-base-extension")}
        value.update(overrides)
        data = json.dumps(value, separators=(",", ":")).encode()
        (co / "active-v1.json").write_bytes(data)
        (co / "application-key.dat").write_bytes(b"existing-local-dpapi-ciphertext")
        return value, data

    def legacy(self):
        panel = self.roots()["panel"]
        (panel / "CSXS").mkdir(parents=True)
        (panel / "CSXS/manifest.xml").write_bytes(XML)
        (panel / "index.html").write_bytes(b"legacy panel")
        (panel / "local-config.json").write_bytes(b'{"privateSetting":"user-value"}')
        (panel / "unknown.txt").write_bytes(b"user-owned unknown")
        return panel

    def install(self):
        return installer.install(self.payload, self.fixture)

    def test_new_install_correct_per_user_targets(self):
        result = self.install()
        roots = self.roots()
        self.assertEqual(result["status"], "installed")
        self.assertEqual((roots["panel"] / "index.html").read_bytes(), b"current panel")
        self.assertEqual((roots["coexist"] / "coexist-host.js").read_bytes(), b"host")
        self.assertTrue((roots["core"] / "python/python.exe").is_file())
        self.assertTrue((roots["companion"] / "manifest.json").is_file())
        self.assertFalse((roots["launcher"] / "pending-transaction.json").exists())

    def test_dry_run_creates_no_directories_or_credentials(self):
        with mock.patch.object(installer, "_dpapi_key", side_effect=AssertionError("no DPAPI")), \
             mock.patch.object(installer, "_processes", side_effect=AssertionError("no process probe")), \
             mock.patch.object(installer, "_reg_read", side_effect=AssertionError("no registry")):
            result = installer.install(self.payload, self.fixture, dry_run=True)
        self.assertEqual(result["status"], "validated")
        self.assertFalse(self.fixture.exists())

    def test_low_space_preflight_runs_before_any_install_write_or_key_generation(self):
        with mock.patch.object(installer.shutil, "disk_usage", return_value=types.SimpleNamespace(free=0)), \
             mock.patch.object(installer, "_generated", side_effect=AssertionError("must not generate config/key")), \
             mock.patch.object(installer, "_lock", side_effect=AssertionError("must not create lock")), \
             mock.patch.object(installer, "_reg_read", side_effect=AssertionError("must not read registry")), \
             mock.patch.object(installer, "_dpapi_key", side_effect=AssertionError("must not generate key")):
            with self.assertRaisesRegex(installer.InstallError, "Not enough free disk space"):
                self.install()
        self.assertFalse(self.fixture.exists())

    def test_low_space_dry_run_is_read_only(self):
        with mock.patch.object(installer.shutil, "disk_usage", return_value=types.SimpleNamespace(free=0)):
            with self.assertRaisesRegex(installer.InstallError, "no files changed"):
                installer.install(self.payload, self.fixture, dry_run=True)
        self.assertFalse(self.fixture.exists())

    def test_disk_usage_failure_stops_before_any_install_writes(self):
        with mock.patch.object(installer.shutil, "disk_usage", side_effect=OSError("fixture cannot query volume")):
            with self.assertRaisesRegex(installer.InstallError, "Cannot check free space"):
                self.install()
        self.assertFalse(self.fixture.exists())

    def test_same_volume_budget_counts_changed_bytes_backups_stage_and_reserve(self):
        roots = self.roots()
        existing = roots["core"] / "old.bin"
        existing.parent.mkdir(parents=True)
        existing.write_bytes(b"old-file!!")
        rows = [{"target": roots["panel"] / "new.bin", "entry": {"size": 100}, "before": None},
                {"target": existing, "entry": {"size": 200}, "before": "existing-hash"}]
        with mock.patch.object(installer.shutil, "disk_usage", return_value=types.SimpleNamespace(free=2 ** 40)):
            result = installer._space_preflight(rows, roots)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["required_bytes"], installer.SPACE_RESERVE + 100 + 200 + 10 + 200)

    def test_separate_volume_budget_puts_original_backups_on_launcher_volume(self):
        roots = self.roots()
        existing = roots["core"] / "old.bin"
        existing.parent.mkdir(parents=True)
        existing.write_bytes(b"old-file!!")
        rows = [{"target": roots["panel"] / "new.bin", "entry": {"size": 100}, "before": None},
                {"target": existing, "entry": {"size": 200}, "before": "existing-hash"}]
        def location(path):
            return ("roaming-volume" if path == roots["panel"] or roots["panel"] in path.parents else "local-volume", self.root)
        with mock.patch.object(installer, "_space_location", side_effect=location), \
             mock.patch.object(installer.shutil, "disk_usage", return_value=types.SimpleNamespace(free=2 ** 40)):
            result = {row["volume"]: row for row in installer._space_preflight(rows, roots)}
        self.assertEqual(result["roaming-volume"]["required_bytes"], installer.SPACE_RESERVE + 100 + 100)
        self.assertEqual(result["local-volume"]["required_bytes"], installer.SPACE_RESERVE + 200 + 10 + 200)

    def test_low_space_never_touches_existing_private_settings(self):
        self.legacy()
        before = {p.relative_to(self.fixture).as_posix(): p.read_bytes() for p in self.fixture.rglob("*") if p.is_file()}
        with mock.patch.object(installer.shutil, "disk_usage", return_value=types.SimpleNamespace(free=0)):
            with self.assertRaises(installer.InstallError):
                self.install()
        after = {p.relative_to(self.fixture).as_posix(): p.read_bytes() for p in self.fixture.rglob("*") if p.is_file()}
        self.assertEqual(before, after)

    def test_legacy_settings_and_unknown_files_preserved_byte_exact(self):
        panel = self.legacy()
        original = (panel / "local-config.json").read_bytes()
        self.install()
        self.assertEqual((panel / "local-config.json").read_bytes(), original)
        self.assertEqual((panel / "unknown.txt").read_bytes(), b"user-owned unknown")

    def test_existing_coexist_key_config_are_never_replaced(self):
        co = self.roots()["coexist"]
        co.mkdir(parents=True)
        (co / "active-v1.json").write_bytes(b'{"private":"local"}')
        (co / "application-key.dat").write_bytes(b"local-protected-key")
        self.install()
        self.assertEqual((co / "active-v1.json").read_bytes(), b'{"private":"local"}')
        self.assertEqual((co / "application-key.dat").read_bytes(), b"local-protected-key")

    def test_incomplete_base_config_preserved_with_warning(self):
        co = self.roots()["coexist"]
        co.mkdir(parents=True)
        (co / "application-key.dat").write_bytes(b"existing")
        result = self.install()
        self.assertEqual((co / "application-key.dat").read_bytes(), b"existing")
        self.assertFalse((co / "active-v1.json").exists())
        self.assertTrue(any("incomplete" in warning for warning in result["warnings"]))

    def test_new_config_uses_receiving_pc_paths_and_unique_pipe(self):
        self.install()
        roots = self.roots()
        value = json.loads((roots["coexist"] / "active-v1.json").read_text())
        self.assertEqual(value["pairStorePath"], str(roots["panel"] / "js/lark-pairing-store.js"))
        self.assertEqual(value["nodePath"], str(roots["core"] / "node.exe"))
        self.assertEqual(len(value["pipeId"]), 32)
        second = self.root / "other-pc"
        installer.install(self.payload, second)
        second_co = installer._roots(second)[0]["coexist"]
        other = json.loads((second_co / "active-v1.json").read_text())
        self.assertNotEqual(value["pipeId"], other["pipeId"])
        self.assertNotEqual(value["profile"], other["profile"])

    def test_sandbox_key_is_explicitly_not_a_usable_dpapi_credential(self):
        self.install()
        self.assertEqual((self.roots()["coexist"] / "application-key.dat").read_bytes(), b"UOY-TEST-NOT-A-DPAPI-KEY")

    def test_manifest_hash_mismatch_no_writes(self):
        (self.payload / "panel/index.html").write_bytes(b"tampered")
        with self.assertRaisesRegex(installer.InstallError, "integrity"):
            self.install()
        self.assertFalse(self.fixture.exists())

    def test_manifest_size_mismatch_no_writes(self):
        self.manifest["files"][0]["size"] += 1
        self.save_manifest()
        with self.assertRaisesRegex(installer.InstallError, "integrity"):
            self.install()
        self.assertFalse(self.fixture.exists())

    def test_unlisted_payload_file_rejected_without_reading_it(self):
        (self.payload / "private-file.txt").write_bytes(b"must not publish")
        with self.assertRaisesRegex(installer.InstallError, "Unlisted"):
            self.install()
        self.assertFalse(self.fixture.exists())

    def test_duplicate_casefold_paths_rejected(self):
        duplicate = dict(self.manifest["files"][1])
        duplicate["path"] = duplicate["path"].upper()
        self.manifest["files"].append(duplicate)
        self.save_manifest()
        with self.assertRaises(installer.InstallError):
            self.install()

    def test_private_paths_blocked(self):
        for path in ["panel/local-config.json", "coexist/application-key.dat", "panel/app_data/a",
                     "core/.huong_tool/config.json", "core/python/__pycache__/x.pyc", "panel/depth-runtime.json"]:
            with self.subTest(path=path):
                original = self.manifest["files"][1]["path"]
                self.manifest["files"][1]["path"] = path
                self.save_manifest()
                with self.assertRaisesRegex(installer.InstallError, "Private/generated"):
                    self.install()
                self.manifest["files"][1]["path"] = original

    def test_path_traversal_and_windows_reserved_paths_rejected(self):
        for path in ["panel/../outside", "/panel/index.html", "panel//index.html", "panel/C:/escape",
                     "panel/foo\\bar", "panel/CON.txt", "panel/file. ", "panel/x:stream", "panel/a?.js",
                     "panel/./index.html", "panel/LPT9/file", "panel/NUL", "panel/index.html/"]:
            with self.subTest(path=path):
                with self.assertRaises(installer.InstallError):
                    installer._relative(path)

    def test_unknown_component_rejected(self):
        self.manifest["files"][1]["path"] = "user/profile.txt"
        self.save_manifest()
        with self.assertRaisesRegex(installer.InstallError, "component"):
            self.install()

    def test_boolean_size_is_not_accepted_as_integer(self):
        self.manifest["files"][0]["size"] = True
        self.save_manifest()
        with self.assertRaisesRegex(installer.InstallError, "size"):
            self.install()

    def test_manifest_duplicate_json_fields_rejected(self):
        (self.payload / installer.MANIFEST).write_text('{"schema":1,"schema":1}')
        with self.assertRaisesRegex(installer.InstallError, "Duplicate"):
            self.install()

    def test_wrong_bundle_cannot_replace_another_extension(self):
        panel = self.legacy()
        (panel / "CSXS/manifest.xml").write_bytes(b'<ExtensionManifest ExtensionBundleId="other"/>')
        with self.assertRaisesRegex(installer.InstallError, "another extension"):
            self.install()
        self.assertEqual((panel / "index.html").read_bytes(), b"legacy panel")

    def test_existing_unknown_target_directory_is_not_overwritten(self):
        panel = self.roots()["panel"]
        panel.mkdir(parents=True)
        (panel / "personal-file").write_bytes(b"keep")
        with self.assertRaises(installer.InstallError):
            self.install()
        self.assertEqual((panel / "personal-file").read_bytes(), b"keep")

    def test_xml_entities_not_accepted(self):
        self.files["panel/CSXS/manifest.xml"] = b'<!DOCTYPE x [<!ENTITY x "abc">]><ExtensionManifest/>'
        self.write_payload()
        with self.assertRaisesRegex(installer.InstallError, "declaration"):
            self.install()

    def test_payload_and_destination_overlap_rejected(self):
        with self.assertRaisesRegex(installer.InstallError, "separate"):
            installer.install(self.payload, self.payload / "fixture", dry_run=True)

    def test_symlink_source_or_ancestor_rejected(self):
        target = self.payload / "panel/index.html"
        outside = self.root / "outside"
        outside.write_bytes(b"current panel")
        target.unlink()
        try:
            target.symlink_to(outside)
        except (OSError, NotImplementedError):
            self.skipTest("Windows symlink privilege not available")
        with self.assertRaisesRegex(installer.InstallError, "Linked"):
            self.install()

    def test_symlink_destination_rejected(self):
        outside = self.root / "unrelated"
        outside.mkdir()
        self.fixture.mkdir()
        try:
            (self.fixture / "Local").symlink_to(outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("Windows symlink privilege not available")
        with self.assertRaisesRegex(installer.InstallError, "Linked"):
            self.install()
        self.assertFalse(any(outside.iterdir()))

    def test_windows_reparse_flag_rejected_without_symlink_privilege(self):
        victim = self.root / "junction-like"
        original = Path.lstat
        def simulated(path, *args, **kwargs):
            if path == victim:
                return types.SimpleNamespace(st_mode=0o040777, st_file_attributes=0x400)
            return original(path, *args, **kwargs)
        with mock.patch.object(Path, "lstat", simulated):
            with self.assertRaisesRegex(installer.InstallError, "junction"):
                installer._plain(victim / "child/file.txt")

    def test_per_user_lock_blocks_second_install(self):
        roots = self.roots()
        with installer._lock(roots, True):
            with self.assertRaisesRegex(installer.InstallError, "already running"):
                self.install()
        self.assertFalse((roots["panel"] / "index.html").exists())

    def test_rollback_restores_legacy_owned_files_unknowns_unchanged(self):
        panel = self.legacy()
        result = self.install()
        outcome = installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual(outcome["status"], "rolled_back")
        self.assertEqual((panel / "index.html").read_bytes(), b"legacy panel")
        self.assertEqual((panel / "unknown.txt").read_bytes(), b"user-owned unknown")
        self.assertEqual((panel / "local-config.json").read_bytes(), b'{"privateSetting":"user-value"}')
        self.assertFalse((panel / "js/main.js").exists())

    def test_rollback_removes_only_exact_new_files_not_unknowns(self):
        result = self.install()
        panel = self.roots()["panel"]
        (panel / "after-user-file.txt").write_bytes(b"keep after install")
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual((panel / "after-user-file.txt").read_bytes(), b"keep after install")
        self.assertFalse((panel / "index.html").exists())

    def test_rollback_preserves_later_user_edit(self):
        result = self.install()
        panel = self.roots()["panel"]
        (panel / "index.html").write_bytes(b"later edit")
        outcome = installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual(outcome["status"], "recovery_required")
        self.assertIn("panel/index.html", outcome["retained"])
        self.assertEqual((panel / "index.html").read_bytes(), b"later edit")

    def test_rollback_rejects_other_pc_and_outside_backup(self):
        result = self.install()
        with self.assertRaisesRegex(installer.InstallError, "exact launcher backup"):
            installer.rollback(Path(result["backup"]), self.root / "different-pc")

    def test_backup_tampering_stops_before_rollback_writes(self):
        self.legacy()
        result = self.install()
        backup = Path(result["backup"])
        next((backup / "files").iterdir()).write_bytes(b"tampered")
        with self.assertRaisesRegex(installer.InstallError, "integrity"):
            installer.rollback(backup, self.fixture)
        self.assertEqual((self.roots()["panel"] / "index.html").read_bytes(), b"current panel")

    def test_failure_mid_transaction_rolls_back_previous_bytes(self):
        panel = self.legacy()
        original = installer._atomic
        failed = False
        def fail_once(file, data, expected):
            nonlocal failed
            if file == panel / "js/main.js" and not failed:
                failed = True
                raise OSError("simulated disk failure")
            return original(file, data, expected)
        with mock.patch.object(installer, "_atomic", side_effect=fail_once):
            with self.assertRaisesRegex(installer.InstallError, "Previous files restored"):
                self.install()
        self.assertEqual((panel / "index.html").read_bytes(), b"legacy panel")
        self.assertFalse((panel / "js/main.js").exists())
        self.assertFalse((self.roots()["launcher"] / "pending-transaction.json").exists())

    def test_write_ahead_journal_supports_power_loss_recovery(self):
        panel = self.legacy()
        original = installer._atomic
        interrupted = False
        def power_loss(file, data, expected):
            nonlocal interrupted
            if file == panel / "js/main.js" and not interrupted:
                interrupted = True
                raise KeyboardInterrupt("simulated power loss")
            return original(file, data, expected)
        with mock.patch.object(installer, "_atomic", side_effect=power_loss):
            with self.assertRaises(KeyboardInterrupt):
                self.install()
        backup = installer.get_recovery_backup(self.fixture)
        self.assertIsNotNone(backup)
        self.assertEqual((panel / "index.html").read_bytes(), b"current panel")
        outcome = installer.rollback(backup, self.fixture)
        self.assertEqual(outcome["status"], "rolled_back")
        self.assertEqual((panel / "index.html").read_bytes(), b"legacy panel")
        self.assertFalse((self.roots()["launcher"] / "pending-transaction.json").exists())

    def test_full_journal_not_rewritten_for_each_runtime_file(self):
        original = installer._write_journal
        with mock.patch.object(installer, "_write_journal", wraps=original) as write:
            self.install()
        self.assertEqual(write.call_count, 2)

    def test_transaction_race_keeps_external_edit_and_pending_recovery(self):
        panel = self.legacy()
        original = installer._atomic
        failed = False
        def race_once(file, data, expected):
            nonlocal failed
            if file == panel / "index.html" and not failed:
                failed = True
                file.write_bytes(b"concurrent user edit")
            return original(file, data, expected)
        with mock.patch.object(installer, "_atomic", side_effect=race_once):
            with self.assertRaisesRegex(installer.InstallError, "retained later edits"):
                self.install()
        self.assertEqual((panel / "index.html").read_bytes(), b"concurrent user edit")
        self.assertTrue((self.roots()["launcher"] / "pending-transaction.json").exists())
        with self.assertRaisesRegex(installer.InstallError, "unfinished"):
            self.install()

    def test_version_and_companion_helpers(self):
        self.assertIsNone(installer.get_installed_version(self.fixture))
        self.install()
        self.assertEqual(installer.get_installed_version(self.fixture), "2026.10.20.1")
        self.assertEqual(installer.get_companion_path(self.fixture), self.roots()["companion"])

    def test_recovery_discovery_is_read_only_and_uses_owned_backup(self):
        self.assertIsNone(installer.get_recovery_backup(self.fixture))
        self.assertFalse(self.fixture.exists())
        result = self.install()
        self.assertEqual(installer.get_recovery_backup(self.fixture), Path(result["backup"]))
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertIsNone(installer.get_recovery_backup(self.fixture))

    def test_pending_recovery_path_cannot_escape_own_backups(self):
        self.install()
        roots = self.roots()
        pending = roots["launcher"] / "pending-transaction.json"
        pending.write_text(json.dumps({"schema": 1, "identity": installer._identity(roots), "backup": "../../outside"}))
        with self.assertRaisesRegex(installer.InstallError, "not valid"):
            installer.get_recovery_backup(self.fixture)

    def test_legacy_broken_paths_are_preserved_but_reported(self):
        co = self.roots()["coexist"]
        co.mkdir(parents=True)
        old = b'{"version":1,"enabled":true,"machine":"another-pc","profile":"X:/old"}'
        (co / "active-v1.json").write_bytes(old)
        (co / "application-key.dat").write_bytes(b"do-not-touch")
        result = self.install()
        self.assertEqual((co / "active-v1.json").read_bytes(), old)
        self.assertEqual((co / "application-key.dat").read_bytes(), b"do-not-touch")
        self.assertTrue(any("old/unavailable paths" in warning for warning in result["warnings"]))

    def test_valid_same_pc_base_paths_migrate_without_repairing_or_resetting_key(self):
        old, original = self.legacy_base()
        result = self.install()
        roots = self.roots()
        co = roots["coexist"]
        new = json.loads((co / "active-v1.json").read_text())
        self.assertEqual(new["nodePath"], str(roots["core"] / "node.exe"))
        self.assertEqual(new["hostPath"], str(co / "coexist-host.js"))
        self.assertEqual(new["bridgePath"], str(roots["panel"] / "js/lark-base-bridge.js"))
        self.assertEqual(new["pairStorePath"], str(roots["panel"] / "js/lark-pairing-store.js"))
        for field in ("pipeId", "enabled", "machine", "profile", "version"):
            self.assertEqual(new[field], old[field])
        self.assertEqual((co / "application-key.dat").read_bytes(), b"existing-local-dpapi-ciphertext")
        self.assertTrue(any("stable managed installation" in warning for warning in result["warnings"]))
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual((co / "active-v1.json").read_bytes(), original)
        self.assertEqual((co / "application-key.dat").read_bytes(), b"existing-local-dpapi-ciphertext")

    def test_disabled_base_runtime_migration_preserves_disabled_policy(self):
        self.legacy_base(enabled=False)
        self.install()
        value = json.loads((self.roots()["coexist"] / "active-v1.json").read_text())
        self.assertIs(value["enabled"], False)
        self.assertEqual(value["pipeId"], "a" * 32)

    def test_foreign_base_identity_is_never_rebound(self):
        _, original = self.legacy_base(machine="NOT-THIS-MACHINE")
        self.install()
        self.assertEqual((self.roots()["coexist"] / "active-v1.json").read_bytes(), original)

    def test_unknown_base_schema_fields_are_never_rebound(self):
        _, original = self.legacy_base(custom_policy="must retain")
        self.install()
        self.assertEqual((self.roots()["coexist"] / "active-v1.json").read_bytes(), original)

    def test_update_new_release_does_not_change_generated_pairing(self):
        self.install()
        roots = self.roots()
        before_config = (roots["coexist"] / "active-v1.json").read_bytes()
        before_key = (roots["coexist"] / "application-key.dat").read_bytes()
        self.files["panel/index.html"] = b"updated release"
        self.write_payload("2026.10.21.1")
        self.install()
        self.assertEqual((roots["coexist"] / "active-v1.json").read_bytes(), before_config)
        self.assertEqual((roots["coexist"] / "application-key.dat").read_bytes(), before_key)
        self.assertEqual(installer.get_installed_version(self.fixture), "2026.10.21.1")

    def test_production_guard_explains_exact_process_and_does_not_kill(self):
        with mock.patch.object(installer, "_processes", return_value=[{"name": "Photoshop.exe", "pid": 12345}]):
            with self.assertRaisesRegex(installer.InstallError, r"Photoshop.exe \(PID 12345\).*Chrome may remain open.*No process was stopped"):
                installer._closed(False)
        with mock.patch.object(installer, "_processes", return_value=[]):
            installer._closed(False)

    def test_fixture_install_never_touches_registry_or_processes(self):
        with mock.patch.object(installer, "_reg_read", side_effect=AssertionError("no real registry")), \
             mock.patch.object(installer, "_reg_set", side_effect=AssertionError("no real registry")), \
             mock.patch.object(installer, "_processes", side_effect=AssertionError("no live processes")), \
             mock.patch.object(installer, "_windows_identity", side_effect=AssertionError("no live identity probe")), \
             mock.patch.object(installer, "_dpapi_key", side_effect=AssertionError("no real key")):
            result = self.install()
            installer.rollback(Path(result["backup"]), self.fixture)

    @unittest.skipUnless(os.name == "nt", "Windows production identity fixture")
    def test_machine_and_sid_identity_differ_even_with_identical_pc_and_user_names(self):
        roots = self.roots()
        with mock.patch.dict(os.environ, {"APPDATA": str(self.fixture / "Roaming"),
                                          "LOCALAPPDATA": str(self.fixture / "Local")}), \
             mock.patch.object(installer, "_windows_identity", side_effect=["GUID-1|SID-1", "GUID-1|SID-2", "GUID-2|SID-1"]):
            identities = [installer._identity(roots) for _ in range(3)]
        self.assertEqual(len(set(identities)), 3)

    def test_mocked_production_registry_failure_restores_only_cep_values(self):
        panel = self.legacy()
        roots, local, _ = installer._roots(self.fixture)
        registry = {n: {"exists": False} for n in range(9, 15)}
        registry[9] = {"exists": True, "kind": 1, "value": "previous-user-value"}
        before = {n: dict(value) for n, value in registry.items()}
        failed = False
        def set_value(version, state):
            nonlocal failed
            if version == 12 and not failed:
                failed = True
                raise OSError("fixture registry write failure")
            registry[version] = dict(state)
        with mock.patch.object(installer, "_roots", return_value=(roots, local, False)), \
             mock.patch.object(installer, "_lock", return_value=contextlib.nullcontext()), \
             mock.patch.object(installer, "_closed"), \
             mock.patch.object(installer, "_generated", return_value=([], [])), \
             mock.patch.object(installer, "_reg_read", side_effect=lambda n: dict(registry[n])), \
             mock.patch.object(installer, "_reg_set", side_effect=set_value):
            with self.assertRaisesRegex(installer.InstallError, "Previous files restored"):
                self.install()
        self.assertEqual(registry, before)
        self.assertEqual((panel / "index.html").read_bytes(), b"legacy panel")

    def test_depth_config_generated_for_full_payload_and_rollback_owned(self):
        self.files.update({"core/depth-engine/engine.py": b"# worker",
                           "core/depth-models/moge-2-vitl-normal.pt": b"fixture-moge",
                           "core/depth-models/depth-anything-v2-vits.pth": b"fixture-da2"})
        self.write_payload("2026.10.20.2")
        result = self.install()
        roots = self.roots()
        config = roots["panel"] / "depth-runtime.json"
        value = json.loads(config.read_text())
        self.assertEqual(value["python"], str(roots["core"] / "python/python.exe"))
        self.assertEqual(value["modelsRoot"], str(roots["core"] / "depth-models"))
        self.assertEqual(value["dataRoot"], str(self.fixture / "Local/UOY/Depth3D/data"))
        before = config.read_bytes()
        self.install()
        self.assertEqual(config.read_bytes(), before)
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertFalse(config.exists())

    def test_existing_depth_config_preserved_exactly(self):
        self.files.update({"core/depth-engine/engine.py": b"# worker",
                           "core/depth-models/moge-2-vitl-normal.pt": b"fixture-moge",
                           "core/depth-models/depth-anything-v2-vits.pth": b"fixture-da2"})
        self.write_payload("2026.10.20.2")
        panel = self.legacy()
        config = panel / "depth-runtime.json"
        old_root = self.root / "existing-depth"
        old_root.mkdir()
        for name in ("python.exe", "engine.py"):
            (old_root / name).write_bytes(b"existing-runtime")
        models, data = old_root / "models", old_root / "data"
        models.mkdir(); data.mkdir()
        pins = {}
        for name in installer.DEPTH_MODELS:
            content = ("fixture-" + name).encode()
            (models / name).write_bytes(content)
            pins[name] = (len(content), hashlib.sha256(content).hexdigest())
        before = json.dumps({"python": str(old_root / "python.exe"), "worker": str(old_root / "engine.py"),
                             "modelsRoot": str(models), "dataRoot": str(data)}, separators=(",", ":")).encode()
        config.write_bytes(before)
        with mock.patch.dict(installer.DEPTH_MODELS, pins, clear=True):
            result = self.install()
        self.assertEqual(config.read_bytes(), before)
        self.assertTrue(any("Depth configuration" in text for text in result["warnings"]))
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual(config.read_bytes(), before)

    def test_stale_known_depth_paths_migrate_transactionally_and_rollback_restores(self):
        self.files.update({"core/depth-engine/engine.py": b"# worker",
                           "core/depth-models/moge-2-vitl-normal.pt": b"fixture-moge",
                           "core/depth-models/depth-anything-v2-vits.pth": b"fixture-da2"})
        self.write_payload("2026.10.20.2")
        panel = self.legacy()
        config = panel / "depth-runtime.json"
        old = json.dumps({"python": str(self.root / "missing/python.exe"), "worker": str(self.root / "missing/engine.py"),
                          "modelsRoot": str(self.root / "missing/models"), "dataRoot": str(self.root / "missing/data")}).encode()
        config.write_bytes(old)
        result = self.install()
        self.assertEqual(json.loads(config.read_text())["worker"], str(self.roots()["core"] / "depth-engine/engine.py"))
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual(config.read_bytes(), old)

    def test_unknown_depth_schema_preserved_and_readiness_warning_explicit(self):
        self.files.update({"core/depth-engine/engine.py": b"# worker",
                           "core/depth-models/moge-2-vitl-normal.pt": b"fixture-moge",
                           "core/depth-models/depth-anything-v2-vits.pth": b"fixture-da2"})
        self.write_payload("2026.10.20.2")
        panel = self.legacy()
        config = panel / "depth-runtime.json"
        old = b'{"unknownSchema":42,"privateMachinePolicy":"keep"}'
        config.write_bytes(old)
        result = self.install()
        self.assertEqual(config.read_bytes(), old)
        self.assertTrue(any("DEPTH_CONFIGURATION_REVIEW_REQUIRED" in warning for warning in result["warnings"]))

    def test_malformed_depth_json_preserved_with_explicit_review_warning(self):
        self.files.update({"core/depth-engine/engine.py": b"# worker",
                           "core/depth-models/moge-2-vitl-normal.pt": b"fixture-moge",
                           "core/depth-models/depth-anything-v2-vits.pth": b"fixture-da2"})
        self.write_payload("2026.10.20.2")
        panel = self.legacy()
        config = panel / "depth-runtime.json"
        config.write_bytes(b"malformed local configuration")
        result = self.install()
        self.assertEqual(config.read_bytes(), b"malformed local configuration")
        self.assertTrue(any("DEPTH_CONFIGURATION_REVIEW_REQUIRED" in warning for warning in result["warnings"]))

    def test_immediate_reinstall_does_not_rewrite_identical_depth_config_before_first_launch(self):
        self.files.update({"core/depth-engine/engine.py": b"# worker",
                           "core/depth-models/moge-2-vitl-normal.pt": b"fixture-moge",
                           "core/depth-models/depth-anything-v2-vits.pth": b"fixture-da2"})
        self.write_payload("2026.10.20.2")
        self.install()
        config = self.roots()["panel"] / "depth-runtime.json"
        original = installer._atomic
        seen = []
        def record(target, data, expected):
            seen.append(target)
            return original(target, data, expected)
        with mock.patch.object(installer, "_atomic", side_effect=record):
            self.assertEqual(self.install()["changed"], 0)
        self.assertNotIn(config, seen)

    def test_local_crt_alias_transactional_and_not_a_public_payload_file(self):
        self.files["core/python/Lib/site-packages/numpy/_core/_multiarray_umath.cp312-win_amd64.pyd"] = b"fixture-numpy"
        self.write_payload("2026.10.20.2")
        source = self.root / "trusted-system-msvcp140.dll"
        source.write_bytes(b"fixture-not-a-real-DLL")
        with mock.patch.object(installer, "_official_crt", return_value=source):
            result = self.install()
        target = self.roots()["core"] / "python/Lib/site-packages/numpy.libs/msvcp140-263139962577ecda4cd9469ca360a746.dll"
        self.assertEqual(target.read_bytes(), source.read_bytes())
        self.assertFalse(any("msvcp140-" in row["path"] for row in self.manifest["files"]))
        installer.rollback(Path(result["backup"]), self.fixture)
        self.assertFalse(target.exists())

    def test_missing_trusted_crt_stops_before_panel_writes_or_credentials(self):
        self.files["core/python/Lib/site-packages/numpy/_core/_multiarray_umath.cp312-win_amd64.pyd"] = b"fixture-numpy"
        self.write_payload("2026.10.20.2")
        with mock.patch.object(installer, "_official_crt", side_effect=installer.InstallError("Missing official CRT")), \
                mock.patch.object(installer, "_dpapi_key", side_effect=AssertionError("no credentials")):
            with self.assertRaisesRegex(installer.InstallError, "official CRT"):
                self.install()
        self.assertFalse(self.fixture.exists())

    def test_payload_backup_and_restore_are_streamed_not_read_bytes(self):
        name = "core/depth-engine/large-test.bin"
        self.files[name] = b"x" * (2 * 1024 * 1024)
        self.write_payload()
        old_target = self.roots()["core"] / "depth-engine/large-test.bin"
        old_target.parent.mkdir(parents=True)
        old_target.write_bytes(b"y" * (2 * 1024 * 1024))
        original = Path.read_bytes
        def guarded(path):
            if path.name == "large-test.bin" or path.suffix == ".bin":
                raise AssertionError("large payload or backup read wholly into RAM")
            return original(path)
        with mock.patch.object(Path, "read_bytes", guarded):
            result = self.install()
            self.assertEqual(installer._hash(old_target), hashlib.sha256(self.files[name]).hexdigest())
            installer.rollback(Path(result["backup"]), self.fixture)
        self.assertEqual(installer._hash(old_target), hashlib.sha256(b"y" * (2 * 1024 * 1024)).hexdigest())

    def test_atomic_pinned_stream_rejects_source_mutation(self):
        source, target = self.root / "source.bin", self.root / "target.bin"
        source.write_bytes(b"first approved bytes")
        data = installer._FileSource(source, installer._hash(source))
        source.write_bytes(b"later foreign bytes")
        with self.assertRaisesRegex(installer.InstallError, "integrity changed"):
            installer._atomic(target, data, None)
        self.assertFalse(target.exists())

    def test_expanded_depth_limits_cover_exact_moge_and_torch_not_unbounded(self):
        self.assertGreaterEqual(installer.MAX_FILE, 1323815904)
        self.assertGreaterEqual(installer.MAX_PAYLOAD, 3200000000)
        self.assertLessEqual(installer.MAX_FILE, 2 * 1024 ** 3)
        self.assertLessEqual(installer.MAX_PAYLOAD, 6 * 1024 ** 3)

    def test_dry_run_existing_tree_unchanged(self):
        self.legacy()
        before = {p.relative_to(self.fixture).as_posix(): p.read_bytes() for p in self.fixture.rglob("*") if p.is_file()}
        installer.install(self.payload, self.fixture, dry_run=True)
        after = {p.relative_to(self.fixture).as_posix(): p.read_bytes() for p in self.fixture.rglob("*") if p.is_file()}
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
