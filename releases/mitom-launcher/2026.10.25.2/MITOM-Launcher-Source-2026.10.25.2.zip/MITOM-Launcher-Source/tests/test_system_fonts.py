from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mitom_ui


class SystemFonts(unittest.TestCase):
    def test_system_font_names_without_registration_or_distributed_files(self):
        view = SimpleNamespace()
        mitom_ui.MITOMLauncherUI._make_fonts(view)
        self.assertEqual(mitom_ui.CAPTION_FONT_FAMILY, "Segoe UI")
        self.assertTrue(all(row[0] in ("Segoe UI", "Segoe UI Symbol") for row in view.fonts.values()))
        self.assertFalse(hasattr(mitom_ui, "_register_private_fonts"))

    def test_source_asset_closure_has_no_font_binaries(self):
        root = Path(__file__).resolve().parents[1]
        extensions = {".ttf", ".otf", ".ttc", ".woff", ".woff2"}
        self.assertEqual([str(path.relative_to(root)) for path in root.rglob("*")
                          if path.is_file() and path.suffix.lower() in extensions], [])


if __name__ == "__main__":
    unittest.main()
