"""Owned synthetic-PC pending recovery tests. No live install/app operations."""
from __future__ import annotations
import hashlib
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import stat
import tempfile
import time
import types
import unittest
from unittest import mock

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'installer.py'
PIN='407a3a003e8299e5d006da59682ca7ed427c0762dda6bab62a9e840ed2df58bf'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==PIN
spec=importlib.util.spec_from_file_location('retained_recovery_fixture_base',HERE/'test_installer.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
installer=base.installer
CANDIDATE=True

def forbidden(*_args,**_kwargs):raise AssertionError('No live OS/credential/registry/application operation allowed')
def write(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
def state(root):return {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in root.rglob('*') if path.is_file()} if root.exists() else {}

class PendingRecovery(base.InstallerTests):
    def setUp(self):
        super().setUp()
        for name in ['_processes','_windows_identity','_dpapi_key','_reg_read','_reg_set','_official_crt']:
            patch=mock.patch.object(installer,name,side_effect=forbidden);patch.start();self.addCleanup(patch.stop)

    def seed_data(self):
        roots,local,_=installer._roots(self.fixture)
        _,active=self.legacy_base()
        protected={roots['coexist']/'application-key.dat':b'FAKE OWNED DPAPI BYTES',
                   roots['coexist']/'active-v1.json':active,
                   roots['coexist']/'custom-pairing-data.json':b'{"fixture":"PAIRING KEEP"}',
                   local/'UOY/DepthGPU/recipient-custom.txt':b'GPU ENV KEEP',
                   self.fixture/'Home/.huong_tool/save_task_incremental_r9/task/state.json':b'{"fixture":"UPLOAD KEEP"}'}
        for path,data in protected.items():write(path,data)
        return protected

    def assert_data(self,protected,after_install=False):
        for path,data in protected.items():
            if after_install and path.name=='active-v1.json':
                actual=json.loads(path.read_bytes());previous=json.loads(data)
                for key in ['version','enabled','machine','profile','pipeId']:self.assertEqual(actual[key],previous[key])
            else:self.assertEqual(path.read_bytes(),data)

    def crash(self):
        original=installer._atomic;fired=False;target=self.roots()['panel']/'js/main.js'
        def interrupted(file,data,expected):
            nonlocal fired
            if file==target and not fired:
                fired=True
                raise KeyboardInterrupt('SYNTHETIC POWER LOSS; not an ordinary handled Exception')
            return original(file,data,expected)
        with mock.patch.object(installer,'_atomic',side_effect=interrupted):
            with self.assertRaises(KeyboardInterrupt):self.install()
        self.assertTrue(fired)
        pending=self.roots()['launcher']/'pending-transaction.json'
        self.assertTrue(pending.is_file())
        backup=installer.get_recovery_backup(self.fixture)
        self.assertEqual(json.loads((backup/'transaction.json').read_bytes())['status'],'preparing')
        before=state(self.fixture)
        with self.assertRaisesRegex(installer.InstallError,'unfinished UOY update'):self.install()
        self.assertEqual(state(self.fixture),before)
        return backup

    def test_fresh_interrupted_before_first_receipt_can_restore_then_retry(self):
        protected=self.seed_data()
        self.assertIsNone(installer.get_installed_version(self.fixture))
        backup=self.crash()
        self.assertIsNone(installer.get_installed_version(self.fixture))
        self.assertEqual(installer.rollback(backup,self.fixture)['status'],'rolled_back')
        self.assertFalse((self.roots()['launcher']/'pending-transaction.json').exists())
        self.assertIsNone(installer.get_installed_version(self.fixture))
        self.assert_data(protected)
        self.assertEqual(self.install()['status'],'installed')
        self.assert_data(protected,after_install=True)

    def test_existing_receipt_interrupted_update_can_restore_then_retry(self):
        self.write_payload('2026.10.23.2');self.install()
        protected=self.seed_data();roots=self.roots()
        protected[roots['panel']/'local-config.json']=b'{"privateSetting":"KEEP"}'
        protected[roots['panel']/'recipient-unknown.psd']=b'FAKE USER ARTWORK; KEEP'
        for path,data in protected.items():write(path,data)
        old_index=(roots['panel']/'index.html').read_bytes()
        self.files['panel/index.html']=b'NEW25 INDEX';self.files['panel/js/main.js']=b'NEW25 JAVASCRIPT';self.write_payload('2026.10.25.1')
        backup=self.crash()
        self.assertEqual(installer.get_installed_version(self.fixture),'2026.10.23.2')
        self.assertEqual(installer.rollback(backup,self.fixture)['status'],'rolled_back')
        self.assertFalse((roots['launcher']/'pending-transaction.json').exists())
        self.assertEqual(installer.get_installed_version(self.fixture),'2026.10.23.2')
        self.assertEqual((roots['panel']/'index.html').read_bytes(),old_index)
        self.assert_data(protected)
        self.install();self.assertEqual(installer.get_installed_version(self.fixture),'2026.10.25.1')
        self.assert_data(protected,after_install=True)

    def test_committed_journal_with_unremoved_pending_restores_safely_then_retry(self):
        result=self.install();roots=self.roots();backup=Path(result['backup'])
        pending=roots['launcher']/'pending-transaction.json'
        write(pending,json.dumps({'schema':1,'identity':installer._identity(roots),'backup':backup.relative_to(roots['launcher']).as_posix()}).encode())
        self.assertEqual(installer.get_recovery_backup(self.fixture),backup)
        self.assertEqual(installer.rollback(backup,self.fixture)['status'],'rolled_back')
        self.assertFalse(pending.exists());self.assertEqual(self.install()['status'],'installed')

    def test_malformed_or_foreign_pending_never_discarded_by_discovery(self):
        self.install();pending=self.roots()['launcher']/'pending-transaction.json'
        for data in [b'{"bad":"PRESERVE"}',json.dumps({'schema':1,'identity':'FOREIGN','backup':'../../outside'}).encode()]:
            write(pending,data);before=state(self.fixture)
            with self.assertRaises(installer.InstallError):installer.get_recovery_backup(self.fixture)
            self.assertEqual(state(self.fixture),before)

    def test_already_rolled_back_journal_with_stale_pending_is_not_silently_deleted(self):
        result=self.install();backup=Path(result['backup']);roots=self.roots()
        installer.rollback(backup,self.fixture)
        pending=roots['launcher']/'pending-transaction.json'
        write(pending,json.dumps({'schema':1,'identity':installer._identity(roots),'backup':backup.relative_to(roots['launcher']).as_posix()}).encode())
        self.assertEqual(installer.get_recovery_backup(self.fixture),backup)
        before=state(self.fixture)
        with self.assertRaisesRegex(installer.InstallError,'does not own'):installer.rollback(backup,self.fixture)
        self.assertEqual(state(self.fixture),before)

    def test_directory_only_nested_skeleton_installs_without_deleting_directories(self):
        roots=self.roots();skeleton=roots['panel']/'CSXS/empty/subdirectory';skeleton.mkdir(parents=True)
        self.assertEqual(self.install()['status'],'installed')
        self.assertTrue(skeleton.is_dir())

    def test_unknown_nested_zero_byte_file_prevents_adoption_without_writes(self):
        root=self.roots()['panel'];write(root/'nested/keep.psd',b'');(root/'CSXS').mkdir()
        before=state(self.fixture)
        with self.assertRaisesRegex(installer.InstallError,'identifiable'):self.install()
        self.assertEqual(state(self.fixture),before)

    def test_foreign_manifest_prevents_adoption_without_writes(self):
        root=self.roots()['panel'];write(root/'CSXS/manifest.xml',b'<ExtensionManifest ExtensionBundleId="some.other.extension"/>')
        before=state(self.fixture)
        with self.assertRaisesRegex(installer.InstallError,'another extension'):self.install()
        self.assertEqual(state(self.fixture),before)

    @unittest.skipUnless(CANDIDATE,'Candidate-only under-lock race proof')
    def test_skeleton_revalidated_under_installer_lock_if_unknown_file_arrives(self):
        root=self.roots()['panel'];(root/'CSXS').mkdir(parents=True)
        original=installer._lock
        @contextlib.contextmanager
        def concurrent_writer(roots,sandbox):
            with original(roots,sandbox):
                write(root/'new-user-file.psd',b'KEEP CONCURRENT USER FILE')
                yield
        with mock.patch.object(installer,'_lock',side_effect=concurrent_writer):
            with self.assertRaisesRegex(installer.InstallError,'identifiable'):self.install()
        self.assertEqual((root/'new-user-file.psd').read_bytes(),b'KEEP CONCURRENT USER FILE')
        self.assertFalse((root/'index.html').exists())
        self.assertFalse((self.roots()['launcher']/'pending-transaction.json').exists())

    @unittest.skipUnless(CANDIDATE,'Candidate-only descendant reparse proof')
    def test_mocked_windows_reparse_descendant_is_not_traversed(self):
        root=self.roots()['panel'];junction=root/'nested/junction';junction.mkdir(parents=True)
        original=Path.lstat
        def reparse(path,*args,**kwargs):
            if path==junction:return types.SimpleNamespace(st_mode=stat.S_IFDIR,st_file_attributes=0x400)
            return original(path,*args,**kwargs)
        before=state(self.fixture)
        with mock.patch.object(Path,'lstat',reparse):
            with self.assertRaisesRegex(installer.InstallError,'junctions'):self.install()
        self.assertEqual(state(self.fixture),before)

def load_tests(loader,tests,pattern):
    # Include only these ten focused cases; test_installer.py separately owns
    # the retained64. Avoid rediscovering inherited tests a second time.
    names=[name for name in PendingRecovery.__dict__ if name.startswith('test_')]
    return unittest.TestSuite(PendingRecovery(name) for name in names)

if __name__=='__main__':unittest.main()

