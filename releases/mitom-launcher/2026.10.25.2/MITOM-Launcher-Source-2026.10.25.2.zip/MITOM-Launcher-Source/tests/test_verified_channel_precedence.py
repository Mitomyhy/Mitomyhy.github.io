"""Only selection of already-authenticated data; no key or verifier changes."""
import inspect, sys, types, unittest
from pathlib import Path
from unittest import mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import main

def release(version):
    return {'launcher':{'version':version,'url':'https://mitomyhy.github.io/releases/mitom-launcher/'+version+'/setup.exe','size':65536,'sha256':'a'*64}}

class VerifiedPrecedenceTests(unittest.TestCase):
    def test_newer_original_signed_feed_beats_older_independent(self):
        panel,independent=release('2026.10.25.3'),release('2026.10.25.1')
        self.assertIs(main.preferred_verified_launcher_release(panel,independent),panel)
    def test_newer_independent_beats_older_original(self):
        panel,independent=release('2026.10.25.1'),release('2026.10.25.3')
        self.assertIs(main.preferred_verified_launcher_release(panel,independent),independent)
    def test_same_version_retains_independent_projection(self):
        panel,independent=release('2026.10.25.3'),release('2026.10.25.3')
        self.assertIs(main.preferred_verified_launcher_release(panel,independent),independent)
    def test_one_unavailable_or_malformed_candidate_does_not_mask_other_verified_release(self):
        panel=release('2026.10.25.3')
        for bad in [None,{},release('not-a-version'),{'launcher':{'version':'2026.10.25.4'}},release('2026.10.25.4')|{'launcher':[]}]:
            self.assertIs(main.preferred_verified_launcher_release(panel,bad),panel)
            self.assertIs(main.preferred_verified_launcher_release(bad,panel),panel)
    def test_no_candidate_means_no_update(self):
        self.assertEqual(main.preferred_verified_launcher_release(None,None),{})
    def test_cached_independent_cannot_hide_new_original_after_channel_failure(self):
        panel,independent=release('2026.10.25.3'),release('2026.10.25.1')
        app=object.__new__(main.MITOMAdapter);app.latest=panel;app._launcher_release=independent
        app._append=mock.Mock();app._refresh_state=mock.Mock(return_value={});app.status_var=types.SimpleNamespace(set=mock.Mock())
        with mock.patch.object(main.self_update,'select_update',wraps=main.self_update.select_update) as select:
            app._apply_catalogue_updates({'panel':None,'launcher':None,'errors':['independent unavailable']})
        select.assert_called_once_with(main.backend,panel)
        self.assertIs(app._launcher_release,independent)
        self.assertIs(app.latest,panel)
        self.assertIn('2026.10.25.3',app.status_var.set.call_args.args[0])
    def test_all_three_ui_action_sites_use_same_precedence(self):
        for method in ['_refresh_state','_apply_catalogue_updates','_download_update']:
            source=inspect.getsource(getattr(main.MITOMAdapter,method))
            self.assertIn('preferred_verified_launcher_release(',source)
            self.assertNotIn('self._launcher_release or',source)

if __name__=='__main__':unittest.main(verbosity=2)
