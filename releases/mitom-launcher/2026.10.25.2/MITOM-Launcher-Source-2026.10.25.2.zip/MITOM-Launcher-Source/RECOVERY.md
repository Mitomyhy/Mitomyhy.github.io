# Launcher 2026.10.25.2 source closure

This archive contains the latest owned website launcher source at Git revision
`b200b649061ee527ffa05d92d6475fc85952f291`, the reviewed installer recovery fix,
the reviewed two-verified-channel version selection, and the runtime inputs
missing from the website's partial source publication.

The original transactional loader/backend was not available entirely as readable
Python. `legacy/*.marshal` and `recovered/*.marshal` retain the exact owner-published
CPython 3.12 code, checked against `recovery-manifest.json` and
`frozen-manifest.json`. These are required build/runtime inputs, not newly
generated signing keys. `installer.py` is the reviewed readable installer and
replaces its earlier thin recovered wrapper. It accepts only a genuinely empty
leftover destination; pending journal, foreign-directory, hash, identity and
rollback guards remain enforced.

`SOURCE-MANIFEST.json` lists the final source archive files and hashes.
`BUILD-PROVENANCE.json` records original input provenance and reviewed overlays.
No private signing keys, pairing state, Chrome profiles, customer files or user
runtime configuration are included. The two public verification keys retain
their original independent trust boundaries.

All five original proprietary font binaries are intentionally excluded. The
resource manifest omits their entries, while original input hashes remain only
as provenance. The UI uses Windows Segoe UI/Segoe UI Symbol by name; no system
font file is copied or redistributed. The build refuses bundled font binaries.

The tested Python runtime's `ssl.py` requires `codex-rejected-cas.pem` when
creating an SSL context. This unchanged public distrust certificate data is
bundled at the runtime root. Certificate and hostname checks are not disabled.
Stock Python builds do not need that file, but can include it harmlessly.

Build on Windows using Python 3.12, install `requirements-build.txt`, and run
`build.ps1 -Python C:/path/to/python.exe`. The build runs all regression tests,
then packaged runtime, hidden UI and verified-HTTPS smoke checks. Smoke checks
do not install the panel or download an installer artifact. No private signing
key is required to build an unsigned executable; Windows may show SmartScreen.

The 2026.10.25.2 release is a one-time manual download for affected 25.1 users.
Its launcher chooser selects the highest version from two already verified
channels, including cached verified metadata, without changing either verifier.
It does not require or perform a signing-key migration.
