"""Integrity-check the owner's fixed CPython modules at normal app runtime."""
from __future__ import annotations

import hashlib
import json
import marshal
from pathlib import Path
import sys
import types

ALLOWED_MODULES = frozenset(("main", "backend", "installer", "mitom_ui", "legacy_loader"))


def populate(name: str, namespace: dict) -> None:
    if name not in ALLOWED_MODULES or sys.version_info[:2] != (3, 12):
        raise RuntimeError("Unexpected recovered launcher module/runtime.")
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    manifest = json.loads((root / "frozen-manifest.json").read_text(encoding="utf-8"))
    filename = f"recovered/{name}.marshal"
    expected = manifest["files"][filename]
    raw = root.joinpath(*filename.split("/")).read_bytes()
    if len(raw) != expected["size"] or hashlib.sha256(raw).hexdigest() != expected["sha256"]:
        raise RuntimeError("Recovered launcher module integrity check failed: " + name)
    code = marshal.loads(raw)
    if not isinstance(code, types.CodeType):
        raise RuntimeError("Invalid recovered launcher code object.")
    exec(code, namespace)
