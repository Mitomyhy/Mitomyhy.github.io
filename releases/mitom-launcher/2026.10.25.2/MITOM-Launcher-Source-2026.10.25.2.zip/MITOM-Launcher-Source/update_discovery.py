"""Nonblocking, metadata-only signed update discovery.

The worker never calls Tk, installer APIs, executable downloads, or process
controls. Only the Tk poller applies a successfully verified release while idle.
"""
from __future__ import annotations

import json
import queue
import threading
import time
import urllib.request

STARTUP_DELAY_MS = 1500
CHECK_INTERVAL_MS = 5 * 60 * 1000
BUSY_RETRY_MS = 15 * 1000
RESULT_POLL_MS = 100
PROBE_TIMEOUT_SECONDS = 12


def probe_signed_release(backend, cancelled=None):
    """Original pin/signature/redirect checks, with a separate 12s probe.

    Manual checker/timeout stay unchanged. The socket timeout bounds network
    inactivity; a monotonic deadline rejects slow responses between reads.
    """
    cancelled = cancelled or threading.Event()
    if cancelled.is_set():
        raise RuntimeError("Update discovery cancelled.")
    key = backend.load_public_key()
    url = backend.validate_https_url(backend.release_feed_url())
    request = urllib.request.Request(url, headers={
        "User-Agent": f"UOY-Apps/{backend.APP_VERSION}", "Accept": "application/json",
    })
    deadline = time.monotonic() + PROBE_TIMEOUT_SECONDS
    opener = urllib.request.build_opener(backend.HttpsRedirectHandler())
    chunks, size = [], 0
    with opener.open(request, timeout=PROBE_TIMEOUT_SECONDS) as response:
        backend.validate_https_url(response.geturl())
        read_chunk = getattr(response, "read1", response.read)
        while True:
            if cancelled.is_set() or time.monotonic() > deadline:
                raise TimeoutError("Update discovery timed out or was cancelled.")
            chunk = read_chunk(min(65536, backend.FEED_LIMIT + 1 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            if size > backend.FEED_LIMIT:
                raise backend.LauncherError("Update metadata exceeds the feed size limit.")
    if cancelled.is_set() or time.monotonic() > deadline:
        raise TimeoutError("Update discovery timed out or was cancelled.")
    envelope = json.loads(b"".join(chunks).decode("utf-8-sig"))
    if not isinstance(envelope, dict):
        raise backend.LauncherError("Invalid update metadata envelope.")
    return backend.verify_release_envelope(envelope, key)


def start_daemon(work):
    thread = threading.Thread(target=work, name="MITOM-update-metadata", daemon=True)
    thread.start()
    return thread


def apply_verified_release(app, release, original_check, backend):
    """Dispatch original successful-check callback synchronously on Tk only.

    Intercept only `_run(message, fetch_release, checked)` and call `checked`
    with verified metadata. Never invoke its worker, busy state or error dialog.
    """
    if threading.get_ident() != app._r4_ui_thread:
        raise RuntimeError("Update UI results must be applied on the Tk thread.")
    if app.busy:
        raise RuntimeError("Cannot apply update metadata during a transaction.")
    had_override = "_run" in app.__dict__
    previous = app.__dict__.get("_run")

    def dispatch(_message, work, callback=None):
        if work is not backend.fetch_release or not callable(callback):
            raise RuntimeError("Unexpected original update callback contract.")
        callback(release)

    app._run = dispatch
    try:
        original_check(app)
    finally:
        if had_override:
            app._run = previous
        else:
            del app._run


class UpdateDiscovery:
    """One daemon probe in flight; failures are activity-log-only, never modal."""

    def __init__(self, root, is_busy, probe, apply, log=lambda _message: None,
                 worker_start=start_daemon):
        self.root, self.is_busy = root, is_busy
        self.probe, self.apply, self.log = probe, apply, log
        self.worker_start = worker_start
        self._results = queue.Queue(maxsize=1)
        self._cancelled = threading.Event()
        self._timer = None
        self._poll_timer = None
        self._closed = False
        self._started = False
        self._inflight = False
        self._pending = None
        self._revision = 0

    def start(self):
        if not self._closed and not self._started:
            self._started = True
            self._schedule(STARTUP_DELAY_MS)

    def _schedule(self, delay):
        if not self._closed and self._timer is None:
            self._timer = self.root.after(delay, self._begin)

    def _poll_later(self):
        if not self._closed and self._poll_timer is None:
            self._poll_timer = self.root.after(RESULT_POLL_MS, self._poll)

    def _begin(self):
        self._timer = None
        if self._closed or self._inflight or self._pending is not None:
            return
        if self.is_busy():
            self._schedule(BUSY_RETRY_MS)
            return
        self._inflight = True
        revision = self._revision

        def work():
            try:
                result = (revision, True, self.probe(self._cancelled))
            except Exception as error:
                result = (revision, False, str(error)[:320])
            if not self._cancelled.is_set():
                try:
                    self._results.put_nowait(result)
                except queue.Full:
                    pass

        try:
            self.worker_start(work)
        except Exception as error:
            self._inflight = False
            self.log("Automatic update discovery could not start: " + str(error)[:320])
            self._schedule(CHECK_INTERVAL_MS)
            return
        self._poll_later()

    def _poll(self):
        self._poll_timer = None
        if self._closed:
            return
        if self._pending is None:
            try:
                revision, ok, value = self._results.get_nowait()
            except queue.Empty:
                if self._inflight:
                    self._poll_later()
                return
            self._inflight = False
            if revision != self._revision:
                self._schedule(CHECK_INTERVAL_MS)
                return
            if not ok:
                self.log("Automatic update discovery unavailable: " + value)
                self._schedule(CHECK_INTERVAL_MS)
                return
            self._pending = (revision, value)
        if self.is_busy():
            self._poll_later()
            return
        revision, release = self._pending
        self._pending = None
        if revision == self._revision:
            try:
                self.apply(release)
            except Exception as error:
                self.log("Automatic update metadata was not applied: " + str(error)[:320])
        self._schedule(CHECK_INTERVAL_MS)

    def supersede(self):
        """An explicit check wins over any older probe or deferred result."""
        self._revision += 1
        self._pending = None
        if not self._inflight:
            self._schedule(CHECK_INTERVAL_MS)

    def close(self):
        self._closed = True
        self._revision += 1
        self._pending = None
        self._cancelled.set()
        for name in ("_timer", "_poll_timer"):
            token = getattr(self, name)
            setattr(self, name, None)
            if token is not None:
                try:
                    self.root.after_cancel(token)
                except Exception:
                    pass
