"""Load original entry module as a library, never as its __main__ entrypoint."""
from frozen_payload import populate as _recover
_recover("main", globals())
