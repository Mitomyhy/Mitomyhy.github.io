Vector Migic 1.0.4
An independent local raster-to-vector application by MITOM.
This application is not affiliated with Vector Magic.

The bundled runtime uses Python, the separate Potrace CLI, VTracer, Pillow, svglib, ReportLab, lxml,
cssselect2, tinycss2, charset-normalizer and webencodings.
See packages.json and each package folder for upstream license notices.
Potrace's GPL license, authors and complete unmodified source archive
are included in potrace/ and vendor/potrace/source/. Its official binary
is unmodified; source URLs and hashes are included.
The unmodified svglib source distribution and its checksum are included.
VectorMigic-source-1.0.4.zip and SOURCE-REBUILD.txt allow rebuilding this app
with a modified or replacement svglib library.
PyInstaller bootloader redistribution uses the GPL exception documented at
https://pyinstaller.org/en/stable/license.html
